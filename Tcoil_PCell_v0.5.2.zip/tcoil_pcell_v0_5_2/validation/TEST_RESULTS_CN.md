# T-coil v0.5.2 测试结果

所有最终报告对应同一份内核源码；成功生成与“所有参数都能生成”是不同结论。压力矩阵保留未生成的组合，未将失败或超时记为通过。新隔离用例的单例时间上限为 120 秒（含启动）；先前已完成的结果保留原运行时间，超时不表示物理上无解。

## 环境与结论

- Virtuoso IC617，从 `/home/meow/tsmc18/` 启动。
- 技术库 `/home/meow/tsmc18/tsmc18`；技术文本 `/home/meow/tsmc18/tech.tf`。
- 使用 `METAL5`、`METAL6`、`M6_M5`，制造网格 0.005 µm。
- 测试库与 `cds.lib` 独立，不修改用户的 PDK 或启动配置。
- 原有四类边界 × 四种默认拓扑全部通过原生生成与 OA 审计（16/16）。

| 检查 | 通过 | 总数 |
|---|---:|---:|
| 内核、参数接口及多边形宿主检查 | 191 | 191 |
| 宿主完整几何生成及独立连通性审计 | 20 | 20 |
| 宿主参数作用检查 | 16 | 16 |
| 真实 PDK 参数生成请求 | 203 | 240 |
| 新增多边形 × 拓扑 | 28 | 32 |
| 20 顶点及高编号边 profile | 5 | 5 |
| 实际 VIA56 阵列坐标与数量 | 3 | 3 |
| 原生无效参数按预期拒绝 | 13 | 13 |
| 公共安装 API / CDF / 项目模板 | 12 | 12 |

## 生成检查覆盖

参数矩阵包含 4 种原有边界、4 种拓扑、4 种绕向组合，以及独立线宽、间距、内缩、偏移、局部 profile、2/1 与 1/2 轮廓、交错分组、1×2 / 2×1 过孔阵列和分叶间隔。无效输入包括零/负尺寸、超限匝数、非制造网格值、无效拓扑/绕向/层/过孔与越界 profile。

这是有限的代表性参数扫描，不是全部参数的笛卡尔积，也不构成全参数域成功率估计。

新增边界为 L 形、12 顶点十字、12 顶点阶梯、三角形、梯形、切角八边形、菱形和带斜边的凹形；另外验证 20 顶点轮廓及第 18 条边的 0.8 µm 局部线宽，检查实际 OA 矩形而不只检查参数回传。

成功案例均检查实际 OA 金属矩形的三 PIN 端点、单一连通分量、零意外导电环路、0.005 µm 网格和原生多边形差运算的零越界面积。连通性审计以实际金属和生成器的过孔位置建立跨层连接；另对 1×1、1×2、2×1 阵列的实际 VIA56 cut 矩形逐一核对数量、尺寸和坐标。

## 多边形扩展与限制

边界输入已解除 4/8 顶点及直角限制，使用一般线段相交、边界点判定与矩形包含检查。直角边界通常保留原轮廓；斜边边界使用保守内接矩形绕组，导体仍为曼哈顿几何，没有沿斜边贴合的导体。分叶会选择边界内两个不重叠矩形；部分堆叠案例在 profile 为空时回退到内接矩形，并记录 `tcoilContourMode`。

不支持带孔多边形、零长度边、自交/自接触、重复闭合点及冗余共线点。内接矩形候选网格不是全局最优求解；过密绕组、过大阵列或有限布线搜索失败不等于物理上不存在其他解。

未运行 foundry DRC/LVS、S 参数或 EM 验证。PDK 初始化日志中的 HSPICE 工具注册错误发生在布局测试之前；布局许可已成功获取，原生 PCell 和几何审计结果单独记录。

## 未生成或审计失败的用例

| 用例 | 原因 |
|---|---|
| `original_contour_offset` | TCOIL: winding W2_ring0 segment 6 violates boundary/minClearance.\\\ |
| `original_contour_turns21` | TCOIL: boundary self intersection.\\\ |
| `original_contour_turns12` | TCOIL: boundary self intersection.\\\ |
| `original_contour_block2` | TCOIL: boundary self intersection.\\\ |
| `original_contour_via21` | TCOIL: winding W2_ring0 segment 6 violates boundary/minClearance.\\\ |
| `original_interleaved_offset` | TCOIL: winding W2_ring0 segment 6 violates boundary/minClearance.\\\ |
| `original_interleaved_turns21` | TCOIL: boundary self intersection.\\\ |
| `original_interleaved_turns12` | TCOIL: boundary self intersection.\\\ |
| `original_interleaved_block2` | TCOIL: boundary self intersection.\\\ |
| `original_interleaved_via21` | TCOIL: winding W2_ring0 segment 6 violates boundary/minClearance.\\\ |
| `original_stacked_cw_cw` | [执行超时] Isolated native case did not complete within 120 seconds including startup. |
| `original_stacked_ccw_cw` | [执行超时] Isolated native case did not complete within 120 seconds including startup. |
| `original_stacked_offset` | *WARNING* (DB-270002): ("error" 189 t nil ("*Error* TCOIL_SEARCH_EXHAUSTED: no validated layout in 189 adaptive opening attempts; not a proof of infeasibility. Last=(\"opening\" (7 7) 0.5 0.5 t \"inscribed_rectangle\" \"(\\\"error\\\" 188 t nil (\\\"*Error* TCOIL_GEOMETRY: candidate opening edge 3 is too short (3.02 required, 1.48 available).\\\\n\ |
| `original_stacked_turns21` | [执行超时] Isolated native case did not complete within 120 seconds including startup. |
| `original_stacked_turns12` | *WARNING* (DB-270002): ("error" 189 t nil ("*Error* TCOIL_SEARCH_EXHAUSTED: no validated layout in 189 adaptive opening attempts; not a proof of infeasibility. Last=(\"opening\" (7 7) 0.5 0.5 t \"inscribed_rectangle\" \"(\\\"error\\\" 188 t nil (\\\"*Error* TCOIL_GEOMETRY: candidate opening edge 3 is too short (3.02 required, 2.48 available).\\\\n\ |
| `original_stacked_block2` | [执行超时] Isolated native case did not complete within 120 seconds including startup. |
| `original_stacked_via21` | *WARNING* (DB-270002): ("error" 189 t nil ("*Error* TCOIL_SEARCH_EXHAUSTED: no validated layout in 189 adaptive opening attempts; not a proof of infeasibility. Last=(\"opening\" (7 7) 0.5 0.5 t \"inscribed_rectangle\" \"(\\\"error\\\" 188 t nil (\\\"*Error* TCOIL_GEOMETRY: candidate opening edge 3 is too short (4.44 required, 1.06 available).\\\\n\ |
| `rectangle_stacked_cw_cw` | *WARNING* (DB-270002): ("error" 24 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 24 attempts; physical feasibility unresolved. Last=(\"routing\" (3 1) 0.25 0.75 t \"boundary_following\" \"(\\\"error\\\" 23 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\ |
| `rectangle_stacked_ccw_cw` | *WARNING* (DB-270002): ("error" 24 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 24 attempts; physical feasibility unresolved. Last=(\"routing\" (3 1) 0.25 0.75 t \"boundary_following\" \"(\\\"error\\\" 23 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\ |
| `rectangle_stacked_ccw_ccw` | *WARNING* (DB-270002): ("error" 23 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 23 attempts; physical feasibility unresolved. Last=(\"routing\" (2 0) 0.25 0.75 t \"boundary_following\" \"(\\\"error\\\" 22 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\ |
| `rectangle_stacked_turns21` | *WARNING* (DB-270002): ("error" 22 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 22 attempts; physical feasibility unresolved. Last=(\"routing\" (2 1) 0.25 0.75 t \"boundary_following\" \"(\\\"error\\\" 21 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\ |
| `rectangle_stacked_block2` | *WARNING* (DB-270002): ("error" 22 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 22 attempts; physical feasibility unresolved. Last=(\"routing\" (2 1) 0.25 0.75 t \"boundary_following\" \"(\\\"error\\\" 21 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\ |
| `wide_notch_stacked_cw_cw` | *WARNING* (DB-270002): ("error" 21 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 21 attempts; physical feasibility unresolved. Last=(\"routing\" (0 1) 0.5 0.5 nil \"inscribed_rectangle\" \"(\\\"error\\\" 20 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\ |
| `wide_notch_stacked_ccw_cw` | *WARNING* (DB-270002): ("error" 21 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 21 attempts; physical feasibility unresolved. Last=(\"routing\" (0 1) 0.5 0.5 nil \"inscribed_rectangle\" \"(\\\"error\\\" 20 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\ |
| `wide_notch_stacked_ccw_ccw` | *WARNING* (DB-270002): ("error" 22 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 22 attempts; physical feasibility unresolved. Last=(\"routing\" (1 1) 0.5 0.5 nil \"boundary_following\" \"(\\\"error\\\" 21 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\ |
| `wide_notch_stacked_insets` | *WARNING* (DB-270002): ("error" 22 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 22 attempts; physical feasibility unresolved. Last=(\"routing\" (1 1) 0.5 0.5 nil \"boundary_following\" \"(\\\"error\\\" 21 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\ |
| `wide_notch_stacked_profile` | *WARNING* (DB-270002): ("error" 21 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 21 attempts; physical feasibility unresolved. Last=(\"routing\" (2 0) 0.5 0.5 t \"boundary_following\" \"(\\\"error\\\" 20 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\\\ |
| `wide_notch_stacked_turns21` | *WARNING* (DB-270002): ("error" 21 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 21 attempts; physical feasibility unresolved. Last=(\"routing\" (0 1) 0.5 0.5 nil \"inscribed_rectangle\" \"(\\\"error\\\" 20 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\ |
| `wide_notch_stacked_turns12` | *WARNING* (DB-270002): ("error" 20 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 20 attempts; physical feasibility unresolved. Last=(\"routing\" (0 1) 0.5 0.5 nil \"boundary_following\" \"(\\\"error\\\" 19 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\ |
| `wide_notch_stacked_block2` | *WARNING* (DB-270002): ("error" 21 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 21 attempts; physical feasibility unresolved. Last=(\"routing\" (0 1) 0.5 0.5 nil \"inscribed_rectangle\" \"(\\\"error\\\" 20 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\ |
| `top_notch_stacked_cw_cw` | *WARNING* (DB-270002): ("error" 21 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 21 attempts; physical feasibility unresolved. Last=(\"routing\" (0 1) 0.5 0.5 nil \"inscribed_rectangle\" \"(\\\"error\\\" 20 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\ |
| `top_notch_stacked_ccw_cw` | *WARNING* (DB-270002): ("error" 21 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 21 attempts; physical feasibility unresolved. Last=(\"routing\" (0 1) 0.5 0.5 nil \"inscribed_rectangle\" \"(\\\"error\\\" 20 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\ |
| `top_notch_stacked_ccw_ccw` | *WARNING* (DB-270002): ("error" 21 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 21 attempts; physical feasibility unresolved. Last=(\"routing\" (0 1) 0.5 0.5 nil \"inscribed_rectangle\" \"(\\\"error\\\" 20 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\ |
| `top_notch_stacked_profile` | *WARNING* (DB-270002): ("error" 21 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 21 attempts; physical feasibility unresolved. Last=(\"routing\" (2 0) 0.5 0.5 t \"boundary_following\" \"(\\\"error\\\" 20 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\\\ |
| `top_notch_stacked_turns21` | *WARNING* (DB-270002): ("error" 20 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 20 attempts; physical feasibility unresolved. Last=(\"routing\" (0 1) 0.5 0.5 nil \"boundary_following\" \"(\\\"error\\\" 19 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\ |
| `top_notch_stacked_turns12` | *WARNING* (DB-270002): ("error" 20 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 20 attempts; physical feasibility unresolved. Last=(\"routing\" (0 1) 0.5 0.5 nil \"boundary_following\" \"(\\\"error\\\" 19 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\ |
| `top_notch_stacked_block2` | *WARNING* (DB-270002): ("error" 20 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 20 attempts; physical feasibility unresolved. Last=(\"routing\" (0 1) 0.5 0.5 nil \"boundary_following\" \"(\\\"error\\\" 19 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\ |
| `l_shape_stacked` | *WARNING* (DB-270002): ("error" 22 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 22 attempts; physical feasibility unresolved. Last=(\"routing\" (1 1) 0.5 0.5 nil \"boundary_following\" \"(\\\"error\\\" 21 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\ |
| `staircase12_stacked` | *WARNING* (DB-270002): ("error" 24 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 24 attempts; physical feasibility unresolved. Last=(\"routing\" (1 2) 0.5 0.5 nil \"boundary_following\" \"(\\\"error\\\" 23 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (720001); feasibility is unresolved.\\ |
| `triangle_stacked` | *WARNING* (DB-270002): ("error" 37 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 37 attempts; physical feasibility unresolved. Last=(\"routing\" (0 3) 0.5 0.5 t \"inscribed_rectangle\" \"(\\\"error\\\" 36 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\\\ |
| `diamond_stacked` | *WARNING* (DB-270002): ("error" 28 t nil ("*Error* TCOIL_SEARCH_BUDGET: adaptive opening search stopped after 28 attempts; physical feasibility unresolved. Last=(\"routing\" (3 1) 0.75 0.25 t \"inscribed_rectangle\" \"(\\\"error\\\" 27 t nil (\\\"*Error* TCOIL_SEARCH_BUDGET: total collision-check budget reached (600001); feasibility is unresolved.\ |

## 与 v0.5.1 对比

| 范围 | 先前通过 | 当前通过 | 新修复 | 回归 |
|---|---:|---:|---:|---:|
| final_matrix_report.json | 197 | 203 | 6 | 0 |
| final_polygons_report.json | 28 | 28 | 0 | 0 |
| final_many_vertices_report.json | 5 | 5 | 0 | 0 |
| final_cut_audit_report.json | 3 | 3 | 0 | 0 |

逐例对比见 `repair_comparison_report.json`。预算停止与执行超时均表示可行性未定；内缩轮廓自交表示当前构造无效，未证明所有其他构造无解。

## Python 估算器验证

独立 `em_estimator/` 提供 1–50 GHz 的 L/R/M/K/Q、CSV、近似 S3P 和可选 FastHenry 导体输入文件。材料配置是明确标注的示例；未运行 FastHenry 或全波 EM，也未校准实际 TSMC18。数值无源性/互易性与格式检查不能证明物理精度。详细说明见 `../em_estimator/README_CN.md`。

数值/文件格式单测：9/9；跨已审计版图的导入与被动网络功能检查：113/113。这些结果不构成 EM 精度验证。


## 查看与复现

- `native/native_gallery.html`：实际 OA 版图及可筛选的完整参数表。
- `native/native_gallery.svg` / `.png`：可分享的静态版图图集。
- `native/final_matrix_report.json`：253 项参数矩阵。
- `native/final_polygons_report.json` / `final_many_vertices_report.json`：新边界与 20 顶点测试。
- `native/final_cut_audit_report.json`：实际过孔阵列矩形验证。
- `native/demo.cds.lib`：可打开 `TCOIL_DEMO_052` 库，包含 12 个已安装的项目 PCell。

```sh
/usr/bin/python3 validation/run_validation.py
/usr/bin/python3 validation/check_geometry_sweep.py --timeout 300
/usr/bin/python3 validation/check_parameter_effects.py
/usr/bin/python3 validation/run_parallel_matrix.py --workers 3 --case-timeout 120
/usr/bin/python3 validation/run_parallel_polygons.py --workers 4 --case-timeout 300
/usr/bin/python3 validation/run_many_vertices.py
/usr/bin/python3 validation/run_native_presets.py
```

本工作站请使用 `/usr/bin/python3`；默认 `python3` 为 3.7，不支持宿主求值器所用的 `math.prod`。

内核 SHA-256：`293e13610fb2ae8989fc47993eb9d9906644e1ae9cd35c62872e0f3149ed3fae`。
