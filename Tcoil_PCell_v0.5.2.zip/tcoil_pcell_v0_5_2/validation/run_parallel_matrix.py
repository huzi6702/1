#!/usr/bin/env python3
"""Bounded native matrix. Resume completed evidence and isolate remaining cases.

Each new case gets a separate library and wall-clock limit, so one difficult
PCell cannot prevent the rest of the parameter matrix from being tested.
"""
import argparse
import concurrent.futures
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import time

from check_geometry import parse
from run_native_matrix import ROOT, NATIVE, cases, collect, run


def native_processes(label):
    target = str(NATIVE / (label + '.cds.log')).encode()
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            args = (path / 'cmdline').read_bytes().split(b'\0')
            if args and args[0].split(b'/')[-1] == b'virtuoso' and target in args:
                yield int(path.name)
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            pass


def stop(label):
    for pid in list(native_processes(label)):
        os.kill(pid, signal.SIGTERM)
        for _ in range(30):
            if pid not in list(native_processes(label)):
                break
            time.sleep(.1)
        if pid in list(native_processes(label)):
            os.kill(pid, signal.SIGKILL)


def timeout_case(row, seconds, note):
    return dict(row, passed=False, generated=False, status='native_timeout',
                time_limit_seconds=seconds, error=note,
                generation_error='Native execution exceeded the observation limit; no physical infeasibility conclusion.')


def main(args):
    source_hash = hashlib.sha256((ROOT / 'tcoil.il').read_bytes()).hexdigest()
    planned = cases()
    expected = {r['name']: r for r in planned}
    completed = {}
    provenance = []
    if args.resume:
        labels = ['budget_rect_probe', 'final_matrix', 'final_top_notch', 'final_invalid']
        labels += [p.name[:-14] for p in sorted(NATIVE.glob('bounded_*_manifest.json'))]
        for label in labels:
            path = NATIVE / (label + '_manifest.json')
            if not path.exists():
                continue
            manifest = json.loads(path.read_text())
            if manifest['source_sha256'] != source_hash:
                continue
            log = NATIVE / (label + '.stdout.log')
            text = log.read_text(errors='replace') if log.exists() else ''
            active = list(native_processes(label))
            if active:
                starts = [line.split('QA_BEGIN ', 1)[1].strip() for line in text.splitlines() if 'QA_BEGIN ' in line]
                current = starts[-1] if starts else None
                quiet = time.time() - log.stat().st_mtime
                stop(label)
                if current in expected and quiet >= args.case_timeout and not (Path(manifest['result_dir']) / (current+'.sexp')).exists():
                    completed[current] = timeout_case(expected[current], round(quiet, 2),
                        'Stopped after at least %.1f seconds without completing this case; earlier completed cases retained.' % quiet)
            ready = []
            for row in manifest['cases']:
                result_path = Path(manifest['result_dir']) / (row['name']+'.sexp')
                if row['name'] not in expected or row['name'] in completed or not result_path.exists():
                    continue
                try:
                    data = parse(result_path.read_text())
                    if data and len(data[0]) >= 3:
                        ready.append(row)
                except Exception:
                    pass
            if ready:
                with contextlib.redirect_stdout(io.StringIO()):
                    report = collect(ready, 'retained_'+label, source_hash,
                                     Path(manifest['loaded_source']), Path(manifest['result_dir']), log)
                for case in report['cases']:
                    completed[case['name']] = case
                provenance.append('retained_'+label+'_report.json')
            report_path = NATIVE / (label + '_report.json')
            if label.startswith('bounded_') and report_path.exists():
                prior = json.loads(report_path.read_text())
                if prior['source_sha256'] == source_hash:
                    for case in prior['cases']:
                        if case['name'] in expected and case.get('status') == 'native_timeout':
                            completed[case['name']] = case

    pending = [r for r in planned if r['name'] not in completed]
    print('Retained', len(completed), 'of', len(planned), '; isolated remaining cases:', len(pending), flush=True)

    def worker(index, row):
        label = 'bounded_%03d' % index
        report = run([row], label, args.case_timeout)
        case = report['cases'][0]
        if report.get('timed_out') and not case.get('generated') and case.get('error', '').startswith('Native result missing'):
            log = (NATIVE / (label+'.stdout.log')).read_text(errors='replace')
            if 'QA_BEGIN '+row['name'] not in log:
                raise RuntimeError('Native setup did not reach case '+row['name']+'; see '+label+'.stdout.log')
            case = timeout_case(row, args.case_timeout,
                                'Isolated native case did not complete within %d seconds including startup.' % args.case_timeout)
            report['cases'] = [case]
            report['passed'] = False
            (NATIVE / (label+'_report.json')).write_text(json.dumps(report, indent=2)+'\n')
        if case.get('error', '').startswith('Native result missing'):
            raise RuntimeError('Uncollected native result: '+row['name'])
        return case, label+'_report.json'

    # Use new labels even when interrupted workers from an earlier run remain.
    last_index = max([int(p.name.split('_')[1]) for p in NATIVE.glob('bounded_*_manifest.json')] or [0])
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(worker, last_index+i+1, row) for i, row in enumerate(pending)]
        for future in concurrent.futures.as_completed(futures):
            case, report_name = future.result()
            completed[case['name']] = case
            provenance.append(report_name)
            print(len(completed), '/', len(planned), case['name'], case.get('status', 'PASS' if case['passed'] else 'generation_failed'), flush=True)
            (NATIVE / 'bounded_matrix_progress.json').write_text(json.dumps(dict(
                source_sha256=source_hash, completed=len(completed), total=len(planned),
                pending=[r['name'] for r in planned if r['name'] not in completed]), indent=2)+'\n')

    assert set(completed) == set(expected)
    ordered = [completed[r['name']] for r in planned]
    for row, case in zip(planned, ordered):
        assert case['params'] == row['params'] and case['pins'] == row['pins']
    report = dict(passed=all(c['passed'] for c in ordered), collection_complete=True,
                  source_sha256=source_hash, source_path=str(ROOT/'tcoil.il'),
                  runtime='Cadence IC617 native SKILL, PCell evaluation and independent actual OA audits',
                  pdk='/home/meow/tsmc18/tsmc18', technology='/home/meow/tsmc18/tech.tf',
                  metals=['METAL5','METAL6'], via='M6_M5', grid_um=.005, cases=ordered,
                  batches=provenance, case_timeout_seconds=args.case_timeout,
                  timeout_policy='New isolated cases have a wall limit including startup; previously completed native evidence is retained.',
                  limitations=['No foundry DRC/LVS or EM; native timeout does not prove physical infeasibility.'])
    (NATIVE / 'final_matrix_report.json').write_text(json.dumps(report, indent=2)+'\n')
    print('Complete native matrix:', sum(c['passed'] for c in ordered), '/', len(ordered), 'expectations met', flush=True)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--workers', type=int, default=3)
    parser.add_argument('--case-timeout', type=int, default=120)
    result = main(parser.parse_args())
    raise SystemExit(0 if result['passed'] else 1)
