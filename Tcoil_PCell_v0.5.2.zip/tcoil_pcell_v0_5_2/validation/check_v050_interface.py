#!/usr/bin/env python3
"""v0.5 fixed-project/compact-CDF contract checks.

The adapter calls are Python mocks. These checks do not execute Cadence CDF,
OpenAccess, pcDefinePCell macro compilation, or any foundry rule deck.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

from check_geometry import VM, Sym, SkillError, parse

ROOT = Path(__file__).resolve().parents[1]
BOUNDARY = '((40 12)(0 12)(0 0)(10 0)(10 5)(27 5)(27 0)(40 0))'
PINS = [[[0., 2.], 2, 'AUTO'], [[40., 2.], 2, 'AUTO'], [[24., 12.], 2, 'AUTO']]


def nodes(form):
    if not isinstance(form, list) or not form or form[0] == 'quote':
        return
    yield form
    for child in form:
        yield from nodes(child)


def run():
    source = (ROOT / 'tcoil.il').read_text()
    forms = parse(source)
    all_nodes = [node for form in forms for node in nodes(form)]
    procedures = {str(form[1][0]): form for form in forms
                  if form and form[0] == 'procedure'}
    vm = VM()
    # Loading definitions is safe in the host subset evaluator; API boundaries
    # below are supplied explicitly as mocks before a public adapter is called.
    for form in forms:
        vm.ev(form)
    schema = json.loads((ROOT / 'parameters.json').read_text())
    checks = []

    def check(name, fn):
        try:
            fn()
            checks.append(dict(name=name, pass_=True))
        except Exception as exc:
            checks.append(dict(name=name, pass_=False, error=str(exc)))

    def eq(a, b):
        assert a == b, (a, b)

    def rejected(fn):
        try:
            fn()
        except SkillError:
            return
        raise AssertionError('Invalid input was accepted')

    def encode(boundary=BOUNDARY, pins=PINS, clearance=.5, grid=.001,
               path='/synthetic/tech.tf', mode='techfile'):
        return vm.call('tc5ProjectEncode', boundary, deepcopy(pins), clearance, grid, path, mode)

    fixture = ROOT / 'validation' / 'tech_fixtures' / 'example.tech.tf'
    selected = vm.call('tc5TFSelect', vm.call('tc5TFParse', fixture.read_text()), 'TM1', 'TM2', 'TM2_TM1')
    snapshot = vm.call('tc5TFSnapshot', selected, 'TM1', 'TM2')

    def values(**changes):
        result = {row['name']: row['default'] for row in schema}
        result.update(projectData=encode(), techData=snapshot)
        result.update(changes)
        return result

    def resolve(**changes):
        return vm.call('tc5ResolveValues', [[Sym(k), v] for k, v in values(**changes).items()])

    def interface_contract():
        macro = next(node for node in all_nodes if node[0] == 'pcDefinePCell')
        formal = [str(row[0]) for row in macro[2]]
        cdf = [node for node in all_nodes if node[0] == 'cdfCreateParam']
        cdf_names = [node[node.index(Sym('?name')) + 1] for node in cdf]
        expected = [row['name'] for row in schema] + ['projectData', 'techData']
        eq(formal, expected)
        eq(cdf_names, expected)
        eq(len(formal), 24)
        assert len(set(formal)) == len(formal)
        obsolete = {'leadWidth', 'terminalLength', 'pinADir', 'pinCTDir', 'pinBDir',
                    'tapTurn', 'tapFraction', 'openingGap', 'pinOrder', 'routePreference',
                    'maxStates', 'viaCost', 'extraPitch', 'scale2', 'groupSize', 'viaMode',
                    'cutWidth', 'cutHeight', 'reloadTech', 'showBoundary', 'showLabels'}
        assert not obsolete.intersection(formal)
        for node in cdf:
            name = node[node.index(Sym('?name')) + 1]
            display = node[node.index(Sym('?display')) + 1]
            if name in ('projectData', 'techData'):
                eq(display, 'nil')
            else:
                row = next(x for x in schema if x['name'] == name)
                eq(display, row['display'])
        eq(sum(row['display'] == 't' for row in schema), 18)
        # Derived visibility is explicitly scoped to useful topology/count cases.
        displays = {row['name']: row['display'] for row in schema}
        assert 'turns1->value > 1' in displays['space1']
        assert 'turns2->value > 1' in displays['space2']
        assert 'interleaveBlock->value' in displays['space2']
        assert 'turns1->value > 1' in displays['interleaveBlock']
        eq(dict(vm.call('tc5DefaultValues')), {row['name']: row['default'] for row in schema})
        # Verify that the PCell body forwards each exact formal parameter once.
        evaluation = next(node for node in nodes(macro) if node[0] == 'tc5Evaluate')
        bindings = evaluation[2][1:]
        eq([str(row[1][1]) for row in bindings], expected)
        eq([str(row[2]) for row in bindings], expected)

    check('24_formals_22_editable_18_unconditional_defaults_and_bindings_match', interface_contract)

    def io_boundary():
        pending = ['tc5Evaluate']; visited = set(); calls = set()
        while pending:
            name = pending.pop()
            if name in visited:
                continue
            visited.add(name)
            for node in nodes(procedures[name]):
                if isinstance(node[0], Sym):
                    call = str(node[0]); calls.add(call)
                    if call in procedures and call not in visited:
                        pending.append(call)
        forbidden = {'infile', 'gets', 'load', 'eval', 'evalstring', 'system',
                     'tc5TFRead', 'tc5TFImportValues', 'tcoil5CDFImport'}
        assert not calls.intersection(forbidden), sorted(calls.intersection(forbidden))
        for node in all_nodes:
            if node[0] in ('append', 'setq'):
                assert len(node) == 3, node
        # SKILL has dynamic scope. A missing local declaration may mutate a
        # caller's variable even though this host evaluator behaves differently.
        def assignments(form, bound, procedure):
            if not isinstance(form, list) or not form or form[0] == 'quote':
                return
            op = form[0]
            if op == 'setq':
                assert form[1] in bound, (procedure, 'unscoped setq', form[1])
                assignments(form[2], bound, procedure)
                return
            if op in ('prog', 'let'):
                local = set(bound)
                for item in form[1]:
                    if isinstance(item, list):
                        local.add(item[0]); assignments(item[1], bound, procedure)
                    else:
                        local.add(item)
                for item in form[2:]:
                    assignments(item, local, procedure)
                return
            if op in ('for', 'foreach'):
                local = set(bound); local.add(form[1])
                for item in form[2:]:
                    assignments(item, local, procedure)
                return
            for item in form[1:]:
                assignments(item, bound, procedure)
        for name, form in procedures.items():
            bound = {p[0] if isinstance(p, list) else p for p in form[1][1:]}
            for body in form[2:]:
                assignments(body, bound, name)

    check('PCell_evaluation_has_no_file_IO_eval_or_variadic_append_setq', io_boundary)
    check('project_roundtrip_preserves_exact_external_pins', lambda: eq(
        vm.call('tc5ProjectDecode', encode()), [BOUNDARY, PINS, .5, .001, '/synthetic/tech.tf', 'techfile']))
    check('project_version_rejected', lambda: rejected(lambda: vm.call('tc5ProjectDecode', encode().replace('TCOIL050', 'TCOIL999'))))
    check('project_trailing_forms_rejected', lambda: rejected(lambda: vm.call('tc5ProjectDecode', encode() + ' system("not_executed")')))
    check('project_grid_must_be_positive', lambda: rejected(lambda: vm.call('tc5ProjectDecode', encode(grid=0.))))
    check('project_clearance_must_be_positive', lambda: rejected(lambda: vm.call('tc5ProjectDecode', encode(clearance=0.))))
    check('project_pin_layer_must_be_one_or_two', lambda: rejected(lambda: vm.call('tc5ProjectDecode', encode(pins=[[[0., 2.], 1.5, 'AUTO']] + deepcopy(PINS[1:])))))
    check('project_pin_off_grid_is_rejected_not_moved', lambda: rejected(lambda: vm.call('tc5ProjectDecode', encode(pins=[[[.0003, 2.], 2, 'AUTO']] + deepcopy(PINS[1:])))))
    check('project_requires_exactly_three_pins', lambda: rejected(lambda: vm.call('tc5ProjectDecode', encode(pins=PINS[:2]))))
    check('project_pin_expression_is_not_executed', lambda: rejected(lambda: vm.call('tc5ProjectDecode',
        '("TCOIL050" "' + BOUNDARY + '" ((plus(0 0) 2 2)(40 2 2)(24 12 2)) .5 .001 "/synthetic/tech.tf" "techfile")')))

    def derived_access():
        p = resolve(width1=.8, width2=1.2)
        eq(p['pins'], PINS)
        eq(p['leadWidth'], .8)
        eq(p['geometryMaxWidth'], 1.2)
        assert abs(p['derivedTerminalLength'] - 1.6) < 1e-10
        assert p['space'] == .5 and p['viaMode'] == 'techfile'
        assert abs(p['cutWidth'] - .324) < 1e-10

    check('pin_access_is_derived_from_winding_geometry_without_formal_parameters', derived_access)

    def local_rules():
        p = resolve(profile1='((-1 -1 1.2 0.8)(0 2 -1 0.6)(0 3 0.8 -1))')
        eq(vm.call('tc5VRule', p, 1, 0, 2), [1.2, .6])
        eq(vm.call('tc5VRule', p, 1, 0, 3), [.8, .8])
        eq(vm.call('tc5VRule', p, 2, 0, 2), [1., .5])
        eq(p['geometryMaxWidth'], 1.2)
        eq(p['leadWidth'], .8)

    check('local_rules_wildcard_precedence_and_independent_windings', local_rules)
    check('profile_turn_index_outside_winding_rejected', lambda: rejected(lambda: resolve(profile1='((1 0 1 .5))')))
    check('profile_edge_index_outside_lobe_rejected', lambda: rejected(lambda: resolve(topology='split_lobe', profile1='((0 4 1 .5))')))
    check('profile_fractional_index_rejected', lambda: rejected(lambda: resolve(profile1='((0.5 0 1 .5))')))
    check('profile_width_off_grid_rejected', lambda: rejected(lambda: resolve(profile1='((0 0 .999 .5))')))
    check('profile_gap_below_project_floor_rejected', lambda: rejected(lambda: resolve(profile1='((0 0 1 .4))')))
    check('profile_expressions_rejected', lambda: rejected(lambda: resolve(profile1='((0 0 plus(1 1) .5))')))
    check('second_winding_direction_is_validated', lambda: rejected(lambda: resolve(sense2='unused')))
    check('legacy_topology_names_are_not_silently_accepted', lambda: rejected(lambda: resolve(topology='figure8_tapped')))

    def landing_accounts_for_local_width():
        p = resolve(profile1='((0 0 2.0 -1))')
        eq(p['geometryMaxWidth'], 2.)
        eq(vm.call('tc5ViaLandingBox', p, [-.233, -.233, .233, .233]), [-1., -1., 1., 1.])

    check('full_width_via_landing_includes_local_profile_maximum', landing_accounts_for_local_width)
    check('editable_array_counts_survive_snapshot_resolution', lambda: eq(
        [resolve(viaRows=2, viaCols=3)[k] for k in ('viaRows', 'viaCols')], [2, 3]))
    check('changed_metal_pair_rejects_incompatible_snapshot', lambda: rejected(lambda: resolve(metal2='M3')))

    counts = {'replace_calls': 0}
    def replace(inst, props):
        counts['replace_calls'] += 1
        for name, kind, value in props:
            inst[name]['value'] = value
        return True
    mocks = dict(getWorkingDir=lambda: '/virtuoso/start', infile=lambda path: open(path),
                 close=lambda port: port.close(), isFile=lambda path: Path(path).is_file(),
                 cdfGetParamByName=lambda cdf, name: cdf.get(name), cdfGetInstCDF=lambda inst: inst,
                 dbReplacePropList=replace, printf=lambda *args: True, warn=lambda *args: True)
    for name, function in mocks.items():
        vm.env[Sym(name)] = function
    cdf = {k: {'value': value} for k, value in values(
        projectData=encode(path=str(fixture)), viaRows=2, viaCols=3).items()}
    vm.env[Sym('cdfgData')] = cdf

    def cdf_refresh():
        fixed = cdf['projectData']['value']
        cdf['techData']['value'] = 'old snapshot sentinel'
        eq(vm.call('tcoil5CDFImport'), True)
        eq(cdf['projectData']['value'], fixed)
        eq(cdf['viaRows']['value'], 2); eq(cdf['viaCols']['value'], 3)
        assert cdf['techData']['value'] != 'old snapshot sentinel'
        eq(vm.call('tc5ProjectDecode', cdf['projectData']['value'])[1], PINS)

    check('CDF_via_refresh_preserves_array_counts_and_fixed_project', cdf_refresh)

    def failed_refresh():
        before = cdf['techData']['value']
        cdf['metal2']['value'] = 'NONEXISTENT_LAYER'
        try:
            eq(vm.call('tcoil5CDFImport'), None)
            eq(cdf['techData']['value'], before)
            eq(cdf['viaRows']['value'], 2); eq(cdf['viaCols']['value'], 3)
        finally:
            cdf['metal2']['value'] = 'TM2'

    check('failed_CDF_import_preserves_previous_snapshot', failed_refresh)

    def instance_refresh():
        fixed_pins = vm.call('tc5ProjectDecode', cdf['projectData']['value'])[1]
        eq(vm.call('tcoilApplyTech', cdf, str(fixture), 'TM2_TM1'), True)
        eq(counts['replace_calls'], 1)
        eq(vm.call('tc5ProjectDecode', cdf['projectData']['value'])[1], fixed_pins)
        eq(cdf['viaRows']['value'], 2); eq(cdf['viaCols']['value'], 3)

    check('instance_refresh_is_one_atomic_property_write_and_keeps_PINs', instance_refresh)
    return dict(passed=all(item['pass_'] for item in checks), checks=checks,
                source_sha256=hashlib.sha256(source.encode()).hexdigest(),
                runtime='host SKILL-subset evaluator plus API mocks; NOT Cadence SKILL/OA')


if __name__ == '__main__':
    result = run()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['passed'] else 1)
