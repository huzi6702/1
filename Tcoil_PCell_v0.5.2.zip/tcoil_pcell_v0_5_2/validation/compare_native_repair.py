#!/usr/bin/env python3
"""Compare final native evidence to an immutable earlier release archive."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]


def compare(baseline):
    source_hash = hashlib.sha256((ROOT / 'tcoil.il').read_bytes()).hexdigest()
    names = ['final_matrix_report.json', 'final_polygons_report.json', 'final_many_vertices_report.json', 'final_cut_audit_report.json']
    result = dict(source_sha256=source_hash, baseline_archive=Path(baseline).name,
                  baseline_archive_sha256=hashlib.sha256(Path(baseline).read_bytes()).hexdigest(), comparisons={})
    with ZipFile(str(baseline)) as archive:
        for name in names:
            old = json.loads(archive.read('tcoil_pcell_v0_5_1/validation/native/' + name))
            new = json.loads((ROOT / 'validation/native' / name).read_text())
            assert new['source_sha256'] == source_hash, 'Stale report: ' + name
            before = {c['name']: c for c in old['cases']}
            after = {c['name']: c for c in new['cases']}
            assert set(before) == set(after), 'Scope changed: ' + name
            positive = [c for c in new['cases'] if c['expected']]
            result['comparisons'][name] = dict(
                baseline_source_sha256=old['source_sha256'], total_positive=len(positive),
                previous_positive_passed=sum(c['passed'] for c in old['cases'] if c['expected']),
                current_positive_passed=sum(c['passed'] for c in positive),
                repaired=[n for n in after if after[n]['passed'] and not before[n]['passed']],
                regressions=[n for n in after if before[n]['passed'] and not after[n]['passed']],
                audit_failures=[c['name'] for c in new['cases'] if c.get('audit_error')],
                remaining=[dict(name=c['name'], status=c.get('status', c.get('failure_class', 'generation_failed')),
                                error=c.get('generation_error', c.get('error', '')))
                           for c in new['cases'] if not c['passed']])
    result['no_regressions'] = all(not c['regressions'] and not c['audit_failures'] for c in result['comparisons'].values())
    out = ROOT / 'validation/repair_comparison_report.json'
    out.write_text(json.dumps(result, indent=2) + '\n')
    for name, r in result['comparisons'].items():
        print(name, r['previous_positive_passed'], '->', r['current_positive_passed'], '/', r['total_positive'], 'regressions=', r['regressions'])
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', default=str(ROOT.parent / 'Tcoil_PCell_v0.5.1.zip'))
    args = parser.parse_args()
    report = compare(args.baseline)
    raise SystemExit(0 if report['no_regressions'] else 1)
