#!/usr/bin/env python3
"""Bounded connection-order retries and transactional geometry regressions.

Host SKILL-subset evaluator only; not Cadence SKILL, OA, or PDK DRC.
"""
from copy import deepcopy
from pathlib import Path

from check_geometry import VM, Sym, SkillError

ROOT = Path(__file__).resolve().parents[1]


def run(source=None, planner=None):
    vm = VM()
    # Cadence assoc accepts nil. The earlier host VM omitted this valid case.
    vm.env[Sym('assoc')] = lambda a, b: next((x for x in b or [] if x[0] == a), None)
    vm.load(source or ROOT / 'tcoil.il')
    if planner is not None:
        vm.load(planner)
    checks = []

    def check(name, fn):
        try:
            fn()
            checks.append(dict(name=name, pass_=True))
        except Exception as exc:
            checks.append(dict(name=name, pass_=False, error=str(exc)))

    def context():
        return dict(boundary=[[0., 0.], [10., 0.], [10., 10.], [0., 10.]],
                    objects=[[1, [0., 0., 4., 4.5], 1, 'lower_left'],
                             [1, [6., 0., 10., 4.5], 2, 'lower_right'],
                             [2, [0., 0., 10., 10.], 3, 'blocked_metal2']],
                    vias=[], routes=[], serial=3, grid=.001, space=.2,
                    leadWidth=.4, viaBox=[-.2, -.2, .2, .2], contactRadius=.2,
                    routePreference='M1', maxStates=12000, viaCost=20.)

    links = [[[8., 8., 1], [8., 8., 1], 'DUMMY_A'],
             [[1., 5., 1], [9., 5., 1], 'FLEX'],
             [[9., 9., 1], [9., 9., 1], 'DUMMY_B'],
             [[5., 1., 1], [5., 6.5, 1], 'CHOKE']]
    base_keys = ('objects', 'vias', 'routes', 'serial')

    def snapshot(c):
        return deepcopy({k: c[k] for k in base_keys})

    def real_order_retry():
        c = context()
        assert vm.call('tc5PlanConnections', c, links) is True
        assert c['plannerAttempts'] == 3, c['plannerAttempts']
        assert c['plannerOrder'] == [3, 2, 1, 0]
        assert c['plannerFailedLink'] is None
        assert len(c['routes']) == 4, c['routes']
        assert sorted(x[1] for x in c['routes']) == sorted(x[2] for x in links)
        assert c['vias'] == []
        # Every final route still has its original physical endpoints.
        by_tag = {tag: states for states, tag in c['routes']}
        for a, b, tag in links:
            assert by_tag[tag][0] == a and by_tag[tag][-1] == b
            assert vm.call('tc5RouteSelfOK', c, by_tag[tag])
        # CHOKE owns the only lower corridor. FLEX must have moved above it.
        assert max(x[1] for x in by_tag['FLEX']) > 7.
        # Replay only accepted routes against fresh base geometry; all clear.
        fresh = context()
        for index in c['plannerOrder']:
            a, b, tag = links[index]
            states = by_tag[tag]
            allow = (vm.call('tc5Anchors', fresh, a[:2], a[2]) or []) + \
                    (vm.call('tc5Anchors', fresh, b[:2], b[2]) or [])
            assert vm.call('tc5RouteCheck', fresh, states, allow), tag
            vm.call('tc5CommitRoute', fresh, states, tag)
        assert snapshot(fresh) == snapshot(c), 'Failed trial geometry leaked'

    check('alternate_order_routes_dead_end_without_leaking_trials', real_order_retry)

    def internal_bridge_first_retry():
        c = context()
        # Move the constrained path into the optional internal-bridge list.
        # Every terminal-first attempt blocks it; bridge-first frees FLEX to
        # use the upper detour. This is actual geometry, not a mocked router.
        extended = deepcopy(links[:3])
        extended.append([[7., 9., 1], [7., 9., 1], 'DUMMY_CT2'])
        extended.append(deepcopy(links[3]))
        assert vm.call('tc5PlanConnections', c, extended) is True
        assert c['plannerAttempts'] == 9
        assert c['plannerOrder'] == [4, 1, 3, 0, 2]
        assert len(c['routes']) == 5 and c['vias'] == []
        by_tag = {tag: states for states, tag in c['routes']}
        assert max(x[1] for x in by_tag['FLEX']) > 7.
        fresh = context()
        for index in c['plannerOrder']:
            a, b, tag = extended[index]
            states = by_tag[tag]
            assert states[0] == a and states[-1] == b
            assert vm.call('tc5RouteSelfOK', c, states)
            allow = (vm.call('tc5Anchors', fresh, a[:2], a[2]) or []) + \
                    (vm.call('tc5Anchors', fresh, b[:2], b[2]) or [])
            assert vm.call('tc5RouteCheck', fresh, states, allow), tag
            vm.call('tc5CommitRoute', fresh, states, tag)
        assert snapshot(fresh) == snapshot(c)

    check('internal_bridge_first_recovers_terminal_first_obstruction', internal_bridge_first_retry)

    original_route = vm.env[Sym('tc5Route')]

    def all_failed_restores_base():
        c = context()
        # Existing committed vias/routes must survive a failed planning batch.
        c['vias'] = [[[9., 9.], 'old_via']]
        c['routes'] = [[[[9., 9., 1]], 'old_route']]
        before = snapshot(c)
        calls = []

        def controlled_route(ctx, a, b):
            calls.append((list(a), list(b)))
            if a == links[3][0]:
                ctx['lastRouteStatus'] = 'synthetic_blocked'
                ctx['lastRouteExpanded'] = 1
                ctx['lastRouteAxes'] = [2, 2]
                return None
            return [a, b] if a != b else [a]

        vm.env[Sym('tc5Route')] = controlled_route
        try:
            try:
                vm.call('tc5PlanConnections', c, links)
                raise AssertionError('Failed plan unexpectedly succeeded')
            except SkillError as exc:
                message = str(exc)
                assert '8 bounded orders' in message and 'CHOKE' in message
                assert 'synthetic_blocked' in message
            assert c['plannerAttempts'] == 8
            assert c['plannerOrder'] is None
            assert c['plannerFailedLink'] == links[3]
            assert snapshot(c) == before
            assert len(calls) > 8, 'Test never committed a partial trial'
        finally:
            vm.env[Sym('tc5Route')] = original_route

    check('all_eight_failed_orders_restore_objects_vias_routes_serial', all_failed_restores_base)

    def internal_link_order_and_limit():
        c = context()
        before = snapshot(c)
        extended = deepcopy(links)
        extended += [[[6., 8., 1], [7., 8., 1], 'BRIDGE_1'],
                     [[6., 9., 1], [7., 9., 1], 'BRIDGE_2']]
        seen = []

        def blocked_second_bridge(ctx, a, b):
            seen.append(list(a))
            if a == extended[5][0]:
                ctx['lastRouteStatus'] = 'synthetic_internal_blocked'
                ctx['lastRouteExpanded'] = 1
                ctx['lastRouteAxes'] = [2, 2]
                return None
            return [a, b] if a != b else [a]

        vm.env[Sym('tc5Route')] = blocked_second_bridge
        try:
            try:
                vm.call('tc5PlanConnections', c, extended)
                raise AssertionError('Blocked internal bridge accepted')
            except SkillError as exc:
                assert '16 bounded orders' in str(exc) and 'BRIDGE_2' in str(exc)
            assert c['plannerAttempts'] == 16 and snapshot(c) == before
            assert sum(a == extended[4][0] for a in seen) == 16
            assert sum(a == extended[5][0] for a in seen) == 16
            for i, a in enumerate(seen):
                if a == extended[5][0]:
                    assert i > 0 and seen[i - 1] == extended[4][0]
            assert c['plannerFailedLink'] == extended[5]
        finally:
            vm.env[Sym('tc5Route')] = original_route

    check('internal_link_order_preserved_and_sixteen_attempts_bounded', internal_link_order_and_limit)

    def unexpected_error_restores_base():
        c = context()
        before = snapshot(c)
        count = 0

        def error_on_second(ctx, a, b):
            nonlocal count
            count += 1
            if count == 2:
                raise SkillError('synthetic unexpected kernel error')
            return [a, b]

        vm.env[Sym('tc5Route')] = error_on_second
        try:
            try:
                vm.call('tc5PlanConnections', c, links)
                raise AssertionError('Unexpected error was swallowed')
            except SkillError as exc:
                assert str(exc) == 'synthetic unexpected kernel error'
            assert count == 2 and snapshot(c) == before
        finally:
            vm.env[Sym('tc5Route')] = original_route

    check('unexpected_kernel_error_rolls_back_partial_commit', unexpected_error_restores_base)

    def reject_wrong_count():
        c = context()
        before = snapshot(c)
        try:
            vm.call('tc5PlanConnections', c, links[:3])
            raise AssertionError('Wrong link count accepted')
        except SkillError as exc:
            assert 'requires at least four' in str(exc)
        assert snapshot(c) == before

    check('four_link_contract_checked_before_mutation', reject_wrong_count)
    return dict(passed=all(x['pass_'] for x in checks), checks=checks,
                runtime='host SKILL-subset evaluator; NOT Cadence SKILL/OA',
                order_candidates=8, order_candidates_with_internal_links=16,
                exhaustive=False)


if __name__ == '__main__':
    import json
    report = run()
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report['passed'] else 1)
