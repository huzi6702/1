("reject_same_metals" nil nil)
