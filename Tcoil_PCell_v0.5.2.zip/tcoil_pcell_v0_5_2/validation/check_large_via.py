"""Regressions for full-sized top-metal landings and native control semantics.

Winding-only tests deliberately stub connection planning; full connectivity is
covered separately by native/OA runs and the geometry sweep.
"""
import hashlib
from pathlib import Path

from check_geometry import VM, SkillError, Sym, parse

ROOT = Path(__file__).resolve().parents[1]
TECH = '''("standardViaDefs" ("M6_M5" "METAL5" "METAL6"
  ("VIA56" 0.36 0.36) (1 1 (0.35 0.35))
  (0.06 0.06) (0.45 0.45) (0 0) (0 0) (0 0)))'''
BOUNDARY = '((40 12)(0 12)(0 0)(10 0)(10 5)(27 5)(27 0)(40 0))'
PINS = [[[0., 2.], 2, 'AUTO'], [[40., 2.], 2, 'AUTO'], [[24., 12.], 2, 'AUTO']]


def run(source=None):
    source = Path(source or ROOT / 'tcoil.il')
    vm = VM()
    vm.load(source)
    checks = []

    def check(name, fn):
        try:
            fn()
            checks.append(dict(name=name, pass_=True))
        except Exception as exc:
            checks.append(dict(name=name, pass_=False, error=str(exc)))

    def values(**changes):
        result = dict(vm.call('tc5DefaultValues'))
        result.update(metal1='METAL5', metal2='METAL6', viaDefName='M6_M5', techData=TECH,
                      projectData=vm.call('tc5ProjectEncode', BOUNDARY, PINS, .5, .005,
                                          'large_top_metal.tech.tf', 'techfile'))
        result.update(changes)
        return result

    def resolve(**changes):
        return vm.call('tc5ResolveValues', list(values(**changes).items()))

    def rejected(fn):
        try:
            fn()
        except SkillError:
            return
        raise AssertionError('Invalid input or control flow was accepted')

    def winding(**changes):
        p = resolve(**changes)
        box = vm.call('tc5ViaLandingBox', p, [-.63, -.63, .63, .63])
        c = vm.call('tc5MakeContext', p, box)
        original = vm.env[Sym('tc5PlanConnections')]
        vm.env[Sym('tc5PlanConnections')] = lambda *args: True
        try:
            vm.call('tc5GeometryTrial', c, p)
        finally:
            vm.env[Sym('tc5PlanConnections')] = original
        return c

    def pad_floor():
        c = winding()
        for entry in c['windingRings']:
            ring = dict(entry)
            assert min(ring['edgeInsets']) >= .63 - 1e-8
            for point in (ring['points'][0], ring['points'][-1]):
                pad = vm.call('tc5MoveBox', c['viaBox'], point)
                assert vm.call('tc5BoxInside', pad, c['boundary']), (point, pad)
        rings = [dict(entry) for entry in c['windingRings']]
        assert abs(rings[1]['edgeInsets'][0] - rings[0]['edgeInsets'][0] - 1.76) < 1e-8

    check('1p26um_landing_fits_default_winding_endpoints', pad_floor)
    for name, changes in [
        ('fractional_turns', dict(turns1=1.5)), ('fractional_via_rows', dict(viaRows=1.5)),
        ('negative_width', dict(width2=-.1)), ('off_grid_width', dict(width1=1.003)),
        ('off_grid_spacing', dict(space2=.503)), ('negative_clearance', dict(space1=-.1)),
        ('profile_expressions', dict(profile1='((0 0 plus(1 1) .5))')),
    ]:
        check(name + '_rejected', lambda changes=changes: rejected(lambda: resolve(**changes)))

    def invalid_unwind_arity():
        rejected(lambda: vm.ev(parse('(unwindProtect 1 2 3)')[0]))

    def crossing_return():
        vm.env[Sym('qaCleaned')] = None
        rejected(lambda: vm.ev(parse('(prog () (unwindProtect (return 1) (setq qaCleaned t)))')[0]))
        assert vm.env[Sym('qaCleaned')] is True

    check('host_rejects_native_invalid_unwind_arity', invalid_unwind_arity)
    check('host_rejects_return_crossing_unwind_but_runs_cleanup', crossing_return)

    def inner_return():
        vm.env[Sym('qaCleaned')] = None
        result = vm.ev(parse('(unwindProtect (prog () (return 7)) (setq qaCleaned t))')[0])
        assert result == 7 and vm.env[Sym('qaCleaned')] is True

    check('return_inside_inner_prog_remains_valid', inner_return)
    return dict(passed=all(c['pass_'] for c in checks), checks=checks,
                source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())


if __name__ == '__main__':
    import argparse
    import json
    parser = argparse.ArgumentParser()
    parser.add_argument('--source')
    args = parser.parse_args()
    result = run(args.source)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['passed'] else 1)
