#!/usr/bin/env python3
"""Finite-width route safety and effective-profile landing regressions.

Executes shipped SKILL in the host subset evaluator, not Cadence/OA or PDK DRC.
An optional source path lets the build review test its patched assembly first.
"""
from pathlib import Path

from check_geometry import VM

ROOT = Path(__file__).resolve().parents[1]


def run(source=None):
    vm = VM()
    vm.load(source or ROOT / 'tcoil.il')
    checks = []

    def check(name, fn):
        try:
            fn()
            checks.append(dict(name=name, pass_=True))
        except Exception as exc:
            checks.append(dict(name=name, pass_=False, error=str(exc)))

    def context():
        return dict(boundary=[[-10., -10.], [20., -10.], [20., 20.], [-10., 20.]],
                    objects=[], vias=[], routes=[], serial=0, grid=.001,
                    space=.5, leadWidth=1., viaBox=[-.5, -.5, .5, .5],
                    contactRadius=.5, routePreference='M2', maxStates=12000, viaCost=20.)

    def end_return(y):
        return [[0., 0., 1], [10., 0., 1], [10., 5., 1], [6., 5., 1], [6., y, 1]]

    def rejected(route):
        c = context()
        assert vm.call('tc5RouteCheck', c, route, []), 'Fixture must fit external obstacles/boundary'
        assert not vm.call('tc5RouteSelfOK', c, route), 'Finite-width return leg was accepted'

    def accepted(route):
        c = context()
        assert vm.call('tc5RouteCheck', c, route, [])
        assert vm.call('tc5RouteSelfOK', c, route), 'Legal intended join was rejected'

    def perpendicular_end_cap():
        route = end_return(.2)
        # The centreline ends at y=.2, but its width-1 square cap reaches -.3.
        # The first wire occupies [-.5,.5], giving .8 of physical overlap.
        first = vm.call('tc5StrokeBox', route[0][:2], route[1][:2], 1., True, True)
        last = vm.call('tc5StrokeBox', route[3][:2], route[4][:2], 1., True, True)
        assert first == [-.5, -.5, 10.5, .5]
        assert last == [5.5, -.3, 6.5, 5.5]
        assert vm.call('tc5Intersect', first, last)
        rejected(route)

    check('perpendicular_return_end_cap_short_is_rejected', perpendicular_end_cap)
    check('perpendicular_return_gap_below_clearance_is_rejected', lambda: rejected(end_return(1.2)))
    check('perpendicular_return_exact_clearance_is_allowed', lambda: accepted(end_return(1.5)))
    check('parallel_disjoint_centrelines_with_overlapping_caps_are_rejected', lambda: rejected(
        [[0., 0., 1], [2., 0., 1], [2., 5., 1], [6., 5., 1], [6., .2, 1], [2.4, .2, 1]]))
    check('adjacent_orthogonal_join_is_allowed', lambda: accepted(
        [[0., 0., 1], [5., 0., 1], [5., 5., 1]]))
    check('unconnected_crossing_on_different_layers_is_allowed', lambda: accepted(
        [[-5., 0., 1], [5., 0., 1], [5., 0., 2], [5., 5., 2], [0., 5., 2], [0., -5., 2]]))

    def profile_landing():
        values = dict(vm.call('tc5DefaultValues'))
        values.update(width1=4., width2=4., profile1='((-1 -1 0.5 -1))',
                      profile2='((-1 -1 0.5 -1))', techData='')
        values['projectData'] = vm.call('tc5ProjectEncode',
            '((40 12)(0 12)(0 0)(10 0)(10 5)(27 5)(27 0)(40 0))',
            [[[0., 2.], 2, 'AUTO'], [[40., 2.], 2, 'AUTO'], [[24., 12.], 2, 'AUTO']],
            .5, .005, '/synthetic/tech.tf', 'standard')
        p = vm.call('tc5ResolveValues', list(values.items()))
        assert p['geometryMaxWidth'] == p['leadWidth'] == .5
        assert vm.call('tc5ViaLandingBox', p, [-.5, -.5, .5, .5]) == [-.5, -.5, .5, .5], \
            'Overridden nominal widths still inflated the landing'
        # A local widening must still cover both metals at the widened width.
        values['profile1'] = '((-1 -1 0.5 -1)(0 2 2.0 -1))'
        p = vm.call('tc5ResolveValues', list(values.items()))
        assert p['geometryMaxWidth'] == 2.
        assert vm.call('tc5ViaLandingBox', p, [-.5, -.5, .5, .5]) == [-1., -1., 1., 1.]

    check('effective_profile_width_replaces_nominal_landing_width', profile_landing)

    def legacy_landing():
        p = dict(width1=2., width2=1., leadWidth=.5, grid=.005)
        assert vm.call('tc5ViaLandingBox', p, [-.5, -.5, .5, .5]) == [-1., -1., 1., 1.]

    check('unprepared_legacy_width_fallback_is_preserved', legacy_landing)
    return dict(passed=all(c['pass_'] for c in checks), checks=checks)


if __name__ == '__main__':
    import json
    result = run()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['passed'] else 1)
