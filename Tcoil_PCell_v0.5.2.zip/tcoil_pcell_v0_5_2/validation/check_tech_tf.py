"""Exercise the actual shipped SKILL tech.tf lexer, parser and import guards."""
from pathlib import Path
import json
from check_geometry import VM, SkillError, defaults

ROOT=Path(__file__).resolve().parents[1]

def run():
    v=VM();v.load(ROOT/'tcoil.il');checks=[]
    sample=(ROOT/'validation/tech_fixtures/example.tech.tf').read_text()
    row='(V21 M1 M2 ("C2" 0.324 0.324) (2 3 (0.306 0.306)) (0.071 0.018) (0.018 0.071) (0 0) (0 0) (0 0))'
    def document(r=row,head=''):
        return head+'\nviaDefs(standardViaDefs(\n'+r+'\n))'
    def read(text,m1='M1',m2='M2',name='V21'):
        return dict(v.call('tc5TFSelect',v.call('tc5TFParse',text),m1,m2,name))
    def check(name,fn):
        try:fn();checks.append(dict(name=name,pass_=True))
        except Exception as e:checks.append(dict(name=name,pass_=False,error=str(e)))
    def eq(a,b):assert a==b,(a,b)
    def fails(fn):
        try:fn()
        except SkillError:return
        raise AssertionError('unsafe/invalid technology accepted')
    check('cut_size_spacing_rows_cols',lambda:eq([read(document())[k] for k in ['cutWidth','cutHeight','cutSpaceX','cutSpaceY','viaRows','viaCols']], [.324,.324,.306,.306,2,3]))
    check('forward_enclosure',lambda:eq([read(document())[k] for k in ['enc1X','enc1Y','enc2X','enc2Y']],[.071,.018,.018,.071]))
    check('reversed_metal_order_enclosure',lambda:eq([read(document(),m1='M2',m2='M1')[k] for k in ['enc1X','enc1Y','enc2X','enc2Y']],[.018,.071,.071,.018]))
    check('unique_via_auto_selection',lambda:eq(read(document(),name='')['viaDefName'],'V21'))
    check('explicit_ambiguous_pair_required',lambda:fails(lambda:read(document(row+'\n'+row.replace('V21','V21_alt')),name='')))
    check('missing_pair_rejected',lambda:fails(lambda:read(document(),m2='M3')))
    check('wrong_via_rejected',lambda:fails(lambda:read(document(),name='missing')))
    check('conflicting_duplicate_rejected',lambda:fails(lambda:read(document(row+'\n'+row.replace('0.324','0.400')))))
    check('identical_duplicate_accepted',lambda:eq(read(document(row+'\n'+row))['cutWidth'],.324))
    check('nonzero_offset_rejected',lambda:fails(lambda:read(document(row.replace('(0 0) (0 0) (0 0)','(0.1 0) (0 0) (0 0)')))))
    check('extra_implant_fields_rejected',lambda:fails(lambda:read(document(row[:-1]+' (NIMP (0.1 0.1)))'))))
    check('cut_pattern_rejected',lambda:fails(lambda:read(document(row.replace('(2 3 (0.306 0.306))','(2 3 (0.306 0.306) (1 0))')))))
    check('unresolved_param_rejected',lambda:fails(lambda:read(document(row.replace('0.324','unknown')))))
    check('negative_enclosure_rejected',lambda:fails(lambda:read(document(row.replace('0.071','-0.071')))))
    check('zero_cut_size_rejected',lambda:fails(lambda:read(document(row.replace('0.324','0')))))
    check('fractional_array_count_rejected',lambda:fails(lambda:read(document(row.replace('(2 3 (','(2.5 3 (')))))
    check('block_comments_and_whitespace_calls',lambda:eq(read('viaDefs /* hi */ ( standardViaDefs ( '+row+' ))')['cutWidth'],.324))
    check('quoted_layer_followed_by_vector',lambda:eq(read(document(row.replace('V21 M1 M2','"V21" "M1" "M2"')))['enc2Y'],.071))
    check('prefix_sections',lambda:eq(read('(viaDefs (standardViaDefs '+row+'))')['cutWidth'],.324))
    check('unbalanced_parenthesis_rejected',lambda:fails(lambda:v.call('tc5TFParse',document()+'(')))
    check('unterminated_string_rejected',lambda:fails(lambda:v.call('tc5TFParse','"missing')))
    check('unterminated_comment_rejected',lambda:fails(lambda:v.call('tc5TFParse','/* missing')))
    check('parameter_reference_and_optional_origin',lambda:eq(read(sample,m1='TM1',m2='TM2',name='TM2_TM1')['cutHeight'],.324))
    check('manufacturing_grid_import',lambda:eq(read(sample,m1='TM1',m2='TM2',name='TM2_TM1')['grid'],.001))
    check('scientific_numeric_literals',lambda:eq(read(document(row.replace('0.324','3.24e-1')))['cutWidth'],.324))
    check('cyclic_tech_param_rejected',lambda:fails(lambda:read(document(row.replace('0.324','cyc'),'techParams((cyc techParam("cyc")))'))))
    check('unknown_units_rejected',lambda:fails(lambda:read(document(head='viewTypeUnits((maskLayout "nanometer" 1000))'))))
    check('conflicting_grids_rejected',lambda:fails(lambda:read(document(head='mfgGridResolution((.001)) mfgGridResolution((.002))'))))
    check('technology_code_not_executed',lambda:eq(read(document(head='exit() system("should never execute")'))['cutWidth'],.324))
    selected=v.call('tc5TFSelect',v.call('tc5TFParse',document()),'M2','M1','V21')
    snap=v.call('tc5TFSnapshot',selected,'M2','M1')
    p=defaults();p.update(dict(selected));p.update(metal1='M2',metal2='M1',viaMode='techfile',techFile='/case/tech.tf',tfSourcePath='/case/tech.tf',tfSnapshot=snap)
    check('snapshot_roundtrip_guard',lambda:eq(v.call('tc5TFGuard',p),True))
    check('array_counts_editable_after_import',lambda:eq(v.call('tc5TFGuard',dict(p,viaRows=4,viaCols=5)),True))
    check('snapshot_dimension_tampering_rejected',lambda:fails(lambda:v.call('tc5TFGuard',dict(p,enc1X=.001))))
    check('changed_path_requires_refresh',lambda:fails(lambda:v.call('tc5TFGuard',dict(p,techFile='/other/tech.tf'))))
    check('changed_metal_pair_requires_refresh',lambda:fails(lambda:v.call('tc5TFGuard',dict(p,metal1='M3'))))
    check('changed_via_requires_refresh',lambda:fails(lambda:v.call('tc5TFGuard',dict(p,viaDefName='wrong'))))
    return dict(passed=all(x['pass_'] for x in checks),checks=checks)

if __name__=='__main__':
    result=run();print(json.dumps(result,indent=2));raise SystemExit(0 if result['passed'] else 1)
