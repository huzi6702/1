#!/usr/bin/env python3
"""Native 20-vertex regression, including actual metal width on edge 18."""
import argparse
import hashlib
import json
from pathlib import Path

from check_geometry import parse
from check_polygon import boundary_text
from run_native_matrix import ROOT, NATIVE, TOPOLOGIES, run


def cases():
    points = [[0, 0], [108, 0], [108, 40]]
    y = 40
    for step in range(8, 0, -1):
        points.append([step*12, y])
        y += 12
        points.append([step*12, y])
    points.append([0, y])
    assert len(points) == 20
    boundary = boundary_text(points)
    pins = [[0, 20, 2], [108, 20, 2], [6, y, 2]]
    rows = [dict(name='staircase20_'+topology, shape='staircase20', topology=topology,
                 boundary=boundary, pins=pins, params=dict(topology=topology), expected=True)
            for topology in TOPOLOGIES]
    rows.append(dict(name='staircase20_profile18', shape='staircase20', topology='contour',
                     variant='profile18', boundary=boundary, pins=pins,
                     params=dict(topology='contour', profile1='((0 18 0.8 -1))'), expected=True))
    return rows


def verify(report):
    assert report['source_sha256'] == hashlib.sha256((ROOT / 'tcoil.il').read_bytes()).hexdigest()
    case = next(c for c in report['cases'] if c['name'] == 'staircase20_profile18')
    if case.get('generated'):
        try:
            assert abs(case['ring_summary'][0]['widths'][18] - .8) < 1e-8
            path = Path(case.get('native_export', NATIVE / 'final_many_vertices.results/staircase20_profile18.sexp'))
            data = parse(path.read_text())[0]
            actual = [b for _, b, _, tag in data[3] if tag == 'W1_ring0']
            assert any(abs(min(b[2]-b[0], b[3]-b[1])-.8) < 1e-8 for b in actual), 'No actual OA segment with requested width'
            case['actual_profile_edge18_verified'] = True
        except Exception as exc:
            case.update(passed=False, audit_error=str(exc))
    report['passed'] = all(c['passed'] for c in report['cases'])
    (NATIVE / 'final_many_vertices_report.json').write_text(json.dumps(report, indent=2)+'\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collect', action='store_true')
    args = parser.parse_args()
    report = (json.loads((NATIVE / 'final_many_vertices_report.json').read_text()) if args.collect
              else run(cases(), 'final_many_vertices', 600))
    report = verify(report)
    print(sum(c['passed'] for c in report['cases']), '/', len(report['cases']), '20-vertex cases passed')
    raise SystemExit(0 if report['passed'] else 1)
