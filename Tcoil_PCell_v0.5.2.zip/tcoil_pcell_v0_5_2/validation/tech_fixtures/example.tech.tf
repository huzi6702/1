; Synthetic technology excerpt for parser tests; not a process rule deck.
controls(
  viewTypeUnits( (maskLayout "micron" 2000) )
  mfgGridResolution( (0.001) )
  techParams( (cut_w 0.324) (cut_h techParam("cut_w")) )
)
viaDefs(
  standardViaDefs(
    ; name layer1 layer2 cut array enc1 enc2 offset1 offset2 [origin]
    (TM2_TM1 TM1 TM2 ("TV2" techParam("cut_w") cut_h 0.0)
      (1 1 (0.306 0.306)) (0.071 0.018) (0.018 0.071) (0.0 0.0) (0.0 0.0))
  )
)
