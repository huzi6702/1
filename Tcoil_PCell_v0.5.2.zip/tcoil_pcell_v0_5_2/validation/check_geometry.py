#!/usr/bin/env python3
"""Execute the shipped prefix-SKILL geometry kernel in a limited host evaluator.

This is NOT Cadence SKILL and does NOT validate OA, CDF, PCell macro expansion,
stream-out, or a foundry DRC deck. It executes the same kernel source, then makes
independent rectangle-union/connectivity/terminal checks and a geometry gallery.
Python 3.9+ standard library only.
"""
import json, math, operator, re, sys, time
from pathlib import Path

class Sym(str): pass
class Ret(Exception):
    def __init__(self, v): self.v=v
class SkillError(Exception): pass
class Env(dict):
    def __init__(self, parent=None): super().__init__(); self.parent=parent
    def find(self,k):
        if k in self: return self
        if self.parent is not None: return self.parent.find(k)
        raise SkillError(f'Unbound symbol: {k}')
    def getval(self,k): return self.find(k)[k]
    def put(self,k,v):
        try: self.find(k)[k]=v
        except SkillError: self[k]=v
        return v

def key(v): return tuple(key(x) for x in v) if isinstance(v,list) else v
def truth(v): return v is not None and v is not False and v != []
def numround(x): return math.floor(x+0.5) if x>=0 else math.ceil(x-0.5)
def parse(text):
    toks=re.findall(r';[^\n]*|"(?:\\.|[^"\\])*"|[()]|\x27|[^\s()\x27]+',text)
    toks=[x for x in toks if not x.startswith(';')]; pos=0
    def one():
        nonlocal pos
        if pos>=len(toks): raise SkillError('Unexpected EOF')
        t=toks[pos]; pos+=1
        if t=='(':
            out=[]
            while pos<len(toks) and toks[pos]!=')': out.append(one())
            if pos==len(toks): raise SkillError('Missing closing parenthesis')
            pos+=1; return out
        if t==')': raise SkillError(f'Extra closing parenthesis near token {pos}')
        if t=="'": return [Sym('quote'),one()]
        if t.startswith('"'): return json.loads(t)
        if re.fullmatch(r'[+-]?\d+',t): return int(t)
        if re.fullmatch(r'[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?',t): return float(t)
        return Sym(t)
    out=[]
    while pos<len(toks): out.append(one())
    return out

class VM:
    def __init__(self):
        self.env=Env(); self.env.update({Sym('nil'):None,Sym('t'):True})
        self.properties={}
        def fmt(_,s,*args):
            def skill(v):
                if isinstance(v,list):return '('+' '.join(skill(x) for x in v)+')'
                if v is None or v is False:return 'nil'
                if v is True:return 't'
                if isinstance(v,Sym):return str(v)
                if isinstance(v,str):return json.dumps(v)
                return str(v)
            if s=='%L':return skill(args[0])
            s=s.replace('%L','%s')
            try:return s % tuple(args)
            except Exception:return s+' '+str(args)
        def fail(s,*a): raise SkillError(fmt(None,s,*a))
        def append(*args):
            if len(args)!=2:
                raise SkillError(f'append: exactly 2 arguments expected, {len(args)} given')
            return (args[0] or [])+(args[1] or [])
        f={
          'car':lambda a:a[0] if a else None,'cadr':lambda a:a[1] if len(a)>1 else None,
          'cdr':lambda a:a[1:] if a else [],'cddr':lambda a:a[2:] if a else [],
          'nth':lambda n,a:a[n] if a and 0<=n<len(a) else None,'last':lambda a:a[-1:] if a else [],
          'list':lambda *a:list(a),'cons':lambda a,b:[a]+(b or []),'append':append,
          'reverse':lambda a:list(reversed(a or [])),'length':lambda a:len(a or []),
          'member':lambda a,b:b[b.index(a):] if a in (b or []) else None,'assoc':lambda a,b:next((x for x in (b or []) if x[0]==a),None),
          'equal':lambda a,b:a==b,'eq':lambda a,b:a==b,'null':lambda a:not truth(a),'not':lambda a:not truth(a),
          'lessp':operator.lt,'greaterp':operator.gt,'leqp':operator.le,'geqp':operator.ge,
          'plus':lambda *a:sum(a),'difference':lambda a,b:a-b,'times':lambda *a:math.prod(a),
          'quotient':lambda a,b:a/b,'abs':abs,'min':min,'max':max,'mod':operator.mod,'floor':math.floor,'round':numround,
          'makeTable':lambda *a:{},'arrayref':lambda a,k:a.get(key(k)),
          'setarray':lambda a,k,v:(a.__setitem__(key(k),v),v)[1],
          'sort':lambda a,fn:sorted(a),'strlen':len,'substring':lambda s,i,n:s[i-1:i-1+n],
          'parseString':lambda s,sep: [x for x in re.split('['+re.escape(sep)+']+',s) if x],
          'atof':float,'atoi':int,'sprintf':fmt,'printf':lambda s,*a: print(fmt(None,s,*a),end=''),'error':fail,'fixp':lambda x:isinstance(x,int) and not isinstance(x,bool),
          'listp':lambda x:isinstance(x,list) or x is None,
          'numberp':lambda x:isinstance(x,(int,float)) and not isinstance(x,bool),
          'stringp':lambda x:isinstance(x,str) and not isinstance(x,Sym),'strcat':lambda *a:''.join(a),
          'linereadstring':lambda s:parse(s),
          'buildString':lambda words,sep:'%s'%sep.join(words or []),
          'get':lambda symbol,prop:self.properties.get((str(symbol),str(prop))),
        }
        self.env.update({Sym(k):v for k,v in f.items()})
    def seq(self,body,e):
        v=None
        for x in body:v=self.ev(x,e)
        return v
    def ev(self,x,e=None):
        if e is None:e=self.env
        if isinstance(x,Sym): return e.getval(x)
        if not isinstance(x,list):return x
        if not x:return None
        op=x[0]; args=x[1:]
        if op=='quote':return args[0]
        if op=='procedure':
            name,*params=args[0]; body=args[1:]
            def fn(*values):
                ee=Env(self.env);optional=False;ix=0
                for p in params:
                    if p=='@optional':optional=True;continue
                    param=p[0] if isinstance(p,list) else p
                    if ix<len(values):ee[param]=values[ix];ix+=1
                    elif optional:ee[param]=self.ev(p[1],ee) if isinstance(p,list) else None
                    else:raise SkillError(f'{name}: missing {param}')
                if ix!=len(values):raise SkillError(f'{name}: too many arguments')
                return self.seq(body,ee)
            self.env[name]=fn;return name
        if op=='prog' or op=='let':
            ee=Env(e)
            for v in args[0]:
                if isinstance(v,list):ee[v[0]]=self.ev(v[1],e)
                else:ee[v]=None
            try:return self.seq(args[1:],ee)
            except Ret as r:
                if op=='prog':return r.v
                raise
        if op=='return':raise Ret(self.ev(args[0],e) if args else None)
        if op=='progn':return self.seq(args,e)
        if op=='errset':
            try:
                value=self.ev(args[0],e)
                self.properties[('errset','errset')]=None
                return [value]
            except Exception as exc:
                self.properties[('errset','errset')]=['error',0,True,None,[str(exc)]]
                return None
        if op in ('getq','dbGetq'):
            obj=self.ev(args[0],e);return obj.get(str(args[1]))
        if op=='putpropq':
            obj=self.ev(args[0],e);value=self.ev(args[1],e);obj[str(args[2])]=value;return value
        if op=='gets':
            line=self.ev(args[1],e).readline();e.put(args[0],line or None);return line or None
        if op=='unwindProtect':
            if len(args)!=2:raise SkillError('unwindProtect expects exactly two forms')
            try:
                try:return self.ev(args[0],e)
                except Ret:raise SkillError('return cannot cross unwindProtect evaluation')
            finally:self.ev(args[1],e)
        if op=='setq':
            if len(args)!=2:raise SkillError('SKILL setq requires exactly a variable and value')
            for i in range(0,len(args),2):v=e.put(args[i],self.ev(args[i+1],e))
            return v
        if op=='if':
            c=self.ev(args[0],e); rest=args[1:]
            if rest and rest[0]=='then':rest=rest[1:]
            if Sym('else') in rest:
                ix=rest.index(Sym('else'));left=rest[:ix];right=rest[ix+1:]
            else:left=rest[:1];right=rest[1:]
            return self.seq(left if truth(c) else right,e)
        if op in ('when','unless'):
            c=truth(self.ev(args[0],e))
            return self.seq(args[1:],e) if c==(op=='when') else None
        if op=='cond':
            for a in args:
                if truth(self.ev(a[0],e)):return self.seq(a[1:],e)
            return None
        if op=='and':
            v=True
            for a in args:
                v=self.ev(a,e)
                if not truth(v):return None
            return v
        if op=='or':
            for a in args:
                v=self.ev(a,e)
                if truth(v):return v
            return None
        if op=='while':
            v=None
            while truth(self.ev(args[0],e)):v=self.seq(args[1:],e)
            return v
        if op=='foreach':
            ee=Env(e);v=None
            for a in self.ev(args[1],e) or []:ee[args[0]]=a;v=self.seq(args[2:],ee)
            return v
        if op=='for':
            ee=Env(e);v=None
            for i in range(int(self.ev(args[1],e)),int(self.ev(args[2],e))+1):ee[args[0]]=i;v=self.seq(args[3:],ee)
            return v
        fn=self.ev(op,e)
        return fn(*(self.ev(a,e) for a in args))
    def call(self,n,*args):return self.env.getval(Sym(n))(*args)
    def load(self,path):
        text=Path(path).read_text().split('; === OPENACCESS ADAPTER ===')[0]
        for form in parse(text):self.ev(form)

def defaults():
    """Current v0.5 sample values, resolved from a literal project/via snapshot."""
    root=Path(__file__).resolve().parents[1]
    vm=VM();vm.load(root/'tcoil.il')
    values={x['name']:x['default'] for x in json.loads((root/'parameters.json').read_text())}
    pins=[[[0.,2.],2,'AUTO'],[[40.,2.],2,'AUTO'],[[24.,12.],2,'AUTO']]
    values['projectData']=vm.call('tc5ProjectEncode',
        '((40 12)(0 12)(0 0)(10 0)(10 5)(27 5)(27 0)(40 0))',
        pins,.5,.001,'synthetic_validation.tech.tf','techfile')
    selected=vm.call('tc5TFSelect',vm.call('tc5TFParse',
        (root/'validation/tech_fixtures/example.tech.tf').read_text()),'TM1','TM2','TM2_TM1')
    values['techData']=vm.call('tc5TFSnapshot',selected,'TM1','TM2')
    return vm.call('tc5ResolveValues',[[Sym(k),v] for k,v in values.items()])

def context(vm,p):
    # Numerical fixture only. Real standard-via dimensions come from OA.
    vm.call('tc5PrepareGeometry',p);vm.call('tc5Validate',p)
    via_box=p.get('rawViaBox',[-1.,-1.,1.,1.])
    if p.get('viaMode')=='techfile':
        vm.call('tc5TFGuard',p)
        bx=p['viaCols']*p['cutWidth']+(p['viaCols']-1)*p['cutSpaceX']
        by=p['viaRows']*p['cutHeight']+(p['viaRows']-1)*p['cutSpaceY']
        hx=bx/2+max(p['enc1X'],p['enc2X']);hy=by/2+max(p['enc1Y'],p['enc2Y'])
        via_box=[-hx,-hy,hx,hy]
    via_box=vm.call('tc5ViaLandingBox',p,via_box)
    return vm.call('tc5MakeContext',p,via_box)

if __name__=='__main__':
    vm=VM();vm.load(Path(__file__).parents[1]/'tcoil.il')
    p=defaults();c=context(vm,p)
    vm.call('tc5Geometry',c,p)
    print(json.dumps({'rectangles':len(c['objects']),'vias':len(c['vias']),'routes':len(c['routes'])}))
