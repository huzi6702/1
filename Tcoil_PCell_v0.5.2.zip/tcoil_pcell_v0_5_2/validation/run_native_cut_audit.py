#!/usr/bin/env python3
"""Verify actual VIA56 cut coordinates for three native array configurations."""
from run_native_matrix import run, SHAPES


if __name__ == '__main__':
    boundary, pins = SHAPES['rectangle']
    rows = [dict(name='cut_array_%d%d' % (r, c), shape='rectangle', topology='contour',
                 variant='cut_audit', boundary=boundary, pins=pins,
                 params=dict(topology='contour', viaRows=r, viaCols=c), expected=True)
            for r, c in ((1, 1), (1, 2), (2, 1))]
    report = run(rows, 'final_cut_audit', 180)
    assert all(c.get('actual_via_cuts_verified') for c in report['cases']), 'Actual cuts not verified'
    raise SystemExit(0 if report['passed'] else 1)
