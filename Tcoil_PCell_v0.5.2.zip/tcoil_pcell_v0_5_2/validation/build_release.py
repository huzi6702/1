#!/usr/bin/env python3
"""Package source, reproducible checks and final evidence; exclude QA databases."""
import difflib
import hashlib
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]


def build():
    version = (ROOT / 'VERSION').read_text().strip()
    prefix = 'tcoil_pcell_v' + version.replace('.', '_')
    paths = [p for p in ROOT.iterdir() if p.is_file() and p.name != 'SHA256SUMS']
    paths += list((ROOT / 'validation').glob('*.py'))
    paths += [p for p in (ROOT / 'em_estimator').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    paths += [ROOT / 'validation' / name for name in (
        'README_CN.md', 'TEST_RESULTS_CN.md', 'validation_report.json', 'geometry_sweep_report.json',
        'parameter_effects_report.json', 'polygon_report.json', 'default_topologies_report.json',
        'parameter_guide_report.json', 'route_staircase_fixture.json', 'repair_comparison_report.json')]
    paths += [p for p in (ROOT / 'validation/tech_fixtures').rglob('*') if p.is_file()]
    paths += [p for p in (ROOT / 'validation/legacy').rglob('*') if p.is_file()]
    native = ROOT / 'validation/native'
    paths += [native / name for name in ('harness.il', 'final_matrix_report.json', 'final_polygons_report.json',
                                       'final_many_vertices_report.json', 'final_cut_audit_report.json',
                                       'demo_report.json', 'demo.cds.lib', 'final_probe_report.json', 'final_many_other_052_report.json', 'native_gallery.html',
                                       'native_gallery.svg', 'native_gallery.png', 'native_gallery.json')]
    paths += sorted((native / 'native_exports').glob('*.sexp'))
    original = ROOT.parent / 'Tcoil_PCell_v0.5.0.zip'
    diff_path = ROOT / ('validation/v0.5.0_to_v' + version + '.diff')
    if original.exists():
        chunks = []
        with ZipFile(str(original)) as archive:
            names = set(archive.namelist())
            for path in sorted(set(paths)):
                relative = path.relative_to(ROOT).as_posix()
                if not (path.suffix in ('.py', '.il', '.md') or relative in ('VERSION', 'parameters.json')):
                    continue
                archive_name = 'tcoil_pcell_v0_5_0/' + relative
                old = archive.read(archive_name).decode() if archive_name in names else ''
                new = path.read_text()
                chunks.extend(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                                  fromfile='v0.5.0/'+relative, tofile='v'+version+'/'+relative))
        diff_path.write_text(''.join(chunks))
        paths.append(diff_path)
    paths = sorted(set(paths))
    assert all(p.exists() for p in paths)
    sums = ''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in paths)
    (ROOT / 'SHA256SUMS').write_text(sums)
    paths.append(ROOT / 'SHA256SUMS')
    output = ROOT.parent / ('Tcoil_PCell_v' + version + '.zip')
    with ZipFile(str(output), 'w', ZIP_DEFLATED, compresslevel=9) as archive:
        for path in paths:
            archive.write(str(path), prefix+'/' + path.relative_to(ROOT).as_posix())
    with ZipFile(str(output)) as archive:
        assert archive.testzip() is None
        for line in archive.read(prefix+'/SHA256SUMS').decode().splitlines():
            wanted, relative = line.split('  ', 1)
            actual = hashlib.sha256(archive.read(prefix+'/' + relative)).hexdigest()
            assert actual == wanted, relative
    print('Built', output, 'with', len(paths), 'files;', output.stat().st_size, 'bytes. All packaged checksums verified.')


if __name__ == '__main__':
    build()
