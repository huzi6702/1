#!/usr/bin/env python3
"""Run reusable kernel and v0.5 project/interface host regressions.

Full layout cases are produced by the separate geometry regression script.
No Cadence executable, OpenAccess database, or foundry DRC deck is invoked.
"""
import hashlib
import json
from pathlib import Path
import time

from check_tech_tf import run as check_tech_tf
from check_boundary import run as check_boundary
from check_route_grid import run as check_route_grid
from check_connection_planner import run as check_connection_planner
from check_v050_interface import run as check_v050_interface
from check_v050_regressions import run as check_v050_regressions
from check_polygon import run as check_polygon
from check_large_via import run as check_large_via
from check_search_repairs import run as check_search_repairs

ROOT = Path(__file__).resolve().parents[1]


def main():
    report = dict(source_sha256=hashlib.sha256((ROOT/'tcoil.il').read_bytes()).hexdigest(),
                  runtime='host SKILL-subset evaluator plus API mocks; NOT Cadence SKILL/OA',
                  limitations=['No Virtuoso compilation or PCell macro evaluation',
                               'No native CDF/OA/stream-out execution',
                               'No PDK DRC/LVS or electromagnetic validation'], suites={})
    for name, fn in [('technology_literals', check_tech_tf),
                     ('boundary_literals', check_boundary),
                     ('routing_grid', check_route_grid),
                     ('connection_planner', check_connection_planner),
                     ('compact_interface', check_v050_interface),
                     ('finite_width_regressions', check_v050_regressions),
                     ('simple_polygon_boundaries', check_polygon),
                     ('large_via_and_native_control', check_large_via),
                     ('adaptive_search_and_backtracking', check_search_repairs)]:
        begin = time.monotonic()
        try:
            result = fn()
        except Exception as exc:
            result = dict(passed=False, checks=[], error=str(exc))
        result['host_seconds'] = round(time.monotonic()-begin, 3)
        report['suites'][name] = result
        print(name, 'PASS' if result['passed'] else 'FAIL', len(result.get('checks', [])), 'checks', flush=True)
        for check in result.get('checks', []):
            if not check['pass_']:
                print('  FAIL', check['name'], check.get('error', ''), flush=True)
        if result.get('error'):
            print('  ERROR', result['error'], flush=True)
    report['passed'] = all(suite['passed'] for suite in report['suites'].values())
    report['check_count'] = sum(len(suite.get('checks', [])) for suite in report['suites'].values())
    (ROOT/'validation/validation_report.json').write_text(json.dumps(report, indent=2)+'\n')
    print('PASS' if report['passed'] else 'FAIL', report['check_count'], 'host checks')
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
