"""Literal boundary interface regression checks; no Cadence runtime required."""
from pathlib import Path
from check_geometry import VM, SkillError

ROOT = Path(__file__).resolve().parents[1]

def run():
    vm = VM(); vm.load(ROOT / 'tcoil.il'); checks = []
    def record(name, fn):
        try: fn(); checks.append(dict(name=name, pass_=True))
        except Exception as exc: checks.append(dict(name=name, pass_=False, error=str(exc)))
    def accepted(text, expected):
        actual = vm.call('tc5ParseBoundary', text, .005)
        assert actual == expected, (actual, expected)
    def rejected(text):
        try: vm.call('tc5ParseBoundary', text, .005)
        except SkillError: return
        raise AssertionError('Malformed boundary accepted: ' + text)
    rect = [[0.,0.],[160.,0.],[160.,120.],[0.,120.]]
    cases = [
      ('compact_rectangle', '((0 0)(160 0)(160 120)(0 120))', rect),
      ('spaces_and_newlines', '(\n (0\t0) (160 0)\r\n (160 120) (0 120)\n)', rect),
      ('clockwise_and_rotated', '((160 120)(160 0)(0 0)(0 120))', rect),
      ('negative_coordinates', '((-10 -20)(150 -20)(150 100)(-10 100))', [[-10.,-20.],[150.,-20.],[150.,100.],[-10.,100.]]),
      ('concave_eight_points', '((0 0)(260 0)(260 200)(170 200)(170 110)(90 110)(90 200)(0 200))', [[0.,0.],[260.,0.],[260.,200.],[170.,200.],[170.,110.],[90.,110.],[90.,200.],[0.,200.]]),
      ('signed_decimal', '((+0.0 -.000)(160.000 0)(160 120)(0 120))', rect),
    ]
    for name, text, expected in cases:
        record(name, lambda text=text, expected=expected: accepted(text, expected))
    invalid = {
      'old_delimiters_rejected':'0,0;160,0;160,120;0,120',
      'unwrapped_pairs_rejected':'(0 0)(160 0)(160 120)(0 120)',
      'missing_close_rejected':'((0 0)(160 0)(160 120)(0 120)',
      'extra_close_rejected':'((0 0)(160 0)(160 120)(0 120)))',
      'three_coordinates_rejected':'((0 0 9)(160 0)(160 120)(0 120))',
      'single_coordinate_rejected':'((0)(160 0)(160 120)(0 120))',
      'flattened_list_rejected':'(0 0 160 0 160 120 0 120)',
      'quoted_numbers_rejected':'(("0" 0)(160 0)(160 120)(0 120))',
      'expression_rejected':'((plus(0 0) 0)(160 0)(160 120)(0 120))',
      'trailing_code_rejected':'((0 0)(160 0)(160 120)(0 120)) system("ignored")',
      'repeated_closing_vertex_rejected':'((0 0)(160 0)(160 120)(0 120)(0 0))',
      'two_corner_bbox_rejected':'((0 0)(160 120))',
      'comma_coordinates_rejected':'((0,0)(160,0)(160,120)(0,120))',
      'off_grid_rejected':'((0 0)(160.003 0)(160.003 120)(0 120))',
    }
    for name, text in invalid.items():
        record(name, lambda text=text: rejected(text))
    return dict(passed=all(x['pass_'] for x in checks), checks=checks)

if __name__ == '__main__':
    import json
    report=run(); print(json.dumps(report, indent=2))
    raise SystemExit(0 if report['passed'] else 1)
