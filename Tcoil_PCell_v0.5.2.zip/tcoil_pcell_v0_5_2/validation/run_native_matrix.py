#!/usr/bin/env python3
"""Reproducible native Virtuoso/OA matrix; never modifies the supplied PDK.

Use /usr/bin/python3 on this workstation (the default python3 is Python 3.7).
Results include actual OA metal rectangles, independently audited after emission.
"""
import argparse
import hashlib
import json
import os
import signal
import re
import shutil
from pathlib import Path
import subprocess
import sys
import time

from check_geometry import parse
from audit_geometry import audit

ROOT = Path(__file__).resolve().parents[1]
NATIVE = ROOT / 'validation/native'
TOPOLOGIES = ('contour', 'interleaved', 'stacked', 'split_lobe')
SHAPES = {
    'original': ('((40 12)(0 12)(0 0)(10 0)(10 5)(27 5)(27 0)(40 0))',
                 [[0, 2, 2], [40, 2, 2], [24, 12, 2]]),
    'rectangle': ('((0 0)(80 0)(80 50)(0 50))',
                  [[0, 10, 2], [80, 10, 2], [48, 50, 2]]),
    'wide_notch': ('((0 0)(20 0)(20 10)(54 10)(54 0)(80 0)(80 50)(0 50))',
                   [[0, 10, 2], [80, 10, 2], [48, 50, 2]]),
    'top_notch': ('((0 0)(80 0)(80 50)(54 50)(54 35)(20 35)(20 50)(0 50))',
                  [[0, 10, 2], [80, 10, 2], [48, 35, 2]]),
}
VARIANTS = {
    'default': {},
    'cw_cw': {'sense1': 'CW', 'sense2': 'CW'},
    'ccw_cw': {'sense1': 'CCW', 'sense2': 'CW'},
    'ccw_ccw': {'sense1': 'CCW', 'sense2': 'CCW'},
    'widths': {'width1': 1.2, 'width2': .8},
    'spacing': {'space1': .75, 'space2': 1.0},
    'insets': {'inset1': .25, 'inset2': .25},
    'offset': {'inset1': .5, 'inset2': .5, 'offsetX': .1, 'offsetY': -.1},
    'profile': {'profile1': '((0 2 0.8 -1))', 'profile2': '((0 1 0.8 -1))'},
    'turns21': {'turns1': 2, 'interleaveBlock': 1},
    'turns12': {'turns2': 2},
    'block2': {'turns1': 2, 'interleaveBlock': 2},
    'via12': {'viaCols': 2},
    'via21': {'viaRows': 2},
    'lobegap': {'lobeGap': 1.0},
}
INVALID = {
    'zero_width': {'width1': 0.0}, 'zero_turns': {'turns1': 0},
    'too_many_turns': {'turns1': 16},
    'negative_inset': {'inset2': -.1}, 'bad_space': {'space1': .1},
    'off_grid_width': {'width1': 1.003}, 'off_grid_offset': {'offsetX': .003},
    'bad_sense': {'sense2': 'invalid'}, 'bad_topology': {'topology': 'invalid'},
    'bad_via': {'viaDefName': 'invalid'}, 'same_metals': {'metal2': 'METAL5'},
    'zero_via_rows': {'viaRows': 0}, 'bad_profile': {'profile1': '((99 0 1 -1))'},
}


def literal(value):
    if isinstance(value, str):
        return json.dumps(value)
    if isinstance(value, (tuple, list)):
        return 'list(' + ' '.join(literal(v) for v in value) + ')'
    return repr(value)


def cases(quick=False):
    variants = {'default': {}} if quick else VARIANTS
    rows = []
    for shape, (boundary, pins) in SHAPES.items():
        for topology in TOPOLOGIES:
            for variant, params in variants.items():
                # Stress cases on the original 12um outline are observed separately.
                rows.append(dict(name=shape + '_' + topology + '_' + variant,
                                 shape=shape, topology=topology, variant=variant,
                                 boundary=boundary, pins=pins,
                                 params=dict(params, topology=topology), expected=True))
    if not quick:
        boundary, pins = SHAPES['rectangle']
        rows.extend(dict(name='reject_' + name, shape='rectangle', boundary=boundary,
                         pins=pins, params=params, expected=False)
                    for name, params in INVALID.items())
    return rows



def cleanup_native_processes(log_path):
    """Remove native children left by a timed-out launcher, matching only its QA log."""
    target = str(Path(log_path).resolve()).encode()
    killed = []
    proc = Path('/proc')
    if not proc.is_dir():
        return killed
    for entry in proc.iterdir():
        if not entry.name.isdigit():
            continue
        try:
            args = (entry / 'cmdline').read_bytes().split(b'\0')
            if args and args[0].split(b'/')[-1] == b'virtuoso' and target in args:
                os.kill(int(entry.name), signal.SIGKILL)
                killed.append(int(entry.name))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    return killed


def run(rows, label, timeout, source=None):
    source = Path(source or ROOT / 'tcoil.il').resolve()
    source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    schema = {p['name']: p['type'] for p in json.loads((ROOT / 'parameters.json').read_text())}
    result_dir = NATIVE / (label + '.results')
    result_dir.mkdir(parents=True, exist_ok=True)
    lib_name = 'TCOIL_QA_' + re.sub('[^a-zA-Z0-9_]', '_', label)
    lib = NATIVE / lib_name
    lib.mkdir(exist_ok=True)
    (lib / '.pcell').mkdir(exist_ok=True)
    loaded_source = lib / '.pcell/tcoil.il'
    shutil.copyfile(str(source), str(loaded_source))
    (lib / 'libInit.il').write_text('load(' + literal(str(loaded_source)) + ')\n')
    (NATIVE / (label + '_manifest.json')).write_text(json.dumps(dict(
        source_sha256=source_hash, source_path=str(source), loaded_source=str(loaded_source),
        result_dir=str(result_dir), cases=rows), indent=2) + '\n')
    cds_lib = NATIVE / (label + '.cds.lib')
    cds_lib.write_text('INCLUDE /home/meow/tsmc18/cds.lib\nDEFINE ' + lib_name + ' ' + str(lib) + '\n')
    lines = ['load(' + literal(str(loaded_source)) + ')',
             'techBindTechFile(ddGetObj(' + literal(lib_name) + ') "tsmc18" "tech.db")',
             'qaLibraryName = ' + literal(lib_name), 'qaResultsPath = ' + literal(str(result_dir)),
             'load(' + literal(str(NATIVE / 'harness.il')) + ')',
             'tcoilInstall(' + literal(lib_name) + ' "METAL5" "METAL6" "M6_M5" "qa_master" "/home/meow/tsmc18/tech.tf")']
    for row in rows:
        path = result_dir / (row['name'] + '.sexp')
        if path.exists():
            path.unlink()
        params = [[k, 'float' if isinstance(v, float) and schema[k] == 'int' else schema[k], v]
                  for k, v in row['params'].items()]
        lines.append('qaRun(' + ' '.join([literal(row['name']), literal(row['boundary']),
                                        literal(row['pins']), literal(params),
                                        't' if row['expected'] else 'nil']) + ')')
    lines.append('exit()')
    script = NATIVE / (label + '.il')
    script.write_text('\n'.join(lines) + '\n')
    log = NATIVE / (label + '.stdout.log')
    start = time.monotonic()
    timed_out = False
    with script.open() as stdin, log.open('w') as stdout:
        try:
            process = subprocess.run(['virtuoso', '-nocdsinit', '-nograph', '-cdslib', str(cds_lib),
                                      '-log', str(NATIVE / (label + '.cds.log'))],
                                     cwd='/home/meow/tsmc18', stdin=stdin, stdout=stdout,
                                     stderr=subprocess.STDOUT, timeout=timeout)
            exit_code = process.returncode
        except subprocess.TimeoutExpired:
            timed_out = True
            exit_code = None
            cleanup_native_processes(NATIVE / (label + '.cds.log'))
    return collect(rows, label, source_hash, loaded_source, result_dir, log,
                   round(time.monotonic() - start, 2), exit_code, timed_out)


def collect(rows, label, source_hash, source, result_dir, log, elapsed=None,
            exit_code=None, timed_out=False):
    results = []
    log_text = log.read_text(errors='replace')
    for row in rows:
        item = dict(row)
        path = result_dir / (row['name'] + '.sexp')
        item['passed'] = False
        item['native_export'] = str(path.resolve())
        if path.exists():
            def clean(value):
                if isinstance(value, list):
                    return [clean(v) for v in value]
                return None if value == 'nil' else value
            data = clean(parse(path.read_text())[0])
            generated = data[1] is True or data[1] == 't'
            item['generated'] = generated
            if len(data)>14:
                item['generation_attempts'],item['search_work'],item['generation_failures'],item['failure_class']=data[14]
                if item['failure_class'] in ('search_budget_total','search_budget_trial'):
                    item['status']='search_budget'
            item['passed'] = generated == row['expected']
            if generated:
                context = dict(objects=data[3], vias=data[4] or [], pins=data[5], boundary=data[6])
                try:
                    if len(data) > 10:
                        assert data[10] == 1, 'Native polygon subtraction found out-of-bound metal'
                        item['native_boundary_subtraction'] = True
                    if len(data) > 11:
                        item['contour_mode'] = data[11]
                    if len(data) > 13:
                        rows, cols, cw, ch, sx, sy = data[13]
                        bx, by = cols*cw+(cols-1)*sx, rows*ch+(rows-1)*sy
                        wanted = set()
                        for x, y in {tuple(v[0]) for v in context['vias']}:
                            for j in range(int(rows)):
                                for i in range(int(cols)):
                                    left, bottom = x-bx/2+i*(cw+sx), y-by/2+j*(ch+sy)
                                    wanted.add(tuple(round(v,8) for v in (left,bottom,left+cw,bottom+ch)))
                        actual = {tuple(round(v,8) for v in box) for box in data[12] or []}
                        assert actual == wanted, ('Actual OA cut rectangles mismatch', len(actual), len(wanted))
                        item['actual_via_cuts_verified'] = True
                        item['actual_cut_count'] = len(actual)
                    item['audit'] = audit(context)
                    for _, box, _, _ in context['objects']:
                        assert all(abs(v / .005 - round(v / .005)) < 1e-6 for v in box), ('off-grid', box)
                    assert [p[0] for p in context['pins']] == [p[:2] for p in row['pins']], 'PIN moved'
                    rings = [dict(ring) for ring in data[7]]
                    for owner in (1, 2):
                        own = [ring for ring in rings if ring['owner'] == owner]
                        assert len(own) == row['params'].get('turns' + str(owner), 1), 'Wrong turn count'
                    item['ring_summary'] = rings
                    item['oa_rectangles'] = len(context['objects'])
                    item['via_count'] = len(context['vias'])
                except Exception as exc:
                    item.update(passed=False, audit_error=str(exc))
        else:
            item['error'] = 'Native result missing (process interrupted or setup failed)'
        if not item.get('generated'):
            block = log_text.split('QA_BEGIN ' + row['name'] + '\n')[-1].split('QA_END ' + row['name'])[0]
            errors = [line for line in block.splitlines() if 'TCOIL:' in line or '*Error*' in line]
            if errors:
                item['generation_error'] = errors[0][:1600]
        results.append(item)
        print(item['name'], 'PASS' if item['passed'] else 'FAIL', item.get('audit_error', ''), flush=True)
    assert source_hash == hashlib.sha256(source.read_bytes()).hexdigest(), 'Source changed during native validation'
    report = dict(passed=all(r['passed'] for r in results), source_sha256=source_hash,
                  runtime='Cadence IC617 native SKILL, pcDefinePCell, dbCreateParamInst and actual OA rectangles',
                  pdk='/home/meow/tsmc18/tsmc18', technology='/home/meow/tsmc18/tech.tf',
                  metals=['METAL5', 'METAL6'], via='M6_M5', grid_um=.005,
                  elapsed_seconds=elapsed, timed_out=timed_out,
                  exit_code=exit_code, cases=results,
                  source_path=str(source),
                  limitations=['No foundry DRC/LVS or EM extraction performed'])
    (NATIVE / (label + '_report.json')).write_text(json.dumps(report, indent=2) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--quick', action='store_true')
    parser.add_argument('--label', default='matrix')
    parser.add_argument('--timeout', type=int, default=1800)
    parser.add_argument('--filter', default='')
    parser.add_argument('--source')
    parser.add_argument('--polygons', action='store_true')
    parser.add_argument('--collect', action='store_true', help='Collect completed results using the saved manifest')
    args = parser.parse_args()
    if args.collect:
        manifest = json.loads((NATIVE / (args.label + '_manifest.json')).read_text())
        result = collect(manifest['cases'], args.label, manifest['source_sha256'],
                         Path(manifest['loaded_source']), Path(manifest['result_dir']),
                         NATIVE / (args.label + '.stdout.log'))
        raise SystemExit(0 if result['passed'] else 1)
    if args.polygons:
        from check_polygon import SHAPES as POLYGONS
        rows = [dict(name=shape + '_' + topology, shape=shape, topology=topology,
                     boundary=boundary, pins=pins, params=dict(topology=topology), expected=True)
                for shape, (boundary, pins) in POLYGONS.items() for topology in TOPOLOGIES]
    else:
        rows = cases(args.quick)
    rows = [row for row in rows if args.filter in row['name']]
    result = run(rows, args.label, args.timeout, args.source)
    raise SystemExit(0 if result['passed'] else 1)
