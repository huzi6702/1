#!/usr/bin/env python3
"""Build a standalone report and vector gallery from actual native OA exports."""
import argparse
import hashlib
import html
import json
from pathlib import Path

from check_geometry import parse

ROOT = Path(__file__).resolve().parents[1]
NATIVE = ROOT / 'validation/native'
COLORS = {1: '#3469c0', 2: '#d87927'}


def clean(value):
    if isinstance(value, list):
        return [clean(v) for v in value]
    return None if value == 'nil' else value


def read_exports(report_path):
    report = json.loads(report_path.read_text())
    label = report_path.name.removesuffix('_report.json') if hasattr(str, 'removesuffix') else report_path.name[:-12]
    result_dir = NATIVE / (label + '.results')
    manifest = NATIVE / (label + '_manifest.json')
    if manifest.exists():
        result_dir = Path(json.loads(manifest.read_text())['result_dir'])
    records = []
    for case in report['cases']:
        path = NATIVE / case['native_export_relative'] if case.get('native_export_relative') else Path(case['native_export']) if case.get('native_export') else result_dir / (case['name'] + '.sexp')
        data = clean(parse(path.read_text())[0]) if path.exists() else None
        records.append((case, data))
    return report, records


def svg_panel(case, data):
    points = data[6] if data and len(data) > 6 else parse(case['boundary'])[0] if case.get('boundary') else []
    if not points:
        return '<svg viewBox="0 0 100 60"><text x="5" y="30" font-size="6">No native geometry</text></svg>'
    x0 = min(p[0] for p in points)
    x1 = max(p[0] for p in points)
    y0 = min(p[1] for p in points)
    y1 = max(p[1] for p in points)
    span = max(x1 - x0, y1 - y0)
    margin = span * .08
    pieces = ['<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="' +
              html.escape(case['name']) + '" viewBox="%g %g %g %g">' %
              (x0-margin, -y1-margin, x1-x0+2*margin, y1-y0+2*margin)]
    pieces.append('<g transform="scale(1,-1)">')
    pieces.append('<polygon points="' + ' '.join('%g,%g' % tuple(p) for p in points) +
                  '" fill="#f4f6fa" stroke="#58616f" stroke-width="1" vector-effect="non-scaling-stroke"/>')
    if case.get('generated'):
        for layer, box, _, _ in sorted(data[3], key=lambda ob: ob[0]):
            pieces.append('<rect x="%g" y="%g" width="%g" height="%g" fill="%s" opacity=".72"/>' %
                          (box[0], box[1], box[2]-box[0], box[3]-box[1], COLORS[layer]))
        for point, _ in data[4] or []:
            pieces.append('<circle cx="%g" cy="%g" r="%g" fill="#162034"/>' %
                          (point[0], point[1], span*.0035))
    pieces.append('</g>')
    if case.get('generated'):
        for point, _, _, name, _ in data[5]:
            pieces.append('<text x="%g" y="%g" font-size="%g" font-family="sans-serif" fill="#111827" ' %
                          (point[0]+span*.012, -point[1]-span*.012, span*.035) +
                          'paint-order="stroke" stroke="white" stroke-width=".25">' + html.escape(name) + '</text>')
    else:
        pieces.append('<text x="%g" y="%g" text-anchor="middle" font-size="%g" fill="#b42318">Generation failed</text>' %
                      ((x0+x1)/2, -(y0+y1)/2, span*.045))
    pieces.append('</svg>')
    return ''.join(pieces)


def build(report_paths, output):
    source_hash = hashlib.sha256((ROOT / 'tcoil.il').read_bytes()).hexdigest()
    reports = []
    records = []
    for path in report_paths:
        report, exported = read_exports(path)
        assert report['source_sha256'] == source_hash, 'Stale report: ' + str(path)
        assert not any(c.get('error', '').startswith('Native result missing') for c in report['cases']), 'Incomplete report: ' + str(path)
        reports.append(report)
        records.extend(exported)
    defaults = [(case, data) for case, data in records
                if case.get('expected') and case.get('variant', 'default') == 'default']
    summaries = []
    for report in reports:
        rows = report['cases']
        positives = [r for r in rows if r['expected']]
        negatives = [r for r in rows if not r['expected']]
        summaries.append(dict(cases=len(rows), requested_generation=len(positives),
                              generated=sum(bool(r.get('generated')) for r in positives),
                              audited=sum(bool(r.get('generated')) and r['passed'] for r in positives),
                              rejected_inputs=sum(r['passed'] for r in negatives), invalid_inputs=len(negatives)))
    cards = []
    for case, data in defaults:
        status = '通过' if case['passed'] else '未生成' if not case.get('generated') else '审计失败'
        cards.append('<article class="card ' + ('ok' if case['passed'] else 'bad') + '"><h3>' +
                     html.escape(case['name']) + '</h3><div class="plot">' + svg_panel(case, data) +
                     '</div><p>' + status + ' · ' + html.escape(case.get('contour_mode', '') or '') + '</p></article>')
    table_rows = []
    for case, _ in records:
        status = ('执行超时' if case.get('status') == 'native_timeout' else
                  '生成并通过审计' if case.get('generated') and case['passed'] else
                  '预期拒绝' if not case['expected'] and case['passed'] else
                  '审计失败' if case.get('generated') else '未生成')
        detail = case.get('error') if case.get('status') == 'native_timeout' else case.get('audit_error') or case.get('generation_error') or case.get('error') or ''
        table_rows.append('<tr data-search="' + html.escape((case['name'] + ' ' + status).lower()) + '"><td>' +
                          html.escape(case['name']) + '</td><td>' + status + '</td><td><code>' +
                          html.escape(json.dumps(case.get('params', {}), ensure_ascii=False)) +
                          '</code>' + ('<details><summary>原因</summary><pre>' + html.escape(detail) + '</pre></details>' if detail else '') +
                          '</td></tr>')
    summary_text = '；'.join(('%d 个用例：%d/%d 个生成请求通过 OA 审计' %
                            (s['cases'], s['audited'], s['requested_generation'])) +
                            ('，%d/%d 个无效输入按预期拒绝' % (s['rejected_inputs'], s['invalid_inputs']) if s['invalid_inputs'] else '')
                            for s in summaries)
    document = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>T-coil 原生 OA 验证 · v0.5.2</title><style>
body{font:15px/1.6 system-ui,sans-serif;color:#202a3a;background:#f7f8fa;margin:0}main{max-width:1400px;margin:auto;padding:32px}
h1{font-size:30px;margin-bottom:6px}h2{margin-top:36px}p{max-width:1100px}.meta{word-break:break-all;color:#536174;font-size:13px}
.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.card{background:white;border:1px solid #d8dee8;border-top:3px solid #468662;border-radius:6px;padding:12px}
.card.bad{border-top-color:#c65345}.card h3{font-size:13px;margin:0;overflow-wrap:anywhere}.plot{height:220px}.plot svg{width:100%;height:100%}.card p{font-size:12px;color:#536174;margin:2px 0}
.legend span{display:inline-block;margin-right:24px}.swatch{display:inline-block;width:13px;height:13px;margin-right:7px}input{font:inherit;padding:8px 12px;border:1px solid #aab5c5;border-radius:4px;width:min(450px,90%)}
.scroll{overflow:auto}table{border-collapse:collapse;width:100%;background:white;font-size:13px}td,th{padding:9px;text-align:left;border-bottom:1px solid #dde3ed;vertical-align:top}th{position:sticky;top:0;background:#eaf0f8}td:first-child{white-space:nowrap}code{font-size:12px}pre{white-space:pre-wrap;word-break:break-word;max-width:800px}summary{cursor:pointer;color:#a44032}
@media(max-width:1000px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:560px){main{padding:16px}.grid{grid-template-columns:1fr}}
</style><main><h1>T-coil 原生 OA 验证</h1><p>'''+html.escape(summary_text)+'''</p>
<p>图形直接来自原生 PCell 输出的 OA 金属矩形。检查包括精确 PIN 端点、连通分量、意外导电环路、0.005 µm 网格及原生多边形差运算。未运行 foundry DRC/LVS 或 EM。</p>
<p>斜边边界使用内接矩形绕组，导体保持曼哈顿几何；部分堆叠形状也会回退到内接矩形。失败卡片只画请求的边界，不画未完成的导体。未生成或超时不代表所有可能结构都不可行。</p>
<p class="meta">METAL5 / METAL6 · M6_M5 · TSMC18 · source SHA-256: '''+source_hash+'''</p>
<p class="legend"><span><i class="swatch" style="background:#3469c0"></i>METAL5</span><span><i class="swatch" style="background:#d87927"></i>METAL6</span><span>黑点：过孔中心</span></p>
<h2>默认形状与四种拓扑</h2><div class="grid">'''+''.join(cards)+'''</div>
<h2>全部参数用例</h2><label>筛选用例或结果 <input id="filter" type="search" placeholder="例如 stacked、triangle、未生成"></label>
<div class="scroll"><table><thead><tr><th>用例</th><th>结果</th><th>参数与原因</th></tr></thead><tbody>'''+''.join(table_rows)+'''</tbody></table></div>
<script>document.getElementById('filter').addEventListener('input',function(){const q=this.value.toLowerCase();document.querySelectorAll('tbody tr').forEach(r=>r.hidden=!r.dataset.search.includes(q));});</script></main></html>'''
    output.with_suffix('.html').write_text(document)
    cell_w, cell_h = 330, 290
    height = 75 + ((len(defaults)+3)//4)*cell_h
    panels = ['<svg xmlns="http://www.w3.org/2000/svg" width="1320" height="%d" viewBox="0 0 1320 %d">' % (height, height),
              '<rect width="100%" height="100%" fill="white"/><text x="20" y="28" font-size="20" font-family="sans-serif">T-coil native OA · METAL5 / METAL6 · v0.5.2</text>',
              '<text x="20" y="51" font-size="12" font-family="monospace">SHA-256: ' + source_hash + '</text>']
    for index, (case, data) in enumerate(defaults):
        x, y = (index % 4)*cell_w, 70+(index//4)*cell_h
        panel = svg_panel(case, data).replace('<svg ', '<svg x="%d" y="%d" width="310" height="240" ' % (x+10, y+30), 1)
        panels.append('<text x="%d" y="%d" font-size="12" font-family="sans-serif">%s [%s]</text>' %
                      (x+12, y+19, html.escape(case['name']), 'PASS' if case['passed'] else 'FAIL'))
        panels.append(panel)
    panels.append('</svg>')
    output.with_suffix('.svg').write_text(''.join(panels))
    output.with_suffix('.json').write_text(json.dumps(dict(source_sha256=source_hash, summaries=summaries,
                                                          reports=[str(p) for p in report_paths]), indent=2)+'\n')
    return defaults


def png_preview(records, path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Polygon, Rectangle
    rows = (len(records)+3)//4
    fig, axes = plt.subplots(rows, 4, figsize=(16, rows*3.5), squeeze=False)
    for ax in axes.flat:
        ax.set_axis_off()
    for ax, (case, data) in zip(axes.flat, records):
        if not data or len(data) < 7:
            continue
        ax.add_patch(Polygon(data[6], closed=True, fill=False, edgecolor='#555b65', linewidth=.8))
        if case.get('generated'):
            for layer, b, _, _ in sorted(data[3], key=lambda ob: ob[0]):
                ax.add_patch(Rectangle((b[0], b[1]), b[2]-b[0], b[3]-b[1],
                                       facecolor=COLORS[layer], alpha=.75, linewidth=0))
            for p, _, _, name, _ in data[5]:
                ax.text(p[0], p[1], name, fontsize=8)
        ax.autoscale_view()
        ax.set_aspect('equal')
        ax.set_title(case['name'] + (' · PASS' if case['passed'] else ' · FAIL'), fontsize=8)
    fig.tight_layout()
    fig.savefig(str(path), dpi=130, facecolor='white')
    plt.close(fig)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reports', nargs='+', default=['final_matrix_report.json', 'final_polygons_report.json', 'final_many_vertices_report.json', 'final_cut_audit_report.json'])
    parser.add_argument('--output', default='native_gallery')
    parser.add_argument('--png', action='store_true', help='Optional matplotlib preview; not required for HTML/SVG')
    args = parser.parse_args()
    paths = [NATIVE / p for p in args.reports]
    output = NATIVE / args.output
    records = build(paths, output)
    if args.png:
        png_preview(records, output.with_suffix('.png'))
    print('Built', len(records), 'native layout panels at', output.with_suffix('.html'))
