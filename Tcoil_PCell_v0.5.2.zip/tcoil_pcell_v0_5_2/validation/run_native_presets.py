#!/usr/bin/env python3
"""Install named shape examples through the public API into an isolated OA library."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

from check_geometry import parse
from run_native_matrix import literal, SHAPES
from check_polygon import SHAPES as POLYGONS

ROOT = Path(__file__).resolve().parents[1]
NATIVE = ROOT / 'validation/native'
DEMO = NATIVE / 'TCOIL_DEMO_052'


def run():
    support = DEMO / '.pcell'
    support.mkdir(parents=True, exist_ok=True)
    for name in ('tcoil.il', 'project_presets_tsmc18.il'):
        shutil.copyfile(str(ROOT / name), str(support / name))
    (DEMO / 'libInit.il').write_text('load(' + literal(str(support / 'tcoil.il')) + ')\n')
    cds_lib = NATIVE / 'demo.cds.lib'
    cds_lib.write_text('INCLUDE /home/meow/tsmc18/cds.lib\nDEFINE TCOIL_DEMO_052 ' + str(DEMO) + '\n')
    output = NATIVE / 'demo.results'
    output.mkdir(exist_ok=True)
    names = list(SHAPES) + list(POLYGONS)
    script = NATIVE / 'install_presets.il'
    lines = ['load(' + literal(str(support / 'tcoil.il')) + ')',
             'techBindTechFile(ddGetObj("TCOIL_DEMO_052") "tsmc18" "tech.db")',
             'load(' + literal(str(support / 'project_presets_tsmc18.il')) + ')']
    for name in names:
        path = output / (name + '.sexp')
        if path.exists():
            path.unlink()
        lines.append('''let((result master port record)
  result = errset(progn(
    master = tcoilInstallPreset("TCOIL_DEMO_052" %s)
    unless(and(master equal(master~>tcoilStatus "GEOMETRY_BUILT_NOT_SIGNOFF")
      equal(length(master~>terminals) 3)) error("Preset installation failed\\n"))
    list(master~>tcoilVersion length(master~>shapes) length(master~>terminals))) t)
  port = outfile(%s)
  fprintf(port "%%L\\n" list(%s result))
  close(port)
  when(master dbClose(master)))''' % (literal(name), literal(str(path)), literal(name)))
    lines.append('exit()')
    script.write_text('\n'.join(lines) + '\n')
    log = NATIVE / 'demo.stdout.log'
    with script.open() as stdin, log.open('w') as stdout:
        process = subprocess.run(['virtuoso', '-nocdsinit', '-nograph', '-cdslib', str(cds_lib),
                                  '-log', str(NATIVE / 'demo.cds.log')], cwd='/home/meow/tsmc18',
                                 stdin=stdin, stdout=stdout, stderr=subprocess.STDOUT, timeout=300)
    cases = []
    for name in names:
        path = output / (name + '.sexp')
        record = parse(path.read_text())[0] if path.exists() else [name, None]
        success = isinstance(record[1], list) and bool(record[1])
        cases.append(dict(name=name, passed=success, native_result=record[1]))
        print(name, 'PASS' if success else 'FAIL')
    report = dict(passed=all(c['passed'] for c in cases), cases=cases, exit_code=process.returncode,
                  source_sha256=hashlib.sha256((support / 'tcoil.il').read_bytes()).hexdigest(),
                  presets_sha256=hashlib.sha256((support / 'project_presets_tsmc18.il').read_bytes()).hexdigest(),
                  library=str(DEMO), cds_lib=str(cds_lib), runtime='Native public tcoilInstallPreset and CDF/PCell installation')
    (NATIVE / 'demo_report.json').write_text(json.dumps(report, indent=2)+'\n')
    return report


if __name__ == '__main__':
    raise SystemExit(0 if run()['passed'] else 1)
