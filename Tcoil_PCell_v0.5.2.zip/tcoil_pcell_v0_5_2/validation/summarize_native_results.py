#!/usr/bin/env python3
"""Merge disjoint native batches and write an evidence-based Chinese test report."""
import hashlib
import json
from pathlib import Path
import shutil

from run_native_matrix import ROOT, NATIVE, cases


def load(name, source_hash):
    report = json.loads((NATIVE / name).read_text())
    assert report['source_sha256'] == source_hash, 'Stale native batch: ' + name
    assert not any(c.get('error', '').startswith('Native result missing') for c in report['cases']), 'Incomplete batch: ' + name
    return report


def summarize():
    source_hash = hashlib.sha256((ROOT / 'tcoil.il').read_bytes()).hexdigest()
    existing = load('final_matrix_report.json', source_hash)
    batch_names = existing.get('batches', [])
    batches = [existing] if existing.get('collection_complete') else [load(name, source_hash) for name in [
        'final_orthogonal_batch_report.json', 'final_top_notch_report.json', 'final_invalid_report.json']]
    by_name = {}
    for batch in batches:
        for case in batch['cases']:
            assert case['name'] not in by_name, 'Duplicate native case: ' + case['name']
            by_name[case['name']] = case
    expected = cases()
    assert set(by_name) == {c['name'] for c in expected}, 'Missing or extra matrix cases'
    ordered = []
    for row in expected:
        case = by_name[row['name']]
        assert case['params'] == row['params'] and case['pins'] == row['pins']
        ordered.append(case)
    matrix = dict(batches[0], cases=ordered, passed=all(c['passed'] for c in ordered),
                  batches=batch_names, elapsed_seconds=None,
                  collection_note='Completed native evidence, each evaluated against an immutable identical source snapshot.')
    (NATIVE / 'final_matrix_report.json').write_text(json.dumps(matrix, indent=2)+'\n')
    polygons = load('final_polygons_report.json', source_hash)
    many = load('final_many_vertices_report.json', source_hash)
    cuts = load('final_cut_audit_report.json', source_hash)
    exports = NATIVE / 'native_exports'
    exports.mkdir(exist_ok=True)
    current_exports = set()
    for filename, report in [('final_matrix_report.json', matrix), ('final_polygons_report.json', polygons),
                             ('final_many_vertices_report.json', many), ('final_cut_audit_report.json', cuts)]:
        label = filename[:-12]
        manifest_path = NATIVE / (label+'_manifest.json')
        manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
        for case in report['cases']:
            if case.get('status') == 'native_timeout':
                continue
            relative = NATIVE / case['native_export_relative'] if case.get('native_export_relative') else None
            source = relative if relative and relative.exists() else Path(case['native_export']) if case.get('native_export') else Path(manifest.get('result_dir', NATIVE/(label+'.results'))) / (case['name']+'.sexp')
            assert source.exists(), 'Native export missing: '+str(source)
            target = exports / (case['name']+'.sexp')
            if source.resolve() != target.resolve():
                shutil.copyfile(str(source), str(target))
            current_exports.add(target.name)
            case['native_export_relative'] = 'native_exports/'+target.name
        (NATIVE / filename).write_text(json.dumps(report, indent=2)+'\n')
    for stale in exports.glob('*.sexp'):
        if stale.name not in current_exports:
            stale.unlink()
    demo = json.loads((NATIVE / 'demo_report.json').read_text())
    assert demo['source_sha256'] == source_hash and demo['passed']
    assert demo['presets_sha256'] == hashlib.sha256((ROOT / 'project_presets_tsmc18.il').read_bytes()).hexdigest()
    host = json.loads((ROOT / 'validation/validation_report.json').read_text())
    sweep = json.loads((ROOT / 'validation/geometry_sweep_report.json').read_text())
    effects = json.loads((ROOT / 'validation/parameter_effects_report.json').read_text())
    for report in (host, sweep, effects):
        assert report['source_sha256'] == source_hash and report['passed']

    reports = [('内核、参数接口及多边形宿主检查', host['check_count'], host['check_count']),
               ('宿主完整几何生成及独立连通性审计', sum(c['passed'] for c in sweep['cases']), len(sweep['cases'])),
               ('宿主参数作用检查', sum(c['passed'] for c in effects['checks']), len(effects['checks']))]
    comparison = json.loads((ROOT / 'validation/repair_comparison_report.json').read_text())
    assert comparison['source_sha256'] == source_hash
    lines = ['# T-coil v0.5.2 测试结果', '',
             '所有最终报告对应同一份内核源码；成功生成与“所有参数都能生成”是不同结论。压力矩阵保留未生成的组合，未将失败或超时记为通过。新隔离用例的单例时间上限为 120 秒（含启动）；先前已完成的结果保留原运行时间，超时不表示物理上无解。', '',
             '## 环境与结论', '',
             '- Virtuoso IC617，从 `/home/meow/tsmc18/` 启动。',
             '- 技术库 `/home/meow/tsmc18/tsmc18`；技术文本 `/home/meow/tsmc18/tech.tf`。',
             '- 使用 `METAL5`、`METAL6`、`M6_M5`，制造网格 0.005 µm。',
             '- 测试库与 `cds.lib` 独立，不修改用户的 PDK 或启动配置。',
             '- 原有四类边界 × 四种默认拓扑全部通过原生生成与 OA 审计（16/16）。', '',
             '| 检查 | 通过 | 总数 |', '|---|---:|---:|']
    lines += ['| %s | %d | %d |' % row for row in reports]
    for title, report in [('真实 PDK 参数生成请求', matrix), ('新增多边形 × 拓扑', polygons), ('20 顶点及高编号边 profile', many), ('实际 VIA56 阵列坐标与数量', cuts)]:
        positive = [c for c in report['cases'] if c['expected']]
        lines.append('| %s | %d | %d |' % (title, sum(c['passed'] for c in positive), len(positive)))
    invalid = [c for c in matrix['cases'] if not c['expected']]
    lines.append('| 原生无效参数按预期拒绝 | %d | %d |' % (sum(c['passed'] for c in invalid), len(invalid)))
    lines.append('| 公共安装 API / CDF / 项目模板 | %d | %d |' % (sum(c['passed'] for c in demo['cases']), len(demo['cases'])))
    lines += ['', '## 生成检查覆盖', '',
              '参数矩阵包含 4 种原有边界、4 种拓扑、4 种绕向组合，以及独立线宽、间距、内缩、偏移、局部 profile、2/1 与 1/2 轮廓、交错分组、1×2 / 2×1 过孔阵列和分叶间隔。无效输入包括零/负尺寸、超限匝数、非制造网格值、无效拓扑/绕向/层/过孔与越界 profile。', '',
              '这是有限的代表性参数扫描，不是全部参数的笛卡尔积，也不构成全参数域成功率估计。', '',
              '新增边界为 L 形、12 顶点十字、12 顶点阶梯、三角形、梯形、切角八边形、菱形和带斜边的凹形；另外验证 20 顶点轮廓及第 18 条边的 0.8 µm 局部线宽，检查实际 OA 矩形而不只检查参数回传。', '',
              '成功案例均检查实际 OA 金属矩形的三 PIN 端点、单一连通分量、零意外导电环路、0.005 µm 网格和原生多边形差运算的零越界面积。连通性审计以实际金属和生成器的过孔位置建立跨层连接；另对 1×1、1×2、2×1 阵列的实际 VIA56 cut 矩形逐一核对数量、尺寸和坐标。', '',
              '## 多边形扩展与限制', '',
              '边界输入已解除 4/8 顶点及直角限制，使用一般线段相交、边界点判定与矩形包含检查。直角边界通常保留原轮廓；斜边边界使用保守内接矩形绕组，导体仍为曼哈顿几何，没有沿斜边贴合的导体。分叶会选择边界内两个不重叠矩形；部分堆叠案例在 profile 为空时回退到内接矩形，并记录 `tcoilContourMode`。', '',
              '不支持带孔多边形、零长度边、自交/自接触、重复闭合点及冗余共线点。内接矩形候选网格不是全局最优求解；过密绕组、过大阵列或有限布线搜索失败不等于物理上不存在其他解。', '',
              '未运行 foundry DRC/LVS、S 参数或 EM 验证。PDK 初始化日志中的 HSPICE 工具注册错误发生在布局测试之前；布局许可已成功获取，原生 PCell 和几何审计结果单独记录。', '',
              '## 未生成或审计失败的用例', '']
    failures = [c for r in (matrix, polygons, many, cuts) for c in r['cases'] if not c['passed']]
    if failures:
        lines += ['| 用例 | 原因 |', '|---|---|']
        for case in failures:
            reason = case.get('error') if case.get('status') == 'native_timeout' else case.get('audit_error') or case.get('generation_error') or case.get('error') or '生成未通过'
            if case.get('status') == 'native_timeout':
                reason = '[执行超时] '+reason
            reason = reason.replace('|', '/').replace('\n', ' ')[:350]
            if 'TCOIL:' in reason:
                reason = 'TCOIL:'+reason.split('TCOIL:',1)[1].split('\\n',1)[0]
            lines.append('| `%s` | %s |' % (case['name'], reason))
    else:
        lines.append('本次测试范围内全部通过。')
    lines += ['', '## 与 v0.5.1 对比', '',
              '| 范围 | 先前通过 | 当前通过 | 新修复 | 回归 |', '|---|---:|---:|---:|---:|']
    for name, result in comparison['comparisons'].items():
        lines.append('| %s | %d | %d | %d | %d |' % (name, result['previous_positive_passed'], result['current_positive_passed'], len(result['repaired']), len(result['regressions'])))
    lines += ['', '逐例对比见 `repair_comparison_report.json`。预算停止与执行超时均表示可行性未定；内缩轮廓自交表示当前构造无效，未证明所有其他构造无解。', '',
              '## Python 估算器验证', '',
              '独立 `em_estimator/` 提供 1–50 GHz 的 L/R/M/K/Q、CSV、近似 S3P 和可选 FastHenry 导体输入文件。材料配置是明确标注的示例；未运行 FastHenry 或全波 EM，也未校准实际 TSMC18。数值无源性/互易性与格式检查不能证明物理精度。详细说明见 `../em_estimator/README_CN.md`。', '']
    em_functional_path = ROOT / 'em_estimator/functional_validation.json'
    em_unit_path = ROOT / 'em_estimator/unit_test_report.json'
    if em_functional_path.exists() and em_unit_path.exists():
        functional = json.loads(em_functional_path.read_text())
        unit = json.loads(em_unit_path.read_text())
        estimator_hash = hashlib.sha256((ROOT / 'em_estimator/estimate.py').read_bytes()).hexdigest()
        if (functional.get('source_sha256') == source_hash and functional.get('estimator_sha256') == estimator_hash
                and unit.get('estimator_sha256') == estimator_hash):
            lines += ['数值/文件格式单测：%d/%d；跨已审计版图的导入与被动网络功能检查：%d/%d。这些结果不构成 EM 精度验证。' % (
                unit['tests_run'] if unit['passed'] else unit['tests_run'] - len(unit['failures']), unit['tests_run'],
                sum(c['passed'] for c in functional['cases']), len(functional['cases'])), '']
    lines += ['', '## 查看与复现', '',
              '- `native/native_gallery.html`：实际 OA 版图及可筛选的完整参数表。',
              '- `native/native_gallery.svg` / `.png`：可分享的静态版图图集。',
              '- `native/final_matrix_report.json`：253 项参数矩阵。',
              '- `native/final_polygons_report.json` / `final_many_vertices_report.json`：新边界与 20 顶点测试。',
              '- `native/final_cut_audit_report.json`：实际过孔阵列矩形验证。',
              '- `native/demo.cds.lib`：可打开 `TCOIL_DEMO_052` 库，包含 12 个已安装的项目 PCell。', '',
              '```sh', '/usr/bin/python3 validation/run_validation.py',
              '/usr/bin/python3 validation/check_geometry_sweep.py --timeout 300', '/usr/bin/python3 validation/check_parameter_effects.py',
              '/usr/bin/python3 validation/run_parallel_matrix.py --workers 3 --case-timeout 120',
              '/usr/bin/python3 validation/run_parallel_polygons.py --workers 4 --case-timeout 300',
              '/usr/bin/python3 validation/run_many_vertices.py', '/usr/bin/python3 validation/run_native_presets.py', '```', '',
              '本工作站请使用 `/usr/bin/python3`；默认 `python3` 为 3.7，不支持宿主求值器所用的 `math.prod`。', '',
              '内核 SHA-256：`%s`。' % source_hash, '']
    (ROOT / 'validation/TEST_RESULTS_CN.md').write_text('\n'.join(lines))
    print('Matrix:', sum(c['passed'] for c in matrix['cases']), '/', len(matrix['cases']), 'expectations met')
    print('Known failed cases:', len(failures))


if __name__ == '__main__':
    summarize()
