#!/usr/bin/env python3
"""Run arbitrary-polygon native cases in isolated, time-bounded libraries."""
import argparse
import concurrent.futures
import hashlib
import json
from pathlib import Path

from check_polygon import SHAPES
from run_native_matrix import NATIVE, ROOT, TOPOLOGIES, run
from run_parallel_matrix import timeout_case


def main(args):
    source_hash = hashlib.sha256((ROOT / 'tcoil.il').read_bytes()).hexdigest()
    rows = [dict(name=shape + '_' + topology, shape=shape, topology=topology,
                 boundary=boundary, pins=pins, params=dict(topology=topology), expected=True)
            for shape, (boundary, pins) in SHAPES.items() for topology in TOPOLOGIES]
    ready = {}
    if args.resume:
        for p in sorted(NATIVE.glob('polygon_bounded_*_report.json')) + ([NATIVE / 'budget_probe_report.json'] if (NATIVE / 'budget_probe_report.json').exists() else []):
            report = json.loads(p.read_text())
            if report['source_sha256'] == source_hash:
                for c in report['cases']:
                    if c.get('status') == 'native_timeout' or not c.get('error', '').startswith('Native result missing'):
                        ready[c['name']] = c
    pending = [r for r in rows if r['name'] not in ready]
    index = max([int(p.name.split('_')[2]) for p in NATIVE.glob('polygon_bounded_*_manifest.json')] or [0])
    def worker(number, row):
        label = 'polygon_bounded_%03d' % number
        report = run([row], label, args.case_timeout)
        c = report['cases'][0]
        if report.get('timed_out') and c.get('error', '').startswith('Native result missing'):
            text = (NATIVE / (label + '.stdout.log')).read_text(errors='replace')
            if 'QA_BEGIN ' + row['name'] not in text:
                raise RuntimeError('Native startup did not reach ' + row['name'])
            c = timeout_case(row, args.case_timeout, 'Isolated polygon case exceeded %d seconds including startup.' % args.case_timeout)
            report['cases'] = [c]; report['passed'] = False
            (NATIVE / (label + '_report.json')).write_text(json.dumps(report, indent=2) + '\n')
        if c.get('error', '').startswith('Native result missing'):
            raise RuntimeError('Missing native result for ' + row['name'])
        return c
    print('Retained', len(ready), 'of', len(rows), flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(worker, index + i + 1, row) for i, row in enumerate(pending)]
        for future in concurrent.futures.as_completed(futures):
            case = future.result(); ready[case['name']] = case
            print(len(ready), '/', len(rows), case['name'], case.get('status', 'PASS' if case['passed'] else 'generation_failed'), flush=True)
    assert source_hash == hashlib.sha256((ROOT / 'tcoil.il').read_bytes()).hexdigest(), 'Source changed during native tests'
    results = [ready[r['name']] for r in rows]
    report = dict(passed=all(c['passed'] for c in results), collection_complete=True,
                  source_sha256=source_hash, source_path=str(ROOT / 'tcoil.il'), cases=results,
                  runtime='Cadence IC617 native SKILL/PCell and independent actual OA audits',
                  pdk='/home/meow/tsmc18/tsmc18', technology='/home/meow/tsmc18/tech.tf',
                  metals=['METAL5', 'METAL6'], via='M6_M5', grid_um=.005,
                  case_timeout_seconds=args.case_timeout,
                  limitations=['Finite search; timeout/budget stop does not prove infeasibility.', 'No foundry DRC/LVS or EM.'])
    (NATIVE / 'final_polygons_report.json').write_text(json.dumps(report, indent=2) + '\n')
    return report


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--workers', type=int, default=4)
    p.add_argument('--case-timeout', type=int, default=300)
    p.add_argument('--resume', action='store_true')
    args = p.parse_args()
    r = main(args)
    raise SystemExit(0 if r['passed'] else 1)
