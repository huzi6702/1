#!/usr/bin/env python3
"""General simple-polygon predicates and conservative contour regressions."""
import argparse
import hashlib
import json
from pathlib import Path
import random

from check_geometry import VM, SkillError

ROOT = Path(__file__).resolve().parents[1]
SHAPES = {
    'l_shape': ('((0 0)(80 0)(80 25)(35 25)(35 60)(0 60))',
                [[0, 10, 2], [80, 10, 2], [20, 60, 2]]),
    'cross12': ('((25 0)(55 0)(55 20)(80 20)(80 45)(55 45)(55 65)(25 65)(25 45)(0 45)(0 20)(25 20))',
                [[0, 30, 2], [80, 30, 2], [40, 65, 2]]),
    'staircase12': ('((0 0)(100 0)(100 60)(80 60)(80 70)(60 70)(60 80)(40 80)(40 90)(20 90)(20 100)(0 100))',
                    [[0, 20, 2], [100, 20, 2], [10, 100, 2]]),
    'triangle': ('((0 0)(100 0)(50 80))', [[20, 0, 2], [80, 0, 2], [50, 70, 2]]),
    'trapezoid': ('((0 0)(100 0)(80 60)(20 60))', [[10, 0, 2], [90, 0, 2], [50, 60, 2]]),
    'octagon': ('((10 0)(90 0)(100 10)(100 50)(90 60)(10 60)(0 50)(0 10))',
                [[0, 30, 2], [100, 30, 2], [50, 60, 2]]),
    'diamond': ('((50 0)(100 40)(50 80)(0 40))', [[10, 40, 2], [90, 40, 2], [50, 70, 2]]),
    'concave_slanted': ('((0 0)(100 0)(100 60)(65 60)(50 40)(35 60)(0 60))',
                        [[0, 10, 2], [100, 10, 2], [20, 60, 2]]),
}


def boundary_text(points):
    return '(' + ''.join('(%s %s)' % tuple(point) for point in points) + ')'


def run(source=None):
    source = Path(source or ROOT / 'tcoil.il')
    vm = VM()
    vm.load(source)
    checks = []

    def check(name, fn):
        try:
            fn()
            checks.append(dict(name=name, pass_=True))
        except Exception as exc:
            checks.append(dict(name=name, pass_=False, error=str(exc)))

    def equal(a, b):
        assert a == b, (a, b)

    def rejects(text):
        try:
            vm.call('tc5ParseBoundary', text, .005)
        except SkillError:
            return
        raise AssertionError('Invalid boundary accepted')

    for name, (text, _) in SHAPES.items():
        def accepted(text=text):
            polygon = vm.call('tc5ParseBoundary', text, .005)
            assert len(polygon) >= 3
            assert vm.call('tc5Area', polygon) > 0
            for shift in range(len(polygon)):
                rotated = polygon[shift:] + polygon[:shift]
                equal(vm.call('tc5ParseBoundary', boundary_text(rotated), .005), polygon)
                equal(vm.call('tc5ParseBoundary', boundary_text(list(reversed(rotated))), .005), polygon)
        check(name + '_canonical_invariant', accepted)

        def contour(text=text):
            polygon = vm.call('tc5ParseBoundary', text, .005)
            winding = vm.call('tc5ContourPolygon', polygon, .005)
            assert vm.call('tc5Orthogonal', winding)
            if vm.call('tc5Orthogonal', polygon):
                equal(winding, polygon)
            else:
                assert vm.call('tc5BoxInside', vm.call('tc5PolyBox', winding), polygon)
        check(name + '_safe_winding_contour', contour)

    invalid = {
        'bow_tie': '((0 0)(20 20)(0 20)(20 0))',
        'collinear': '((0 0)(10 10)(20 20)(0 20))',
        'repeated_close': '((0 0)(20 0)(10 20)(0 0))',
        'nonadjacent_touch': '((0 0)(30 0)(30 30)(15 0)(0 30))',
        'off_grid': '((0 0)(20 0)(10.003 20))',
        'code': '((0 0)(20 0)(plus(1 1) 20))',
        'trailing_code': '((0 0)(20 0)(10 20)) system("ignored")',
    }
    for name, text in invalid.items():
        check(name + '_rejected', lambda text=text: rejects(text))

    triangle = vm.call('tc5ParseBoundary', SHAPES['triangle'][0], .005)
    check('triangle_on_slanted_edge', lambda: equal(vm.call('tc5Inside', [25., 40.], triangle), True))
    check('triangle_outside_edge', lambda: equal(bool(vm.call('tc5Inside', [24., 40.], triangle)), False))
    check('triangle_box_crosses_slant', lambda: equal(bool(vm.call('tc5BoxInside', [5., 5., 95., 70.], triangle)), False))
    notch = vm.call('tc5ParseBoundary', '((0 0)(40 0)(40 40)(25 40)(25 15)(15 15)(15 40)(0 40))', .005)
    check('box_with_all_corners_inside_crosses_notch', lambda: equal(bool(vm.call('tc5BoxInside', [5., 5., 35., 30.], notch)), False))
    check('disjoint_diagonal_segments_with_overlapping_bboxes', lambda: equal(bool(vm.call(
        'tc5SegmentsTouch', [0., 0.], [10., 10.], [0., 8.], [3., 11.])), False))

    rng = random.Random(51030)
    for index in range(40):
        def fuzz(index=index):
            # Random positive steps form simple monotone polygons with 6..34 vertices.
            count = rng.randrange(2, 16)
            points = [[0, 0], [10 * count, 0], [10 * count, 40]]
            y = 40
            for step in range(count - 1, 0, -1):
                points.append([10 * step, y])
                y += rng.choice([5, 10, 15])
                points.append([10 * step, y])
            points.append([0, y])
            polygon = vm.call('tc5ParseBoundary', boundary_text(points), .005)
            equal(len(polygon), len(points))
            equal(vm.call('tc5ParseBoundary', boundary_text(list(reversed(points))), .005), polygon)
            assert vm.call('tc5BoxInside', [1., 1., 10 * count - 1., 39.], polygon)
        check('seeded_monotone_polygon_%02d' % index, fuzz)

    return dict(passed=all(c['pass_'] for c in checks), checks=checks,
                source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                runtime='host predicates and contour construction; not native OA or DRC')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source')
    args = parser.parse_args()
    result = run(args.source)
    (ROOT / 'validation/polygon_report.json').write_text(json.dumps(result, indent=2) + '\n')
    for c in result['checks']:
        if not c['pass_']:
            print('FAIL', c['name'], c.get('error'))
    print('PASS' if result['passed'] else 'FAIL', len(result['checks']), 'polygon checks')
    raise SystemExit(0 if result['passed'] else 1)
