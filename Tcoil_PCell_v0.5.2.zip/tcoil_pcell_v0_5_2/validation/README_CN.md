# 验证说明

v0.5.2 另外提供原生 Virtuoso/OA 验证：`/usr/bin/python3 validation/run_native_matrix.py --label final_matrix` 运行四种边界、四种拓扑及参数变化；加 `--polygons --label final_polygons` 验证新多边形。它们使用给定 TSMC18 技术库、METAL5/METAL6/M6_M5 和独立测试库。每个 QA 库保存不可变源码副本，报告记录该副本的哈希；检查实际 OA 金属、三个 PIN、连通分量、意外环路、制造网格，以及原生多边形布尔差运算的越界结果。失败用例保留在报告中，不自动视为通过。中断后使用同一标签加 `--collect` 恢复汇总。

宿主主套件还包括 68 项简单多边形检查与 11 项大过孔及原生控制语义回归。下文描述的是宿主验证部分。最终结果与命令见 `TEST_RESULTS_CN.md`，原生图集见 `native/native_gallery.html`。

这些脚本使用 Python 标准库实现的 SKILL 子集求值器和少量 CDF/OA 接口替身。它们直接读取本包 `tcoil.il`，用于检查几何算法、技术文本解析、参数传递及回退行为；不能代替 Cadence 原生编译、PCell 求值、PDK DRC/LVS 或 EM 仿真。

在已安装 Python 3 的环境执行：

```sh
python3 validation/run_validation.py
python3 validation/check_geometry_sweep.py
python3 validation/check_parameter_effects.py
```

第一条命令检查技术文本、边界、路由网格、连接规划、精简界面与有限线宽回归，输出 `validation_report.json`。第二条命令按给定边界和固定 PIN 生成几何样例，输出 `geometry_sweep_report.json`；默认每个样例最多运行 120 秒。超时和生成失败均保留，不会自动当作通过。

几何审计独立计算实际金属矩形的并集、跨层连接、连通分量和环数，并检查三处 PIN 的准确位置。它没有使用 PDK 规则文件；项目 `minClearance` 是几何间距下限。测试中使用的两种 via 快照详见报告 `via_fixtures`，不能据此断言换成任意 PDK 的大孔阵列后仍可布通。

第三条命令对生成结果检查 16 项参数作用，包括独立绕向、匝数、物理交错顺序、局部线宽与间距、偏移及完整覆盖线宽的等价性。

报告保存所测 `tcoil.il` 的 SHA-256。修改源文件后应重新运行；旧报告不证明修改后的代码正确。HTML 中的生成图例使用报告里的实际矩形，概念图另有标注。
