"""Independent exact coordinate-compressed rectangle-union topology audit.

Models each via array as a single inter-layer connection. Checks connected metal,
planar holes and cycle rank across the two metal layers. No geometry-kernel calls.
"""
from collections import deque

def layer_union(boxes):
    xs=sorted(set(round(v,8) for b in boxes for v in (b[0],b[2])))
    ys=sorted(set(round(v,8) for b in boxes for v in (b[1],b[3])))
    xs=[xs[0]-1]+xs+[xs[-1]+1];ys=[ys[0]-1]+ys+[ys[-1]+1]
    xi={v:i for i,v in enumerate(xs)};yi={v:i for i,v in enumerate(ys)}
    nx=len(xs)-1;ny=len(ys)-1;filled=set()
    for b in boxes:
        a,c,e,f=map(lambda v:round(v,8),b)
        filled.update((i,j) for i in range(xi[a],xi[e]) for j in range(yi[c],yi[f]))
    labels={};nc=0
    def neighbors(p):
        i,j=p
        for q in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):
            if 0<=q[0]<nx and 0<=q[1]<ny:yield q
    for p in filled:
        if p in labels:continue
        nc+=1;labels[p]=nc;todo=[p]
        while todo:
            for q in neighbors(todo.pop()):
                if q in filled and q not in labels:labels[q]=nc;todo.append(q)
    empty={(i,j) for i in range(nx) for j in range(ny)}-filled
    nempty=0
    while empty:
        nempty+=1;todo=[empty.pop()]
        while todo:
            for q in neighbors(todo.pop()):
                if q in empty:empty.remove(q);todo.append(q)
    def components_at(x,y):
        # At an edge, either neighboring filled cell may represent the contact.
        ix=[i for i in range(nx) if xs[i]-1e-7<=x<=xs[i+1]+1e-7]
        iy=[j for j in range(ny) if ys[j]-1e-7<=y<=ys[j+1]+1e-7]
        return {labels[i,j] for i in ix for j in iy if (i,j) in labels}
    return dict(components=nc,holes=nempty-1,at=components_at)

def audit(c):
    unions={layer:layer_union([b for l,b,_,_ in c['objects'] if l==layer]) for layer in (1,2)}
    nodes={(l,i) for l in (1,2) for i in range(1,unions[l]['components']+1)}
    adj={n:set() for n in nodes};edges=[]
    for x,y in sorted(set(tuple(v[0]) for v in c['vias'])):
        a=unions[1]['at'](x,y);b=unions[2]['at'](x,y)
        assert len(a)==len(b)==1, f'ambiguous or missing via contact at {(x,y)}: {a}/{b}'
        u=(1,next(iter(a)));v=(2,next(iter(b)))
        edges.append((u,v));adj[u].add(v);adj[v].add(u)
    labels={};ncc=0
    for n in nodes:
        if n in labels:continue
        ncc+=1;labels[n]=ncc;todo=[n]
        while todo:
            for q in adj[todo.pop()]:
                if q not in labels:labels[q]=ncc;todo.append(q)
    rank=len(edges)-len(nodes)+ncc+sum(u['holes'] for u in unions.values())
    pins=[]
    for pin,inside,l,name,d in c['pins']:
        cs=unions[l]['at'](*pin)
        assert len(cs)==1,f'{name}: missing or ambiguous terminal metal'
        pins.append(labels[l,next(iter(cs))])
        tagged=[b for layer,b,_,tag in c['objects'] if tag=='PIN_'+name]
        assert len(tagged)==1
        b=tagged[0];x,y=pin
        end={'E':(b[0],(b[1]+b[3])/2),'W':(b[2],(b[1]+b[3])/2),
             'N':((b[0]+b[2])/2,b[1]),'S':((b[0]+b[2])/2,b[3])}[d]
        assert abs(end[0]-x)<1e-8 and abs(end[1]-y)<1e-8, f'{name}: shifted pin endpoint'
    assert ncc==1 and len(set(pins))==1, f'{ncc} disconnected metal components'
    assert rank==0, f'{rank} unintended conductive cycles/shorted turns'
    return dict(connected_components=ncc,unintended_cycles=rank,
                planar_holes={str(l):unions[l]['holes'] for l in (1,2)},pin_endpoint_checks=3)
