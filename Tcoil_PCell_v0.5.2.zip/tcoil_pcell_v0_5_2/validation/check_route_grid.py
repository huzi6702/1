#!/usr/bin/env python3
"""Regression for grid-equivalent coordinates that broke raw-float A* lookup.

This exercises the shipped SKILL source in the host subset evaluator. It does
not claim Cadence execution. The original v0.4.0 fails both drift cases.
"""
import json
from pathlib import Path
from check_geometry import VM, SkillError

ROOT=Path(__file__).resolve().parents[1]

def run():
    vm=VM();vm.load(ROOT/'tcoil.il')
    checks=[]
    def context():
        return dict(boundary=[[-10.,-10.],[10.,-10.],[10.,10.],[-10.,10.]],
          objects=[],vias=[],routes=[],serial=0,grid=.001,space=.5,leadWidth=1.,
          viaBox=[-.5,-.5,.5,.5],contactRadius=.5,routePreference='M2',
          maxStates=12000,viaCost=20.)
    def check(name,fn):
        try:fn();checks.append(dict(name=name,pass_=True))
        except Exception as exc:checks.append(dict(name=name,pass_=False,error=str(exc)))
    def route(a,b):
        c=context();axes=vm.call('tc5Axes',c,a,b)
        r=vm.call('tc5AStar',c,a,b,[],axes)
        assert r, (a,b,c.get('lastRouteStatus'))
        assert r[0]==a and r[-1]==b, 'Caller endpoint coordinates changed'
        assert vm.call('tc5RouteCheck',c,r,[])
        assert vm.call('tc5RouteSelfOK',c,r)
        assert c['lastRouteStatus']=='astar_found'
    check('ordinary_grid_route',lambda:route([1.,1.,1],[9.,9.,1]))
    check('start_roundoff_does_not_lose_axis_neighbors',lambda:route([1.+1e-12,1.+1e-12,1],[9.,9.,1]))
    check('goal_roundoff_does_not_prevent_completion',lambda:route([1.,1.,1],[9.+1e-12,9.+1e-12,1]))
    check('both_endpoints_roundoff_preserve_exact_coordinates',lambda:route([1.-1e-12,1.+1e-12,1],[9.+1e-12,9.-1e-12,1]))
    check('negative_coordinates_and_layer_transition',lambda:route([-9.-1e-12,-9.+1e-12,1],[-1.+1e-12,-1.-1e-12,2]))
    check('same_xy_different_layers_requires_via',lambda:route([1.,1.,1],[1.,1.,2]))
    def limit():
        c=context();c['maxStates']=1;a=[1.,1.,1];b=[9.,9.,1]
        assert not vm.call('tc5AStar',c,a,b,[],vm.call('tc5Axes',c,a,b))
        assert c['lastRouteStatus']=='astar_state_limit'
        assert c['lastRouteExpanded']==2 and all(c['lastRouteAxes'])
    check('state_limit_is_distinct_from_exhaustion',limit)
    def exhausted():
        c=context();c['objects']=[[1,[-9.,-9.,9.,9.],1,'block1'],[2,[-9.,-9.,9.,9.],2,'block2']]
        a=[1.,1.,1];b=[8.,8.,1]
        assert not vm.call('tc5AStar',c,a,b,[],vm.call('tc5Axes',c,a,b))
        assert c['lastRouteStatus']=='astar_exhausted'
    check('blocked_search_reports_exhaustion',exhausted)
    def stair():
        fixture=json.loads((ROOT/'validation/route_staircase_fixture.json').read_text())
        c=fixture['context'];r=fixture['route'];a=r[0];b=r[-1]
        allow=vm.call('tc5Anchors',c,a[:2],a[2])+vm.call('tc5Anchors',c,b[:2],b[2])
        assert vm.call('tc5RouteCheck',c,r,allow)
        assert not vm.call('tc5RouteSelfOK',c,r), 'Fixture no longer exercises rejection'
        polished=vm.call('tc5PolishRoute',c,r,allow)
        assert polished and len(polished)<len(r)
        assert polished[0]==a and polished[-1]==b
        vias=lambda states:[(x[:2],x[2],y[2]) for x,y in zip(states,states[1:]) if x[2]!=y[2]]
        assert vias(polished)==vias(r), 'Polishing moved or removed a via'
        assert vm.call('tc5RouteCheck',c,polished,allow)
        assert vm.call('tc5RouteSelfOK',c,polished)
    check('reported_LEAD_A_staircase_polished_with_vias_and_endpoints_fixed',stair)
    def blocked_shortcut():
        c=context();c['objects']=[[1,[-1.,-9.,1.,7.],1,'obstacle']]
        r=[[-8.,-8.,1],[-8.,8.,1],[8.,8.,1],[8.,-8.,1]]
        assert vm.call('tc5RouteCheck',c,r,[])
        assert vm.call('tc5RouteSelfOK',c,r)
        assert not vm.call('tc5PolishRoute',c,r,[]), 'Shortcut crossed existing metal'
    check('polish_keeps_obstacle_detour',blocked_shortcut)
    return dict(passed=all(c['pass_'] for c in checks),checks=checks)

if __name__=='__main__':
    import json
    result=run();print(json.dumps(result,indent=2))
    raise SystemExit(0 if result['passed'] else 1)
