#!/usr/bin/env python3
"""Check that independent user controls change their intended generated geometry."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def run():
 report=json.loads((ROOT/'validation/geometry_sweep_report.json').read_text())
 assert report['source_sha256']==hashlib.sha256((ROOT/'tcoil.il').read_bytes()).hexdigest(),'Geometry report is stale; rerun check_geometry_sweep.py'
 assert report['passed'],'Geometry sweep must pass before checking parameter effects'
 cases={c['name']:c for c in report['cases'] if c['passed']};checks=[]
 def check(name,fn):
  try:fn();checks.append({'name':name,'passed':True})
  except Exception as exc:checks.append({'name':name,'passed':False,'error':str(exc)})
 def eq(a,b):assert a==b,(a,b)
 def near(a,b):assert abs(a-b)<1e-8,(a,b)
 def rings(name):return [dict(r) for r in cases[name]['geometry']['windingRings']]
 def ring(name,owner,turn=0):return next(r for r in rings(name) if r['owner']==owner and r['turn']==turn)
 def physical(name):
  c=cases[name]['geometry']
  return (sorted((l,tuple(round(x,8) for x in box)) for l,box,_,_ in c['objects']),sorted(tuple(round(x,8) for x in v[0]) for v in c['vias']))
 check('four_topologies_generated_with_fixed_project',lambda:eq({c for c in ('contour_default','interleaved_default','stacked_default','split_lobe_default') if c in cases},{'contour_default','interleaved_default','stacked_default','split_lobe_default'}))
 def fixedpins():
  for c in cases.values():eq([p[0] for p in c['geometry']['pins']],[[0.,2.],[40.,2.],[24.,12.]])
 check('all_successful_cases_preserve_three_pin_coordinates',fixedpins)
 check('independent_W1_sense_reverses_W1_only',lambda:(eq(ring('sense1_ccw',1)['points'],list(reversed(ring('contour_default',1)['points']))),eq(ring('sense1_ccw',2)['points'],ring('contour_default',2)['points'])))
 check('independent_W2_sense_reverses_W2_only',lambda:(eq(ring('sense2_cw',2)['points'],list(reversed(ring('contour_default',2)['points']))),eq(ring('sense2_cw',1)['points'],ring('contour_default',1)['points'])))
 check('independent_widths_applied',lambda:(eq(set(ring('unequal_widths',1)['widths']),{1.2}),eq(set(ring('unequal_widths',2)['widths']),{.8})))
 def offset():
  r=ring('relative_offset_xy',2);near(min(p[0] for p in r['points']),r['edgeInsets'][3]+.25);near(max(p[1] for p in r['points']),12-r['edgeInsets'][2]-.25)
 check('W2_offset_xy_changes_absolute_coordinates',offset)
 check('independent_insets_applied',lambda:(near(ring('independent_insets',1)['edgeInsets'][0],.75),near(ring('independent_insets',2)['edgeInsets'][0],2.5)))
 check('per_edge_width_and_gap_overrides_applied',lambda:(near(ring('local_edge_profile',1)['widths'][2],.8),near(ring('local_edge_profile',1)['spaces'][6],.75),near(ring('local_edge_profile',2)['widths'][1],.8)))
 def physicalgap():
  outer=ring('local_edge_profile',1);inner=ring('local_edge_profile',2)
  radius=max(abs(v) for v in cases['local_edge_profile']['derived']['viaBox'])
  for edge in (2,6):
   outer_half=outer['widths'][edge]/2;inner_half=inner['widths'][edge]/2
   actual=inner['edgeInsets'][edge]-outer['edgeInsets'][edge]-inner_half-outer_half
   required=outer['spaces'][edge]+max(0,radius-outer_half)+max(0,radius-inner_half)
   near(actual,required)
   assert actual>=outer['spaces'][edge]-1e-8
 check('local_spacing_and_full_via_footprint_control_actual_parallel_edge_gap',physicalgap)
 check('independent_turn_count_changes_ring_count',lambda:eq([r['owner'] for r in rings('three_turns_contour')],[1,1,2]))
 check('interleave_block_changes_physical_owner_order',lambda:(eq([r['owner'] for r in rings('interleaved_block1')],[1,2,1]),eq([r['owner'] for r in rings('interleaved_block2')],[1,1,2])))
 check('per_turn_profile_changes_selected_turn_only',lambda:(eq(set(ring('local_turn_profile',2,0)['widths']),{.5}),eq(set(ring('local_turn_profile',2,1)['widths']),{.4})))
 check('stacked_assigns_windings_to_two_metals',lambda:(eq(ring('stacked_default',1)['layer'],1),eq(ring('stacked_default',2)['layer'],2)))
 def lobegap():
  near(max(p[0] for p in ring('split_lobe_default',1)['points'])-max(p[0] for p in ring('split_lobe_gap',1)['points']),.5)
  near(min(p[0] for p in ring('split_lobe_gap',2)['points'])-min(p[0] for p in ring('split_lobe_default',2)['points']),.5)
 check('lobe_gap_separates_both_lobes',lobegap)
 check('uniform_width_profile_equals_explicit_width',lambda:eq(physical('wide_profile_equivalent'),physical('unequal_widths')))
 check('overridden_large_base_width_does_not_enlarge_vias_or_routes',lambda:(eq(physical('all_width_overrides_equivalent'),physical('contour_default')),near(cases['all_width_overrides_equivalent']['derived']['geometryMaxWidth'],1.)))
 result={'passed':all(c['passed'] for c in checks),'source_sha256':report['source_sha256'],'runtime':'checks of generated host geometry; NOT Cadence or EM','checks':checks}
 (ROOT/'validation/parameter_effects_report.json').write_text(json.dumps(result,indent=2)+'\n')
 return result
if __name__=='__main__':
 r=run();print(json.dumps(r,indent=2));raise SystemExit(0 if r['passed'] else 1)
