#!/usr/bin/env python3
"""Regression checks for alternative-route search, error evidence and rollback."""
from copy import deepcopy
from pathlib import Path
from check_geometry import VM, Sym, SkillError

ROOT = Path(__file__).resolve().parents[1]


def run():
    checks = []
    def check(name, fn):
        try:
            fn(); checks.append(dict(name=name, pass_=True))
        except Exception as exc:
            checks.append(dict(name=name, pass_=False, error=str(exc)))
    def vm():
        v = VM(); v.load(ROOT / 'tcoil.il'); return v
    def context():
        return dict(boundary=[[0., 0.], [10., 0.], [10., 10.], [0., 10.]],
                    objects=[[1, [0., 0., 4., 4.5], 1, 'left'],
                             [1, [6., 0., 10., 4.5], 2, 'right'],
                             [2, [0., 0., 10., 10.], 3, 'metal2']],
                    vias=[], routes=[], serial=3, grid=.001, space=.2,
                    leadWidth=.4, viaBox=[-.2, -.2, .2, .2], contactRadius=.2,
                    routePreference='M1', maxStates=512, viaCost=20.)
    links = [[[8., 8., 1], [8., 8., 1], 'A'],
             [[1., 5., 1], [9., 5., 1], 'FLEX'],
             [[9., 9., 1], [9., 9., 1], 'B'],
             [[5., 1., 1], [5., 6.5, 1], 'CHOKE']]
    keys = ('objects', 'vias', 'routes', 'serial')

    def alternative_route_frees_choke_in_same_order():
        v, c = vm(), context()
        assert v.call('tc5RouteTree', c, links, [1, 3, 0, 2])
        assert len(c['routes']) == 4
        by_tag = {tag: states for states, tag in c['routes']}
        assert max(p[1] for p in by_tag['FLEX']) > 7
        # Replay accepted routes against fresh physical obstacles.
        replay = context()
        for index in [1, 3, 0, 2]:
            a, b, tag = links[index]
            allow = (v.call('tc5Anchors', replay, a[:2], a[2]) or []) + (v.call('tc5Anchors', replay, b[:2], b[2]) or [])
            assert v.call('tc5RouteCheck', replay, by_tag[tag], allow)
            v.call('tc5CommitRoute', replay, by_tag[tag], tag)
        assert all(replay[k] == c[k] for k in keys)
    check('backtrack_route_choice_without_changing_terminal_order', alternative_route_frees_choke_in_same_order)

    def failed_tree_restores_all_reservations():
        v, c = vm(), context(); before = deepcopy(c)
        blocked = deepcopy(links); blocked[3][1] = [5., -2., 1]
        assert not v.call('tc5RouteTree', c, blocked, [1, 3, 0, 2])
        assert all(c[k] == before[k] for k in keys)
    check('unsuccessful_route_tree_rolls_back', failed_tree_restores_all_reservations)

    def budget_rollback():
        v, c = vm(), context(); before = deepcopy(c)
        c.update(searchWorkLimit=7, trialWorkLimit=100, routeBacktracking=True)
        try:
            v.call('tc5PlanConnections', c, links)
            raise AssertionError('Budget did not stop search')
        except SkillError as e:
            assert 'TCOIL_SEARCH_BUDGET' in str(e)
        assert c['failureClass'] == 'search_budget_total'
        assert all(c[k] == before[k] for k in keys)
        assert c.get('routeSkip') is None
    check('collision_budget_is_explicit_and_transactional', budget_rollback)

    def trial_error_evidence():
        v, c = vm(), context()
        for key in keys:
            c['initial' + key[0].upper() + key[1:]] = deepcopy(c[key])
        before = deepcopy(c)
        def fail(context, parameters):
            context['generationStage'] = 'routing'
            context['objects'] = [[1, [1, 1, 2, 2], 99, 'LEAK']]
            context['serial'] = 99
            raise SkillError('specific diagnostic witness')
        v.env[Sym('tc5GeometryTrial')] = fail
        assert not v.call('tc5GeometryAttempt', c, {}, c['boundary'], [2, 0], .5, .5, None)
        assert 'specific diagnostic witness' in c['lastGenerationFailure'][-1]
        assert c['lastGenerationFailure'][0] == 'routing'
        assert all(c[k] == before[k] for k in keys)
    check('candidate_error_preserved_and_partial_geometry_removed', trial_error_evidence)
    def alternate_region_not_starved_by_deep_outline_trials():
        v, c = vm(), context()
        original = [[0., 0.], [10., 0.], [10., 4.], [4., 4.], [4., 10.], [0., 10.]]
        c.update(boundary=original, windingBoundary=original, objects=[], vias=[], routes=[],
                 serial=0, searchWork=0, searchWorkLimit=8, trialWorkLimit=4)
        p = dict(topology='stacked', profile1='', profile2='')
        calls = []
        def constrained_trial(context, parameters):
            calls.append(deepcopy(context['windingBoundary']))
            if context['windingBoundary'] != original:
                return context
            context['generationStage'] = 'routing'
            for _ in range(3):
                v.call('tc5Spend', context)
            raise SkillError('Outline route did not complete within its allocation')
        v.env[Sym('tc5GeometryTrial')] = constrained_trial
        assert v.call('tc5Geometry', c, p) is c
        assert len(calls) == 3 and calls[-1] != original
        assert c['searchWork'] <= c['searchWorkLimit']
        assert c['contourMode'] == 'inscribed_rectangle'
    check('contained_region_receives_budget_before_repeated_outline_trials', alternate_region_not_starved_by_deep_outline_trials)
    def budget_uses_vertices_not_serialized_text_length():
        v = vm()
        a = '((0 0)(10 0)(10 10)(0 10))'
        b = '( ( 0 0 ) ( 10 0 ) ( 10 10 ) ( 0 10 ) )' + ' ' * 60
        contexts = []
        for text in (a, b):
            p = dict(boundary=text, contourBoundary=v.call('tc5ParseBoundary', text, .005),
                     grid=.005, geometryMaxWidth=1., space=.5, leadWidth=1.,
                     routePreference='M2', maxStates=12000, viaCost=20.)
            contexts.append(v.call('tc5MakeContext', p, [-.63, -.63, .63, .63]))
        assert contexts[0]['boundary'] == contexts[1]['boundary']
        assert contexts[0]['searchWorkLimit'] == contexts[1]['searchWorkLimit']
        assert contexts[0]['trialWorkLimit'] == contexts[1]['trialWorkLimit']
    check('search_allocation_is_invariant_to_boundary_serialization', budget_uses_vertices_not_serialized_text_length)
    return dict(passed=all(c['pass_'] for c in checks), checks=checks)


if __name__ == '__main__':
    import json
    result = run(); print(json.dumps(result, indent=2)); raise SystemExit(0 if result['passed'] else 1)
