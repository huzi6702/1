#!/usr/bin/env python3
"""v0.5 geometry examples with bounded host execution; no Cadence/OA/PDK DRC."""
from pathlib import Path
import json,time,hashlib,contextlib,io,multiprocessing as mp,queue
from check_geometry import VM
from audit_geometry import audit
ROOT=Path(__file__).resolve().parents[1]
BOUNDARY='((40 12)(0 12)(0 0)(10 0)(10 5)(27 5)(27 0)(40 0))'
PINS=[[[0.,2.],2,'AUTO'],[[40.,2.],2,'AUTO'],[[24.,12.],2,'AUTO']]
TECH='("standardViaDefs" ("TM2_TM1" "TM1" "TM2" ("TV2" 0.5 0.5) (1 1 (0.5 0.5)) (0.25 0.25) (0.25 0.25) (0 0) (0 0) (0 0)))'
USER_TECH='("standardViaDefs" ("TM2_TM1" "TM1" "TM2" ("TV2" 0.324 0.324) (1 1 (0.306 0.306)) (0.071 0.018) (0.018 0.071) (0 0) (0 0) (0 0)))'
CASES=[{'name':t+'_default','params':{'topology':t}} for t in ('contour','interleaved','stacked','split_lobe')]
CASES += [{'name':'contour_grid_'+str(g),'grid':g,'params':{}} for g in (.0005,.002,.005)]
CASES += [
 {'name':'sense1_ccw','params':{'sense1':'CCW'}},
 {'name':'sense2_cw','params':{'sense2':'CW'}},
 {'name':'unequal_widths','params':{'width1':1.2,'width2':.8}},
 {'name':'relative_offset_xy','params':{'space1':1.,'offsetX':.25,'offsetY':-.25}},
 {'name':'independent_insets','params':{'space1':.75,'inset1':.25,'inset2':.25}},
 {'name':'local_edge_profile','params':{'profile1':'((0 2 0.8 -1)(0 6 0.8 0.75))','profile2':'((0 1 0.8 -1))'}},
 {'name':'three_turns_contour','via_fixture':'user_TM2_TM1','params':{'turns1':2,'width1':.5,'width2':.5}},
 {'name':'interleaved_block1','via_fixture':'user_TM2_TM1','params':{'topology':'interleaved','turns1':2,'width1':.5,'width2':.5,'sense2':'CW','interleaveBlock':1}},
 {'name':'interleaved_block2','via_fixture':'user_TM2_TM1','params':{'topology':'interleaved','turns1':2,'width1':.5,'width2':.5,'sense2':'CW','interleaveBlock':2}},
 {'name':'local_turn_profile','via_fixture':'user_TM2_TM1','params':{'turns2':2,'width1':.5,'width2':.5,'space1':.75,'space2':.75,'profile2':'((1 -1 0.4 -1))'}},
 {'name':'split_lobe_gap','params':{'topology':'split_lobe','lobeGap':1.0}},
 {'name':'wide_profile_equivalent','params':{'width2':.8,'profile1':'((-1 -1 1.2 -1))'}},
 {'name':'all_width_overrides_equivalent','params':{'width1':3.,'width2':3.,'profile1':'((-1 -1 1.0 -1))','profile2':'((-1 -1 1.0 -1))'}},
]
def build(item):
 start=time.monotonic();vm=VM();vm.load(ROOT/'tcoil.il')
 prefix='tc5' if 'tc5DefaultValues' in vm.env else 'tc'
 def call(name,*args):return vm.call(prefix+name,*args)
 values=dict(call('DefaultValues'))
 values.update(metal1='TM1',metal2='TM2',viaDefName='TM2_TM1',viaRows=1,viaCols=1)
 values.update(item.get('params',{}))
 values['projectData']=call('ProjectEncode',BOUNDARY,PINS,.5,item.get('grid',.001),'synthetic_validation.tech.tf','techfile')
 fixture=item.get('via_fixture','grid_compatible_1um')
 values['techData']=USER_TECH if fixture=='user_TM2_TM1' else TECH
 result={'name':item['name'],'params':item.get('params',{}),'grid':item.get('grid',.001),'via_fixture':fixture}
 try:
  p=call('ResolveValues',list(values.items()))
  bx=p['viaCols']*p['cutWidth']+(p['viaCols']-1)*p['cutSpaceX']
  by=p['viaRows']*p['cutHeight']+(p['viaRows']-1)*p['cutSpaceY']
  hx=bx/2+max(p['enc1X'],p['enc2X']);hy=by/2+max(p['enc1Y'],p['enc2Y'])
  box=call('ViaLandingBox',p,[-hx,-hy,hx,hy]);c=call('MakeContext',p,box)
  with contextlib.redirect_stdout(io.StringIO()):call('Geometry',c,p)
  result.update(passed=True,rectangles=len(c['objects']),vias=len(c['vias']),audit=audit(c),geometry=c,values=values,
    derived={'geometryMaxWidth':p['geometryMaxWidth'],'leadWidth':p['leadWidth'],'derivedTerminalLength':p['derivedTerminalLength'],'viaBox':box})
 except Exception as e:result.update(passed=False,error=str(e))
 result['seconds']=round(time.monotonic()-start,3)
 return result

def _worker(item,out):
 try:out.put(build(item))
 except BaseException as exc:out.put({'name':item['name'],'params':item.get('params',{}),'passed':False,'error':repr(exc)})

def run(cases=CASES,workers=4,timeout=120,output=None):
 source_sha=hashlib.sha256((ROOT/'tcoil.il').read_bytes()).hexdigest();results=[];pending=list(cases);active=[]
 outpath=Path(output) if output else ROOT/'validation/geometry_sweep_report.json'
 def save():
  order={item['name']:i for i,item in enumerate(cases)};ordered=sorted(results,key=lambda r:order[r['name']])
  report={'passed':len(ordered)==len(cases) and all(r['passed'] for r in ordered),'source_sha256':source_sha,
    'runtime':'host SKILL-subset evaluator; NOT Cadence SKILL/OA or PDK DRC','case_timeout_seconds':timeout,
    'via_fixtures':{'grid_compatible_1um':'0.5cut/0.25enclosure;raw1um','user_TM2_TM1':'0.324cut;0.071/0.018enclosures;raw0.466um'},'cases':ordered}
  outpath.write_text(json.dumps(report,indent=2)+'\n');return report
 while pending or active:
  while pending and len(active)<workers:
   item=pending.pop(0);q=mp.Queue(1);proc=mp.Process(target=_worker,args=(item,q));proc.start()
   active.append((item,proc,q,time.monotonic()))
  for rec in list(active):
   item,proc,q,started=rec;result=None
   try:result=q.get_nowait()
   except queue.Empty:pass
   if result is None and time.monotonic()-started>timeout:
    proc.terminate();proc.join(.5)
    if proc.is_alive():proc.kill();proc.join(.5)
    result={'name':item['name'],'params':item.get('params',{}),'grid':item.get('grid',.001),'via_fixture':item.get('via_fixture','grid_compatible_1um'),
      'passed':False,'status':'host_timeout','seconds':round(time.monotonic()-started,3),'error':'Host execution exceeded bounded timeout; no physical infeasibility conclusion.'}
   elif result is None and not proc.is_alive():
    try:result=q.get(timeout=.2)
    except queue.Empty:result={'name':item['name'],'passed':False,'error':'Worker exited without result','seconds':round(time.monotonic()-started,3)}
   if result is not None:
    proc.join(.5);q.close();active.remove(rec);results.append(result);save()
    print(result['name'],'PASS' if result['passed'] else 'FAIL',result.get('error',''),result.get('seconds'),flush=True)
  time.sleep(.05)
 assert hashlib.sha256((ROOT/'tcoil.il').read_bytes()).hexdigest()==source_sha,'source changed during regression'
 return save()
if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--timeout',type=int,default=120)
 parser.add_argument('--workers',type=int,default=4)
 args=parser.parse_args()
 result=run(workers=args.workers,timeout=args.timeout);print('PASS' if result['passed'] else 'FAIL',len(result['cases']),'geometry cases')
 raise SystemExit(0 if result['passed'] else 1)
