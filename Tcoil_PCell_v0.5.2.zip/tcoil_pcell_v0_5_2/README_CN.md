# T-coil SKILL PCell v0.5.2

## v0.5.2：漏解修复、可追踪搜索与 Python 估算

对所有拓扑启用开口边/位置重试，堆叠的候选轮廓按开口组合交替搜索以避免内接矩形候选被饿死，连接规划增加短路径回溯，非方形 via 阵列按实际法向/切向落脚尺寸退让。失败分支回滚，并保留原生错误、失败阶段和搜索工作量；`TCOIL_SEARCH_BUDGET` 表示有限搜索未定，不能解释成物理无解。搜索仍不完备，已知未生成组合见最终报告。

新增独立的 `em_estimator/`，从真实生成的导体中心线估算 L/R/M/K/Q 和 1–50 GHz 三端口 S。它使用需替换的示例堆栈，尚未 EM 校准；方法、配置和命令见 `em_estimator/README_CN.md`。

## 真实 PDK 与多边形扩展

本版保留 22 个可编辑参数及 `TCOIL050` 项目快照格式，增加任意顶点数的简单多边形边界。修正了大过孔落脚区、堆叠开口接入及原生 SKILL 的 `unwindProtect` / `return` 兼容问题。

当前工作站从 `/home/meow/tsmc18/` 启动 Virtuoso；技术库为 `tsmc18`，技术文本为 `/home/meow/tsmc18/tech.tf`，实际层名为 **`METAL5` / `METAL6`**，标准过孔为 **`M6_M5`**，网格为 **0.005 µm**。在已附着该技术库的可写测试库中执行：

```skill
load("/home/meow/tcoil/tcoil_pcell_v0_5_2/tcoil.il")
tcoilInstall("TCOIL_TEST" "METAL5" "METAL6" "M6_M5"
  "tcoil_v052" "/home/meow/tsmc18/tech.tf")
```

更多项目模板见 `project_presets_tsmc18.il`。先加载主文件及模板，再调用 `tcoilInstallPreset("TCOIL_TEST" "triangle")`；可选名称包括 `original`、`rectangle`、`wide_notch`、`top_notch`、`l_shape`、`cross12`、`staircase12`、`triangle`、`trapezoid`、`octagon`、`diamond`、`concave_slanted`。模板只在显式调用时安装，不改动 PDK。

### 多边形支持的确切含义

- 接受至少三个顶点的简单多边形，坐标须在制造网格上；拒绝自交、自接触、重复闭合点、零长度边和冗余共线边。当前不支持孔洞。
- 直角多边形的普通轮廓沿规范化边界生成，不再限制 4/8 个顶点；局部 profile 的边号按规范化后的轮廓确定。
- **斜边项目边界采用保守内接矩形作为绕组轮廓，导体与接入布线仍为曼哈顿几何。没有新增沿斜边贴合的绕组。** 包含检查使用原始多边形，不能用外包矩形替代。
- 轴向矩形 PIN 需要足够的截面空间。斜边项目的固定 PIN 可选在内部或合适的水平/垂直边段上；正线宽接入不能以外端截面中心精确贴在斜边或尖角上，生成器不会自动移动 PIN。
- `split_lobe` 优先保留原矩形 / 单凹口策略，其他形状使用两个互不重叠、完全位于边界内的矩形叶片。斜边轮廓和分叶 profile 使用各自矩形的 0..3 边号。
- 所有拓扑重试有限个开口边与位置组合；`stacked` 在 profile 均为空时，还可回退到内接矩形。显式边 profile 不会因回退而被悄悄重编号。输出 OA 属性 `tcoilContourMode` 和 `tcoilWindingBoundary` 记录实际轮廓策略。

内接候选网格包含原顶点坐标和八等分采样，检查包含关系是精确的，矩形搜索不是全局最优求解。输入被接受不保证任何匝数、线宽、过孔阵列都能布通；失败只表示当前几何或有限搜索未通过。

### 大过孔与参数间距

`M6_M5` 的默认联合落脚区宽高为 1.26 µm。绕组首层退让和相邻轮廓节距会为完整落脚区预留空间，因此 `space1/space2/profile gap` 是间距下限；实际边到边间距可能更大。三个外部 PIN 的坐标、层次保持项目快照中的精确值。

### 测试与实际版图

工作站默认 `python3` 为 3.7；本次使用 `/usr/bin/python3`（3.8.10）运行标准库检查：

```sh
/usr/bin/python3 validation/run_validation.py
/usr/bin/python3 validation/check_geometry_sweep.py --timeout 300
/usr/bin/python3 validation/check_parameter_effects.py
/usr/bin/python3 validation/run_parallel_matrix.py --workers 3 --case-timeout 120
/usr/bin/python3 validation/run_parallel_polygons.py --workers 4 --case-timeout 300
```

原生测试会创建独立 QA 库和独立 `cds.lib`，从指定启动目录运行，不修改 `/home/meow/tsmc18/cds.lib` 或 PDK。并行矩阵对每个新用例施加 120 秒运行上限，避免一个难解的堆叠组合阻塞其余测试。报告含源码 SHA-256、逐例结果和失败原因；并行矩阵可加 `--resume` 保留已完成结果，单批测试可用 `--collect --label <原标签>` 恢复汇总。

最终结果、原生 OA 图集和已知失败组合见 `validation/TEST_RESULTS_CN.md` 与 `validation/native/native_gallery.html`。生成与几何检查不等于 foundry DRC/LVS 或 EM 验证。

## 原有接口说明

本版本把普通实例界面收敛为 22 个可编辑字段：17 个绕组几何字段与 5 个金属 / 过孔字段，根据拓扑与轮廓数量隐藏不生效的字段。默认 1/1 轮廓时 contour / interleaved / split_lobe 显示 19 个，stacked 显示 18 个；任何拓扑最多显示 21 个。

只固定三个外部 PIN 的坐标和层次。PIN 接入宽度、长度和方向不再是参数，由生成器计算；内部开口和 CT 汇合点也不作为扫描变量。W1 对应 A–CT，W2 对应 B–CT，各自具有明确的轮廓数量、绕向、线宽和间距。

PCell 本身仅生成几何，不执行 PDK DRC；独立 Python 估算器提供未校准的 L/Q/K/S 初筛模型。宿主验证不能代替真实 Cadence SKILL / OA / PCell 求值。

## 安装

建立可写且已 attach 到目标 PDK 的 library，例如 TCOIL_TEST。在 CIW 执行：

```skill
load("/你的路径/tcoil_pcell_v0_5_2/tcoil.il")
tcoilInstall("TCOIL_TEST" "TM1" "TM2" "TM2_TM1")
```

默认生成 `tcoil_v050/layout`。放置新实例后按 q 修改参数；旧版实例不会自动迁移为新参数语义。内部辅助函数使用独立的 `tc5` 命名空间，可与 v0.4.1 的辅助函数同时加载；公共安装入口 `tcoilInstall` 以最后加载版本为准。包内 `libInit.il.example` 给出库启动时加载代码的模板，不在其中重复执行安装。

两层金属及标准 via 名需换成实际 PDK 名称。viaDefName 是连接两层金属的 via 定义，不是 cut layer 名。默认技术文本路径为 Virtuoso 当前工作 / 启动目录下的 `tech.tf`；安装时读取技术数据，PCell 求值使用已保存的快照，不在每次求值时读取外部文件。

## 当前项目的固定约束

```text
boundary = ((40 12)(0 12)(0 0)(10 0)(10 5)(27 5)(27 0)(40 0))
pinA  = (0,2),   metal2
pinCT = (40,2),  metal2
pinB  = (24,12), metal2
```

PIN 坐标是接入线外端截面的中心。边界与 PIN 在项目安装时写入快照，不占用每个实例的普通参数界面。宽度、长度、接入方向以及内部开口和汇合位置由几何生成器决定，不承诺维持旧版内部开口或百分比抽头的物理坐标。

`minClearance` 是项目的最小几何检查间距。普通实例里的 space1/space2/profile 不能低于它；它不是自动验证过的完整工艺 DRC 规则。制造网格从技术来源保存到项目配置中。

## 更换项目的边界与 PIN

编辑包内 `project_setup.il`，然后执行：

```skill
load("/你的路径/tcoil_pcell_v0_5_2/project_setup.il")
tcoilInstallProject("TCOIL_TEST")
```

`pins` 的顺序为 A、CT、B，每项 `(x y layerAlias)`；layerAlias=1/2 分别指 metal1/metal2。模板只把边界、PIN 坐标 / 层次和 minClearance 作为项目配置，PIN 宽度和长度不在其中。

完整安装调用：

```skill
tcoilInstall("TCOIL_TEST" "TM1" "TM2" "TM2_TM1"
  "tcoil_myproject" "/work/my_pdk/tech.tf"
  (list
    (list 'boundary "((40 12)(0 12)(0 0)(10 0)(10 5)(27 5)(27 0)(40 0))")
    (list 'pins '((0 2 2)(40 2 2)(24 12 2)))
    (list 'minClearance 0.5)))
```

扩展安装参数现在依次为 cellName、techPath、project。旧版 manualCut 参数已删除；四参数的基础调用保持不变。省略技术路径且默认 tech.tf 不存在时，使用附着工艺库里的标准 via。项目与工艺分别保存为隐藏的 projectData / techData，共 24 个 PCell 形式参数，普通界面只显示当前拓扑适用的可编辑字段。

## 四种拓扑

| topology | 主绕组安排 | 专用参数 |
|---|---|---|
| contour | 两段绕组沿同一形状的轮廓按组排列 | 无 |
| interleaved | 两段绕组的轮廓按组交错 | interleaveBlock |
| stacked | W1 / W2 的主绕组分别在 metal1 / metal2 | 无 |
| split_lobe | 两段绕组放在分离的叶片区域 | lobeGap |

partial_interleaved 合并为 interleaved 的分组大小；分叶的同向 / 反向组合由 sense1/2 表示，不再额外提供重复的 figure8 开关。W1 / W2 各只有一条轮廓时，contour 与 interleaved 的轮廓排列相同；多轮廓时才体现交错次序的差异。每种拓扑仍需满足当前边界、端口、线宽和孔占用约束；切换拓扑不保证所有参数组合均可生成。

## 保留的参数

| 参数 | 含义 |
|---|---|
| turns1 / turns2 | 每条支路自己的开口轮廓数；正整数 |
| width1 / width2 | 每段绕组的基础宽度 |
| space1 / space2 | 该绕组轮廓朝向下一条内侧轮廓的边到边间距 |
| sense1 / sense2 | 分别以 A→CT、B→CT 为参考的 CW / CCW 绕向 |
| inset1 / inset2 | 在拓扑基准轮廓上的额外内缩，非负 |
| offsetX / offsetY | W2 相对基准位置的 X / Y 平移 |
| profile1 / profile2 | 各绕组按匝、按边的局部宽度和间距覆盖 |
| interleaveBlock | 同一绕组连续放置几条轮廓后再切换；仅交错显示 |
| lobeGap | 分叶自动划分之后增加的叶片间隔；仅分叶显示 |
| metal1 / metal2 | 实际金属层名 |
| viaDefName | 跨两层金属的 via 定义名 |
| viaRows / viaCols | via cut 阵列行数 / 列数 |

加上 topology 共 22 个字段，但不同时全部显示。space1 在 contour / interleaved 或 turns1>1 时显示；space2 在 turns2>1，或 interleaved 且 turns1>interleaveBlock 时显示；interleaveBlock 只在 interleaved 且 turns1>1 时显示；lobeGap 只在 split_lobe 时显示。没有内侧相邻轮廓时，该轮廓的 gap 没有几何作用，局部 profile 的 gap 也同样如此。普通界面不再出现 leadWidth、terminalLength、pinDir、openingGap、tapTurn、tapFraction、pinOrder、routePreference、maxStates、viaCost 等字段。

## 局部线宽与间距

profile1/profile2 默认空字符串，表示使用对应基础 width/space。输入格式：

```text
((turn edge width gap) ...)
```

- turn：本绕组从外到内的匝号，0 起始；-1 匹配所有匝。
- edge：基准轮廓的边号，0 起始；-1 匹配所有边。
- width / gap：单位 µm；-1 表示本行不覆盖该项。
- 多行匹配时按先后顺序应用，后续有效数值覆盖此前设置。

例如：

```text
((-1 2 1.2 -1) (0 1 0.8 0.7))
```

表示所有匝的边 2 使用 1.2 µm 宽度，最外匝的边 1 使用 0.8 µm 宽度和 0.7 µm 向内间距。列表只是参数含义示例，不保证当前小边界中可行。q 界面输入列表本身；脚本中作为字符串传入，需要外层双引号。不要输入可执行 SKILL 表达式。

边号由规范化后的基准多边形确定，不随 sense 改变。矩形为 0 下、1 右、2 上、3 左。当前凹形边界为：0 右下底边、1 右外边、2 顶边、3 左外边、4 左下底边、5 凹口左竖边、6 凹口顶边、7 凹口右竖边。分叶使用各自叶片的基准轮廓；请结合图解检查边号。

局部宽度变化会影响轮廓中心线偏置和后续轮廓节距，不能按“保持中心线原位只改变矩形宽度”理解。via landing 需覆盖实际宽度；局部加宽可能同时增加换层点的占用。

## 自动接入与失败含义

三个 PIN 的短接入段先按固定坐标及可用方向建立，再生成主绕组。PIN 接入尺寸由几何尺寸派生；叠层结构需要为同层 PIN 接入保留空间时，生成器可自动增加对应边的退让量。

连接求解将多轮廓绕组的内部桥接，以及 W1→A、W1→CT、W2→B、W2→CT 四条支路连接一起纳入有界的连接顺序组合。每次失败回退该尝试新增的连接；不会提交半完成的绕线。优先尝试简单路径，需要时用 A* 避障，并保留完整 landing、边界、间距与路径自身检查。

这不是保证全局完备的拓扑求解器。报错意味着本次参数在当前生成与搜索策略下未通过；不能把一次搜索失败解释为所有可能结构都不存在。

## 实际生成图与验证来源

原始 v0.5.0 的独立 HTML、SVG/PNG 图例继续保留，属于历史宿主示例，不代表 v0.5.2 的原生 PDK 结果。当前结果使用 `validation/native/native_gallery.html`，图形来自实际 OA 输出的金属矩形，不是 Virtuoso 截图。蓝色 / 橙色分别表示 metal1 / metal2，小方点标出 via 中心；图集不等于 DRC 或 EM 验证。

- `actual_topology_gallery.svg`：四种拓扑：当前边界与默认 1/1 轮廓。
- `actual_interleaved_gallery.svg`：交错拓扑：已通过宿主检查的多轮廓示例。

历史 v0.5.0 图例源码 SHA-256：`dfbbeee469472bea46d893cde219d49f0cc1a168077c4f5abc3d87595a30a229`。`gallery_metadata.json` 对应历史图例；当前测试源码哈希见各个新报告。

## 文件

| 文件 | 用途 |
|---|---|
| tcoil.il | 运行代码、项目配置、PCell 与 CDF |
| project_setup.il | 一次性项目配置与安装调用模板 |
| parameters.json | 22 个可编辑字段的名称、类型、默认值和显示条件 |
| Tcoil_Parameter_Guide_v0.5.0.html | 离线图解、全部字段和局部 profile 说明 |
| validation/ | 宿主检查与结果；不替代 Cadence 或工艺验证 |

扫描阶段建议保存每组参数、生成成功 / 失败结果以及失败原因。Q/L/K 数值覆盖仍需在后续 EM 抽取阶段确认。
