#!/usr/bin/env python3
"""Export ordered A->CT and B->CT centerlines from a native QA layout export."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'validation'))
from check_geometry import parse
from audit_geometry import audit


def export(path, source=None):
    path = Path(path)
    raw = parse(path.read_text())[0]
    if len(raw) < 9 or not raw[1]:
        raise ValueError('A successful native layout export is required')
    if len(raw) <= 10 or raw[10] != 1:
        raise ValueError('Native zero-outside-area boundary audit flag is required')
    native_audit = audit(dict(objects=raw[3], vias=raw[4] or [], pins=raw[5], boundary=raw[6]))
    rings = [dict((str(k), v) for k, v in ring) for ring in raw[7]]
    routes = dict((str(tag), states) for states, tag in raw[8])
    pins = dict((str(p[3]), p) for p in raw[5])
    widths = [w for r in rings for w in r['widths']]
    lead_width = min(widths)
    branches = []
    for owner, label in ((1, 'A'), (2, 'B')):
        segments = []

        def add(states, values, tag):
            if len(values) != len(states) - 1:
                raise ValueError('Segment widths do not match the path: ' + tag)
            for a, b, width in zip(states, states[1:], values):
                a, b = list(a), list(b)
                if a == b:
                    continue
                if a[2] != b[2] and a[:2] != b[:2]:
                    raise ValueError('Nonvertical via transition')
                if a[2] == b[2] and a[0] != b[0] and a[1] != b[1]:
                    raise ValueError('Estimator supports Manhattan emitted conductors')
                if segments and segments[-1]['end'] != a:
                    raise ValueError('Discontinuous branch at ' + tag)
                segments.append(dict(start=a, end=b, width_um=width,
                                     kind='via' if a[2] != b[2] else 'metal', tag=tag))

        def route(tag, reverse=False):
            states = list(routes[tag])
            if reverse:
                states.reverse()
            add(states, [lead_width] * (len(states) - 1), tag)

        p = pins[label]
        add([list(p[0]) + [p[2]], list(p[1]) + [p[2]]], [lead_width], 'PIN_' + label)
        route('LEAD_' + label, reverse=True)
        owned = sorted((r for r in rings if r['owner'] == owner), key=lambda r: r['turn'])
        for index, r in enumerate(owned):
            if index:
                route('W%d_link%d' % (owner, index))
            rw = r.get('pathWidths')
            if rw is None:
                if len(set(r['widths'])) != 1:
                    raise ValueError('Nonuniform widths require a v0.5.2 native export')
                rw = [r['widths'][0]] * (len(r['points']) - 1)
            add([list(p) + [r['layer']] for p in r['points']], rw,
                'W%d_ring%d' % (owner, r['turn']))
        route('W%d_TO_CT' % owner)
        p = pins['CT']
        add([list(p[1]) + [p[2]], list(p[0]) + [p[2]]], [lead_width], 'PIN_CT')
        branches.append(dict(name='W%d' % owner, ports=[label, 'CT'], segments=segments))
    result = dict(schema='tcoil-centerlines-1', name=str(raw[0]), units='um',
                  port_order=['A', 'CT', 'B'], branches=branches,
                  source_export=path.name,
                  source_export_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                  boundary=raw[6], via_array=raw[13] if len(raw) > 13 else None,
                  native_geometry_audit=native_audit, native_boundary_subtraction_verified=True)
    if source:
        result['pcell_source_sha256'] = hashlib.sha256(Path(source).read_bytes()).hexdigest()
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_export')
    parser.add_argument('output')
    parser.add_argument('--source', help='Exact PCell source loaded for the native run')
    args = parser.parse_args()
    result = export(args.native_export, args.source)
    Path(args.output).write_text(json.dumps(result, indent=2) + '\n')
    print('Exported', result['name'], 'with', sum(len(b['segments']) for b in result['branches']), 'segments')
