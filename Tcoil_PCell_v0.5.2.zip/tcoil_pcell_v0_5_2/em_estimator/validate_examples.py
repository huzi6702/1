#!/usr/bin/env python3
"""Exercise geometry import and approximate networks across native audited cases.

A functional/numerical regression, not a comparison against EM or measurements.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import numpy as np
from export_geometry import export, ROOT
from estimate import estimate, write_fasthenry


def run(paths):
    source_hash = hashlib.sha256((ROOT / 'tcoil.il').read_bytes()).hexdigest()
    stack_path = Path(__file__).with_name('example_stack.json')
    config = json.loads(stack_path.read_text())
    config['frequency_ghz']['points'] = 5
    results = []
    for path in paths:
        report = json.loads(path.read_text())
        if report['source_sha256'] != source_hash:
            raise ValueError('Stale native report: ' + str(path))
        for case in report['cases']:
            if not case.get('generated') or not case['passed']:
                continue
            # All polygon cases, defaults and selected width/turn/array variants.
            if case.get('variant', 'default') not in ('default', 'profile', 'profile18', 'turns12', 'turns21', 'via12', 'via21'):
                continue
            item = dict(name=case['name'], passed=False)
            try:
                raw = path.parent / case['native_export_relative'] if case.get('native_export_relative') else Path(case['native_export'])
                g = export(raw, ROOT / 'tcoil.il')
                frequencies, s, rows, model, atoms = estimate(g, copy.deepcopy(config))
                with tempfile.TemporaryDirectory() as directory:
                    write_fasthenry(Path(directory) / 'conductors.inp', atoms, g, config)
                item.update(passed=True, atomic_segments=len(atoms), signed_K=model['signed_K'],
                            max_singular_value_S=model['max_singular_value_S'],
                            max_reciprocity_error=model['max_reciprocity_error'])
            except Exception as exc:
                item['error'] = str(exc)
            results.append(item)
    result = dict(passed=bool(results) and all(c['passed'] for c in results), cases=results,
                  source_sha256=source_hash, estimator_sha256=hashlib.sha256(Path(__file__).with_name('estimate.py').read_bytes()).hexdigest(), stack_sha256=hashlib.sha256(stack_path.read_bytes()).hexdigest(),
                  frequencies_GHz=[1., 13.25, 25.5, 37.75, 50.],
                  scope='Import, branch continuity, optional deck graph connectivity, finite/passive/reciprocal approximate networks only; no solver execution or physical accuracy validation')
    out = Path(__file__).with_name('functional_validation.json')
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(sum(c['passed'] for c in results), '/', len(results), 'functional geometry/model checks')
    for c in results:
        if not c['passed']:
            print(c['name'], c['error'])
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reports', nargs='*')
    args = parser.parse_args()
    paths = [Path(p) for p in args.reports] if args.reports else [ROOT / 'validation/native' / name for name in ('final_matrix_report.json', 'final_polygons_report.json', 'final_many_vertices_report.json')]
    result = run(paths)
    raise SystemExit(0 if result['passed'] else 1)
