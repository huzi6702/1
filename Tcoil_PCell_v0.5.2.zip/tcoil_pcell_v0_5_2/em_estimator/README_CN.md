# T-coil Python 电磁估算原型（1–50 GHz）

可以用 Python 从 PCell 几何和少量材料配置计算 L1、L2、带符号的互感 M / K、损耗 Q，并输出三端口 `.s3p`。这里已经提供可运行原型。**示例材料数值不是 TSMC18 数据；此模型尚未经实测或场求解器校准，不能把输出作为工艺预测或签核结果。**

## 直接运行

从本发布目录运行；需要 NumPy，绘图另需 matplotlib。本工作站默认 `python3` 的 Anaconda 环境已包含两者；PCell 宿主检查请继续用 `/usr/bin/python3`。

```sh
python3 em_estimator/test_estimate.py
python3 em_estimator/estimate.py em_estimator/example_geometry.json \
  --stack em_estimator/example_stack.json --out em_estimator/my_output
python3 em_estimator/plot_results.py em_estimator/my_output
```

`example_geometry.json` 来自真实 Virtuoso 生成的 `original_stacked_default` 版图，包含绕组、引线、固定 PIN 和 via 的有序中心线及源码哈希。替换版图时：

```sh
python3 em_estimator/export_geometry.py \
  validation/native/native_exports/rectangle_contour_default.sexp \
  em_estimator/my_geometry.json --source tcoil.il
```

`--source` 必须指向该次生成实际加载的源码，不能给历史几何冒记当前源码哈希。导出器会重做实际金属连通性/意外环路/PIN 端点审计，并要求原生零越界面积标记；实际 via cut 坐标仍以对应原生 JSON 报告的验证为准。非均匀线宽使用 v0.5.2 的 `pathWidths`，旧版导出仅支持均匀线宽。导体必须是当前生成器的曼哈顿中心线。

## 需要填写的工艺信息

编辑 `example_stack.json` 的副本。坐标和厚度单位 µm；方块电阻为 Ω/□，via 电阻为 Ω/cut，衬底电阻率为 Ω·cm。

| 信息 | 用途 |
|---|---|
| 每层金属中心高度、厚度、方块电阻 | 三维距离、DC 电阻、体电阻率 `ρ=R□t`、近似趋肤损耗 |
| 每段介质的上下高度、εr、tanδ | 层间/对衬底电容及介质损耗 |
| via cut 尺寸、单 cut 电阻 | 阵列等效面积与串联电阻；数量从几何读取 |
| 衬底 εr、电阻率，以及回流/接地假设 | 粗略衬底损耗，直接影响 Q 和 S |
| 频率、端口位置、参考阻抗 | 输出的物理含义与归一化 |

已从用户提供的 `tech.tf` 核对到 `sheetResistance METAL5=0.078`、`METAL6=0.0178`（按方块电阻 Ω/□ 使用），以及 `M6_M5` 的 0.36×0.36 µm cut。`tsmc18_stack_template.json` 保存这些已知值和技术文件哈希，其余缺失物理量使用 `null`，必须填写后才能运行；没有把示例层高/介质冒充为该工艺数据。标准 via 定义未给出单 cut 电阻，custom via 中的 0.0 占位值不应当成真实零电阻。该文件也未提供这里所需的完整垂直材料堆栈和衬底参数。

仅给 εr、方块电阻和金属厚度仍不充分：金属高度、层间距、衬底与实际回流条件不能从这些量唯一推导。本原型把参考地假设为远处理想衬底地，尚不支持真实地环/背面金属/接地接触布局。不能把 tech.tf 中未提供的垂直堆栈凭空补成真实工艺。

## 模型与输出定义

1. 两支路电流方向分别为 **A→CT、B→CT**，端口顺序固定 **1=A、2=CT、3=B**。共享 CT 金属先拆分去重，因此共享电阻进入 `R12`。
2. 对每段三维直线计算带截面软化长度的 Neumann 积分，组装部分电感矩阵，再投影至两个支路。软化长度是启发式近似；不是完整 PEEC 场求解。`L1/L2` 包括引线及 CT 共享段。
3. 金属 DC 电阻 `R□l/w`；频率损耗使用有限厚度导电薄板的趋肤近似。磁电感保持常数，未求解邻近效应、转角拥挤或高频电流重新分布。
4. 平行板/侧壁近似给出电容，未单独建模 via pad 电容，也未扣除转角矩形面积的重复计数；按沿导体的线性电位基函数投影。衬底用独立的半空间扩展 RC：`R≈ρ/(4a)`、`C≈4εa`，`a=√(A/π)`。这是很粗的局部近似，不包含横向衬底耦合和衬底涡流。
5. 构造对称被动的三端口 Y，再用 `S=(I−Z0Y)(I+Z0Y)⁻¹` 转换。**S3P 中 CT 是实际端口，并未短接至参考地。**

`metrics.csv` 区分：磁模型 L/M/K、仅金属损耗的 `Qmetal=ωL/R`，以及把 CT 接地后从 A/B 两端口 Z 矩阵提取的表观 L/Q/K。表观 Q 是 `Im(Zii)/Re(Zii)`，只在感性区有通常的电感 Q 含义；接近谐振的表观 K 不能再当作几何耦合系数。带符号 `K=M/√(L1L2)` 与上述电流方向绑定，不能无说明地取绝对值。A→B 串联磁电感为 `L1+L2−2M`。

`model_report.json` 记录输入哈希、数值互易/无源性检查和限制；`tcoil_approx.s3p` 使用 Hz、实虚部、50 Ω（可配置），三端口按行存储。`estimate_preview.png/.svg` 为示例曲线。数值检查通过只说明网络自洽，不能给出物理误差上限。

## 如何提高可信度

当前两电流、少数电位基函数的集中模型适合初筛和敏感性分析，**未验证整个 1–50 GHz 的定量精度**，尤其 Q、谐振位置及 S 参数可能偏差很大。没有证据支持“误差小于某个百分比”。

可先以 FastHenry 求频率相关 R/L 和电流分布，配合 FasterCap 等提取电容，再加入衬底、接地及分布网络；最终以覆盖典型形状/尺寸的 EM 或实测数据校准。FastHenry 本身是磁准静态导体求解器，单独使用它不能得到包含介质/衬底的可信 S3P。[MIT 求解器说明](https://www.rle.mit.edu/cpg/research_codes.htm)、[FastFieldSolvers 软件说明](https://www.fastfieldsolvers.com/software.htm)。

脚本同时导出 `conductors.inp`：两个外部端口 A–CT/B–CT、µm 单位和相应 S/µm 电导率、等效实体 via。**本次未安装/执行 FastHenry，deck 仅验证了本地连接图，尚未验证求解器读取及网格收敛。** 它不包含 via landing pad 的扩散电流或完整衬底。使用前按最高频率检查厚度/宽度细分并做网格收敛。[FastHenry 官方用户指南](https://www.fastfieldsolvers.com/Download/FastHenry_User_Guide.pdf)。

规则单平面螺旋可以采用 Mohan 等解析公式作量级对照，但其方形/六边形/八边形/圆形适用范围与精度不能直接套到任意凹多边形、多层 T-coil。[原论文](https://web.stanford.edu/~boyd/papers/inductance_expressions.html)。S3P 文件格式依据 [IBIS Touchstone 规范](https://ibis.org/touchstone_ver2.1/touchstone_ver2_1.pdf)。
