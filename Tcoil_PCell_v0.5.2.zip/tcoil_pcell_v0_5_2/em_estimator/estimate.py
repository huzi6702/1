#!/usr/bin/env python3
"""Uncalibrated reduced two-current RLC model; requires NumPy, no field solver.

This is a trend/sanity estimator, not a validated 1-50 GHz extraction engine.
"""
import argparse
import csv
import hashlib
import json
import math
import platform
from pathlib import Path
import numpy as np

MU0 = 4e-7 * math.pi
EPS0 = 8.8541878128e-12


def positive(value, name):
    try:
        value = float(value)
    except (TypeError, ValueError):
        raise ValueError(name + ' is required; replace missing/null material data')
    if not math.isfinite(value) or value <= 0:
        raise ValueError(name + ' must be finite and positive')
    return value


def validate_config(c):
    positive(c['reference_ohm'], 'reference_ohm')
    freq = c['frequency_ghz']
    positive(freq['start'], 'frequency start')
    if freq['stop'] <= freq['start'] or int(freq['points']) != freq['points'] or freq['points'] < 2:
        raise ValueError('Invalid frequency range/point count')
    positive(freq['stop'], 'frequency stop')
    for name, m in c['metals'].items():
        for key in ('z_center_um', 'thickness_um', 'sheet_resistance_ohm'):
            positive(m[key], name + '.' + key)
        if m['z_center_um'] <= m['thickness_um'] / 2:
            raise ValueError('Metal must lie above substrate surface z=0')
    previous = 0.
    for d in sorted(c['dielectrics'], key=lambda x: x['z_bottom_um']):
        if abs(d['z_bottom_um'] - previous) > 1e-9 or d['z_top_um'] <= previous:
            raise ValueError('Dielectrics must tile from z=0 with no gaps/overlaps')
        positive(d['eps_r'], 'dielectric eps_r')
        if not math.isfinite(d['tan_delta']) or d['tan_delta'] < 0:
            raise ValueError('Invalid dielectric loss tangent')
        previous = d['z_top_um']
    if previous < max(m['z_center_um'] + m['thickness_um'] / 2 for m in c['metals'].values()):
        raise ValueError('Dielectric stack does not cover all metals')
    for key in ('eps_r', 'resistivity_ohm_cm'):
        positive(c['substrate'][key], 'substrate.' + key)
    if c['substrate']['model'] != 'halfspace_spreading':
        raise ValueError('Only the explicit halfspace_spreading substrate model is implemented')
    for key in ('resistance_per_cut_ohm', 'cut_width_um', 'cut_height_um'):
        positive(c['via'][key], 'via.' + key)


def atoms_from_geometry(g, c):
    """Split collinear overlaps so a shared CT conductor is counted once."""
    if g['units'] != 'um' or g['port_order'] != ['A', 'CT', 'B']:
        raise ValueError('Expected um and fixed A,CT,B port order')
    array = g.get('via_array')
    if not array:
        raise ValueError('Actual via array dimensions are required')
    rows, cols, cw, ch = array[:4]
    positive(rows, 'via rows'); positive(cols, 'via columns')
    if abs(cw - c['via']['cut_width_um']) > 1e-6 or abs(ch - c['via']['cut_height_um']) > 1e-6:
        raise ValueError('Configured via cut dimensions disagree with native geometry')
    groups = {}
    for bi, branch in enumerate(g['branches']):
        if branch['ports'] != [(['A', 'B'][bi]), 'CT']:
            raise ValueError('Branch current must point from A/B to CT')
        arc = 0.
        prepared = []
        for seg in branch['segments']:
            a, b = seg['start'], seg['end']
            ma, mb = c['metals'][str(a[2])], c['metals'][str(b[2])]
            p = [a[0], a[1], ma['z_center_um']]
            q = [b[0], b[1], mb['z_center_um']]
            changed = [i for i in range(3) if abs(p[i] - q[i]) > 1e-10]
            if len(changed) != 1:
                raise ValueError('Zero-length or non-Manhattan segment')
            axis = changed[0]
            fixed = tuple(round(p[i], 9) for i in range(3) if i != axis)
            lo, hi = sorted((p[axis], q[axis]))
            via = axis == 2
            # Equivalent solid via area is the total cut area, not the pad area.
            width = math.sqrt(rows * cols * cw * ch) if via else positive(seg['width_um'], 'width')
            thick = width if via else ma['thickness_um']
            resistance = c['via']['resistance_per_cut_ohm'] / (rows * cols) if via else ma['sheet_resistance_ohm'] * (hi - lo) / width
            entry = dict(axis=axis, fixed=fixed, lo=lo, hi=hi, branch=bi,
                         sign=1 if q[axis] > p[axis] else -1, arc=arc,
                         width=width, thick=thick, via=via, resistance=resistance,
                         rho=None if via else ma['sheet_resistance_ohm'] * thick * 1e-6,
                         z=p[2], layer=str(a[2]), tag=seg['tag'])
            prepared.append(entry)
            arc += hi - lo
        if not prepared:
            raise ValueError('Empty branch')
        for entry in prepared:
            entry['total_arc'] = arc
            groups.setdefault((entry['axis'], entry['fixed']), []).append(entry)
    # A perpendicular lead/via endpoint can meet the interior of a conductor.
    # Split there as well, so optional FastHenry nodes are electrically joined.
    endpoints = []
    for (axis, fixed), entries in groups.items():
        for e in entries:
            for position in (e['lo'], e['hi']):
                it = iter(fixed)
                endpoints.append(tuple(position if k == axis else next(it) for k in range(3)))
    atoms = []
    for (axis, fixed), entries in sorted(groups.items()):
        cuts = set(x for e in entries for x in (e['lo'], e['hi']))
        for point in endpoints:
            if tuple(round(point[k], 9) for k in range(3) if k != axis) == fixed:
                if any(e['lo'] < point[axis] < e['hi'] for e in entries):
                    cuts.add(point[axis])
        cuts = sorted(cuts)
        for lo, hi in zip(cuts, cuts[1:]):
            mid = (lo + hi) / 2
            covered = [e for e in entries if e['lo'] < mid < e['hi']]
            if not covered:
                continue
            e = max(covered, key=lambda e: e['width'])
            coeff = np.zeros(2)
            potentials = []
            for item in covered:
                coeff[item['branch']] += item['sign']
                offset = mid - item['lo'] if item['sign'] > 0 else item['hi'] - mid
                frac = (item['arc'] + offset) / item['total_arc']
                v = np.zeros(3); v[[0, 2][item['branch']]] = 1 - frac; v[1] = frac
                potentials.append(v)
            if len(set(item['branch'] for item in covered)) > 1:
                potential = np.array([0., 1., 0.])  # shared CT stub
            else:
                potential = np.mean(potentials, axis=0)
            xyz = []; it = iter(fixed)
            for i in range(3):
                xyz.append(mid if i == axis else next(it))
            atoms.append(dict(axis=axis, fixed=fixed, lo=lo * 1e-6, hi=hi * 1e-6,
                              center=np.array(xyz) * 1e-6, length=(hi - lo) * 1e-6,
                              width=e['width'] * 1e-6, thick=e['thick'] * 1e-6,
                              rdc=e['resistance'] * (hi - lo) / (e['hi'] - e['lo']),
                              rho=e['rho'], via=e['via'], layer=e['layer'],
                              coeff=coeff, potential=potential))
    return atoms


def parallel_integral(a, b, c, d, soft_distance):
    """Analytic double integral of 1/sqrt((x-y)^2+s^2), in metres."""
    s = soft_distance
    def f(u):
        return u * math.asinh(u / s) - math.hypot(u, s)
    return f(b - c) - f(a - c) - f(b - d) + f(a - d)


def inductance_matrix(atoms):
    n = len(atoms)
    partial = np.zeros((n, n))
    for i, a in enumerate(atoms):
        for j in range(i + 1):
            b = atoms[j]
            if a['axis'] != b['axis']:
                continue
            # Softened line kernel: heuristic cross-section regularization.
            ga = .2235 * (a['width'] + a['thick']) / math.sqrt(2.)
            gb = .2235 * (b['width'] + b['thick']) / math.sqrt(2.)
            perp2 = sum((a['center'][k] - b['center'][k]) ** 2 for k in range(3) if k != a['axis'])
            s = math.sqrt(perp2 + ga * ga + gb * gb)
            partial[i, j] = partial[j, i] = MU0 / (4 * math.pi) * parallel_integral(a['lo'], a['hi'], b['lo'], b['hi'], s)
    incidence = np.array([a['coeff'] for a in atoms])
    result = incidence.T.dot(partial).dot(incidence)
    if np.linalg.eigvalsh(result).min() <= 0:
        raise ValueError('Nonpositive inductance matrix: geometry/model needs investigation')
    return result, incidence


def skin_factor(rho, width, thickness, frequency):
    delta = math.sqrt(2 * rho / (2 * math.pi * frequency * MU0))
    x = (1 + 1j) * min(width, thickness) / (2 * delta)
    return 1. if abs(x) < 1e-5 else float((x / np.tanh(x)).real)


def dielectric_path(c, z0, z1):
    """Return equivalent d/epsilon in m and a thickness-weighted loss tangent."""
    distance = loss = 0.
    for d in c['dielectrics']:
        span = max(0., min(z1, d['z_top_um']) - max(z0, d['z_bottom_um']))
        weight = span * 1e-6 / d['eps_r']
        distance += weight; loss += weight * d['tan_delta']
    if distance <= 0:
        raise ValueError('No positive dielectric thickness between metal faces')
    return distance, loss / distance


def capacitances(atoms, c):
    grounds, pairs = [], []
    for a in atoms:
        if a['via']:
            continue
        area = a['length'] * a['width']
        height = a['center'][2] * 1e6 - a['thick'] * .5e6
        path, loss = dielectric_path(c, 0., height)
        cap = EPS0 * area / path
        radius = math.sqrt(area / math.pi)
        substrate_r = c['substrate']['resistivity_ohm_cm'] * .01 / (4 * radius)
        substrate_c = 4 * EPS0 * c['substrate']['eps_r'] * radius
        grounds.append((a['potential'], cap, loss, substrate_r, substrate_c))
    for i, a in enumerate(atoms):
        if a['via']:
            continue
        for b in atoms[:i]:
            if b['via']:
                continue
            cap = loss = 0.
            # Axis-aligned conductor footprints; overlap uses finite rectangles.
            def footprint(s):
                x, y = s['center'][:2]
                if s['axis'] == 0:
                    return s['lo'], y - s['width'] / 2, s['hi'], y + s['width'] / 2
                return x - s['width'] / 2, s['lo'], x + s['width'] / 2, s['hi']
            ra, rb = footprint(a), footprint(b)
            if a['layer'] == b['layer'] and a['axis'] == b['axis']:
                overlap = max(0., min(a['hi'], b['hi']) - max(a['lo'], b['lo']))
                transverse = 1 - a['axis']
                gap = abs(a['center'][transverse] - b['center'][transverse]) - (a['width'] + b['width']) / 2
                if gap > 1e-12 and overlap > 0:
                    z = a['center'][2] * 1e6
                    dielectric = next(d for d in c['dielectrics'] if d['z_bottom_um'] <= z <= d['z_top_um'])
                    cap = EPS0 * dielectric['eps_r'] * min(a['thick'], b['thick']) * overlap / gap
                    loss = dielectric['tan_delta']
            elif a['layer'] != b['layer']:
                area = max(0., min(ra[2], rb[2]) - max(ra[0], rb[0])) * max(0., min(ra[3], rb[3]) - max(ra[1], rb[1]))
                if area:
                    low, high = sorted((a, b), key=lambda s: s['center'][2])
                    z0 = (low['center'][2] + low['thick'] / 2) * 1e6
                    z1 = (high['center'][2] - high['thick'] / 2) * 1e6
                    if z1 <= z0:
                        raise ValueError('Metal volumes overlap vertically')
                    path, loss = dielectric_path(c, z0, z1)
                    cap = EPS0 * area / path
            if cap:
                difference = a['potential'] - b['potential']
                pairs.append((np.outer(difference, difference), cap, loss))
    return grounds, pairs


def y_to_s(y, z0):
    identity = np.eye(y.shape[0])
    # Right-hand matrix division preserves the general matrix formula.
    return np.linalg.solve((identity + z0 * y).T, (identity - z0 * y).T).T


def write_touchstone(path, frequencies, matrices, z0):
    """Touchstone 1 compatible three-port full matrix, ROW-major per IBIS."""
    with Path(path).open('w') as stream:
        stream.write('! Uncalibrated approximate model; ports 1=A 2=CT 3=B\n')
        stream.write('! Reference is ideal remote substrate ground; see model_report.json\n')
        stream.write('# Hz S RI R %.12g\n' % z0)
        for frequency, matrix in zip(frequencies, matrices):
            for row in range(3):
                values = ' '.join('%.12g %.12g' % (v.real, v.imag) for v in matrix[row])
                stream.write(('%.12g ' % frequency if row == 0 else '  ') + values + '\n')


def estimate(g, c):
    validate_config(c)
    atoms = atoms_from_geometry(g, c)
    inductance, incidence = inductance_matrix(atoms)
    grounds, pairs = capacitances(atoms, c)
    frequencies = np.linspace(c['frequency_ghz']['start'], c['frequency_ghz']['stop'], int(c['frequency_ghz']['points'])) * 1e9
    topology = np.array([[1., 0.], [-1., -1.], [0., 1.]])
    rows, matrices = [], []
    worst_passivity = worst_reciprocity = 0.
    for f in frequencies:
        omega = 2 * math.pi * f
        rs = np.array([a['rdc'] if a['via'] else a['rdc'] * skin_factor(a['rho'], a['width'], a['thick'], f) for a in atoms])
        resistance = incidence.T.dot(rs[:, None] * incidence)
        branch_z = resistance + 1j * omega * inductance
        y = topology.dot(np.linalg.solve(branch_z, topology.T))
        for potential, cap, loss, sr, sc in grounds:
            oxide_y = omega * cap * (loss + 1j)
            substrate_y = 1 / sr + 1j * omega * sc
            y += np.outer(potential, potential) * oxide_y * substrate_y / (oxide_y + substrate_y)
        for stamp, cap, loss in pairs:
            y += stamp * omega * cap * (loss + 1j)
        s = y_to_s(y, c['reference_ohm'])
        worst_passivity = max(worst_passivity, float(np.linalg.svd(s, compute_uv=False).max()))
        worst_reciprocity = max(worst_reciprocity, float(np.abs(s - s.T).max()))
        # CT grounded ONLY for characterization; .s3p retains CT as port 2.
        apparent = np.linalg.inv(y[np.ix_([0, 2], [0, 2])])
        lapp = np.imag(np.diag(apparent)) / omega
        qapp = np.imag(np.diag(apparent)) / np.real(np.diag(apparent))
        kapp = apparent[0, 1].imag / omega / math.sqrt(lapp[0] * lapp[1]) if min(lapp) > 0 else float('nan')
        rows.append([f / 1e9, inductance[0, 0] * 1e12, inductance[1, 1] * 1e12,
                     inductance[0, 1] * 1e12, inductance[0, 1] / math.sqrt(inductance[0, 0] * inductance[1, 1]),
                     resistance[0, 0], resistance[1, 1], resistance[0, 1],
                     omega * inductance[0, 0] / resistance[0, 0], omega * inductance[1, 1] / resistance[1, 1],
                     lapp[0] * 1e12, lapp[1] * 1e12, qapp[0], qapp[1], kapp,
                     int(min(lapp) > 0 and min(qapp) > 0), abs(s[2, 0])])
        matrices.append(s)
    if worst_passivity > 1 + 1e-8 or worst_reciprocity > 1e-8:
        raise ValueError('Model failed numerical passivity/reciprocity check')
    report = dict(model='uncalibrated softened-Neumann / slab-skin / projected lumped RC',
                  calibrated=bool(c.get('calibrated', False)), stack_label=c['label'],
                  port_order=['A', 'CT', 'B'], reference_ohm=c['reference_ohm'],
                  frequency_ghz=[float(frequencies[0] / 1e9), float(frequencies[-1] / 1e9)],
                  atomic_segments=len(atoms), inductance_H=inductance.tolist(),
                  signed_K=float(inductance[0, 1] / math.sqrt(inductance[0, 0] * inductance[1, 1])),
                  max_singular_value_S=worst_passivity, max_reciprocity_error=worst_reciprocity,
                  geometry_name=g['name'], pcell_source_sha256=g.get('pcell_source_sha256'),
                  limitations=[
                      'No measured or full-wave EM calibration; numerical passivity does not establish physical accuracy.',
                      'Two uniform branch currents and linearly projected voltages; distributed resonances/current redistribution are not solved.',
                      'Softened line inductance heuristic, constant magnetic L; approximate slab skin resistance only.',
                      'No proximity effect, corner crowding, via pad spreading, substrate eddy currents, finite ground or contact geometry.',
                      'Parallel-plate/sidewall capacitances omit fringing and explicit via-pad capacitance; corner overlap areas are not union-corrected.',
                      'Independent halfspace spreading RC omits lateral substrate coupling.',
                      'Not validated for quantitative prediction over 1-50 GHz; Q/S/resonance may have large errors.'
                  ])
    return frequencies, np.array(matrices), rows, report, atoms


def write_fasthenry(path, atoms, g, c):
    """Optional conductor-only solver input. Solver execution is NOT included."""
    nodes, edges = {}, []
    def node(xyz):
        key = tuple(round(v * 1e6, 9) for v in xyz)
        if key not in nodes:
            nodes[key] = 'N%d' % (len(nodes) + 1)
        return nodes[key]
    fmax = c['frequency_ghz']['stop'] * 1e9
    for i, a in enumerate(atoms):
        p = a['center'].copy(); q = p.copy(); p[a['axis']] = a['lo']; q[a['axis']] = a['hi']
        n1, n2 = node(p), node(q)
        # Equivalent resistivity ensures a solid equivalent via has configured Rdc.
        rho = a['rdc'] * a['width'] * a['thick'] / a['length']
        sigma_um = 1 / rho * 1e-6
        delta = math.sqrt(2 * rho / (2 * math.pi * fmax * MU0))
        nw = max(3, int(math.ceil(a['width'] / delta)))
        nh = max(3, int(math.ceil(a['thick'] / delta)))
        nw += 1 - nw % 2; nh += 1 - nh % 2
        orientation = ' wx=0 wy=1 wz=0' if a['axis'] == 0 else ' wx=1 wy=0 wz=0'
        edges.append('E%d %s %s w=%.9g h=%.9g sigma=%.9g nwinc=%d nhinc=%d%s' %
                     (i + 1, n1, n2, a['width'] * 1e6, a['thick'] * 1e6, sigma_um, nw, nh, orientation))
    endpoints = {}
    for branch in g['branches']:
        for label, point in ((branch['ports'][0], branch['segments'][0]['start']), ('CT', branch['segments'][-1]['end'])):
            xyz = [point[0], point[1], c['metals'][str(point[2])]['z_center_um']]
            endpoints[label] = nodes[tuple(round(v, 9) for v in xyz)]
    adjacency = {label: set() for label in nodes.values()}
    for edge in edges:
        _, a, b = edge.split()[:3]
        adjacency[a].add(b); adjacency[b].add(a)
    reached = {endpoints['CT']}; todo = list(reached)
    while todo:
        for neighbor in adjacency[todo.pop()] - reached:
            reached.add(neighbor); todo.append(neighbor)
    if len(reached) != len(nodes):
        raise ValueError('Centerline graph disconnected; conductor deck requires geometry review')
    lines = ['* Generated uncalibrated conductor geometry; verify mesh convergence.', '.Units UM']
    lines += ['%s x=%.9g y=%.9g z=%.9g' % ((label,) + xyz) for xyz, label in nodes.items()]
    lines += edges
    lines += ['.external %s %s' % (endpoints['A'], endpoints['CT']),
              '.external %s %s' % (endpoints['B'], endpoints['CT']),
              '.freq fmin=%.9g fmax=%.9g ndec=10' % (c['frequency_ghz']['start'] * 1e9, fmax), '.end']
    Path(path).write_text('\n'.join(lines) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('geometry')
    parser.add_argument('--stack', default=str(Path(__file__).with_name('example_stack.json')))
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    geometry_path, stack_path = Path(args.geometry), Path(args.stack)
    g, c = json.loads(geometry_path.read_text()), json.loads(stack_path.read_text())
    frequencies, s, rows, report, atoms = estimate(g, c)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    write_touchstone(out / 'tcoil_approx.s3p', frequencies, s, c['reference_ohm'])
    write_fasthenry(out / 'conductors.inp', atoms, g, c)
    report['estimator_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    report['runtime'] = dict(python=platform.python_version(), numpy=np.__version__)
    report['frequency_points'] = len(frequencies)
    report['geometry_sha256'] = hashlib.sha256(geometry_path.read_bytes()).hexdigest()
    report['stack_sha256'] = hashlib.sha256(stack_path.read_bytes()).hexdigest()
    with (out / 'metrics.csv').open('w') as stream:
        writer = csv.writer(stream)
        writer.writerow(['frequency_GHz', 'L1_magnetic_pH', 'L2_magnetic_pH', 'M_signed_pH', 'K_signed', 'R11_ohm', 'R22_ohm', 'R12_shared_ohm', 'Q1_metal', 'Q2_metal', 'L1_apparent_pH_CT_grounded', 'L2_apparent_pH_CT_grounded', 'Q1_apparent_CT_grounded', 'Q2_apparent_CT_grounded', 'K_apparent_CT_grounded', 'apparent_inductive_valid', 'abs_S31'])
        writer.writerows(rows)
    (out / 'model_report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(L_pH=(np.array(report['inductance_H']) * 1e12).tolist(), K=report['signed_K'],
                         points=len(frequencies), calibrated=report['calibrated'], out=str(out)), indent=2))
