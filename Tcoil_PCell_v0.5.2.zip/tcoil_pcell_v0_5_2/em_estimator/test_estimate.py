#!/usr/bin/env python3
"""Numerical/format invariants; these tests do not calibrate physical accuracy."""
import copy
import hashlib
import json
import math
from pathlib import Path
import tempfile
import unittest
import numpy as np
from estimate import (MU0, atoms_from_geometry, estimate, inductance_matrix,
                      parallel_integral, skin_factor, validate_config,
                      write_touchstone, y_to_s)

HERE = Path(__file__).resolve().parent


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.g = json.loads((HERE / 'example_geometry.json').read_text())
        cls.c = json.loads((HERE / 'example_stack.json').read_text())

    def test_straight_integral_and_scale(self):
        length, soft = 40e-6, .3e-6
        expected = 2 * (length * math.asinh(length / soft) - math.hypot(length, soft) + soft)
        self.assertAlmostEqual(parallel_integral(0, length, 0, length, soft) / expected, 1., places=12)
        self.assertAlmostEqual(parallel_integral(0, 3 * length, 0, 3 * length, 3 * soft) / expected, 3., places=11)

    def test_dc_squares_and_shared_ct(self):
        atoms = atoms_from_geometry(self.g, self.c)
        metal = next(a for a in atoms if not a['via'])
        expected = self.c['metals'][metal['layer']]['sheet_resistance_ohm'] * metal['length'] / metal['width']
        self.assertAlmostEqual(metal['rdc'], expected)
        b = np.array([a['coeff'] for a in atoms])
        r = b.T.dot(np.array([a['rdc'] for a in atoms])[:, None] * b)
        self.assertGreater(r[0, 1], 0)  # shared physical CT stub has off-diagonal R
        self.assertGreater(np.linalg.eigvalsh(r).min(), 0)

    def test_reversing_current_changes_mutual_sign(self):
        atoms = atoms_from_geometry(self.g, self.c)
        original, _ = inductance_matrix(atoms)
        for a in atoms:
            a['coeff'][1] *= -1
        flipped, _ = inductance_matrix(atoms)
        self.assertTrue(np.allclose(np.diag(original), np.diag(flipped), rtol=1e-12, atol=1e-24))
        self.assertAlmostEqual(flipped[0, 1] / original[0, 1], -1)
        self.assertGreater(np.linalg.eigvalsh(original).min(), 0)

    def test_skin_limit_and_increase(self):
        rho = 2.7e-8
        self.assertAlmostEqual(skin_factor(rho, 1e-6, .6e-6, 1.), 1., places=8)
        self.assertGreater(skin_factor(rho, 1e-6, .6e-6, 50e9), 1.)

    def test_floating_rl_common_mode(self):
        incidence = np.array([[1., 0.], [-1., -1.], [0., 1.]])
        y = incidence.dot(np.linalg.inv(np.array([[2 + 5j, .2 + .4j], [.2 + .4j, 3 + 6j]]))).dot(incidence.T)
        s = y_to_s(y, 50.)
        self.assertTrue(np.allclose(s.dot(np.ones(3)), np.ones(3)))
        self.assertLessEqual(np.linalg.svd(s, compute_uv=False).max(), 1 + 1e-12)

    def test_s3p_row_order_with_nonsymmetric_oracle(self):
        # A symmetric reciprocal example cannot detect transpose/order mistakes.
        matrix = np.arange(1, 10).reshape(3, 3) + 1j * np.arange(11, 20).reshape(3, 3)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'check.s3p'
            write_touchstone(path, [1e9], [matrix], 50)
            data = [line.split() for line in path.read_text().splitlines() if not line.startswith(('!', '#'))]
        self.assertEqual([float(x) for x in data[0]], [1e9, 1, 11, 2, 12, 3, 13])
        self.assertEqual([float(x) for x in data[1]], [4, 14, 5, 15, 6, 16])
        self.assertEqual([float(x) for x in data[2]], [7, 17, 8, 18, 9, 19])

    def test_complete_model_passive_reciprocal_and_sensitive(self):
        c = copy.deepcopy(self.c); c['frequency_ghz']['points'] = 5
        f, s, rows, report, _ = estimate(self.g, c)
        self.assertEqual((f[0], f[-1]), (1e9, 50e9))
        self.assertLessEqual(report['max_singular_value_S'], 1 + 1e-10)
        self.assertLess(report['max_reciprocity_error'], 1e-12)
        c['dielectrics'][0]['eps_r'] *= 2
        _, changed, _, _, _ = estimate(self.g, c)
        self.assertGreater(np.max(abs(s - changed)), 1e-5)
        self.assertFalse(report['calibrated'])

    def test_reject_incomplete_stack_and_bad_values(self):
        for modify in (lambda c: c['dielectrics'][0].update(z_bottom_um=1),
                       lambda c: c['metals']['1'].update(sheet_resistance_ohm=-1),
                       lambda c: c['metals']['1'].pop('z_center_um'),
                       lambda c: c['substrate'].update(resistivity_ohm_cm=0)):
            c = copy.deepcopy(self.c); modify(c)
            with self.assertRaises((ValueError, KeyError)):
                validate_config(c)

    def test_real_process_template_refuses_unknown_heights(self):
        template = json.loads((HERE / 'tsmc18_stack_template.json').read_text())
        self.assertEqual(template['metals']['1']['sheet_resistance_ohm'], .078)
        self.assertEqual(template['metals']['2']['sheet_resistance_ohm'], .0178)
        with self.assertRaisesRegex(ValueError, 'z_center_um is required'):
            validate_config(template)


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ModelTests)
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    report = dict(passed=result.wasSuccessful(), tests_run=result.testsRun,
                  failures=[str(test) + ': ' + detail for test, detail in result.failures + result.errors],
                  estimator_sha256=hashlib.sha256((HERE / 'estimate.py').read_bytes()).hexdigest(),
                  geometry_sha256=hashlib.sha256((HERE / 'example_geometry.json').read_bytes()).hexdigest(),
                  stack_sha256=hashlib.sha256((HERE / 'example_stack.json').read_bytes()).hexdigest(),
                  scope='Numerical invariants and file format only; no physical accuracy calibration')
    (HERE / 'unit_test_report.json').write_text(json.dumps(report, indent=2) + '\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
