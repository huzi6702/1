#!/usr/bin/env python3
"""Plot exported metrics and three-port S magnitudes (optional matplotlib)."""
import argparse
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('directory')
args = parser.parse_args()
root = Path(args.directory)
with (root / 'metrics.csv').open() as stream:
    data = list(csv.DictReader(stream))
f = np.array([float(r['frequency_GHz']) for r in data])
lines = [line for line in (root / 'tcoil_approx.s3p').read_text().splitlines() if line.strip() and not line.startswith(('!', '#'))]
s = []
for index in range(0, len(lines), 3):
    values = [float(v) for row in lines[index:index + 3] for v in row.split()][1:]
    s.append(np.array([complex(values[k], values[k + 1]) for k in range(0, 18, 2)]).reshape(3, 3))
s = np.array(s)
fig, axes = plt.subplots(1, 3, figsize=(13, 3.8))
for key, label in [('L1_apparent_pH_CT_grounded', 'L1 apparent'), ('L2_apparent_pH_CT_grounded', 'L2 apparent')]:
    axes[0].plot(f, [float(r[key]) for r in data], label=label)
axes[0].set_ylabel('pH (CT grounded for extraction)')
for key, label in [('Q1_metal', 'Q1 metal only'), ('Q2_metal', 'Q2 metal only'), ('Q1_apparent_CT_grounded', 'Q1 apparent'), ('Q2_apparent_CT_grounded', 'Q2 apparent')]:
    axes[1].plot(f, [float(r[key]) for r in data], label=label)
axes[1].set_ylabel('Q')
for row, col, label in [(0, 0, 'S11'), (1, 0, 'S21 (A to CT)'), (2, 0, 'S31 (A to B)')]:
    axes[2].plot(f, 20 * np.log10(np.maximum(abs(s[:, row, col]), 1e-15)), label=label)
axes[2].set_ylabel('dB; configured port impedance')
for ax in axes:
    ax.set_xlabel('GHz'); ax.grid(alpha=.25); ax.legend(fontsize=8)
fig.suptitle('Illustrative stack only - uncalibrated approximate model', fontsize=12)
fig.tight_layout(rect=[0, 0, 1, .93])
fig.savefig(str(root / 'estimate_preview.png'), dpi=160)
fig.savefig(str(root / 'estimate_preview.svg'))
print(root / 'estimate_preview.png')
