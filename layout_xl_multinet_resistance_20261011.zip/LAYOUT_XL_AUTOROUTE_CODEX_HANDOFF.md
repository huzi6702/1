# Virtuoso Layout XL 两点自动连线项目：Codex 接手文档

整理日期：2026-10-10。本文配套代码基线：`layout_xl_autoroute_20260930_via_candidates_fix.zip`。

本文供本地 Codex 在没有聊天记录的情况下继续项目。它整理需求、实现约束、已修复问题、验证边界和下一步任务。本文没有修改压缩包中的程序，也没有把最后一个用户实际案例标记为已解决。

## 1. 本地接手先读这里

将本文与配套 ZIP 放在同一目录，解压 ZIP 后会得到 `layout_xl_autoroute/`。在本地 Codex 中打开这个共同父目录，先发送本文末尾的“接手提示词”。

接手时必须区分三类材料：

| 材料 | 用途与可信边界 |
| --- | --- |
| 配套 ZIP | 已交付代码基线，可复现程序逻辑和合成测试 |
| 用户当前工作目录的 config、geometry、日志 | 判断实际 PDK/版图问题的直接证据；若用户已自行改代码，也应保留并比较 |
| 本文及包内 README、REVIEW | 需求和研发背景；遇到当前运行行为差异，应结合当前代码与原始数据核查 |

**最重要的当前状态：**

- 基线包记录了 **127 项 Python 回归通过**，见 `VALIDATION.txt`。这些主要是合成配置/几何测试。
- 上次交付已经修复“同一层对只保留最后一种 via”的确定代码缺陷，并增加换层诊断。
- 用户最后一个 **M2→M3 实际案例尚未确认跑通**。还没有收到该次实际 `route_config.json`、`route_geometry.txt` 和新版搜索报告。
- 开发环境未编译、执行 Virtuoso 原生 SKILL，也没有完成该用户工艺的完整 Layout XL 集成验证。
- 包内 `route_config.json` 是早期 **METAL1–METAL6 示例/旧配置**，不是用户后来运行的 17 层配置。不能用它覆盖用户工作配置，也不能把测试孔尺寸当成 PDK 规则。
- 本次仅制作移交文档，核对了 ZIP 校验和、文件清单、代码和测试记录，没有重新执行那 127 项测试。

### 配套版本校验

| 项目 | 值 |
| --- | --- |
| ZIP 文件名 | `layout_xl_autoroute_20260930_via_candidates_fix.zip` |
| ZIP 字节数 | `224126` |
| ZIP SHA256 | `22b7eaa254abce1d939ff4f4b6f8ad6b768c50574c578f90f9155065ebb80186` |
| `route_engine.py` SHA256 | `a1e4ddf7008dca9419e9029351096e133a72bc4a7a1d63b4bd5df10e90365b48` |
| `autoroute.il` SHA256 | `7a67619773df09393226ad1c4e83817c7191ba1a1d096bcb726ea933438f1a2c` |

ZIP 内还有 `SHA256SUMS`。如果用户本地文件与基线不同，先保存差异，不能为了匹配基线而直接覆盖本地改动。

## 2. 项目目标与用户确定的需求

使用 **Cadence Virtuoso Layout XL**：用户依次点击版图中的两个已有金属位置，通过弹窗选择具体图形，然后自动用 metal 与 via 连通。先显示预览，用户确认后写入版图。

当前版本按几何判断，不依赖 net 信息。用户版图里的金属通常没有 net，未来再考虑带 net 的版本。

| 需求 | 必须保留的含义 |
| --- | --- |
| 点击已有金属 | 起终点必须实际命中已有金属，不能任意落在空白处；多个候选由弹窗选择 |
| 方向可配置 | 默认奇横偶纵，可改为偶横奇纵，也可逐层指定 H/V；任意层名均可 |
| 反方向例外非常有限 | **只有沿被点金属自身的方向、同中心线、同线宽作直线延长时才允许**；不能把“端点附近”整体当作自由转弯区 |
| 例外的时序范围 | 源接入段只在第一颗 via 之前；目标接入段只在最后一颗 via 之后；不能中途重新进入源接入例外 |
| 原金属接入质量 | 自动对齐真实中心线，接入宽度采用所选金属的实际局部宽度，避免错误台阶、偏移 |
| 两端可不同宽/不同层 | 分别保留各端宽度；跨层通过已知真实 via 关系连接 |
| 避开实际导体 | 包括 cell 内部金属和已有 via；不能直接把 cell 的整个外框投影成所有层障碍 |
| 避免新增 short | 无 net 时不能因为图形靠近或看起来同一条线就忽略它；保留同层占地和间距检查 |
| 查询/搜索规模 | 两点通常相距 300 µm 以下；真实项目障碍数可能显著超过最早的 3519 个 |
| 工艺配置 | 自动解析 tech.tf 的金属、层叠、宽度、space、via，并允许人工覆盖 |
| 自动孔 | 用户希望按线宽及交叠面积选单孔/阵列，优先利用 Cadence 自动打孔 |
| 实现语言 | 允许 SKILL 调用本地 Python，不要求纯 SKILL；运行端应适合离线环境 |

初始需求不要求直接连接 child cell 内部 pin/金属。当前包的选择、坐标变换和测试中保留了层级端点能力；这不等于需要新增“自动找 pin”或基于 net 自动扩展连接的功能。不要因此忽略 child cell 的障碍。

## 3. 代码与资料地图

以下路径均相对解压后的 `layout_xl_autoroute/`。

| 文件 | 职责 |
| --- | --- |
| `autoroute.il` | Layout XL 入口、F8、两点选择与弹窗、层级几何导出、预览、原生 metal/via 创建、复核与回滚 |
| `build_config.py` | 解析 tech.tf、输出 JSON 草稿、应用覆盖、校验并编译 `route_config.il` |
| `config_validation.py` | 配置合法性、配置指纹、pad 网格取整；生成器与引擎共用 |
| `route_engine.py` | 端点拟合、障碍索引、分阶段搜索、via 候选、完整路径验证、实际孔检查、诊断和快照 |
| `route_config.json` | 实际运行配置入口；用户工作版本应单独保留 |
| `route_config.il` | JSON 编译得到的 SKILL 数据；不要长期靠手改此文件维护规则 |
| `route_overrides.template.json` | 人工覆盖模板；按真实层/孔名填写 |
| `README.md` | 使用流程、参数、当前实现和升级说明；其中保留了历史版本小节 |
| `REVIEW_CN.md` | 逐次问题审查、修复依据、限制与参考 |
| `VALIDATION.txt` | 最近一次交付时的 127 项测试记录 |
| `changes.patch` | 相对早期 20260929 原包的累计差异，不是仅上一版到本版的增量 |
| `SHA256SUMS` | 包内文件校验和 |
| `tests/` | Python 合成回归、性能案例以及尚未执行的原生 SKILL 测试 |
| `*_REPRO.json`、`SEARCH_REPRO.txt` | 历次合成复现和对照，不能当作用户完整 PDK 的运行结果 |

### 关键函数定位

使用函数名搜索，避免依赖修改后失效的行号。

| 工作内容 | 代码入口 |
| --- | --- |
| UI 启动、路径、Python 日志 | `arStart`、`arSetDir`、`arRunPython` |
| 点选及端点导出 | `arPickMetal`、`arWriteEndpoint`、`arPrepareEndpoints` |
| 层级兼容及已有 via | `arHierarchyContextIssues`、`arCheckHierarchy`、`arExistingViaScope`、`arExportGeometry` |
| 预览及提交 | `arPreview`、`arDrawPreview`、`arCommit` |
| 原生孔与实际占地 | `arGetAutoViaOptions`、`arCreateVia`、`arActualViaLayerBoxes`、`arWriteActualVia` |
| 工艺提取 | `extract`、`metal_stack`、`via_catalog`、`apply_overrides`、`compile_skill` |
| 几何与端点 | `read_geometry`、`endpoint_section`、`endpoint_covered_obstacles`、`prepare_route` |
| 方向例外 | `endpoint_line_ok`、`profile_transition_allowed`、`direct_endpoint_route` |
| 寻路与索引 | `Index`、`route`、`_route_stages`、`_route_search` |
| 孔尺寸与换层诊断 | `via_geometry`、`endpoint_via_report`、`format_via_report` |
| 复核与快照 | `validate`、`validate_actual_vias`、`save_snapshot`、`check_snapshot` |

## 4. 实际执行链路

1. `arStart()` 校验并编译当前 JSON，加载配置，检查当前 technology，进入两点选择。
2. 导出真实端点到 `route_endpoints.txt`；Python `--prepare-endpoints` 求实际中心线、宽度和障碍查询 halo。
3. SKILL 在局部窗口中检查层级兼容，导出同层金属、分层已有 via 和未知层障碍到 `route_geometry.txt`。
4. Python 拟合端点、做 clearance 检查，再按 `coarse → layered → detailed` 寻路。
5. 完整路径验证通过后，生成 `route_result.il/json` 和预览指纹 `route_preview.json`；SKILL 显示预览。
6. 用户确认后，重新导出当前几何、核对 config/geometry/路径指纹并验证路线，随后创建线段和 pad，再调用原生 via API。
7. 导出实际 via 的分层 footprint，Python 复查真实占地与现有障碍、边界、查询窗口。失败回滚本次新增对象；成功后 `dbSave`。

`status=found` 仅代表搜索找到路径；不等于最终已写入版图，也不等于实际自动孔已通过。

提交保留原实现的自动保存行为：`dbSave` 会保存当前 cellview 的其他未保存编辑。回滚只处理本次新增对象，不是整个 cellview 的通用 undo。

## 5. 本地目录与启动方式

### 工作目录规则

入口 `autoroute.il` 可以放在任意路径，但程序文件、配置与中间结果按 **`arBaseDir`** 找到。当前代码加载时把 `arBaseDir` 初始化为 `/home/meow`，不会自动取入口所在目录。

最简单的部署是把六个运行文件放在同一个可写目录：`autoroute.il`、`build_config.py`、`config_validation.py`、`route_engine.py`、`route_config.json`、`route_config.il`。目录要能保存日志和中间文件。

在 CIW 中使用实际绝对路径，例如：

```lisp
load("/absolute/path/layout_xl_autoroute/autoroute.il")
arSetDir("/absolute/path/layout_xl_autoroute")
arStart()
```

也可按 F8 启动。每次重新 `load` 入口后，再调用 `arSetDir`；活动预览期间先选择 `Discard preview`，再切换目录/重启。不要让多个 Virtuoso 会话共用同一个输出目录并发运行。

`arRunPython` 当前调用 `python3 -u`，通过 `/bin/sh -c` 执行，并合并记录 stdout/stderr。因此应核对 **启动 Virtuoso 的环境**能找到哪个 Python；仅在另一个终端能运行 Python，并不能证明 Virtuoso 的 PATH 相同。

运行代码使用 Python 标准库。基线未正式声明/验证全部 Python 3 小版本兼容性，接手时记录本地 `python3 --version` 并执行回归。

### 初次接手建议

在新目录解压代码，不要直接覆盖用户现有运行目录。先读取用户已修改的配置和代码差异，再决定合并哪些文件。可以建立本地 Git 基线，后续提交应包含修复、相关测试和说明；不要把工艺配置替换成测试配置。

## 6. tech.tf 和配置的语义

### 生成、复核与编译

如用户已有可运行配置，应首先使用它复现问题。若要重新提取工艺，先用新的输出文件名保存草稿：

```bash
python3 build_config.py --techfile /absolute/path/tech.tf --config route_config.draft.json --draft
```

`--draft` 用于保留可审查草稿。缺失参数可能返回退出码 2，但草稿已经写出。没有缺项也不要把“已写 JSON”误认为工艺条件全部得到支持。

生成器会保留 `ignored_rules`、`skipped_vias`、`unresolved` 和层叠诊断。核对真实规则并将确认后的配置作为运行目录的 `route_config.json` 后执行：

```bash
python3 build_config.py --compile --config route_config.json
```

`--force` 会覆盖指定的已有 JSON，不能在用户手改文件上无意使用。`--compile` 不改 JSON；失败不覆盖旧 IL，但正常 F8 会重新校验 JSON，不应依赖旧 IL 绕过错误。

金属来自 `layerRules/functions` 的 `metal` 类型，孔关系来自标准/自定义 via 定义。不能硬编码只有 METALn 或 Mn。`M5` 和 `METAL5` 也不是自动别名。

层叠按真实 via 连接图推导；名字不明确、图有分支/环/不连通时需人工复核。`--stack` 可以显式指定真实层名及顺序；逐层 H/V 最终以 JSON 为准。可用 `--pattern odd-h-even-v`、`even-h-odd-v`、`tech`。

当前解析器不执行 SKILL 表达式，也不自动加载 PDK 引用库。仅含引用/增量定义的 tech.tf 可能不足，应由 Virtuoso 导出完整技术数据。不能编造缺失 minWidth/minSpacing。受支持的 width/length spacing table 会保守取其间距值最大值，不支持的条件规则保留诊断。

### 关键字段

| 字段 | 约束或行为 |
| --- | --- |
| `grid` | 制造网格，必须来自实际工艺并与原生环境一致 |
| `layers[].name` | 真实金属层名；不是数字顺序的替代品 |
| `layers[].direction` | `H` 或 `V` |
| `layers[].width` | 普通路线宽度；目前要求为 `2*grid` 的整数倍，保证居中两边在网格上 |
| `layers[].space` | 与其他同层导体的目标边到边间距，必须有限且正数 |
| `extra_clearance` | 在 space 上增加的几何保守余量，允许 0；0 不会取消 space |
| `pitch` | 搜索常规采样距离，区别于 grid；部分阶段还加入障碍边缘坐标 |
| `margin` | 两端包围区域外扩的搜索范围 |
| `max_distance` | 两点直线距离上限，生成器默认 300 个技术用户单位 |
| `max_nodes` | 分阶段累计搜索状态预算，包括待扩展状态；生成器默认 600000 |
| `max_array` | 规划 via 行列数上限 |
| `route_bounds` | `null` 或数值数组 `[xmin,ymin,xmax,ymax]`，约束完整新金属/pad 占地；不是仅限制中心线 |
| `obstacle_purposes` | 默认 `["*"]`；所有真实导体 purpose 应参与避障 |
| `vias[]` | 名称、lower/upper、cut_layer、cut、cut_space、enc_lower/enc_upper；同一层对可以有多个不同名候选 |
| `via_mode` | `auto_preferred`、`auto_required`、`standard` |
| `via_constraint_group` | 默认 `CURRENT` |
| `stack_reviewed` | 对歧义层叠的人工确认；不要未经复核直接设 true 消除错误 |

JSON 必须使用标准 JSON：不用注释、智能引号、尾逗号或字符串形式的数值。无硬边界时是 `"route_bounds": null`，不是空字符串，也不是字符串 `"null"`。

技术尺寸是 technology user units，使用前确认 `maskLayout` 的单位为 micron。历史用户日志曾显示 DBU/UU=2000、制造网格=0.0005；这是该次日志的事实，不能直接成为其他工艺的默认值。

历史用户曾把 `extra_clearance` 改为 0 进行测试；实际接手仍应读取当前 JSON。原生成器/示例默认 0.05，不能误以为用户当前也使用这个值。

## 7. 几何和结果协议

`route_geometry.txt` 是空白分隔的文本，坐标已变换到当前编辑 cellview 的坐标系。

| 记录 | 含义 |
| --- | --- |
| `E layerA xA yA layerB xB yB` | 点击端点 |
| `AR/BR layer xmin ymin xmax ymax` | 所选真实矩形端点 |
| `AP/BP layer N x1 y1 ...` | 所选端点的真实 polygon 轮廓 |
| `AT/BT layer width N x1 y1 ...` | 所选 path/pathSeg 的宽度与中心线点 |
| `O layer xmin ymin xmax ymax` | 同层矩形或保守外框障碍；path/pathSeg 常以外框导出 |
| `P layer N x1 y1 ...` | 同层 polygon，按实际轮廓碰撞检查 |
| `VO layer xmin ymin xmax ymax` | 已有 via 在指定实际金属层上的保守外框；同一孔可有多条 VO |
| `X xmin ymin xmax ymax` | 未知层/旧式全层障碍，作用于所有路线层 |

旧 `A/B` 只有 bbox，无法证明所选 path 的真实局部宽度，默认拒绝用于端点拟合。应重新用新版入口导出，不要手改 tag 伪装成 AR/BR。E-only 输入主要用于显式合成测试，没有真实端点方向例外。

`Geometry` 保存原始行号和 tag；过滤或索引调整后仍应准确对应障碍记录。内部 `__ar_endpoint_A/B` 等 profile 用于保存两端实际宽度/方向及接入角色，不是真实 PDK 金属层。输出映射回物理层，并在 JSON 中保留验证所需的 profile 元数据；名字不是稳定用户接口，不要硬编码某一日志拼写。

`route_result.json` 的条目为 `segment` 或 `via`；SKILL 对应 `S`、`V` 记录。via 条目含所选名称、位置、行列数及上下层 pad。路径验证必须保留这些信息，不能只输出折线中心点。

新建实际孔导出到 `route_actual_vias.txt`：

```text
AV 计划条目序号 实际孔序号 孔名 下层 上层 行数 列数 xmin ymin xmax ymax
AO 实际孔序号 层名 xmin ymin xmax ymax
AO 实际孔序号 层名 xmin ymin xmax ymax
```

两端导体都必须有 AO，额外已配置层也参与检查。同层可有多个图形框。旧 union 记录仍保守检查，并明确标记 fallback，不从一个总框猜各层形状。

## 8. 寻路与几何判断的实现约束

### 端点接入

`endpoint_section` 识别真实局部直段；`prepare_route` 为两端建立独立宽度/方向状态。普通 M6=V 且原金属也为 V 时，其接入段只能竖走。原金属为 H 时，仅沿原中心线的源/目标接入延长可为 H，不能中途横向绕障。

中心线或半线宽不在 grid 上时停止，不靠静默移位/改宽解决。不同端点宽度通过其他层衔接，不在接入位置直接拼出宽度台阶。via 的必要包围 pad 可以宽于线宽，这与错误接入宽度是两回事。

完全被所选真实直段覆盖的同层障碍外框可从内部索引排除；仅部分重叠、靠近、断开的图形不排除。polygon/path 使用局部直段，不用整体 bbox 扩大豁免；path 排除区域还避开端帽/弯角。VO 逐层判断，不能连带忽略另一层。X 不适用此豁免。

原始 geometry 文件和指纹保留这些记录；过滤不能导致版图变化后旧预览继续提交。

### 搜索与性能

当前是基于 Manhattan 坐标图的 A*，状态包含位置和路由层/profile。总代价包含线长和换层成本；当前换层成本为 5，启发式使用线长加 via 图距离。目标是较快找到通过现有几何检查的可行路径，没有承诺全局最短或连续平面上的完备性。

| 阶段 | 坐标策略 |
| --- | --- |
| `coarse` | 常规 pitch 及端点坐标；仍检查所有障碍 |
| `layered` | 增加各层自己的障碍边缘坐标；跨层进入后保留精确坐标 |
| `detailed` | 公共 X/Y 坐标图回退 |

坐标笛卡尔积不整体分配。`implicit_grid_nodes` 只是理论组合数；不能再次用它代替实际状态数而提前判失败。坐标轴另有上限 `max(4096,min(200000,max_nodes))`。

各阶段共用累计状态预算和静态每层 BVH。`max_nodes=600000` 时 coarse 最多 50000，layered 最多 150000，其余留给 detailed；阶段未用完的预算保留。阶段间重复访问会再次计数。预算小于 128 时直接采用 detailed。

已有 via 的 VO 进入各自物理层索引；X 使用共享全层索引。每个路线边仍检查完整线宽和 spacing，via 检查两侧 pad。

同一层对的全部 via 定义均保留。按 pad 总面积/名称排序尝试，首个合法候选代表同成本、同目标状态的边；前驱记录具体孔名，回溯不能重新随意选择候选。未来若加入不同孔的不同代价或额外历史状态，需重新审查这一假设。

## 9. 层级、LPP 与实际自动孔

用户不希望仅因顶层与 stdcell 的 technology 对象不同就停止。当前不再要求 technology DB ID 相同，而检查脚本查询实际依赖的映射与坐标单位。

新几何按 layer name / `drawing` 创建；OA layer number 用于跨库查询兼容性校验，不是 GDS layer number，也不决定层叠顺序。当前要求被配置金属的同名 OA 层号一致、user units 与 DBU/UU 一致；明确指定 purpose 名单时也核对其编号。默认所有 purpose 时不比较 purpose 号。未实现任意不同 OA 编号的通用显式映射。

`AR_TECH_ACCEPT` 只说明当前查询映射/坐标解释兼容，不说明两份工艺规则完全相同。无法解析的 hierarchy、black box 或明显不适合的视图不能当作空白版图。

已有 via 和新建实际 via 的模型不同：

- **已有 via：**识别实际连接层，导出每相关层 VO；当前仍可能使用该实例的整个 bbox，因此有保守性。未知层归属保留 X。
- **新建实际 via：**读取 generated master 的金属图形，按实例 origin/orient 变换后逐层导出 AO。提取失败时保留总框检查并输出 `AR_ACTUAL_VIA_FALLBACK`。

`auto_preferred` 在 API/约束组选项可用时调用 `viaGenerateViasAtPoint`；不可用时用标准定义。`auto_required` 取得不到选项则停止。`standard` 使用 `dbCreateVia`。GUI 快捷键 `o` 可用不等于自动孔 SKILL API/许可必然可用。

规划 seed 与 Cadence 最后选中的孔可能不同。实际创建后继续检查已知 via 定义、层对、覆盖计划换层点、各层占地、边界和导出窗口，并跟踪 API 的新增对象。错误处理、实际孔验证和失败回滚必须保留。

当前几何检查不包含完整 PDK DRC/LVS：条件 spacing、线端、最小面积、复杂 cut 规则等仍有边界。无 net 模型也不能验证最终电路语义上的网络是否连接正确。

## 10. 已处理的问题及其状态

| 问题 | 已实施处理 | 状态边界 |
| --- | --- | --- |
| M5 等 width/space 提取失败、层名不一定 METALn | 解析真实 metal/via 定义、支持有限参数/表格、保留缺项草稿和诊断 | 未提供实际完整 tech.tf，不能补造缺失规则 |
| 任意入口路径找不到配套文件 | 统一使用 `arBaseDir` / `arSetDir` | load 后需重新设置实际目录 |
| `route_bounds` 格式错误 | 统一接受数值四元组或 null | 真实硬边界不能为寻路成功而擅自放宽 |
| 不同 technology 对象阻断层级导出 | 检查单位和 LPP 查询映射 | 用户日志已有 AR_TECH_ACCEPT |
| 隐式网格很大就被提前拒绝 | 分离坐标轴上限和真实搜索状态预算 | 仍可能达到实际 max_nodes |
| 搜索过慢、跨层坐标过度细分 | 分阶段搜索、每层 BVH、状态/堆优化与进度 | 合成性能案例通过，不代表所有大项目都快速 |
| M6=V 却出现横向绕障 | 严格方向，例外仅限原金属同宽同中心线接入延长 | 必须继续保留回归 |
| 端点接入错位/宽度台阶 | 真实局部几何拟合，独立源/目标 profile | via 必要 pad 仍可能更宽 |
| 低层 cell/via 挡住 M6/M7 | 已有孔按实际层导出 VO | 用户后来反馈 M7 拉通可实现 |
| extra_clearance 导致窄间隙端点失败 | 显示 space、extra 和具体 blocker | 用户曾设 extra=0；不是取消工艺间距 |
| 预览可行、提交时实际孔总框误判 | 新建 via 按层 AO 复核、失败详细报告 | 用户之后明确表示上一问题已解决 |
| 目标导体内部另一图形自阻挡 | 仅完全被真实直段覆盖的同层 bbox 豁免 | 合成复现通过，未收到该次完整实际数据 |
| 同层对只留最后一种 via | 保留全部候选并保存实际所选边 | 合成复现通过；最新 M2→M3 实际 case 待确认 |

## 11. 接下来优先处理的实际问题

### 最后一次用户案例

| 项目 | 用户日志内容 |
| --- | --- |
| 源层 / 方向 / 宽度 | M2 / V / 0.019 |
| 源点击 / 拟合中心 | `[0.022,4.926]` / `[0.023,4.926]` |
| 源 section（首次输出） | `[0.0135,3.6995,0.0325,4.966]` |
| 目标层 / 方向 / 宽度 | M3 / H / 0.020 |
| 目标点击 / 拟合中心 | `[16.623,4.318]` / `[16.623,4.316]` |
| 目标 section | `[16.577,4.306,18.5685,4.326]` |
| 导出规模 | 10659 metal、702 via；搜索图中可用 17 个物理层、19 个 routing profile，不表示已经到达这些层 |
| coarse / layered / detailed 状态 | 51 / 320 / 1888，累计 2259 |
| 耗时及堆峰值 | 约 0.26 s；peak_heap_entries=2 |
| 碰撞统计 | collision_queries=13548，collision_candidates=0 |
| 最终错误 | `No clear route found on detailed search graph` |

该次没有耗尽 600000 状态预算。模式与“源端一直沿 M2 竖线搜索，首个换层在碰撞检查前就因边界失败”吻合，但当时缺少实际 JSON/geometry，尚未证明这是唯一原因。

**需要核查的条件推论：**若左硬边界仍为 x=0，在源中心线 x=0.023 居中放孔时，每侧 pad 的 X 向宽度都需满足 `pad_width <= 2*(0.023-0)=0.046`。任一侧更宽就越界，沿 V 接入段改变 Y 无法解决。该值不是新工艺规则，不能用来擅自缩小 via/enclosure；也不能据此断言当前配置的边界一定为 0。

这次日志转贴中存在 `global=1` 与 Python `global_boxes=0`、X 坐标数量、源 section 和 profile 拼写等不一致。继续定位应读取原始文件，不按转贴文本改源代码或推断具体孔尺寸。

上次已交付新的 `via_candidates_fix` 包；用户尚未反馈升级后的结果。首要任务是读取升级后的实际配置、几何与报告，确认是候选覆盖已解决，还是所有真实候选确实越界/被挡。

### 优先收集的最小材料

1. 当前实际 `route_config.json`。
2. 同一次运行的 `route_geometry.txt`。
3. `route_result.search_report.json` 或 `route_debug.search_report.json`。
4. 原始 `route_engine.log`，以及必要的 `build_config.log`。
5. 若是预览确认后失败：再加 `route_actual_vias.txt`、`route_actual_vias.report.json`、`route_result.json`、`route_preview.json` 和相关 CIW 行。
6. 当前实际源码版本、Virtuoso 版本、Python 版本、运行目录与是否已有本地修改。

日志会被后续命令覆盖；复现前将同一次失败的材料一起复制到独立 case 目录。不要混用不同选点或不同配置生成的文件。

## 12. 本地复现和诊断命令

以下命令在解压项目目录中运行。命令中的几何和配置应来自实际同一案例，输出使用独立 debug 名称。

```bash
python3 --version
python3 -m unittest discover -s tests -v

python3 route_engine.py --config route_config.json --geometry route_geometry.txt --output route_debug.il

python3 route_engine.py --config route_config.json --geometry route_geometry.txt --diagnose-endpoints --diagnostics-json endpoint_report.json

python3 route_engine.py --config route_config.json --geometry route_geometry.txt --output route_detailed.il --search-mode detailed
```

若使用独立 case 目录，可以保持源码目录不变：

```bash
python3 route_engine.py --config /absolute/path/case/route_config.json --geometry /absolute/path/case/route_geometry.txt --output /absolute/path/case/route_debug.il
```

仅验证已有 Python 路径：

```bash
python3 route_engine.py --config route_config.json --geometry route_geometry.txt --validate route_debug.json
```

检查已经导出的实际孔时，`--output` 的同名 JSON 必须就是该次原生提交的计划，不能混用另一次 debug 路线：

```bash
python3 route_engine.py --config route_config.json --geometry route_geometry.txt --output route_result.il --check-vias route_actual_vias.txt
```

这些 Python 命令本身不写 Virtuoso 数据库。debug 路径供排查，不应跳过正常预览/快照检查而手动提交。

`--diagnose-endpoints` 只检查端点；不能证明整条路线可行。没有独立的 `--diagnose-vias` CLI 开关；普通寻路最终 no_path 时会自动附加 `endpoint_via_access` 到搜索报告。

### 新版搜索报告怎么读

报告外层包含 `status`、`error`、`config`、`geometry`、`stats`。在 `stats` 中重点看：

| 字段 | 解释 |
| --- | --- |
| `attempts` | 各阶段独立统计和失败原因 |
| `total_stored_states` | 跨阶段累计状态；与 max_nodes 比较 |
| `reached_layers` | 最后阶段真正到达的物理层；区别于配置可达的 active_layers |
| `source_escape_attempts` / `source_escape_accepted` | 最后阶段源接入状态的换层尝试/成功数量 |
| `via_rejections` | route_bounds、same_layer_obstacle、global_obstacle；每次尝试只计最先失败项 |
| `via_rejection_examples` | 最多 8 个失败例子，包含孔、位置、检查层、pad、外框和具体越界边 |
| `endpoint_via_access` | 最终 no_path 时的完整两端 anchor 候选诊断；CIW 不展开全部内容 |
| `endpoint_covered_count/examples` | 端点内部完全覆盖障碍的排除证据 |

`all_candidates_fixed_axis_bounds_blocked=true` 表示在当前固定中心线上，所有已配置候选都因固定坐标方向的硬边界无法放下。单纯 `clear_at_anchor_count=0` 不能说明无路：可能沿原线延长后另找位置打孔。

`collision_candidates=0` 仅描述此次搜索索引实际检查到的候选数量，不能推出整个版图没有障碍，也不能推出其他层没有冲突。

## 13. 回归资料与验收范围

| 测试文件 | 重点 |
| --- | --- |
| `tests/test_config.py` | tech.tf、缺项、覆盖、层叠和配置校验 |
| `tests/test_engine.py` | 基本寻路和输出 |
| `tests/test_safety.py` | 方向、宽度、连接、边界、快照、资源限制等 |
| `tests/test_search_diagnostics.py` | 理论网格与实际状态、端点诊断和坐标预算 |
| `tests/test_performance_search.py` | BVH、分阶段搜索、预算和回退 |
| `tests/test_endpoint_fit.py` | 原中心线/宽度、不同端点宽度、严格接入例外、path/polygon |
| `tests/test_via_layers.py` | 低层 cell/via 不影响无关高层，真实同层 via 仍受检查 |
| `tests/test_actual_via_layers.py` | 实际孔分层 footprint、总框误判、真实冲突和报告 |
| `tests/test_endpoint_overlap.py` | 完全覆盖豁免与独立邻线、部分重叠、X 等反例 |
| `tests/test_via_candidates.py` | 多孔候选、顺序、反向连接、固定轴边界、拒绝原因和报告 |

合成证据文件：`SEARCH_REPRO.txt`、`PERFORMANCE_REPRO.json`、`VIA_LAYER_REPRO.json`、`ACTUAL_VIA_REPRO.json`、`ENDPOINT_OVERLAP_REPRO.json`、`VIA_CANDIDATES_REPRO.json`。数字与孔尺寸都需结合文件中的 synthetic/real_pdk/scope 描述使用。

可运行独立合成性能案例：

```bash
python3 tests/benchmark_search.py --output benchmark.json
```

最近对照中，3519 障碍/17 层的特定合成场景仍保存 567 状态并通过验证。不要把这个状态数/耗时当作用户所有复杂场景的性能目标或保证。

原生测试 `tests/test_hierarchy_compat.il` 和 `tests/fresh_integration.il` 尚未在开发环境运行。前者检查兼容性比较函数；后者会创建、保存新测试 cell，包含特定库名 `test`、层名 METAL1/2/3 和目录约定，需按本地 PDK 审查并使用唯一 `AR_TEST_TOKEN`，不能拿它直接覆盖用户设计。

修改后的最小验收应围绕实际缺陷建立失败前/修复后对照，同时保留相关“必须拒绝”的反例。涉及几何/搜索/协议的改动应运行现有 Python 回归；涉及原生接口还需明确记录 Layout XL 实际执行结果。不要仅凭括号平衡、Python PASS 或预览显示，声称原生接口/最终版图已验证。

## 14. 后续开发顺序与工作规则

### 优先级

1. **闭环最后的 M2→M3 案例。**先确认当前代码/配置/报告，再判断候选覆盖、真实硬边界、via pad 尺寸、障碍或其他代码问题。
2. **在用户原生环境完成最小集成验证。**验证两点选择、层级导出、预览、实际孔、失败回滚、成功保存；保留工具版本和结果。
3. **根据真实诊断改进保守模型。**例如已有 via 总框、path 总框、部分重叠导体可能导致误阻挡；改进应导出更准确几何或增加可证明的条件，不是按距离删除障碍。
4. **根据真实 profiling 继续性能优化。**先分清导出、索引构造、搜索与实际孔检查耗时，保留所有物理检查。
5. **后续独立规划带 net 版本。**用户已提出未来需求，但当前任务不依赖它；不能在无 net 版本中偷偷按猜测合并网络。

### 给继续开发的 Codex

- 先读代码和同一案例数据，再修改；缺少实际数据时，可以完善诊断和合成复现，但要标明推论与验证边界。
- 保留用户的本地配置与已改源码；在明确的开发副本中修改，输出可审查差异。
- 不硬编码 M1/M2 等名字，不把层号、名字数字后缀与真实工艺层叠混为一谈。
- 保留严格 H/V、同中心线同宽接入、真实 via 图、制造网格、spacing、硬边界及快照检查。
- 不通过删除 X、降低工艺 space/enclosure、放宽反方向或增大 bounds 来掩盖未知根因。
- 预览、路径验证、实际 via 验证要使用一致的障碍语义；更新一种模型时检查另外两处。
- 调整过滤、索引和 profile 时，保留原始物理层、行号、tag 以及原 geometry 指纹。
- 修改协议时同步 SKILL 和 Python，并明确旧格式如何处理；不要让旧几何被当成新格式。
- 继续以 Python 标准库为优先，新增依赖需考虑用户离线部署。
- 修复后记录：问题证据、根因、修改文件、测试、原生验证状态和剩余限制，并更新本文件的接手状态。
- 完成常规代码检查、可逆修复和验证时可直接推进；实际数据库写入仍遵循项目既有“预览→用户确认→提交”流程。

## 15. 可直接发给本地 Codex 的接手提示词

```text
请接手这个 Virtuoso Layout XL 两点自动连线项目。

先完整阅读 LAYOUT_XL_AUTOROUTE_CODEX_HANDOFF.md，再解压并阅读配套
layout_xl_autoroute_20260930_via_candidates_fix.zip 中的 README.md、
REVIEW_CN.md、VALIDATION.txt 和核心代码。

保留我本地实际的 route_config.json 和现有源码改动，不要拿包内旧的
METAL1–METAL6 配置覆盖它们。请先比较我的运行版本与交付基线。

当前是无 net 的几何避障版本。严格执行配置的 H/V；反方向只允许沿
被点金属的同宽、同中心线直线延长，且限定在第一颗 via 前/最后一颗
via 后。保留障碍、间距、边界、快照、实际 via 复核和失败回滚。

上次修复了同一层对 via 候选被最后一种覆盖的问题，但我最后一次
M2→M3 的实际案例尚未闭环。请优先读取我提供的实际 config、geometry、
search_report 和原始日志，复现并定位根因，再做最小修复与相关回归。
如果本地还没有这些实际数据，请指出缺少的具体文件；不要把合成
测试通过当成我的实际案例已经解决，也不要猜测 PDK 尺寸。

先完成代码审查、诊断和可以执行的测试，再给出结论。最终说明根因、
修改内容、测试结果、是否实际运行 Virtuoso，以及我需要在本地执行的步骤。
```

## 16. 下一次接手时填写的状态记录

| 项目 | 当前记录 |
| --- | --- |
| 用户实际工作目录 | 本机发现 `/home/meow/` 与 `/home/meow/auto_con/autoroute/` 两份旧运行文件；当前 CIW 的 `arBaseDir` 待用户确认。Virtuoso 从 `/home/meow/` 启动 |
| 实际 Python / Virtuoso 版本 | 本次记录：Python 3.7.0；Virtuoso IC6.1.7-64b.500.2 |
| 与基线的源码差异 | 两处本地源码相同，且与本地 20260929 原包相同；仍有最后一种 via 覆盖和端点 2.5 区域反向豁免。差异与原始副本已保存到 `audit/`，原运行文件未覆盖 |
| 实际 config/geometry/报告 | 用户确认历史 M2→M3 材料不在本机，授权按 `/home/meow/tsmc18/tech.tf` 重建；真实 TSMC 规则及 6 份原生 geometry/报告保存在 `cases/tsmc18_rebuilt/` |
| 最后 M2→M3 实际案例 | 历史案例仍未复现；本地重建 METAL2→METAL3 已通过原生提交。所提供工艺为 grid=0.005、6 层 METAL 配置，与历史 17 层/grid=0.0005 不同，不宣称历史根因闭环 |
| 最近 Python 测试 | 基线 127 项通过；真实 tech 的包装 spacing table 表头解析修复后，新增 3 项回归，总计 130 项全部通过，见 `audit/fixed_python_tests.log` |
| 原生 SKILL / Layout XL 集成测试 | 从 ~/ 实际执行加载、10 项只读测试及 6 项重建原生集成测试；提交保存、AV/AO 分层复核、硬边界拒绝、实际孔冲突回滚及快照变化拒绝通过。自动孔 API 在本机不可用，auto_preferred 验证的是标准回退；GUI 点击/高亮及 DRC/LVS 未验证。PDK 初始化有已有 HSPICE 错误，测试完成后 TERM 超时仍驻留，仅本次测试 PID 用 KILL 清理；原 GUI 保留 |
| 修改与下一步 | `work/` 中只新增修改 `build_config.py` 的包装表头解析及配置回归；引擎/SKILL 沿用基线，本地 JSON 原样保留，原运行目录未覆盖。最新根因、证据和 CIW 步骤见 `cases/tsmc18_rebuilt/REBUILT_REVIEW_CN.txt`，补丁见 `audit/spacing_table_fix.patch` |

## 17. 2026-10-11 多 net 整体规划独立版本

用户确认源图无 net 关联，改用显式 net—端点清单；测试 case 由本次重建。
新版本 multinet/ 使用整棵 net 连接树、候选冲突图、适应占用的重新规划和全局回退，
统一复核所有 net 后用 SKILL 创建独立 overlay，用户按 0:0/R0/1 手动放置。
旧两点源码、实际配置与 F8 保留。新增 11 项 Python 测试、原 130 项回归、
5 项原生集成检查通过；复杂 case 为 6 net / 20 端点，生成 23 path + 19 via，
源图不变，实际孔复核、快照拒绝、整份输出回滚及原点叠加均有原生证据。
有限候选与预算未证明全局最优；原始用户 net 清单及 DRC/LVS 未验证。
入口：multinet/README_CN.md；证据：multinet/cases/tsmc18_complex/TEST_RESULTS.json。


## 18. 2026-10-11 层次电路绑定自动提取与 terminal 流程

后续用户要求由新建层次 schematic 的真实连接关系自动提取 net，包含顶层对外 pin。
multinet/hierarchy/auto_export.il 增加先障碍、后连接的只读导出；hierarchy_io.py
自动组装 nets.json、几何及 binding report。run_offline.py 在 terminal 进行全体
net 联合规划，再实际调用 Virtuoso/SKILL 创建独立连线 layout，最后由用户调入。
IC6.1.7 的 bndGetBoundObjects/lxGetLXInfo 需要真正 XL 编辑器上下文；-nograph 不够。
正确入口为 deOpen(fileSpec nil mode "Virtuoso XL")，不是将 maskLayoutXL 当数据库
viewType。通过独立 Xvfb 保留 XL 上下文，源只读，不碰用户已有 GUI。

新增 pin-only 的 4 种下层 schematic/symbol/layout，真实 lxSetConnRef/bnd binding；
顶层逻辑／物理实例异名，含 R0/MY/R90/MX、底层与顶层障碍、4 个对外 pin。
自动得到 5 net / 20 endpoint / 36 obstacle record；本机生成 33 颗标准 via，
全体连接及 AV/AO 复核通过。源 OA／reference 文件哈希不变，home/auto_con 原文件
仍与 audit/version_comparison.json 一致。11 项新 IO Python + 11 项旧 multinet +
130 项原回归通过，新增 8 项 native assertion 与原 5 项 native regression 通过。
还有同 job 重跑旧日志误读防护及并发互斥检查，证据统一记入 TEST_RESULTS.json。

可打开 AR_AUDIT_20261010：hier_top_xl20261011b 的 schematic/layout，
hier_routes_xl20261011b/layout，hier_assembly_xl20261011b/layout。
人工命令和支持范围：multinet/HIERARCHY_CN.md。证据：cases/hierarchy_xl/release/。
新增 audit/batch_cds.lib 避免 home 已被用户设置 include audit/native_cds.lib 后的
递归 INCLUDE；未更改 home cds.lib。Xvfb 仅 apt download 后解包到 audit/xvfb_root，
未修改系统安装。原始用户历史 M2→M3 失败数据仍缺失，此处均为授权新建案例。
当前矩形 pin、一对一本级 binding；复杂 binding、pin permutation、mosaic 和 bus
表达式明确拒绝。有限预算无全局最优证明，未进行 foundry 完整 DRC/LVS 签核。

## 19. 2026-10-11 分开 terminal 求解和现有 CIW 创建

用户明确要求 Python 只计算，回到现有 CIW 读取方案创建独立连线版图。
新增 multinet/run_plan.py：只读取两阶段导出、联合求解并生成 batch_plan.json/il，
写入 plan_result.json(status=planned, native_created=false)，不调用 Virtuoso/Xvfb。
auto_export.il 新增 mnBuildFromPlan(job lib NEWcell [view] [cv])，从当前 XL 源图
核对采集哈希、源身份、几何／逻辑／binding 快照及完整方案，创建并复核实际 via，
成功写 ciw_build_result.json。保留原 mnBuild 的整份新 view 失败回滚；不关闭源窗口。
job_state.py 与 hierarchy_io.py 的任务租约防止 CIW 创建期间重新求解或并发创建。
原 run_offline.py 继续保留，复用相同规划函数；完整原生兼容性运行已通过。

新建 source hier_top_splitxl20261011a，4 个底层、5 net、20 端点，33 标准 via。
可打开 AR_AUDIT_20261010/hier_routes_splitxl20261011a/layout 和其 _recovered 版。
29 项 Python 测试通过（7 项新的分开流程测试），9 项真实 XL 断言通过，包含错误
源图、已有输出、几何／逻辑变化、不完整／篡改方案、实际 via 不符的整份回滚和恢复。
纯求解在无 DISPLAY 且 Cadence 命令替换为调用探针的环境中成功，未调用 Cadence。
既有设计及新 source 数据库哈希不变，home/auto_con 源码和实际配置仍保持接手值。
用户 GUI PID1379116 未停止；验证使用独立受控会话运行同一个 CIW 创建入口。

使用及 via 复核解释：multinet/SPLIT_FLOW_CN.md。
证据：multinet/cases/hierarchy_xl/SPLIT_TEST_RESULTS.json 与 split_release/ 原始日志。
原始历史 M2→M3 数据仍缺失，有限预算和完整 DRC/LVS 的限制延续。
