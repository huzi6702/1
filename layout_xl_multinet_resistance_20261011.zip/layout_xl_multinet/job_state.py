"""Coordinate terminal planning and a build in an existing CIW session."""
from contextlib import contextmanager
import fcntl
from pathlib import Path


@contextmanager
def locked_job(job, allow_build=False):
    job = Path(job)
    if not job.is_dir():
        raise ValueError('Job directory does not exist')
    with (job/'.offline.lock').open('a') as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError('Another terminal run is using this job directory')
        if not allow_build and (job/'.ciw_build.lock').exists():
            raise ValueError('A CIW build is using this job directory')
        yield job


def require_no_ciw_build(job):
    if (Path(job)/'.ciw_build.lock').exists():
        raise ValueError('A CIW build is using this job directory')
