#!/usr/bin/env python3
"""Joint, bounded multi-net tree routing; never modifies the source layout."""
from __future__ import annotations

import argparse
import copy
import hashlib
import heapq
import json
import math
import re
import sys
import time
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / 'kernel'))
import route_engine as k
from build_config import atomic_text, compile_skill, obstacle_query_halo, parse
from config_validation import validate_config
from routing_cost import RoutingCost

DEFAULTS = dict(max_seconds=60, max_states=256, max_route_calls=600,
                candidates_per_net=3, max_access_points=6)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_manifest(path, cfg):
    data = json.loads(Path(path).read_text())
    if data.get('schema') != 'virtuoso-multinet-1':
        raise ValueError('Expected schema virtuoso-multinet-1')
    if not isinstance(data.get('nets'), list) or not data['nets']:
        raise ValueError('nets must be a nonempty list')
    names, ids = set(), set()
    layers = {x['name'] for x in cfg['layers']}
    for net in data['nets']:
        name = net.get('name')
        if not isinstance(name, str) or not name or name in names:
            raise ValueError('Net names must be nonempty and unique')
        names.add(name)
        if not isinstance(net.get('terminals'), list) or len(net['terminals']) < 2:
            raise ValueError('Each net requires at least two terminals: ' + name)
        for terminal in net['terminals']:
            tid = terminal.get('id')
            if not isinstance(tid, str) or not tid or tid in ids:
                raise ValueError('Terminal IDs must be globally unique')
            ids.add(tid)
            p = terminal.get('point')
            if terminal.get('layer') not in layers or not isinstance(p, list) or len(p) != 2:
                raise ValueError('Invalid layer/point: ' + tid)
            if any(not k.finite_number(x) or not k.on_grid(x, cfg['grid']) for x in p):
                raise ValueError('Terminal coordinates must be finite and on grid: ' + tid)
            hierarchy = terminal.get('instance_path', [])
            if not isinstance(hierarchy, list) or any(not isinstance(x, str) for x in hierarchy):
                raise ValueError('instance_path must be a list of instance names')
    options = dict(DEFAULTS, **data.get('options', {}))
    if set(options) != set(DEFAULTS):
        raise ValueError('Unknown planner option')
    for key, value in options.items():
        if not k.finite_number(value) or value <= 0:
            raise ValueError('Positive planner option required: ' + key)
        if key != 'max_seconds' and (isinstance(value, bool) or int(value) != value):
            raise ValueError('Integer planner option required: ' + key)
    if options['candidates_per_net'] > 8 or options['max_access_points'] > 32:
        raise ValueError('Candidate/access limits are 8/32')
    data['options'] = options
    return data


def shape_from_record(record):
    if record[0] == 'rect':
        return k._box(record[1:])
    if record[0] == 'polygon':
        return k.Polygon([tuple(map(float, p)) for p in record[1]])
    if record[0] == 'path':
        return k.EndpointPath([tuple(map(float, p)) for p in record[2]], float(record[1]))
    raise ValueError('Unknown exported shape')


def read_export(path, manifest, cfg):
    tree = parse(Path(path).read_text())
    if len(tree) != 1 or tree[0][0] != 'MNET1':
        raise ValueError('Invalid native geometry export')
    sections = {x[0]: x[1:] for x in tree[0][1:]}
    source = sections['source']
    for key, index in [('lib', 0), ('cell', 1), ('view', 2)]:
        if manifest.get('source', {}).get(key, source[index]) != source[index]:
            raise ValueError('Manifest source identity differs from the open layout')
    if not math.isclose(float(source[5]), cfg['grid'], rel_tol=0, abs_tol=cfg['grid']*1e-6):
        raise ValueError('Native technology manufacturing grid differs from config')
    terminals = {}
    for name, tid, layer, x, y, shape in sections['terminals']:
        if tid in terminals:
            raise ValueError('Duplicate native terminal export')
        terminals[tid] = dict(id=tid, net=name, layer=layer,
                             point=[float(x), float(y)], shape=shape_from_record(shape), record=shape)
    expected = {t['id']: (n['name'], t) for n in manifest['nets'] for t in n['terminals']}
    if set(expected) != set(terminals):
        raise ValueError('Native export did not resolve every manifest terminal')
    for tid, (name, terminal) in expected.items():
        actual = terminals[tid]
        if actual['net'] != name or actual['layer'] != terminal['layer'] or actual['point'] != terminal['point']:
            raise ValueError('Native terminal does not match manifest: ' + tid)
        if not k.point_in_shape(actual['point'], actual['shape']):
            raise ValueError('Terminal is outside its actual native metal: ' + tid)
        # Reject off-grid centerlines/widths immediately, before global search.
        g = k.Geometry((actual['layer'], *actual['point']), (actual['layer'], *actual['point']),
                       {}, [], {'A': (actual['layer'], actual['shape'])})
        g.endpoint_kinds = {'A': actual['record'][0]}
        k.prepare_route(cfg, g)
    obstacles = []
    for layer, owner, shape in sections['obstacles']:
        if layer != '*' and layer not in {x['name'] for x in cfg['layers']}:
            raise ValueError('Unknown obstacle layer')
        if owner and owner not in {x['name'] for x in manifest['nets']}:
            raise ValueError('Unknown obstacle owner')
        actual_shape = shape_from_record(shape)
        if isinstance(actual_shape, k.EndpointPath):
            actual_shape = actual_shape.bbox
        obstacles.append(dict(layer=layer, owner=owner, shape=actual_shape))
    return dict(source=source, window=k._box(sections['window']), terminals=terminals,
                obstacles=obstacles, export_path=str(path))


def item_boxes(items):
    result = []
    for i, item in enumerate(items):
        if item['kind'] == 'segment':
            r = item['width']/2
            result.append(dict(layer=item['layer'], box=(min(item['x1'], item['x2'])-r,
                          min(item['y1'], item['y2'])-r, max(item['x1'], item['x2'])+r,
                          max(item['y1'], item['y2'])+r), item=i))
        else:
            for pad in item['pads']:
                result.append(dict(layer=pad['layer'], box=(item['x']-pad['width']/2,
                    item['y']-pad['height']/2, item['x']+pad['width']/2,
                    item['y']+pad['height']/2), item=i))
    return result


def candidate_items(candidate):
    return [item for branch in candidate['branches'] for item in branch['items']]


def native_items(plan):
    """One physical via can serve multiple branches of the same electrical tree."""
    records = []
    for candidate in plan['nets']:
        seen = set()
        for branch in candidate['branches']:
            for item in branch['items']:
                if item['kind'] == 'via':
                    key = (item['name'], item['x'], item['y'], item['rows'], item['cols'])
                    if key in seen:
                        continue
                    seen.add(key)
                records.append((candidate['name'], item, branch))
    return records


def inflate(box, clearance):
    return (box[0]-clearance, box[1]-clearance, box[2]+clearance, box[3]+clearance)


def planning_config(cfg, data):
    """A later tree tap must not grow the search beyond exported obstacle data."""
    work = copy.deepcopy(cfg)
    window = data['window']
    clearance = max(l['space'] for l in cfg['layers'])+cfg['extra_clearance']
    scope = [window[0]+clearance, window[1]+clearance,
             window[2]-clearance, window[3]-clearance]
    bounds = k.get_route_bounds(cfg)
    if bounds is not None:
        scope = [max(scope[0],bounds[0]),max(scope[1],bounds[1]),
                 min(scope[2],bounds[2]),min(scope[3],bounds[3])]
    work['route_bounds'] = scope
    k.get_route_bounds(work)
    return work


def conflicts(first, second, cfg):
    spacing = {x['name']: x['space']+cfg['extra_clearance'] for x in cfg['layers']}
    indices = defaultdict(list)
    for entry in item_boxes(candidate_items(second)):
        indices[entry['layer']].append(entry['box'])
    indices = {name: k.Index(boxes) for name, boxes in indices.items()}
    return any(entry['layer'] in indices and
               indices[entry['layer']].any(inflate(entry['box'], spacing[entry['layer']]))
               for entry in item_boxes(candidate_items(first)))


def branch_geometry(net, source, target, data, assignments, guides=()):
    metals, globals_ = defaultdict(list), []
    for obstacle in data['obstacles']:
        if obstacle['owner'] == net:
            continue
        if obstacle['layer'] == '*':
            globals_.append(obstacle['shape'])
        else:
            metals[obstacle['layer']].append(obstacle['shape'])
    for name, candidate in assignments.items():
        if name != net:
            for entry in item_boxes(candidate_items(candidate)):
                metals[entry['layer']].append(entry['box'])
    for layer, box in guides:
        metals[layer].append(box)
    shapes, kinds = {}, {}
    for tag, endpoint in [('A', source), ('B', target)]:
        if 'id' in endpoint:
            native = data['terminals'][endpoint['id']]
            shapes[tag] = (native['layer'], native['shape'])
            kinds[tag] = native['record'][0]
    geo = k.Geometry((source['layer'], *source['point']), (target['layer'], *target['point']),
                     metals, globals_, shapes, source_path=data['export_path'])
    geo.endpoint_kinds = kinds
    return geo


def branch_cost(items, cfg):
    return RoutingCost(cfg).items(items)


def existing_group(tid, data):
    """Identical actual conductor geometry proves existing physical contact."""
    terminal = data['terminals'][tid]
    return {other for other, record in data['terminals'].items()
            if record['net'] == terminal['net'] and record['layer'] == terminal['layer']
            and record['record'] == terminal['record']}


def route_access(items, grid):
    access = []
    for item in items:
        if item['kind'] == 'segment':
            for frac in (0, .25, .5, .75, 1):
                point = [item['x1']+frac*(item['x2']-item['x1']),
                         item['y1']+frac*(item['y2']-item['y1'])]
                point = [round(x/grid)*grid for x in point]
                access.append(dict(layer=item['layer'], point=point))
        else:
            for pad in item['pads']:
                access.append(dict(layer=pad['layer'], point=[item['x'], item['y']]))
    return access


class Budget(Exception):
    pass


class Planner:
    def __init__(self, cfg, manifest, data):
        self.cfg, self.manifest, self.data = cfg, manifest, data
        self.search_cfg = planning_config(cfg, data)
        self.weights = RoutingCost(cfg)
        self.options = manifest['options']
        self.started = time.monotonic()
        self.report = dict(algorithm='joint candidate constraint search with adaptive trees and backtracking',
                           route_calls=0, global_states=0, candidate_conflicts=0,
                           adaptive_candidates=0, alternative_states=0, failures=[],
                           objective=('maximize fully connected nets, then terminals; minimize '+
                                      ('estimated branch resistance' if self.weights.mode == 'resistance'
                                       else 'length+via cost')),
                           cost_model=self.weights.describe(), cost_unit=self.weights.unit,
                           optimality_proven=False)

    def check_budget(self):
        if time.monotonic()-self.started >= self.options['max_seconds']:
            raise Budget('max_seconds')
        if self.report['route_calls'] >= self.options['max_route_calls']:
            raise Budget('max_route_calls')

    def tree(self, net, assignments, variant=0, guides=()):
        terminals = net['terminals'][:]
        if variant % 2:
            terminals.reverse()
        root = terminals.pop(0)
        connected = existing_group(root['id'], self.data)
        access = [t for t in net['terminals'] if t['id'] in connected]
        terminals = [t for t in terminals if t['id'] not in connected]
        branches = []
        while terminals:
            self.check_budget()
            best = None
            ordered = sorted(terminals, key=lambda t: min(
                (self.weights.access_estimate(t, a) if self.weights.mode == 'resistance'
                 else abs(t['point'][0]-a['point'][0])+abs(t['point'][1]-a['point'][1])) for a in access))
            # A far-first variant provides a different trunk/tree topology.
            if variant >= 2:
                ordered.reverse()
            for terminal in ordered:
                targets = sorted(access, key=lambda a: self.weights.access_estimate(terminal, a))
                for target in targets[:int(self.options['max_access_points'])]:
                    self.check_budget()
                    self.report['route_calls'] += 1
                    geo = branch_geometry(net['name'], terminal, target, self.data, assignments, guides)
                    stats = {}
                    try:
                        items = k.route(self.search_cfg, geo, stats)
                        k.validate(items, self.cfg, geo)
                    except ValueError as exc:
                        if len(self.report['failures']) < 32:
                            self.report['failures'].append(dict(net=net['name'], terminal=terminal['id'],
                                reason=str(exc), stats=stats))
                        continue
                    branch = dict(source=copy.deepcopy(terminal), target=copy.deepcopy(target), items=items)
                    cost = branch_cost(items, self.cfg)
                    if best is None or cost < best[0]:
                        best = cost, terminal, branch
                    # Nearest feasible access already gives a useful candidate;
                    # other global/tree variants perform the subsequent search.
                    break
                if best is not None:
                    break
            if best is None:
                return None
            _, terminal, branch = best
            branches.append(branch)
            connected |= existing_group(terminal['id'], self.data)
            terminals = [t for t in terminals if t['id'] not in connected]
            access += [terminal] + route_access(branch['items'], self.cfg['grid'])
            unique = {}
            for a in access:
                unique[(a['layer'], *a['point'], a.get('id'))] = a
            access = list(unique.values())
        detail = self.weights.breakdown([item for branch in branches for item in branch['items']])
        return dict(name=net['name'], root=root['id'], branches=branches,
                    cost=detail['total_cost'], cost_breakdown=detail,
                    terminals=[t['id'] for t in net['terminals']])

    def candidates(self, net, assignments):
        results, signatures = [], set()
        def add(candidate):
            if candidate is None:
                return
            signature = json.dumps(candidate_items(candidate), sort_keys=True)
            if signature not in signatures:
                signatures.add(signature)
                results.append(candidate)
        count = int(self.options['candidates_per_net'])
        for variant in range(min(count, 2)):
            add(self.tree(net, assignments, variant))
        if results and count > len(results):
            # Divert an internal primary trunk, generating a genuinely different
            # corridor candidate. Temporary guides never relax any real obstacle.
            segments = sorted((i for i in candidate_items(results[0]) if i['kind'] == 'segment'),
                              key=lambda i: -(abs(i['x2']-i['x1'])+abs(i['y2']-i['y1'])))
            for segment in segments[:count]:
                x = (segment['x1']+segment['x2'])/2
                y = (segment['y1']+segment['y2'])/2
                r = max(segment['width'], self.cfg['grid'])/2
                add(self.tree(net, assignments, 2, [(segment['layer'], (x-r,y-r,x+r,y+r))]))
                if len(results) >= count:
                    break
        return sorted(results, key=lambda c: c['cost'])[:count]

    def solve(self):
        pools, initial_conflicts, best = {}, defaultdict(int), {}
        reason = 'search_exhausted'
        nets = {n['name']: n for n in self.manifest['nets']}
        def score(assigned):
            return (len(assigned), sum(len(c['terminals']) for c in assigned.values()),
                    -sum(c['cost'] for c in assigned.values()))
        try:
            for name, net in nets.items():
                pools[name] = self.candidates(net, {})
            names = list(nets)
            for i, first in enumerate(names):
                for second in names[i+1:]:
                    count = sum(conflicts(a,b,self.cfg) for a in pools[first] for b in pools[second])
                    initial_conflicts[first] += count
                    initial_conflicts[second] += count
            self.report['initial_conflict_degree'] = dict(initial_conflicts)
            queue, serial = [], 0
            heapq.heappush(queue, ((0, 0, 0), serial, {}, frozenset()))
            while queue and self.report['global_states'] < self.options['max_states']:
                self.check_budget()
                _, _, assigned, skipped = heapq.heappop(queue)
                self.report['global_states'] += 1
                if score(assigned) > score(best):
                    best = assigned
                pending = set(nets)-set(assigned)-set(skipped)
                if not pending:
                    continue
                if len(assigned)+len(pending) < len(best):
                    continue
                compatible = {}
                for name in pending:
                    compatible[name] = [c for c in pools[name] if all(
                        not conflicts(c, other, self.cfg) for other in assigned.values())]
                    self.report['candidate_conflicts'] += len(pools[name])-len(compatible[name])
                # Most constrained net first. Earlier alternatives remain in the
                # frontier; a failed later net rolls back those global decisions.
                name = min(pending, key=lambda n: (len(compatible[n]), -initial_conflicts[n], n))
                choices = compatible[name][:]
                if assigned and not choices:
                    for candidate in self.candidates(nets[name], assigned):
                        sig = json.dumps(candidate_items(candidate), sort_keys=True)
                        if all(sig != json.dumps(candidate_items(c), sort_keys=True) for c in choices):
                            choices.append(candidate)
                            self.report['adaptive_candidates'] += 1
                for candidate in choices[:int(self.options['candidates_per_net'])]:
                    next_assignment = dict(assigned, **{name: candidate})
                    serial += 1
                    value = score(next_assignment)
                    heapq.heappush(queue, ((-value[0], -value[1], -value[2]), serial,
                                          next_assignment, skipped))
                    self.report['alternative_states'] += 1
                    if score(next_assignment) > score(best):
                        best = next_assignment
                # The explicit unresolved branch yields an honest best partial
                # diagnostic. It can never be built as a complete overlay.
                serial += 1
                heapq.heappush(queue, ((-len(assigned), -score(assigned)[1],
                                      -score(assigned)[2]+1e6), serial, assigned, skipped | {name}))
            reason = 'max_states' if queue else 'search_exhausted'
        except Budget as exc:
            reason = str(exc)
        self.report.update(termination=reason, elapsed_seconds=round(time.monotonic()-self.started, 3),
                           completed_nets=sorted(best), unresolved_nets=sorted(set(nets)-set(best)),
                           total_nets=len(nets), total_terminals=sum(len(n['terminals']) for n in nets.values()),
                           connected_terminals=sum(len(c['terminals']) for c in best.values()),
                           total_cost=sum(c['cost'] for c in best.values()))
        detail = self.weights.breakdown([item for c in best.values() for item in candidate_items(c)])
        self.report['cost_breakdown'] = detail
        self.report['physical_via_count'] = sum(item['kind'] == 'via'
            for _, item, _ in native_items(dict(nets=list(best.values()))))
        if self.weights.mode == 'resistance':
            self.report['estimated_resistance_ohm'] = detail['estimated_resistance_ohm']
        return best, self.report


def point_on_items(target, items, eps=1e-9):
    layer, (x, y) = target['layer'], target['point']
    return any(entry['layer'] == layer and entry['box'][0]+eps < x < entry['box'][2]-eps and
               entry['box'][1]+eps < y < entry['box'][3]-eps for entry in item_boxes(items))


def validate_plan(plan, cfg, manifest, data, require_complete=True):
    if plan.get('schema') != 'virtuoso-multinet-plan-1':
        raise ValueError('Invalid global plan schema')
    assignments = {c['name']: c for c in plan['nets']}
    if len(assignments) != len(plan['nets']):
        raise ValueError('Duplicate net in global plan')
    expected = {n['name']: n for n in manifest['nets']}
    if not set(assignments) <= set(expected):
        raise ValueError('Plan contains an unknown net')
    if require_complete and (set(assignments) != set(expected) or plan.get('status') != 'complete'):
        raise ValueError('Incomplete global plan; no overlay may be built')
    for name, candidate in assignments.items():
        ids = {t['id'] for t in expected[name]['terminals']}
        root = candidate['root']
        if root not in ids or set(candidate['terminals']) != ids:
            raise ValueError('Tree terminal set does not match manifest')
        connected, items_so_far = existing_group(root, data), []
        by_id = {t['id']: t for t in expected[name]['terminals']}
        for branch in candidate['branches']:
            source, target = branch['source'], branch['target']
            if source.get('id') not in ids-connected or source != by_id[source['id']]:
                raise ValueError('Invalid tree source terminal')
            if 'id' in target:
                if target['id'] not in connected or target != by_id[target['id']]:
                    raise ValueError('Tree branch does not reach an already connected terminal')
            elif not point_on_items(target, items_so_far):
                raise ValueError('Tree branch anchor is not on the existing generated tree')
            geo = branch_geometry(name, source, target, data, assignments)
            k.validate(branch['items'], cfg, geo)
            spacing = {l['name']:l['space']+cfg['extra_clearance'] for l in cfg['layers']}
            for entry in item_boxes(branch['items']):
                if not k.inside_bounds(inflate(entry['box'],spacing[entry['layer']]),data['window']):
                    raise ValueError('Tree conductor clearance exceeds exported obstacle window')
            connected |= existing_group(source['id'], data)
            items_so_far += branch['items']
        if connected != ids:
            raise ValueError('Tree leaves disconnected terminals: ' + name)
    return assignments


def snapshots(cfg_path, manifest_path, export_path):
    return dict(config=digest(cfg_path), manifest=digest(manifest_path), geometry=digest(export_path))


def load_inputs(args):
    cfg = json.loads(Path(args.config).read_text())
    validate_config(cfg)
    manifest = read_manifest(args.manifest, cfg)
    data = read_export(args.geometry, manifest, cfg)
    return cfg, manifest, data


def actual_check(args, cfg, manifest, data, plan):
    assignments = validate_plan(plan, cfg, manifest, data)
    native = native_items(plan)
    all_items = [item for name, item, branch in native]
    references = [(name, branch) for name, item, branch in native]
    actuals = k.read_actual_vias(Path(args.actual_vias))
    expected = {i for i, item in enumerate(all_items) if item['kind'] == 'via'}
    seen, actual_boxes, checks = set(), defaultdict(list), []
    via_defs = {v['name']: v for v in cfg['vias']}
    layers = {l['name']: l for l in cfg['layers']}
    for actual in actuals:
        index = actual['index']
        if actual['representation'] != 'per_layer' or index not in expected or index in seen:
            raise ValueError('Every planned via needs exactly one native per-layer record')
        seen.add(index)
        item = all_items[index]
        definition = via_defs.get(actual['name'])
        pair = {p['layer'] for p in item['pads']}
        if (actual['name'] != item['name'] or definition is None or
                set(actual['layers']) != pair or actual['rows'] != item['rows'] or actual['cols'] != item['cols']):
            raise ValueError('Actual via name/pair/array differs from reviewed global plan')
        if not k.inside_bounds(actual['bbox'], k.get_route_bounds(cfg)):
            raise ValueError('Actual via exceeds route bounds')
        if not k.inside_bounds(actual['bbox'], data['window']):
            raise ValueError('Actual via exceeds exported obstacle window')
        if any(not k.inside_bounds(b['bbox'], inflate(actual['bbox'], cfg['grid']*1e-6))
               for b in actual['boxes']):
            raise ValueError('Actual layer box exceeds its native instance box')
        if not all(any(b['layer']==layer and b['bbox'][0] < item['x'] < b['bbox'][2] and
                       b['bbox'][1] < item['y'] < b['bbox'][3] for b in actual['boxes']) for layer in pair):
            raise ValueError('Actual via does not cover its planned transition')
        name, branch = references[index]
        geo = branch_geometry(name, branch['source'], branch['target'], data, assignments)
        for footprint in actual['boxes']:
            layer, box = footprint['layer'], footprint['bbox']
            if layer not in layers:
                raise ValueError('Unexpected conductor in native via')
            clearance_box = inflate(box, layers[layer]['space']+cfg['extra_clearance'])
            if not k.inside_bounds(clearance_box, data['window']):
                raise ValueError('Actual via clearance exceeds the exported query window')
            if k.Index(list(geo[2].get(layer, []))+list(geo[3])).any(clearance_box):
                raise ValueError('Actual via conflicts with source obstacle or another net: ' + name)
            actual_boxes[name].append((layer, box))
            checks.append(dict(net=name, index=index, layer=layer, bbox=box))
    if seen != expected:
        raise ValueError('Missing actual via for a global transition')
    # Actual footprints may both grow beyond their plans. Check actual vs actual,
    # rather than each actual only against the other planned footprint.
    for first, entries in actual_boxes.items():
        for second, other in actual_boxes.items():
            if first >= second:
                continue
            for layer, box in entries:
                if any(layer == ol and k.intersects(inflate(box, layers[layer]['space']+cfg['extra_clearance']), ob)
                       for ol, ob in other):
                    raise ValueError('Actual vias of different nets violate spacing')
    return dict(status='clear', native_scoped=len(actuals), checks=checks)


def skill_plan(plan):
    records = []
    for candidate in plan['nets']:
        rows = []
        for name, item, branch in native_items(dict(nets=[candidate])):
            if item['kind'] == 'segment':
                rows.append(['S', item['layer'], item['width'], item['x1'], item['y1'], item['x2'], item['y2']])
            else:
                pads = [v for p in item['pads'] for v in [p['layer'], p['width'], p['height']]]
                rows.append(['V', item['name'], item['x'], item['y'], item['rows'], item['cols'], *pads])
        records.append([candidate['name'], rows])
    return 'mnPlanStatus = '+k.skill_literal(plan['status'])+'\nmnPlanNets = '+k.skill_literal(records)+'\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--geometry')
    parser.add_argument('--output', required=True)
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--validate', action='store_true')
    parser.add_argument('--actual-vias')
    args = parser.parse_args()
    output = Path(args.output)
    report_path = output.with_suffix('.actual_report.json' if args.actual_vias else
                                     '.validation_report.json' if args.validate else '.report.json')
    report = dict(status='failed')
    try:
        if args.prepare:
            cfg = json.loads(Path(args.config).read_text())
            validate_config(cfg)
            manifest = read_manifest(args.manifest, cfg)
            compile_skill(cfg, output.with_suffix('.config.il'))
            text = re.sub(r'\bar([A-Z]\w*)', r'mnK\1', output.with_suffix('.config.il').read_text())
            atomic_text(output.with_suffix('.config.il'), text)
            rows = [[n['name'], t['id'], t['layer'], *t['point'], t.get('instance_path', [])]
                    for n in manifest['nets'] for t in n['terminals']]
            atomic_text(output.with_suffix('.request.il'), 'mnRequests = '+k.skill_literal(rows)+'\n')
            return 0
        cfg, manifest, data = load_inputs(args)
        if args.validate or args.actual_vias:
            plan = json.loads(output.read_text())
            if plan['snapshot'] != snapshots(args.config, args.manifest, args.geometry):
                raise ValueError('Source geometry/config/manifest changed; recompute the entire plan')
            if output.with_suffix('.il').read_text() != skill_plan(plan):
                raise ValueError('SKILL plan differs from validated JSON; recompute the entire plan')
            validate_plan(plan, cfg, manifest, data)
            report = actual_check(args,cfg,manifest,data,plan) if args.actual_vias else dict(status='clear')
        else:
            # Failed/incomplete planning cannot leave a stale buildable SKILL plan.
            atomic_text(output.with_suffix('.il'), 'mnPlanStatus = "failed"\nmnPlanNets = nil\n')
            assignments, report = Planner(cfg, manifest, data).solve()
            complete = len(assignments) == len(manifest['nets'])
            plan = dict(schema='virtuoso-multinet-plan-1', status='complete' if complete else 'incomplete',
                        cost_model=RoutingCost(cfg).describe(),
                        source=data['source'][:3], placement=dict(origin=[0,0], orient='R0'),
                        snapshot=snapshots(args.config,args.manifest,args.geometry),
                        nets=[assignments[n['name']] for n in manifest['nets'] if n['name'] in assignments])
            validate_plan(plan, cfg, manifest, data, require_complete=False)
            atomic_text(output, json.dumps(plan, indent=2)+'\n')
            atomic_text(output.with_suffix('.il'), skill_plan(plan))
            report['status'] = plan['status']
        atomic_text(report_path, json.dumps(report, indent=2)+'\n')
        print(json.dumps({key:report[key] for key in ('status','completed_nets','unresolved_nets','route_calls','global_states') if key in report}))
        return 0 if report['status'] in ('complete','clear') else 2
    except (ValueError, KeyError, TypeError, OSError) as exc:
        report.update(status='failed', error=str(exc))
        atomic_text(report_path, json.dumps(report, indent=2)+'\n')
        print(str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
