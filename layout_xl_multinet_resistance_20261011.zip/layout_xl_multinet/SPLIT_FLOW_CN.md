# 分开执行：CIW 导出 → Python 求解 → CIW 创建 layout

此入口使用你已经打开的 Virtuoso XL 会话。Python 求解不启动 Virtuoso，不需要 `--xvfb`、`--cdslib` 或显示环境。旧 `run_offline.py` 仍保留一条命令求解及另起 Virtuoso 创建的功能。

本文包含当前推荐流程的完整命令和信息流。方案好坏的评价、代价计算及搜索限制见
[ROUTING_QUALITY_CN.md](ROUTING_QUALITY_CN.md)；一体化入口的读写说明见
[USAGE_AND_DATAFLOW_CN.md](USAGE_AND_DATAFLOW_CN.md)。
按电阻优化及如何填写每层方块阻值／每种 via 阻值，见
[RESISTANCE_COST_CN.md](RESISTANCE_COST_CN.md)。启用时导出新合成的实际几何＋电阻配置；
其余操作顺序和文件信息流相同。

## 0. 压缩包与程序路径

当前电阻版本为 `layout_xl_multinet_resistance_20261011.zip`，程序和上述说明位于包内
`layout_xl_multinet/`。原 `layout_xl_multinet_split_20261011.zip` 已有使用和信息流
说明；电阻版包含完整使用、信息流、方案评价及阻值配置说明。两个更早的 multinet／hierarchy 包没有这些
完整说明，请使用 split 包。

现有本机运行目录是 `/home/meow/autoroute/multinet`，下文可以直接使用。另一台机器
应先解压到一个全新目录，在 CIW 把 `mnBaseDir` 设为解压后的 `layout_xl_multinet`
绝对路径，并同步替换 Python 命令中的程序路径及 job 路径。不要直接解压覆盖已有
运行目录；显式指定自己的实际配置，保留本地源码改动和 `route_config.json`。

包内独立的 `native_test_library/` 是已保存的测试 OA 库，其 `README.txt` 说明如何
定义 `AR_AUDIT_20261010`；包里不含 PDK。使用测试库时还需在自己的库定义中提供
实际 `tsmc18` 技术库。使用自己的设计时，源库和输出库采用自己已有的库定义。

## 1. 打开并保存源版图

当前测试源：`AR_AUDIT_20261010/hier_top_splitxl20261011a/layout`，电路参考是同 cell 的 `schematic`。也可使用原来的 `hier_top_xl20261011b/layout`。

人工在 Layout XL 中打开源图，保存电路、版图和绑定关系。真实设计使用自己的有绑定源图和与技术匹配的实际配置。

Terminal 创建新任务目录：

```bash
mkdir -p /home/meow/autoroute/multinet/jobs/manual_split_01
```

## 2. CIW 加载，然后先导出障碍、再导出连接

程序更新后先重新加载这两个脚本；加载放在两次导出之前。

```lisp
mnBaseDir = "/home/meow/autoroute/multinet"
load(strcat(mnBaseDir "/autoroute_multinet.il"))
load(strcat(mnBaseDir "/hierarchy/auto_export.il"))
```

点击源 layout 窗口后执行：

```lisp
mnExportCv = geGetEditCellView()
printf("Export source: %s/%s/%s\n"
       mnExportCv~>libName mnExportCv~>cellName mnExportCv~>viewName)
mnExportObstacles("/home/meow/autoroute/multinet/jobs/manual_split_01"
                  mnExportCv
                  "/home/meow/autoroute/multinet/cases/hierarchy_xl/route_config.json")
mnExportConnections("/home/meow/autoroute/multinet/jobs/manual_split_01"
                    mnExportCv)
```

确认源身份正确，并看到 `HIER_EXPORT_READY`。上述配置仅适用于提供的 TSMC 测试版图；实际设计把配置参数换成自己的匹配配置绝对路径。配置只复制到 job，原文件不覆盖。

两次导出在同一会话、同一源图、同一 job 执行。后续创建完成前保持源图、逻辑连接及绑定不变。

## 3. Terminal 只计算方案

```bash
python3 /home/meow/autoroute/multinet/run_plan.py \
  --job /home/meow/autoroute/multinet/jobs/manual_split_01
```

可增加预算：`--max-seconds 300 --max-states 256`；默认 90 秒、64 个整体搜索状态。所有 net 联合搜索候选连接树并处理共享通道／冲突；有限预算不保证数学全局最优。

成功显示 `Plan ready; no Virtuoso started and no layout created.`。

检查：

| 文件 | 应有状态 |
|---|---|
| `plan_result.json` | `status=planned`，`native_created=false` |
| `batch_plan.json` | `status=complete` |
| `batch_plan.report.json` | `unresolved_nets=[]` |

这时只有连线方案，尚无新 OA layout。Python 使用 job 中的配置副本、`obstacles.sexp`、`connections.sexp` 和 ready 哈希，生成／更新 `nets.json`、`batch_geometry.sexp`、`binding_report.json`、搜索选项及 `batch_plan.json/il`。

## 4. 现有 CIW 会话读取方案，创建独立连线 layout

点击正确的源 layout 窗口后，在 CIW 执行：

```lisp
mnBuildFromPlan("/home/meow/autoroute/multinet/jobs/manual_split_01"
                "AR_AUDIT_20261010"
                "hier_routes_manual_split_01")
```

输出库须存在且技术、单位、DBU、grid 相容；输出 cell/view 必须全新。默认 view 为 `layout`。

若要明确指定源 cellView 或输出 view：

```lisp
mnBuildFromPlan("/home/meow/autoroute/multinet/jobs/manual_split_01"
                "AR_AUDIT_20261010"
                "hier_routes_manual_split_02"
                "layout"
                mnExportCv)
```

此入口会：

1. 检查原始采集哈希、完整方案、方案输入快照及 JSON／SKILL 一致性。
2. 锁定本次 job，防止 terminal 求解或另一个 CIW 创建改写同一任务。
3. 核对当前 layout 的库／cell／view 身份；从当前 XL 会话重新采集几何和逻辑绑定进行比较。
4. 只在新 view 创建 path、pad、标准 via，并复核实际 via。
5. 全部通过才保存新 view，写入 `ciw_build_result.json` 并释放任务锁。

这里的重采集用于核对导出后有没有改图／改连接，不重新决定连接需求。创建仍依据 Python 已计算的完整方案。

入口不会新开 Virtuoso 会话，不关闭或 purge 你的源图窗口，不把连线自动插入源图。创建过程会调用 Python 做数据校验，因此现有 Virtuoso 会话的环境仍须能调用 `python3`。

成功显示 **`HIER_CIW_BUILD_SAVED`**；`ciw_build_result.json` 应为 `status=complete`，`batch_plan.actual_report.json` 应为 `status=clear`。

失败看 CIW 错误、job 的 `batch_engine.log`、`batch_plan.validation_report.json`／`batch_plan.actual_report.json`。源图变化会拒绝创建；native 创建或 via 复核失败会回滚整份新建未保存 view。已有输出 view 会被拒绝。

## 5. 人工调入源版图

打开新输出 `AR_AUDIT_20261010/hier_routes_manual_split_01/layout` 检查。

在原始 top 通过 Create Instance 放入新输出：**Origin=0:0，Orientation=R0，Magnification=1**。输出使用源 top 坐标，不能按输出 bbox 左下角对齐。

插入、保存及项目要求的连通性／DRC／LVS 检查由你执行。再次规划前先移除旧连线实例并保存，再导出。

## 6. 实际 via 复核的作用

Python 搜索时用配置中的 via 定义、pad 尺寸和间距模型判断放置是否可行。CIW 的 `dbCreateVia` 则使用输出技术库的真实标准 via 定义及数组参数创建 OA 对象。

复核从这个真实 via 的 master 金属图形取得各层占地，按实例变换映射到 top 坐标，写入 `batch_actual_vias.txt`。随后检查：

- 每个规划换层位置都有且只有一个对应实际 via。
- via 名称、上下层、行／列数与方案一致；各层导体覆盖规划换层点。
- 实际 via 未越过 route bounds 或导出窗口。
- 实际各层金属占地加间距后，不碰原有障碍或其他 net 的规划金属。
- 不同 net 的实际 via 占地之间满足间距。

例如：规划认为某 via 能放在窄通道中，但实际技术库创建出的 enclosure 更大，可能侵入旁边金属的间距范围。只检查规划模型会漏掉它，实际占地复核会拒绝保存并回滚新 view。

复核不启动额外 Virtuoso：真实对象已经在现有 CIW 会话中创建，Python 读取其导出数据进行校验。这一步不是完整 foundry DRC／LVS，未检查全部 cut、端点、密度等工艺规则。

## 7. 分开后的信息流与文件

```mermaid
flowchart TD
    A[现有 CIW：源图、电路 net 和 XL binding] --> B[障碍与连接采集文件]
    B --> C[Terminal：run_plan.py]
    C --> D[batch_plan.json / il + plan_result.json]
    D --> E[现有 CIW：mnBuildFromPlan]
    A --> E
    E --> F[源快照核对、创建 path / pad / via]
    F --> G[导出实际 via，由 Python 复核]
    G --> H[保存新 OA layout + ciw_build_result.json]
    H --> I[人工以 0:0 / R0 / 1 实例化到源图]
```

| 阶段 | 主要文件 |
|---|---|
| CIW 采集 | `route_config.json` 副本、`obstacles.sexp`、`connections.sexp`、`config_capture.json`、`export_ready.json` |
| 路由输入 | `nets.json`、`batch_geometry.sexp`、`binding_report.json` |
| Terminal 求解 | `planner_options.json`、`batch_plan.config.il`、`batch_plan.request.il`、`batch_plan.json/il`、`batch_plan.report.json`、`plan_result.json` |
| CIW 创建／复核 | `current_obstacles.sexp`、`current_connections.sexp`、`batch_plan.validation_report.json`、`batch_actual_vias.txt`、`batch_plan.actual_report.json`、`ciw_build_result.json` |
| CIW 调用 Python 日志 | `batch_engine.log` |
| 最终 layout | 指定输出库的 OA 数据库 |

分开流程不生成 `offline_native.log`；原生错误在你的当前 CIW 会话日志中。`offline_result.json`、`offline_native.log` 属于保留的一体化入口。

修改配置、几何、电路或 binding 后，保存并重新执行两阶段导出。重跑求解必须等本次 CIW 创建结束；已有方案、图片或旧成功报告不能证明本次运行成功。

## 8. 本机验证与可打开的版图

已实际运行 IC6.1.7 Virtuoso XL，新建 4 个底层模块、顶层及真实绑定后验证分开流程：5 个 net、20 个端点全部连接，33 颗真实标准 via 占地复核通过。

| 库 AR_AUDIT_20261010 中的 cell | 内容 |
|---|---|
| `hier_top_splitxl20261011a` 的 schematic/layout | 本次源电路和有绑定的层次版图 |
| `hier_routes_splitxl20261011a/layout` | 现有 XL 会话通过新入口创建的连线 layout |
| `hier_routes_splitxl20261011a_recovered/layout` | 故意触发失败后恢复，再创建的完整连线 layout |
| `hier_routes_splitxl20261011a_legacy/layout` | 保留的一体化入口兼容性验证输出 |

29 项 Python 测试、9 项新的真实 native 检查通过。纯求解在没有 DISPLAY 且 Cadence 命令设为调用探针的环境中成功，确认没有调用 Virtuoso／Xvfb。native 检查覆盖错误源图、源几何／逻辑变化、已有 view、不完整方案、修改过的 SKILL 方案、实际 via 数组不符时回滚，以及恢复后重新创建。

原有本地源码／配置、已有案例和本次源数据库哈希未变。测试使用独立受控 Virtuoso 会话运行相同 CIW 入口，没有操作或关闭用户现有 GUI；用户正常使用时无需另起会话或 Xvfb。

原始证据在 `cases/hierarchy_xl/split_release/`；汇总见 `cases/hierarchy_xl/SPLIT_TEST_RESULTS.json`。本次是新建真实工艺案例；历史缺失的 M2→M3 原始失败数据仍未闭环。
