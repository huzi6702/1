#!/usr/bin/env python3
"""Pure Python planning from CIW captures; never starts Virtuoso or Xvfb."""
from __future__ import annotations
import argparse
import json
import math
import subprocess
from pathlib import Path
import batch_router as b
from hierarchy_io import write_inputs, verify_ready
from job_state import locked_job


def plan_routes(job, root, max_seconds=90, max_states=64):
    # Invalidate the buildable payload before checking a new run's inputs.
    b.atomic_text(job/'batch_plan.il', 'mnPlanStatus = "failed"\nmnPlanNets = nil\n')
    if not math.isfinite(max_seconds) or max_seconds <= 0 or max_states <= 0:
        raise ValueError('Time/state limits must be positive and finite')
    verify_ready(job)
    extracted = write_inputs(job)
    manifest_path = job/'nets.json'
    manifest = json.loads(manifest_path.read_text())
    manifest['options'].update(max_seconds=max_seconds, max_states=max_states)
    b.atomic_text(job/'planner_options.json', json.dumps(manifest['options'], indent=2)+'\n')
    b.atomic_text(manifest_path, json.dumps(manifest, indent=2, ensure_ascii=False)+'\n')
    common = ['--config',str(job/'route_config.json'),'--manifest',str(manifest_path),
              '--geometry',str(job/'batch_geometry.sexp'),'--output',str(job/'batch_plan.json')]
    for flags in [['--prepare'], []]:
        result = subprocess.run(['python3',str(root/'batch_router.py'),*flags,*common])
        if result.returncode:
            raise ValueError('Global routing failed/incomplete; no native overlay created')
    return extracted


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', type=Path, required=True)
    parser.add_argument('--max-seconds', type=float, default=90)
    parser.add_argument('--max-states', type=int, default=64)
    args = parser.parse_args(argv)
    job = args.job.resolve()
    root = Path(__file__).resolve().parent
    try:
        with locked_job(job):
            report = dict(status='failed', native_created=False)
            try:
                exported = plan_routes(job, root, args.max_seconds, args.max_states)
                report.update(status='planned', exported=exported,
                              plan=str(job/'batch_plan.json'),
                              skill_plan=str(job/'batch_plan.il'))
                print('Plan ready; no Virtuoso started and no layout created.')
                print('In the existing source Layout XL session, use mnBuildFromPlan(job lib NEWcell).')
                return 0
            except (ValueError, OSError, RuntimeError, KeyError, TypeError) as exc:
                report['error'] = str(exc)
                print(str(exc), file=b.sys.stderr)
                return 2
            finally:
                b.atomic_text(job/'plan_result.json', json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    except (ValueError, OSError) as exc:
        # A refused concurrent invocation must not overwrite the active result.
        print(str(exc), file=b.sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
