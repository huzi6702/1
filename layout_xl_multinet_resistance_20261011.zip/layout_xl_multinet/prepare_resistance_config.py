#!/usr/bin/env python3
"""Combine an actual geometry config with resistance values into a NEW config."""
from __future__ import annotations
import argparse
import copy
import json
import sys
from pathlib import Path
import batch_router as b


def prepare(config, model, output):
    config, model, output = map(lambda p: Path(p).resolve(), (config, model, output))
    if output in (config, model):
        raise ValueError('Output must differ from both input files; preserve the actual config')
    if output.exists():
        raise ValueError('Output already exists; choose a new config filename')
    cfg = copy.deepcopy(json.loads(config.read_text()))
    cfg['cost_model'] = json.loads(model.read_text())
    if cfg['cost_model'].get('mode') != 'resistance':
        raise ValueError('Resistance model requires mode=resistance')
    b.validate_config(cfg)
    output.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation refuses overwrites even if another process wins the race.
    with output.open('x') as stream:
        stream.write(json.dumps(cfg, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
    return cfg


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        cfg = prepare(args.config, args.model, args.output)
        print('New resistance config: '+str(args.output.resolve()))
        print('ASSUMED resistance values; replace with your actual values.' if
              cfg['cost_model'].get('assumed') else 'Resistance values are user supplied.')
        return 0
    except (ValueError, TypeError, AttributeError, OSError) as exc:
        print(str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
