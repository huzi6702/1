#!/usr/bin/env python3
"""Convert two native, bound-layout exports into immutable routing inputs."""
from __future__ import annotations
import argparse
import json
import re
import shutil
import uuid
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace
import batch_router as b
from job_state import locked_job


def sexp_literal(value):
    if isinstance(value, list):
        return '(' + ' '.join(sexp_literal(x) for x in value) + ')'
    return b.k.skill_literal(value)


def section_file(path, schema):
    tree = b.parse(Path(path).read_text())
    if len(tree) != 1 or tree[0][0] != schema:
        raise ValueError('Invalid native export: ' + str(path))
    pairs = tree[0][1:]
    if len({x[0] for x in pairs}) != len(pairs):
        raise ValueError('Duplicate native export section')
    return {x[0]: x[1:] for x in pairs}


def shape(record):
    actual = b.shape_from_record(record)
    if record[0] == 'rect':
        return ['rect', *map(float, record[1:])]
    if record[0] == 'polygon':
        return ['polygon', [list(map(float, p)) for p in record[1]]]
    return ['path', float(record[1]), [list(map(float, p)) for p in record[2]]]


def key(record):
    # Keys contain only quoted identity strings and numeric geometry. Native
    # IDs and iteration order never participate in a persisted snapshot.
    path, layer, purpose, kind, geometry = record
    return json.dumps([[] if path == 'nil' else path, layer, purpose, kind, shape(geometry)],
                      separators=(',', ':'), ensure_ascii=False)


def obstacles(path):
    data = section_file(path, 'HOBS1')
    source = data['source'][:4] + [float(x) for x in data['source'][4:]]
    records = [[layer, shape(geometry), key(identity)] for layer, geometry, identity in data['obstacles']]
    return dict(source=source, window=list(map(float, data['window'])),
                obstacles=sorted(records, key=lambda x: json.dumps(x, sort_keys=True)))


def assemble(obstacle_file, connection_file):
    obs = obstacles(obstacle_file)
    con = section_file(connection_file, 'HCON1')
    if con['source'][:3] != obs['source'][:3]:
        raise ValueError('Obstacle and connection source identities differ')
    nets, owners, terminal_records, ids = defaultdict(list), {}, [], set()
    provenance = []
    for row in con['terminals']:
        name, tid, layer, x, y, geom, identity, logical = row
        if tid in ids:
            raise ValueError('Duplicate physical terminal: ' + tid)
        ids.add(tid)
        ident = key(identity)
        if ident in owners and owners[ident] != name:
            raise ValueError('One physical conductor belongs to different schematic nets')
        owners[ident] = name
        term = dict(id=tid, layer=layer, point=[float(x), float(y)],
                    instance_path=[] if identity[0] == 'nil' else identity[0])
        nets[name].append(term)
        terminal_records.append([name, tid, layer, float(x), float(y), shape(geom), ident])
        provenance.append(dict(net=name, terminal=tid, schematic=logical,
                               instance_path=term['instance_path'], layer=layer, point=term['point']))
    skipped = sorted(name for name, terms in nets.items() if len(terms) < 2)
    active = set(nets) - set(skipped)
    if not active:
        raise ValueError('No net has two physical endpoints to connect')
    manifest = dict(schema='virtuoso-multinet-1',
                    source=dict(zip(('lib', 'cell', 'view'), obs['source'][:3])),
                    nets=[dict(name=name, terminals=sorted(nets[name], key=lambda t: t['id']))
                          for name in sorted(active)], options=dict(b.DEFAULTS))
    owned_records, found = [], set()
    for layer, geom, ident in obs['obstacles']:
        # Exemption only for the exact selected pin figure, never an entire
        # instance/net or arbitrary neighboring existing wires.
        owner = owners.get(ident, '')
        owner = owner if owner in active else ''
        if owner:
            geom = next(t[5] for t in terminal_records if t[6] == ident)
            found.add(ident)
        owned_records.append([layer, owner, geom])
    for name, tid, layer, x, y, geom, ident in terminal_records:
        if name in active and ident not in found:
            owned_records.append([layer, name, geom])
            found.add(ident)
    owned_records.sort(key=lambda r: json.dumps(r))
    terminals = sorted([r[:6] for r in terminal_records if r[0] in active], key=lambda r: r[1])
    native = ['MNET1', ['source', *obs['source']], ['window', *obs['window']],
              ['terminals', *terminals], ['obstacles', *owned_records]]
    report = dict(schema='virtuoso-hierarchy-binding-1', source=manifest['source'],
                  schematic=con['schematic'], instances=sorted(con['bindings'], key=lambda r: r[0]),
                  terminals=sorted(provenance, key=lambda r: r['terminal']), skipped_single_terminal_nets=skipped,
                  net_count=len(active), terminal_count=len(terminals), obstacle_count=len(owned_records))
    return manifest, sexp_literal(native) + '\n', report


def write_inputs(job, obstacle_file=None, connection_file=None, compare=False):
    capture = job/'config_capture.json'
    if capture.exists() and json.loads(capture.read_text())['sha256'] != b.digest(job/'route_config.json'):
        raise ValueError('Config changed since obstacle export; export obstacles first again')
    manifest, native, report = assemble(obstacle_file or job/'obstacles.sexp',
                                        connection_file or job/'connections.sexp')
    if (job/'planner_options.json').exists():
        manifest['options'] = json.loads((job/'planner_options.json').read_text())
    contents = {'nets.json': json.dumps(manifest, indent=2, ensure_ascii=False)+'\n',
                'batch_geometry.sexp': native,
                'binding_report.json': json.dumps(report, indent=2, ensure_ascii=False)+'\n'}
    if compare:
        for name, content in contents.items():
            if (job/name).read_text() != content:
                raise ValueError('Saved layout/schematic/binding changed since export: ' + name)
    else:
        for name, content in contents.items():
            b.atomic_text(job/name, content)
    cfg = json.loads((job/'route_config.json').read_text())
    b.validate_config(cfg)
    b.read_manifest(job/'nets.json', cfg)
    b.read_export(job/'batch_geometry.sexp', manifest, cfg)
    return report


def stamp_ready(job):
    ready = {name: b.digest(job/name) for name in
             ('route_config.json','obstacles.sexp','connections.sexp')}
    b.atomic_text(job/'export_ready.json', json.dumps(ready,indent=2)+'\n')


def verify_ready(job):
    if not (job/'export_ready.json').is_file():
        raise ValueError('Complete obstacle export followed by connection export first')
    ready = json.loads((job/'export_ready.json').read_text())
    for name in ('route_config.json','obstacles.sexp','connections.sexp'):
        if ready.get(name) != b.digest(job/name):
            raise ValueError('Captured inputs changed after connection export: '+name)


def prepare_config(config, job):
    cfg = json.loads(config.read_text())
    b.validate_config(cfg)
    job.mkdir(parents=True, exist_ok=True)
    if config.resolve() != (job/'route_config.json').resolve():
        shutil.copyfile(config, job/'route_config.json')
    for name in ('export_ready.json','connections.sexp','planner_options.json'):
        if (job/name).exists():
            (job/name).unlink()
    b.atomic_text(job/'config_capture.json',
                  json.dumps(dict(sha256=b.digest(job/'route_config.json')),indent=2)+'\n')
    target = job/'batch_plan.config.il'
    b.compile_skill(cfg, target)
    b.atomic_text(target, re.sub(r'\bar([A-Z]\w*)', r'mnK\1', target.read_text()))


def claim_build(job):
    """Reserve captured inputs/plan until the existing CIW finishes building."""
    with locked_job(job):
        verify_ready(job)
        write_inputs(job, compare=True)
        cfg, manifest, data = b.load_inputs(SimpleNamespace(
            config=job/'route_config.json', manifest=job/'nets.json',
            geometry=job/'batch_geometry.sexp'))
        plan = json.loads((job/'batch_plan.json').read_text())
        if plan['snapshot'] != b.snapshots(job/'route_config.json',job/'nets.json',job/'batch_geometry.sexp'):
            raise ValueError('Plan input snapshot changed; run run_plan.py again')
        if (job/'batch_plan.il').read_text() != b.skill_plan(plan):
            raise ValueError('SKILL plan differs from validated JSON; run run_plan.py again')
        b.validate_plan(plan,cfg,manifest,data)
        lease = uuid.uuid4().hex
        guard = job/'.ciw_build.lock'
        guard.mkdir()
        try:
            state = dict(lease=lease, source=manifest['source'], plan_sha256=b.digest(job/'batch_plan.json'))
            b.atomic_text(guard/'lease.json',json.dumps(state,indent=2)+'\n')
            source = [manifest['source'][k] for k in ('lib','cell','view')]
            b.atomic_text(job/'ciw_build.context.il',
                          'mnBuildLease = '+b.k.skill_literal(lease)+'\n'+
                          'mnExpectedSource = '+b.k.skill_literal(source)+'\n')
            return state
        except Exception:
            if (guard/'lease.json').exists():
                (guard/'lease.json').unlink()
            guard.rmdir()
            raise


def finish_build(job, lease, status, output):
    with locked_job(job,allow_build=True):
        guard = job/'.ciw_build.lock'
        state = json.loads((guard/'lease.json').read_text())
        if lease != state['lease']:
            raise ValueError('CIW build lease differs; active build was not released')
        report = dict(status=status, source=state['source'], output=output,
                      placement=dict(origin=[0,0],orient='R0',magnification=1),
                      plan_sha256=state['plan_sha256'], mode='existing_ciw')
        try:
            if status == 'complete':
                actual = json.loads((job/'batch_plan.actual_report.json').read_text())
                if actual['status'] != 'clear':
                    raise ValueError('Actual via review did not pass')
                report['actual_review'] = actual
            b.atomic_text(job/'ciw_build_result.json',json.dumps(report,indent=2,ensure_ascii=False)+'\n')
            return report
        finally:
            (guard/'lease.json').unlink()
            guard.rmdir()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', type=Path, required=True)
    parser.add_argument('--prepare-config', type=Path)
    parser.add_argument('--obstacles', type=Path)
    parser.add_argument('--connections', type=Path)
    parser.add_argument('--compare', action='store_true')
    parser.add_argument('--compare-obstacles', type=Path)
    parser.add_argument('--claim-build', action='store_true')
    parser.add_argument('--finish-build', help='Lease of the existing CIW build to finish')
    parser.add_argument('--build-status',choices=('complete','failed'))
    parser.add_argument('--output-lib')
    parser.add_argument('--output-cell')
    parser.add_argument('--output-view',default='layout')
    args = parser.parse_args()
    try:
        if args.claim_build:
            print(json.dumps(claim_build(args.job)))
        elif args.finish_build:
            if not all((args.build_status,args.output_lib,args.output_cell)):
                raise ValueError('Finishing a CIW build requires status and output lib/cell')
            print(json.dumps(finish_build(args.job,args.finish_build,args.build_status,
                dict(lib=args.output_lib,cell=args.output_cell,view=args.output_view))))
        elif args.prepare_config:
            args.job.mkdir(parents=True,exist_ok=True)
            with locked_job(args.job):
                prepare_config(args.prepare_config, args.job)
        elif args.compare_obstacles:
            if obstacles(args.compare_obstacles) != obstacles(args.job/'obstacles.sexp'):
                raise ValueError('Obstacles changed between exports; export obstacles first again')
        else:
            print(json.dumps(write_inputs(args.job, args.obstacles, args.connections, args.compare)))
            if not args.compare:
                stamp_ready(args.job)
        return 0
    except (ValueError, KeyError, TypeError, OSError) as exc:
        print(str(exc), file=b.sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
