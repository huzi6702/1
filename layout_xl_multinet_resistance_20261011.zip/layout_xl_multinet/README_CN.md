# 多 net 整体连线与独立连线 layout

独立于两点 F8 版本。此版本不安装快捷键，不修改原始 layout，也不改旧的
`~/route_config.json`、`~/autoroute.il` 或 `~/auto_con/autoroute/`。
新增 schematic／layout 真实 XL 绑定自动提取入口：
**先导出障碍，再导出连接，terminal 整体求解，回到现有 CIW 创建独立连线 layout**。
分开入口见 [SPLIT_FLOW_CN.md](SPLIT_FLOW_CN.md)：`run_plan.py` 不启动 Virtuoso，`mnBuildFromPlan` 在当前 XL 会话创建及复核。原 `run_offline.py` 一体化入口继续保留。
推荐流程的完整命令、文件信息流及实际 via 复核见 [SPLIT_FLOW_CN.md](SPLIT_FLOW_CN.md)。
[USAGE_AND_DATAFLOW_CN.md](USAGE_AND_DATAFLOW_CN.md) 保留一体化入口的详细读写说明；
已保存层次测试见 [HIERARCHY_CN.md](HIERARCHY_CN.md)，方案评分与局限见
[ROUTING_QUALITY_CN.md](ROUTING_QUALITY_CN.md)。
新增可配置的方块阻值／via 单 cut 阻值代价；启用和填写步骤见
[RESISTANCE_COST_CN.md](RESISTANCE_COST_CN.md)。示例为明确标注的假设值，不是 PDK 数据。
也保留 JSON net—端点清单兼容入口；不会按距离猜测 net。

## 整体规划

1. SKILL 根据清单坐标查找真实原生金属，导出全部端点与全局搜索窗口的障碍。
   层次坐标经过实际 transform；多重命中拒绝，不能用 bbox 代替真实端点。
2. 每个多端点 net 建立连接树，可在已有树上的端点、线段内部和 via 节点分支。
   不预先锁死成互不相关的两点配对。相同实际金属几何上的点视为已互联。
3. 为全部 net 建立候选树及冲突图，整体搜索兼容的树组合。优先处理通道最受限
   的 net；尝试不同树根、接入位置和绕行通道。备选全局状态保留早先选择，后续
   net 失败时可回退；必要时针对当前其他 net 的占用重新规划候选。
4. 目标按顺序为：最多完整 net、最多端点、最低配置代价。可选择线长＋via 权重，
   或导线 Rs×L/W 与 via 单 cut 理想并联电阻之和。内层和外层使用同一套权重。所有 net 的占用
   共同决定可行性；不是逐条永久提交。底层仍调用 A* 求解树的局部支路。
5. 推荐的 `run_plan.py` 入口默认 90 秒、64 个全局状态；路由器直接入口默认
   60 秒、256 个全局状态。每 net 默认最多 3 个候选，最多 600 次支路搜索。时间预算在
   支路调用间检查，单次 A* 另外受配置 max_nodes 限制。有限候选与预算不能保证
   数学上的全局最优或有解必找到。预算耗尽时准确报告 unresolved_nets；只要有
   未完成 net，就禁止生成可被误认为完整的 layout。较多 net 可调高清单预算。

保留配置的 H/V、障碍、间距与 route_bounds。反向延长继续使用两点版本中真实
端点的同宽、同中心线 profile，仅在支路第一颗 via 前/最后一颗 via 后使用；
生成树上的普通接入点按照配置方向走线。相同 net 的金属可相交或共用树干，其他
net 的端点、路线和实际 via 均参与隔离检查。未在清单中识别归属的原有金属与
所有原有 via 按障碍处理，不假定它们属于某个 net。
树的后续分支也被限制在同一份全局障碍导出窗口内；整条导线与间距包络均须
位于窗口内，不能沿树接入点逐次扩大搜索而绕到尚未导出的区域。

## 手写 net 清单的兼容入口

`route_config.json` 默认是接手时用户 home 实际配置的逐字节副本。复杂测试的
独立配置放在 `cases/tsmc18_complex/route_config.json`，来自真实 tech.tf，按宽度/
长度表保守取最大间距。修改新版本配置不会影响旧目录。kernel 中保存经审查的
两点安全内核；SKILL helper 全部使用 mnK 命名空间且不安装 F8。

先按 `nets.example.json` 编写自己的清单。每个端点：唯一 id、实际金属层、原始
layout 坐标（工艺用户单位），应落在可辨认的直线段内部，中心线与半宽必须符合
制造网格。可选 `instance_path` 为从原始 layout 到金属所属实例的名字列表。
不指定时要求该层/坐标只有一个金属命中；指定后仍要求唯一命中。不支持 mosaic
端点路径、总线表达式自动展开；这个兼容入口使用手写清单。此入口支持普通多层
层次实例和旋转/镜像；端点 polygon/path 的限制继承安全内核。

创建专用 job 目录，例如终端运行：

```bash
mkdir -p /home/meow/autoroute/multinet/jobs/my_job
```

从 `~/` 启动 Virtuoso，打开原始 layout。在 CIW 中：

```text
load("/home/meow/autoroute/multinet/autoroute_multinet.il")
mnPlan(geGetEditCellView() "/绝对路径/my_nets.json" "/home/meow/autoroute/multinet/jobs/my_job")
```

检查 job 中 `batch_plan.report.json`，确认 status=complete 与 unresolved_nets=[]；
检查 JSON 中每个树、路径与布局范围。然后生成一个全新的输出 cell：

```text
mnBuild("你的库名" "routing_overlay_new")
```

输出库必须已经存在并使用相容的技术层映射、单位、DBU 和制造网格。已有输出
view 会被拒绝；源 layout 可以只读，输出才需要写权限。创建前重新导出源数据，
检查 config/清单/几何快照和 JSON—SKILL 方案一致性。创建后导出真实 via 的
AV/AO 各层占地，检查类型、数组、外部障碍、其他 net 规划金属及 actual 对 actual
间距；全部通过才 dbSave。失败时移除整份新输出 view，不修改原 layout。
此版本只生成配置中审查过的标准孔，未使用 Cadence 自动 via API。

在原始 layout 中手动实例化输出 layout：**原点 (0,0)、R0、倍率 1**。
输出坐标完全沿用原始 layout，不能按输出 bbox 的左下角对齐，也不能随意平移。
只含新增导线、via/pad 与 net 属性，未复制原图形或器件；放置过程由用户完成。
若原始几何或清单改变，应重新规划，不复用旧 overlay。导入后需进行自己的
连通性/DRC/LVS 检查；几何安全模型未实现完整 foundry signoff 规则，原图的无 net
数据库也不会因放入实例而自动获得完整顶层逻辑 net 关联。

## 文件和证据

- `batch_geometry.sexp`：同一次运行的真实端点及障碍，包含源 lib/cell/view、单位。
- `batch_plan.json/il`：整体方案；JSON 保存输入 SHA256 与放置变换。
- `batch_plan.report.json`：整体候选冲突、回退/备选、预算与未连通 net。
- `batch_plan.validation_report.json`：创建前完整复核及快照拒绝证据。
- `batch_actual_vias.txt`、`batch_plan.actual_report.json`：原生实际孔复核。
- `batch_engine.log`：各阶段原始 Python 输出，逐次追加。

复杂 case 有 6 个 net、20 个端点、6 层、7 个金属障碍、1 个原有 via 和一个 R90
层次端点；3/4 端点 net 交叉连接并共享通道。实例化后供用户查看的版图和测试
断言见 `cases/tsmc18_complex/TEST_RESULTS.json` 及原生 `native_release.log`。
本机结果：6/6 net、20/20 端点，23 段导线、19 颗标准 via；11 项新增 Python
测试、原 130 项回归、5 项原生集成断言通过。分层预览为 `routing_preview.svg/png`。

查看已保存版图，可从 home 启动使用隔离库定义的 GUI：

```bash
virtuoso -cdslib /home/meow/autoroute/audit/batch_cds.lib
```

打开 AR_AUDIT_20261010 库的 `multinet_overlay_mn20261011d/layout` 查看纯连线，
或 `multinet_assembly_mn20261011d/layout` 查看 source 与 overlay 按原点/R0 叠加。
用户原来的 `~/cds.lib` 未改动。

Python 回归：

```bash
python3 -m unittest discover -s /home/meow/autoroute/multinet/tests -v
```

原生重跑先备份 case 证据，准备 case，再从 `~/` 执行（换唯一 token）：

```bash
python3 /home/meow/autoroute/multinet/tests/prepare_native.py
MN_TEST_TOKEN=unique_new_token timeout -k 10s -s TERM 180s virtuoso -nocdsinit -nograph \
  -cdslib /home/meow/autoroute/audit/batch_cds.lib \
  -log /home/meow/autoroute/multinet/cases/tsmc18_complex/native_rerun.log \
  < /home/meow/autoroute/multinet/tests/native_suite.il
```

测试只在隔离库 AR_AUDIT_20261010 创建新 cell。PDK 初始化可能出现已有的 HSPICE
错误；本机 exit() 后可能驻留，测试以明确的 PASS/COMPLETE 断言和保存证据判断。
timeout 最后清理本次进程，不触碰用户原 GUI 会话。
