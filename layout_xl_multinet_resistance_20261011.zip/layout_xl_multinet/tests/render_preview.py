"""Standalone layer-by-layer plan preview for review, not image editing."""
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import batch_router as b
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon

base=Path(__file__).resolve().parents[1]/'cases/tsmc18_complex'
cfg=json.loads((base/'route_config.json').read_text())
manifest=b.read_manifest(base/'nets.json',cfg)
data=b.read_export(base/'complex/batch_geometry.sexp',manifest,cfg)
plan=json.loads((base/'complex/batch_plan.json').read_text())
fig,axes=plt.subplots(2,3,figsize=(15,10))
colors=dict(zip([n['name'] for n in plan['nets']],plt.cm.tab10.colors))
for ax,layer in zip(axes.ravel(),cfg['layers']):
    name=layer['name']
    for obs in data['obstacles']:
        if obs['layer'] not in (name,'*'):
            continue
        shape=obs['shape']
        color=colors.get(obs['owner'],'#999999')
        if isinstance(shape,b.k.Polygon):
            patch=Polygon(shape.points,facecolor=color,alpha=.35)
        else:
            box=b.k.shape_bbox(shape)
            patch=Rectangle((box[0],box[1]),box[2]-box[0],box[3]-box[1],facecolor=color,alpha=.35)
        ax.add_patch(patch)
    for net in plan['nets']:
        for item in b.candidate_items(net):
            if item['kind']=='segment' and item['layer']==name:
                ax.plot([item['x1'],item['x2']],[item['y1'],item['y2']],color=colors[net['name']],lw=1.5)
            elif item['kind']=='via' and any(p['layer']==name for p in item['pads']):
                ax.plot(item['x'],item['y'],'o',color=colors[net['name']],markersize=4)
    for tid,t in data['terminals'].items():
        if t['layer']==name:
            ax.text(*t['point'],s=tid,fontsize=7)
    ax.set_title(name+'  '+layer['direction'])
    ax.set_xlim(0,36);ax.set_ylim(0,34);ax.set_aspect('equal');ax.grid(alpha=.15)
    ax.set_xlabel('x (um)');ax.set_ylabel('y (um)')
fig.suptitle('Joint routing: 6 nets / 20 terminals / 19 native vias. Gray: obstacles.',fontsize=14)
fig.tight_layout(rect=[0,0,1,.96])
fig.savefig(str(base/'routing_preview.svg'))
fig.savefig(str(base/'routing_preview.png'),dpi=130)
print(base/'routing_preview.svg')
