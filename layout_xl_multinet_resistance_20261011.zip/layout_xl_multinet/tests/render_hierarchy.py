"""Review artifacts drawn only from actual native exports and validated plan."""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import batch_router as b
import hierarchy_io as h
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon

parser=argparse.ArgumentParser()
parser.add_argument('--job',type=Path,required=True)
parser.add_argument('--output-dir',type=Path)
args=parser.parse_args()
job=args.job
output_dir=args.output_dir or job.parent
output_dir.mkdir(parents=True,exist_ok=True)
cfg=json.loads((job/'route_config.json').read_text())
manifest=b.read_manifest(job/'nets.json',cfg)
data=b.read_export(job/'batch_geometry.sexp',manifest,cfg)
plan=json.loads((job/'batch_plan.json').read_text())
binding=json.loads((job/'binding_report.json').read_text())
colors=dict(zip([n['name'] for n in plan['nets']],plt.cm.tab10.colors))
bounds=cfg['route_bounds']

def obstacle(ax,obs,alpha=.45):
    geom=obs['shape'];color=colors.get(obs['owner'],'#777777')
    if isinstance(geom,b.k.Polygon):
        patch=Polygon(geom.points,facecolor=color,alpha=alpha)
    else:
        box=b.k.shape_bbox(geom)
        patch=Rectangle((box[0],box[1]),box[2]-box[0],box[3]-box[1],facecolor=color,alpha=alpha)
    ax.add_patch(patch)

def routes(ax,layer=None):
    for net in plan['nets']:
        for item in b.candidate_items(net):
            if item['kind']=='segment' and (layer is None or item['layer']==layer):
                ax.plot([item['x1'],item['x2']],[item['y1'],item['y2']],
                        color=colors[net['name']],lw=1.3)
            elif item['kind']=='via' and (layer is None or any(p['layer']==layer for p in item['pads'])):
                ax.plot(item['x'],item['y'],'o',color=colors[net['name']],markersize=3)

def finish(ax):
    ax.set_xlim(bounds[0],bounds[2]);ax.set_ylim(bounds[1],bounds[3])
    ax.set_aspect('equal');ax.grid(alpha=.12)
    ax.set_xlabel('x (um)');ax.set_ylabel('y (um)')

for with_routes in (False,True):
    fig,ax=plt.subplots(figsize=(13,10))
    for obs in data['obstacles']:obstacle(ax,obs)
    if with_routes:routes(ax)
    for t in binding['terminals']:
        label=t['terminal'].split('@')[0].replace('$TOP/','')
        if t['instance_path']:label=label.split('/')[-1]
        ax.text(t['point'][0]+.2,t['point'][1]+.3,label,fontsize=7,
                color=colors[t['net']])
    obs=h.obstacles(job/'obstacles.sexp')
    for physical,logical,*rest in binding['instances']:
        boxes=[b.k.shape_bbox(b.shape_from_record(geom)) for layer,geom,key in obs['obstacles']
               if json.loads(key)[0]==[physical]]
        x0=min(r[0] for r in boxes)-.5;y0=min(r[1] for r in boxes)-.5
        x1=max(r[2] for r in boxes)+.5;y1=max(r[3] for r in boxes)+.5
        ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fill=False,ls='--',lw=.8,color='#333333'))
        ax.text((x0+x1)/2,y1+1,logical+'\n'+physical,fontsize=8,ha='center')
    finish(ax)
    title='Routing assembly' if with_routes else 'Source layout: pins and obstacles, no interconnect'
    ax.set_title(title+'\n4 bound modules / 4 external pins / 5 nets / 20 endpoints',fontsize=12)
    for name,color in colors.items():ax.plot([],[],color=color,label=name)
    ax.legend(loc='lower center',ncol=5,bbox_to_anchor=(.5,-.15),frameon=False)
    fig.tight_layout()
    stem='assembly_preview' if with_routes else 'source_preview'
    fig.savefig(str(output_dir/(stem+'.svg')))
    fig.savefig(str(output_dir/(stem+'.png')),dpi=140)
    plt.close(fig)

fig,axes=plt.subplots(2,3,figsize=(16,10))
for ax,layer in zip(axes.ravel(),cfg['layers']):
    name=layer['name']
    for obs in data['obstacles']:
        if obs['layer'] in (name,'*'):obstacle(ax,obs)
    routes(ax,name)
    for terminal in data['terminals'].values():
        if terminal['layer']==name:
            label=terminal['id'].split('@')[0].split('/')[-1]
            ax.text(*terminal['point'],s=label,fontsize=6)
    finish(ax);ax.set_title(name+' '+layer['direction'])
fig.suptitle('Native export + global plan; dots are via locations. Gray shapes are obstacles.')
fig.tight_layout(rect=[0,0,1,.96])
fig.savefig(str(output_dir/'routing_layers.svg'))
fig.savefig(str(output_dir/'routing_layers.png'),dpi=140)
print(output_dir/'assembly_preview.png')
