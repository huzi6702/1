import copy
import json
import math
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import batch_router as b
import prepare_resistance_config as prepare
import hierarchy_io as h
from routing_cost import RoutingCost
from test_hierarchy_io import captures

ROOT = Path(__file__).resolve().parents[1]
BASE = json.loads((ROOT/'cases/hierarchy_xl/route_config.json').read_text())
MODEL = json.loads((ROOT/'resistance.example.json').read_text())


def config(layers=('METAL1', 'METAL2', 'METAL3')):
    cfg = copy.deepcopy(BASE)
    cfg['layers'] = [l for l in cfg['layers'] if l['name'] in layers]
    cfg['vias'] = [v for v in cfg['vias'] if v['lower'] in layers and v['upper'] in layers]
    cfg.update(route_bounds=[0, 0, 24, 12], margin=4, max_nodes=20000)
    cfg['cost_model'] = copy.deepcopy(MODEL)
    cfg['cost_model']['sheet_resistance_ohm_per_square'] = {
        l['name']: MODEL['sheet_resistance_ohm_per_square'][l['name']] for l in cfg['layers']}
    cfg['cost_model']['via_resistance_ohm_per_cut'] = {
        v['name']: MODEL['via_resistance_ohm_per_cut'][v['name']] for v in cfg['vias']}
    return cfg


def segment(layer='METAL2', width=.28, length=10):
    return dict(kind='segment', layer=layer, width=width, x1=2, y1=4, x2=2, y2=4+length)


class ResistanceTests(unittest.TestCase):
    def test_formula_actual_width_and_ideal_parallel_cuts(self):
        cfg = config()
        items = [segment(), dict(kind='via', name='M3_M2', rows=2, cols=2)]
        detail = RoutingCost(cfg).breakdown(items)
        self.assertAlmostEqual(detail['wire_resistance_ohm'], .08*10/.28)
        self.assertAlmostEqual(detail['via_resistance_ohm'], .8/4)
        self.assertAlmostEqual(b.branch_cost(items, cfg), .08*10/.28+.2)
        self.assertAlmostEqual(b.branch_cost([segment(width=.56)], cfg), .08*10/.56)
        self.assertEqual(detail['cost_unit'], 'ohm')

    def test_missing_typo_and_invalid_values_are_rejected(self):
        for field in ('sheet_resistance_ohm_per_square', 'via_resistance_ohm_per_cut'):
            cfg = config()
            name = next(iter(cfg['cost_model'][field]))
            del cfg['cost_model'][field][name]
            with self.assertRaisesRegex(ValueError, 'missing'):
                b.validate_config(cfg)
            cfg = config()
            cfg['cost_model'][field]['TYPO'] = 1.0
            with self.assertRaisesRegex(ValueError, 'unknown'):
                b.validate_config(cfg)
            for value in (0, -1, True, math.inf, math.nan, '0.1'):
                cfg = config()
                cfg['cost_model'][field][name] = value
                with self.assertRaisesRegex(ValueError, 'positive resistance'):
                    b.validate_config(cfg)

    def test_endpoint_profiles_use_physical_names_and_actual_widths(self):
        cfg = config(('METAL2', 'METAL3'))
        geo = b.k.Geometry(('METAL2', 2, 4), ('METAL3', 18, 4), {}, [],
                          {'A': ('METAL2', (1.72, 3, 2.28, 5)),
                           'B': ('METAL3', (17, 3.86, 19, 4.14))})
        effective, prepared, _ = b.k.prepare_route(cfg, geo)
        b.validate_config(effective)
        costs = RoutingCost(effective)
        source = prepared[0][0]
        self.assertAlmostEqual(costs.segment_rate(source, .56), .08/.56)
        for via in effective['vias']:
            original = effective['_physical_vias'][via['name']]
            self.assertEqual(costs.via(via['name'], 1, 2),
                             cfg['cost_model']['via_resistance_ohm_per_cut'][original]/2)

    def two_vias(self):
        cfg = config(('METAL2', 'METAL3'))
        via = copy.deepcopy(cfg['vias'][0])
        via['name'] = 'CHEAP'
        cfg['vias'].append(via)
        cfg['cost_model']['via_resistance_ohm_per_cut'] = {'M3_M2': .8, 'CHEAP': .05}
        return cfg

    def test_same_layer_pair_chooses_cheapest_legal_via(self):
        cfg = self.two_vias()
        geo = b.k.Geometry(('METAL2', 10, 6), ('METAL3', 10, 6), {}, [])
        items = b.k.route(cfg, geo, search_mode='detailed')
        b.k.validate(items, cfg, geo)
        self.assertEqual([i['name'] for i in items if i['kind'] == 'via'], ['CHEAP'])

    def test_blocked_cheapest_via_retains_more_expensive_candidate(self):
        cfg = self.two_vias()
        cfg['route_bounds'] = [9.7, 5.7, 10.3, 6.3]
        cfg['vias'][1].update(enc_lower=[1, 1], enc_upper=[1, 1])
        geo = b.k.Geometry(('METAL2', 10, 6), ('METAL3', 10, 6), {}, [])
        items = b.k.route(cfg, geo, search_mode='detailed')
        b.k.validate(items, cfg, geo)
        self.assertEqual([i['name'] for i in items if i['kind'] == 'via'], ['M3_M2'])

    def low_resistance_upper_layer(self):
        cfg = config()
        cfg['cost_model']['sheet_resistance_ohm_per_square'].update(METAL1=1, METAL2=.001, METAL3=.001)
        cfg['cost_model']['via_resistance_ohm_per_cut'] = {'M2_M1': .01, 'M3_M2': .01}
        return cfg

    def test_inner_astar_uses_resistance_instead_of_short_wire_and_few_vias(self):
        cfg = self.low_resistance_upper_layer()
        geo = b.k.Geometry(('METAL1', 2, 4), ('METAL1', 20, 4), {}, [])
        items = b.k.route(cfg, geo, search_mode='detailed')
        b.k.validate(items, cfg, geo)
        self.assertTrue(any(i['kind'] == 'segment' and i['layer'] == 'METAL3' for i in items))
        self.assertLess(b.branch_cost(items, cfg), 1.0)
        legacy = copy.deepcopy(cfg)
        del legacy['cost_model']
        old = b.k.route(legacy, geo, search_mode='detailed')
        self.assertFalse(any(i['kind'] == 'via' for i in old))

    def test_direct_endpoint_shortcut_does_not_hide_lower_resistance_route(self):
        cfg = self.low_resistance_upper_layer()
        for layer in cfg['layers']:
            layer['width'] = .28
        geo = b.k.Geometry(('METAL1', 2, 4), ('METAL1', 20, 4), {}, [],
                          {'A': ('METAL1', (1, 3.86, 3, 4.14)),
                           'B': ('METAL1', (19, 3.86, 21, 4.14))})
        items = b.k.route(cfg, geo)
        b.k.validate(items, cfg, geo)
        self.assertTrue(any(i['kind'] == 'via' for i in items))
        self.assertLess(b.branch_cost(items, cfg), 18/.28)

    def test_direct_feasible_route_is_kept_when_search_budget_fails(self):
        cfg = config(('METAL2', 'METAL3'))
        cfg['max_nodes'] = 1
        geo = b.k.Geometry(('METAL3', 2, 4), ('METAL3', 20, 4), {}, [],
                          {'A': ('METAL3', (1, 3.86, 3, 4.14)),
                           'B': ('METAL3', (19, 3.86, 21, 4.14))})
        items = b.k.route(cfg, geo)
        b.k.validate(items, cfg, geo)
        self.assertTrue(items[0]['endpoint_direct'])

    def test_custom_legacy_via_weight_is_used_by_inner_search(self):
        cfg = config(('METAL2', 'METAL3'))
        del cfg['cost_model']
        cfg['via_cost'] = .25
        self.assertEqual(RoutingCost(cfg).via('M3_M2', 1, 1), .25)
        stats = {}
        geo = b.k.Geometry(('METAL2', 10, 6), ('METAL3', 10, 6), {}, [])
        self.assertAlmostEqual(b.branch_cost(b.k.route(cfg, geo, stats), cfg), .25)

    def test_config_preparation_preserves_inputs_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source, model, output = [root/n for n in ('actual.json', 'resistance.json', 'new.json')]
            source.write_text(json.dumps(BASE))
            model.write_text(json.dumps(MODEL))
            before = source.read_bytes()
            prepare.prepare(source, model, output)
            self.assertEqual(source.read_bytes(), before)
            self.assertEqual(json.loads(output.read_text())['cost_model'], MODEL)
            with self.assertRaisesRegex(ValueError, 'differ'):
                prepare.prepare(source, model, source)
            with self.assertRaisesRegex(ValueError, 'already exists'):
                prepare.prepare(source, model, output)

    def test_global_selection_prefers_lower_resistance_longer_candidate(self):
        cfg = config()
        cfg['cost_model']['sheet_resistance_ohm_per_square']['METAL3'] = .001
        manifest = dict(nets=[dict(name='N', terminals=[dict(id='a'), dict(id='b')])],
                        options=dict(b.DEFAULTS, max_states=8))
        choices = []
        for layer, length in [('METAL2', 10), ('METAL3', 30)]:
            items = [segment(layer=layer, length=length)]
            choices.append(dict(name='N', root='a', terminals=['a', 'b'],
                                branches=[dict(items=items)], cost=b.branch_cost(items, cfg)))
        with patch.object(b.Planner, 'candidates', return_value=choices):
            chosen, report = b.Planner(cfg, manifest, dict(window=(-10, -10, 50, 50))).solve()
        self.assertEqual(chosen['N']['branches'][0]['items'][0]['layer'], 'METAL3')
        self.assertEqual(report['cost_unit'], 'ohm')
        self.assertAlmostEqual(report['total_cost'], .001*30/.28)

    def test_resistance_capture_cli_report_and_snapshot_without_cadence(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            model_path = folder/'model.json'
            model_path.write_text(json.dumps(MODEL))
            new_config = folder/'new_config.json'
            prepare.prepare(ROOT/'cases/hierarchy_xl/route_config.json', model_path, new_config)
            job = folder/'job'
            h.prepare_config(new_config, job)
            captures(job)
            h.write_inputs(job)
            h.stamp_ready(job)
            tools = folder/'bin'
            tools.mkdir()
            (tools/'python3').symlink_to(sys.executable)
            sentinel = folder/'cadence_started'
            for name in ('virtuoso', 'Xvfb'):
                command = tools/name
                command.write_text('#!/bin/sh\n: > "{}"\nexit 99\n'.format(sentinel))
                command.chmod(0o755)
            env = dict(os.environ, PATH=str(tools))
            env.pop('DISPLAY', None)
            result = subprocess.run([sys.executable, str(ROOT/'run_plan.py'), '--job', str(job),
                                     '--max-states', '8'], env=env, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, universal_newlines=True)
            self.assertEqual(result.returncode, 0, result.stdout)
            self.assertFalse(sentinel.exists())
            plan = json.loads((job/'batch_plan.json').read_text())
            report = json.loads((job/'batch_plan.report.json').read_text())
            self.assertTrue(plan['cost_model']['assumed'])
            self.assertEqual(report['cost_unit'], 'ohm')
            self.assertAlmostEqual(report['cost_breakdown']['estimated_resistance_ohm'],
                                   report['total_cost'])
            actual = json.loads((job/'route_config.json').read_text())
            actual['cost_model']['sheet_resistance_ohm_per_square']['METAL2'] *= 2
            (job/'route_config.json').write_text(json.dumps(actual))
            with self.assertRaisesRegex(ValueError, 'Captured inputs changed'):
                h.claim_build(job)


if __name__ == '__main__':
    unittest.main()
