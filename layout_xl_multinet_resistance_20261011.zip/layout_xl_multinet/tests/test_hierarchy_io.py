import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import hierarchy_io as h
import batch_router as b


def captures(directory):
    source=['source','L','top','layout','micron',1000,.005]
    a=['rect',1.86,3,2.14,5]
    c=['rect',17,3.86,19,4.14]
    ka=[['PHYSICAL'], 'METAL2','pin','rect',a]
    kc=[[], 'METAL3','pin','rect',c]
    obs=['HOBS1',source,['window',-10,-10,50,50],
         ['obstacles',['METAL2',a,ka],['METAL3',c,kc],
          ['METAL3',['rect',7,7,9,8],[['PHYSICAL'],'METAL3','drawing','rect',['rect',7,7,9,8]]]]]
    con=['HCON1',source,['schematic','L','top','schematic'],
         ['bindings',['PHYSICAL','LOGICAL','L','leaf',[[2,4],'R0',1],'L','leaf']],
         ['terminals',['NET','PHYSICAL/INPUT','METAL2',2,4,a,ka,['LOGICAL','INPUT','NET']],
          ['NET','$TOP/EXTERNAL','METAL3',18,4,c,kc,['$TOP','EXTERNAL','NET']]]]
    def save():
        (directory/'obstacles.sexp').write_text(h.sexp_literal(obs)+'\n')
        (directory/'connections.sexp').write_text(h.sexp_literal(con)+'\n')
    save()
    return obs,con,save


class HierarchyExportTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.job=Path(self.tmp.name)
        cfg=Path(__file__).resolve().parents[1]/'cases/hierarchy_xl/route_config.json'
        h.prepare_config(cfg,self.job)
        self.obs,self.con,self.save=captures(self.job)

    def tearDown(self):
        self.tmp.cleanup()

    def test_top_external_and_different_module_pin_names_group_by_source_net(self):
        result=h.write_inputs(self.job)
        manifest=json.loads((self.job/'nets.json').read_text())
        self.assertEqual(result['net_count'],1)
        self.assertEqual(result['terminal_count'],2)
        self.assertEqual(manifest['nets'][0]['name'],'NET')
        self.assertEqual(result['instances'][0][:2],['PHYSICAL','LOGICAL'])
        owned=b.read_export(self.job/'batch_geometry.sexp',manifest,json.loads((self.job/'route_config.json').read_text()))['obstacles']
        self.assertEqual(sorted(x['owner'] for x in owned),['','NET','NET'])

    def test_native_iteration_order_does_not_change_snapshot(self):
        h.write_inputs(self.job)
        self.obs[-1][1:]=reversed(self.obs[-1][1:])
        self.con[-1][1:]=reversed(self.con[-1][1:])
        self.save()
        h.write_inputs(self.job,compare=True)

    def test_unselected_instance_wire_is_never_owned(self):
        h.write_inputs(self.job)
        geom=(self.job/'batch_geometry.sexp').read_text()
        parsed=b.parse(geom)[0][-1][1:]
        anonymous=[r for r in parsed if r[1]=='']
        self.assertEqual(len(anonymous),1)
        self.assertEqual(anonymous[0][2][1:],['7','7','9','8'])

    def test_duplicate_conductor_across_nets_refused(self):
        other=copy.deepcopy(self.con[-1][1])
        other[0]='OTHER';other[1]='OTHER/PIN'
        self.con[-1].append(other)
        self.save()
        with self.assertRaisesRegex(ValueError,'different schematic nets'):
            h.write_inputs(self.job)

    def test_schematic_change_without_geometry_change_refused(self):
        h.write_inputs(self.job)
        self.con[-1][1][-1][0]='RENAMED_LOGICAL'
        self.save()
        with self.assertRaisesRegex(ValueError,'binding changed'):
            h.write_inputs(self.job,compare=True)

    def test_moved_obstacle_refused_without_rewriting_original_capture(self):
        h.write_inputs(self.job)
        before=(self.job/'batch_geometry.sexp').read_bytes()
        self.obs[-1][-1][1][1]=6.5
        self.save()
        with self.assertRaisesRegex(ValueError,'changed'):
            h.write_inputs(self.job,compare=True)
        self.assertEqual(before,(self.job/'batch_geometry.sexp').read_bytes())

    def test_singleton_pin_net_remains_hard_obstacle(self):
        singleton=copy.deepcopy(self.con[-1][1])
        singleton[0]='SINGLE';singleton[1]='single';singleton[3:5]=[30,4]
        singleton[5]=['rect',29.86,3,30.14,5]
        singleton[6]=[['SPARE'],'METAL2','pin','rect',singleton[5]]
        self.obs[-1].append(['METAL2',singleton[5],singleton[6]])
        self.con[-1].append(singleton)
        self.save()
        result=h.write_inputs(self.job)
        self.assertEqual(result['skipped_single_terminal_nets'],['SINGLE'])
        parsed=b.parse((self.job/'batch_geometry.sexp').read_text())[0][-1][1:]
        self.assertEqual(len([r for r in parsed if r[1]=='']),2)

    def test_config_copy_namespace_and_offgrid_rejection(self):
        self.assertIn('mnKLayers',(self.job/'batch_plan.config.il').read_text())
        self.con[-1][1][3]=2.001
        self.save()
        with self.assertRaisesRegex(ValueError,'grid'):
            h.write_inputs(self.job)

    def test_planner_options_survive_source_refresh(self):
        opts=dict(b.DEFAULTS,max_states=12)
        (self.job/'planner_options.json').write_text(json.dumps(opts))
        h.write_inputs(self.job)
        self.assertEqual(json.loads((self.job/'nets.json').read_text())['options'],opts)
        h.write_inputs(self.job,compare=True)

    def test_config_change_requires_obstacle_recapture(self):
        cfg=json.loads((self.job/'route_config.json').read_text())
        cfg['extra_clearance']+=.1
        (self.job/'route_config.json').write_text(json.dumps(cfg))
        with self.assertRaisesRegex(ValueError,'Config changed since obstacle'):
            h.write_inputs(self.job)

    def test_export_order_and_raw_capture_integrity(self):
        with self.assertRaisesRegex(ValueError,'obstacle export followed'):
            h.verify_ready(self.job)
        h.write_inputs(self.job)
        h.stamp_ready(self.job)
        h.verify_ready(self.job)
        self.con[-1][1][-1][0]='DIFFERENT_SOURCE'
        self.save()
        with self.assertRaisesRegex(ValueError,'Captured inputs changed'):
            h.verify_ready(self.job)


if __name__=='__main__':
    unittest.main()
