import fcntl
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import hierarchy_io as h
import run_plan as p
from test_hierarchy_io import captures


class SplitFlowTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.job = Path(self.tmp.name)
        self.root = Path(__file__).resolve().parents[1]
        h.prepare_config(self.root/'cases/hierarchy_xl/route_config.json',self.job)
        self.obs,self.con,self.save = captures(self.job)
        h.write_inputs(self.job)
        h.stamp_ready(self.job)

    def tearDown(self):
        self.tmp.cleanup()

    def solve(self):
        self.assertEqual(p.main(['--job',str(self.job),'--max-states','8','--max-seconds','10']),0)

    def test_cli_works_without_display_and_never_invokes_cadence(self):
        tools_dir = self.job/'bin'
        tools_dir.mkdir()
        (tools_dir/'python3').symlink_to(sys.executable)
        sentinel = self.job/'cadence_was_started'
        for name in ('virtuoso','Xvfb'):
            target = tools_dir/name
            target.write_text('#!/bin/sh\n: > "{}"\nexit 99\n'.format(sentinel))
            target.chmod(0o755)
        env = dict(os.environ,PATH=str(tools_dir))
        env.pop('DISPLAY',None)
        frozen = {name:(self.job/name).read_bytes() for name in
                  ('route_config.json','obstacles.sexp','connections.sexp','export_ready.json')}
        result = subprocess.run([sys.executable,str(self.root/'run_plan.py'),'--job',str(self.job),
                                 '--max-states','8'],env=env,stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT,universal_newlines=True)
        self.assertEqual(result.returncode,0,result.stdout)
        self.assertFalse(sentinel.exists())
        self.assertFalse((self.job/'offline_native.log').exists())
        report = json.loads((self.job/'plan_result.json').read_text())
        self.assertEqual(report['status'],'planned')
        self.assertFalse(report['native_created'])
        self.assertEqual(json.loads((self.job/'batch_plan.json').read_text())['status'],'complete')
        for name,value in frozen.items():
            self.assertEqual((self.job/name).read_bytes(),value)

    def test_ciw_build_reservation_blocks_new_planning_and_second_builder(self):
        self.solve()
        before = (self.job/'plan_result.json').read_bytes()
        state = h.claim_build(self.job)
        with self.assertRaisesRegex(ValueError,'CIW build'):
            h.claim_build(self.job)
        self.assertEqual(p.main(['--job',str(self.job)]),2)
        self.assertEqual((self.job/'plan_result.json').read_bytes(),before)
        h.finish_build(self.job,state['lease'],'failed',dict(lib='L',cell='new',view='layout'))
        self.assertFalse((self.job/'.ciw_build.lock').exists())

    def test_modified_skill_plan_cannot_be_claimed(self):
        self.solve()
        (self.job/'batch_plan.il').write_text('mnPlanStatus = "complete"\nmnPlanNets = nil\n')
        with self.assertRaisesRegex(ValueError,'SKILL plan differs'):
            h.claim_build(self.job)
        self.assertFalse((self.job/'.ciw_build.lock').exists())

    def test_changed_capture_cannot_be_claimed(self):
        self.solve()
        self.con[-1][1][0] = 'OTHER_NET'
        self.save()
        with self.assertRaisesRegex(ValueError,'Captured inputs changed'):
            h.claim_build(self.job)
        self.assertFalse((self.job/'.ciw_build.lock').exists())

    def test_failed_new_run_invalidates_previous_buildable_payload(self):
        self.solve()
        self.assertEqual(p.main(['--job',str(self.job),'--max-states','0']),2)
        self.assertEqual(json.loads((self.job/'plan_result.json').read_text())['status'],'failed')
        with self.assertRaisesRegex(ValueError,'SKILL plan differs'):
            h.claim_build(self.job)

    def test_wrong_lease_cannot_release_active_builder(self):
        self.solve()
        state = h.claim_build(self.job)
        with self.assertRaisesRegex(ValueError,'lease differs'):
            h.finish_build(self.job,'wrong','failed',dict(lib='L',cell='new',view='layout'))
        self.assertTrue((self.job/'.ciw_build.lock').exists())
        h.finish_build(self.job,state['lease'],'failed',dict(lib='L',cell='new',view='layout'))
        report = json.loads((self.job/'ciw_build_result.json').read_text())
        self.assertEqual(report['status'],'failed')
        self.assertEqual(report['source']['cell'],'top')

    def test_terminal_lock_refuses_claim_and_preserves_result(self):
        self.solve()
        before = (self.job/'plan_result.json').read_bytes()
        with (self.job/'.offline.lock').open('a') as lock:
            fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            with self.assertRaisesRegex(ValueError,'terminal run'):
                h.claim_build(self.job)
            self.assertEqual(p.main(['--job',str(self.job)]),2)
        self.assertEqual((self.job/'plan_result.json').read_bytes(),before)
        self.assertFalse((self.job/'.ciw_build.lock').exists())


if __name__ == '__main__':
    unittest.main()
