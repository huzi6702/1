"""Build netless test manifests; all widths/vias come from supplied TSMC tech."""
import copy
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'cases' / 'tsmc18_complex'
BASE.mkdir(parents=True, exist_ok=True)
cfg = json.loads((ROOT.parents[0] / 'cases/tsmc18_rebuilt/route_config.json').read_text())
cfg.update(via_mode='standard', route_bounds=[0,0,36,34], margin=8, max_nodes=100000)
cfg.pop('_extract_report', None)
(BASE / 'route_config.json').write_text(json.dumps(cfg,indent=2)+'\n')
for name in ('batch_router.py', 'kernel'):
    path = BASE / name
    if not path.exists():
        path.symlink_to(ROOT / name, target_is_directory=name=='kernel')
points = {
 'A': [('METAL2',2,4), ('METAL3',30,4), ('METAL2',16,26)],
 'B': [('METAL2',4,24), ('METAL3',28,24), ('METAL2',26,6), ('METAL3',6,12)],
 'C': [('METAL3',2,18), ('METAL2',30,10), ('METAL3',14,2)],
 'D': [('METAL2',10,3), ('METAL3',24,28), ('METAL2',32,18)],
 'E': [('METAL3',8,28), ('METAL2',22,2), ('METAL3',32,12)],
 'F': [('METAL2',2,30), ('METAL3',34,30), ('METAL2',34,2), ('METAL3',20,16)]}
nets = []
for name, rows in points.items():
    terminals=[]
    for i, (layer,x,y) in enumerate(rows):
        t=dict(id=name+str(i),layer=layer,point=[x,y])
        if t['id']=='A0':
            t['instance_path']=['ROTATED_PIN']
        terminals.append(t)
    nets.append(dict(name=name,terminals=terminals))
manifest=dict(schema='virtuoso-multinet-1',nets=nets,
              options=dict(max_seconds=90,max_states=64,max_route_calls=600,
                           candidates_per_net=3,max_access_points=6))
(BASE/'nets.json').write_text(json.dumps(manifest,indent=2)+'\n')
for case in ('complex','stale','rollback','incomplete'):
    (BASE/case).mkdir(exist_ok=True)
print('Prepared 6 nets, 20 terminals, real-tech config, crossing/obstacle/rotated hierarchy fixture.')
