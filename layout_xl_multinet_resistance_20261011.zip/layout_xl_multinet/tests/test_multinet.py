import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import batch_router as b

CFG=json.loads((Path(__file__).resolve().parents[1]/'cases/hierarchy_xl/route_config.json').read_text())
CFG.update(route_bounds=[0,0,40,40],margin=10,max_nodes=10000)


def fixture():
    nets=[dict(name='N',terminals=[dict(id='p0',layer='METAL2',point=[2,4]),
          dict(id='p1',layer='METAL3',point=[18,4]),dict(id='p2',layer='METAL2',point=[10,14])])]
    manifest=dict(schema='virtuoso-multinet-1',nets=nets,options=dict(b.DEFAULTS,max_states=16,max_route_calls=60))
    shapes={'p0':(1.86,3,2.14,5),'p1':(17,3.86,19,4.14),'p2':(9.86,13,10.14,15)}
    terminals={t['id']:dict(t,net='N',shape=shapes[t['id']],record=['rect',*shapes[t['id']]]) for t in nets[0]['terminals']}
    data=dict(terminals=terminals,obstacles=[dict(layer=t['layer'],owner='N',shape=shapes[t['id']]) for t in nets[0]['terminals']],
              source=['L','C','layout','micron',1000,.005],window=(-10,-10,50,50),export_path='fixture')
    return manifest,data


class MultiNetTests(unittest.TestCase):
    def test_three_terminal_tree_and_branch_tap(self):
        manifest,data=fixture()
        tree=b.Planner(CFG,manifest,data).tree(manifest['nets'][0],{})
        self.assertEqual(len(tree['branches']),2)
        plan=dict(schema='virtuoso-multinet-plan-1',status='complete',nets=[tree])
        b.validate_plan(plan,CFG,manifest,data)
        self.assertTrue(any('id' not in x['target'] for x in tree['branches']))
        tree['branches'][-1]['target']=dict(layer='METAL3',point=[39,39])
        with self.assertRaisesRegex(ValueError,'anchor'):
            b.validate_plan(plan,CFG,manifest,data)

    def test_other_net_and_unknown_metal_are_not_exempt(self):
        manifest,data=fixture()
        data['obstacles'].append(dict(layer='METAL2',owner='other',shape=(1.8,3.5,2.2,4.5)))
        self.assertIsNone(b.Planner(CFG,manifest,data).tree(manifest['nets'][0],{}))
        data['obstacles'][-1]['owner']=''
        self.assertIsNone(b.Planner(CFG,manifest,data).tree(manifest['nets'][0],{}))

    def test_global_backtracking_succeeds_where_first_choice_blocks_net(self):
        manifest,data=fixture()
        manifest['nets']=[dict(name='A',terminals=[dict(id='a'),dict(id='b')]),
                          dict(name='B',terminals=[dict(id='c'),dict(id='d')])]
        def candidate(name,y,cost):
            item=dict(kind='segment',layer='METAL3',width=.28,x1=2,y1=y,x2=18,y2=y)
            return dict(name=name,root='unused',terminals=['a','b'],branches=[dict(items=[item])],cost=cost)
        pools={'A':[candidate('A',4,1),candidate('A',8,4)],
               'B':[candidate('B',4,1),candidate('B',4,2)]}
        self.assertTrue(b.conflicts(pools['A'][0],pools['B'][0],CFG))
        def choices(self,net,assignments):
            return [] if assignments else pools[net['name']]
        with patch.object(b.Planner,'candidates',choices):
            assignments,report=b.Planner(CFG,manifest,data).solve()
        self.assertEqual(set(assignments),{'A','B'})
        self.assertEqual(assignments['A']['cost'],4)
        self.assertGreater(report['global_states'],2)
        self.assertGreater(report['candidate_conflicts'],0)

    def test_incomplete_plan_cannot_be_built(self):
        manifest,data=fixture()
        with self.assertRaisesRegex(ValueError,'Incomplete'):
            b.validate_plan(dict(schema='virtuoso-multinet-plan-1',status='incomplete',nets=[]),CFG,manifest,data)

    def test_duplicate_terminal_and_offgrid_manifest_rejected(self):
        manifest,_=fixture()
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'nets.json'
            manifest['nets'][0]['terminals'][1]['id']='p0'
            path.write_text(json.dumps(manifest))
            with self.assertRaisesRegex(ValueError,'unique'):
                b.read_manifest(path,CFG)
            manifest['nets'][0]['terminals'][1]['id']='p1'
            manifest['nets'][0]['terminals'][1]['point'][0]=18.001
            path.write_text(json.dumps(manifest))
            with self.assertRaisesRegex(ValueError,'grid'):
                b.read_manifest(path,CFG)

    def test_true_endpoint_profile_constraints_retained(self):
        manifest,data=fixture()
        # Source H on configured V: only same width/centerline before first via.
        t=data['terminals']['p0'];t['shape']=(1,3.86,4,4.14);t['record']=['rect',*t['shape']]
        data['obstacles'][0]['shape']=t['shape']
        tree=b.Planner(CFG,manifest,data).tree(manifest['nets'][0],{},1)
        plan=dict(schema='virtuoso-multinet-plan-1',status='complete',nets=[tree])
        b.validate_plan(plan,CFG,manifest,data)
        for branch in tree['branches']:
            for item in branch['items']:
                if item['kind']=='segment' and item['layer']=='METAL2' and item['y1']==item['y2']:
                    self.assertEqual(item['width'],.28)
                    self.assertAlmostEqual(item['y1'],4)
                    self.assertIn('routing_profile',item)

    def test_plan_item_spacing_between_nets(self):
        a=dict(branches=[dict(items=[dict(kind='segment',layer='METAL3',width=.28,x1=1,y1=4,x2=20,y2=4)])])
        c=copy.deepcopy(a); c['branches'][0]['items'][0].update(y1=4.5,y2=4.5)
        self.assertTrue(b.conflicts(a,c,CFG))
        c['branches'][0]['items'][0].update(y1=6,y2=6)
        self.assertFalse(b.conflicts(a,c,CFG))

    def test_same_actual_conductor_needs_no_redundant_branch(self):
        manifest,data=fixture()
        manifest['nets'][0]['terminals'][2]=dict(id='p2',layer='METAL2',point=[2,4.5])
        data['terminals']['p2']=dict(data['terminals']['p0'],id='p2',point=[2,4.5])
        tree=b.Planner(CFG,manifest,data).tree(manifest['nets'][0],{})
        self.assertEqual(len(tree['branches']),1)
        b.validate_plan(dict(schema='virtuoso-multinet-plan-1',status='complete',nets=[tree]),CFG,manifest,data)

    def test_shared_branch_via_created_only_once(self):
        via=dict(kind='via',name='M3_M2',x=2,y=4,rows=1,cols=1,pads=[])
        tree=dict(name='N',branches=[dict(items=[via]),dict(items=[copy.deepcopy(via)])])
        self.assertEqual(len(b.native_items(dict(nets=[tree]))),1)

    def test_hard_bounds_can_leave_a_net_unresolved(self):
        manifest,data=fixture()
        cfg=copy.deepcopy(CFG)
        cfg['route_bounds']=[1.85,0,40,40]
        planner=b.Planner(cfg,manifest,data)
        assignments,report=planner.solve()
        self.assertFalse(assignments)
        self.assertEqual(report['unresolved_nets'],['N'])

    def test_tree_search_cannot_expand_past_exported_global_window(self):
        manifest,data=fixture()
        cfg=copy.deepcopy(CFG);cfg['route_bounds']=None
        scoped=b.planning_config(cfg,data)
        self.assertGreater(scoped['route_bounds'][0],data['window'][0])
        tree=b.Planner(cfg,manifest,data).tree(manifest['nets'][0],{})
        b.validate_plan(dict(schema='virtuoso-multinet-plan-1',status='complete',nets=[tree]),cfg,manifest,data)
        data['window']=(1.9,0,40,40)
        with self.assertRaisesRegex(ValueError,'window'):
            b.validate_plan(dict(schema='virtuoso-multinet-plan-1',status='complete',nets=[tree]),cfg,manifest,data)


if __name__=='__main__':
    unittest.main()
