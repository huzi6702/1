#!/usr/bin/env python3
"""Terminal entry: joint solve, then native reviewed independent route layout."""
from __future__ import annotations
import argparse
import json
import fcntl
from pathlib import Path
import batch_router as b
from run_plan import plan_routes
from job_state import require_no_ciw_build
from native_runner import run_native


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', type=Path, required=True)
    parser.add_argument('--cdslib', type=Path, required=True)
    parser.add_argument('--output-lib', required=True)
    parser.add_argument('--output-cell', required=True)
    parser.add_argument('--output-view', default='layout')
    parser.add_argument('--xvfb', type=Path, help='Optional Xvfb executable for an isolated virtual display')
    parser.add_argument('--native-timeout', type=float, default=180)
    parser.add_argument('--max-seconds', type=float, default=90)
    parser.add_argument('--max-states', type=int, default=64)
    args = parser.parse_args()
    job = args.job.resolve()
    root = Path(__file__).resolve().parent
    report_file = job/'offline_result.json'
    report = dict(status='failed')
    lock = None
    locked = False
    try:
        if not job.is_dir():
            raise ValueError('Job directory does not exist')
        lock = (job/'.offline.lock').open('a')
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError('Another offline run is using this job directory')
        require_no_ciw_build(job)
        locked = True
        if not args.cdslib.is_file():
            raise ValueError('cds.lib not found')
        if args.xvfb and not args.xvfb.is_file():
            raise ValueError('Xvfb executable not found')
        if args.native_timeout <= 0 or args.max_seconds <= 0 or args.max_states <= 0:
            raise ValueError('Time/state limits must be positive')
        extracted = plan_routes(job, root, args.max_seconds, args.max_states)
        manifest_path = job/'nets.json'
        manifest = json.loads(manifest_path.read_text())
        source = [manifest['source'][x] for x in ('lib','cell','view')]
        q = b.k.skill_literal
        script = job/'offline_build.il'
        content = '\n'.join([
            'mnBaseDir = '+q(str(root)),
            'load(strcat(mnBaseDir "/autoroute_multinet.il"))',
            'load(strcat(mnBaseDir "/hierarchy/auto_export.il"))',
            'procedure(mnOfflineMain()',
            ' let((win cv)',
            '  win = deOpen(list(nil \'libName '+q(source[0])+' \'cellName '+q(source[1])+' \'viewName '+q(source[2])+') nil "r" "Virtuoso XL")',
            '  unless(win error("Cannot initialize read-only XL source.\\n"))',
            '  cv = geGetWindowCellView(win)',
            '  mnSourceCv = cv',
            '  mnJobDir = '+q(str(job)),
            '  mnManifest = '+q(str(manifest_path)),
            '  mnConfigFile = '+q(str(job/'route_config.json')),
            '  mnAutoJob = mnJobDir',
            '  load(strcat(mnJobDir "/batch_plan.config.il"))',
            '  mnKEffectiveQueryHalo = mnKObstacleQueryHalo',
            '  mnBuild('+q(args.output_lib)+' '+q(args.output_cell)+' '+q(args.output_view)+')',
            '  hiCloseWindow(win)',
            '  when(dbIsId(cv) dbPurge(cv))',
            '  foreach(openCv dbGetOpenCellViews()',
            '   when(dbIsId(openCv) dbPurge(openCv)))',
            '  t))',
            'mnOfflineResult = errset(mnOfflineMain() t)',
            'if(and(mnOfflineResult car(mnOfflineResult))',
            ' printf("HIER_OFFLINE_COMPLETE\\n")',
            ' printf("HIER_OFFLINE_FAILED\\n"))',
            'exit()', ''])
        b.atomic_text(script, content)
        native = run_native(script, args.cdslib.resolve(), job/'offline_native.log',
                            'HIER_OFFLINE_COMPLETE','HIER_OFFLINE_FAILED',
                            args.native_timeout, args.xvfb.resolve() if args.xvfb else None)
        report.update(native=native, exported=extracted,
                      output=dict(lib=args.output_lib,cell=args.output_cell,view=args.output_view),
                      placement=dict(origin=[0,0],orient='R0',magnification=1))
        if native['status'] != 'success':
            raise ValueError('Native XL build did not complete; inspect offline_native.log')
        actual = json.loads((job/'batch_plan.actual_report.json').read_text())
        if actual['status'] != 'clear':
            raise ValueError('Actual via review did not pass')
        report.update(status='complete', actual_review=actual)
        print('Saved overlay: {}/{}/{}; place at 0:0 / R0 / magnification 1'.format(
            args.output_lib,args.output_cell,args.output_view))
        return 0
    except (ValueError, OSError, RuntimeError, KeyError, TypeError) as exc:
        report['error'] = str(exc)
        print(str(exc),file=b.sys.stderr)
        return 2
    finally:
        if locked:
            b.atomic_text(report_file,json.dumps(report,indent=2,ensure_ascii=False)+'\n')
        if lock:
            lock.close()


if __name__ == '__main__':
    raise SystemExit(main())
