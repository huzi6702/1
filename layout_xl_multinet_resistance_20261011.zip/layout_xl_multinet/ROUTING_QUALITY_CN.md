# 当前连线方案如何评价

本文按本次交付的 `batch_router.py`、`kernel/route_engine.py`、`run_plan.py` 和已保存
层次 case 核对。运行步骤与文件信息流见 [SPLIT_FLOW_CN.md](SPLIT_FLOW_CN.md)。
新增电阻模型的定义、假设值及配置命令见 [RESISTANCE_COST_CN.md](RESISTANCE_COST_CN.md)。

## 1. 先检查是否合格

生成独立连线 layout 前，方案必须同时满足：

- 清单中的每个 net 都有一棵连接其全部端点的树；分支确实接到已有树上。
- 普通走线严格遵循各层配置 H/V。反方向只允许沿真实被选端点的同宽、同中心线
  直线延长，且位于支路第一颗 via 前或最后一颗 via 后。
- 满足配置中的线宽、制造网格、障碍与间距；不同 net 的导线和 via pad 不冲突。
- 满足 `route_bounds`，导体及间距包络不超过本次障碍导出窗口。
- 配置、几何、逻辑连接和 XL binding 快照与采集时一致；JSON 与 SKILL 方案一致。
- CIW 创建出的真实标准 via 类型、层对、数组、覆盖和实际金属占地复核通过。

同 net 可以共用树干或相交。未知归属的原有金属、原有 via 仍按障碍处理。低代价
不会抵消以上任何失败；有未完成 net 时仅保留诊断，禁止构建完整 overlay。实际
via 检查失败时回滚整份新建输出 view。

## 2. 合格候选之间的评分

整体搜索按以下元组比较，前一项优先级严格高于后一项：

```text
score = (完整 net 数, 这些完整 net 的端点总数, -总路径代价)
```

| 顺序 | 更好的方案 | 当前计算口径 |
|---|---|---|
| 1 | 完整连接的 net 更多 | 一个 net 的全部端点连通才计入 |
| 2 | 完整 net 覆盖的端点更多 | 仅统计上述完整 net 中的端点 |
| 3 | 总路径代价更低 | 按配置的线长／via 权重或电阻模型对所有分支求和 |

例如，连通 5 个 net 的方案优先于只连通 4 个 net 的方案，即使前者绕线更长。
完整 net 数相同时，先比较端点数；两者都相同时才比较路径代价。所有 net 均连通
后，前两项固定，搜索继续尝试降低代价，直至队列耗尽或预算结束。

当前不会把“某 net 接好了部分端点”计入完整 net 或端点评分。`connected_terminals`
是已完整连接的那些 net 的端点数，不是所有失败 net 中局部连通点的总数。

## 3. 路径代价的含义

配置未启用电阻时，`batch_router.branch_cost()` 的公式是：

```text
分支代价 = Σ(|x2-x1| + |y2-y1|) + λ × 分支中的 via 记录数
net 代价 = Σ该 net 的分支代价
total_cost = Σ所选完整 net 的代价
```

线长按导线中心线计算，使用配置／版图坐标的用户单位。外层评分读取
`route_config.json` 中可选的 `via_cost`，未提供时 λ=5.0。本次实际配置未提供此项，
因此默认一颗 via 相当于 5 个用户单位的线长代价。它是寻路权重，不表示电阻或
实际生产成本。比如多走 4 个单位而少用一颗 via，会使默认代价降低 1。

启用 `cost_model.mode=resistance` 时，改为：

```text
分支代价 = Σ(Rsheet[layer] × L / 实际 W) + Σ(Rsingle_cut[via] / (rows × cols))
total_cost 的单位 = Ω
```

这个值是所有分支的估计电阻之和，不是多端点网络的端到端等效电阻。

需要理解两个实现细节：

1. **内层 A* 与外层现在共用代价实现。** 线长模式下自定义 `via_cost` 同时影响
   内层；电阻模式下，实际线宽、物理金属 Rs、via 名称及阵列行列数同时参与内外
   层计价。端点内部 profile 使用原物理层／via 名查表，避免漏掉真实宽度。
2. **评分按分支记录累计，没有对全部导体取并集。** 同 net 分支重复经过某段导线
   或某个 via 会重复计分；原生构建时会对同 net 同位置、同类型及同数组的 via
   去重。因此代价中的 via 次数可能大于最终实际 via 对象数，`total_cost` 也不是
   去除重叠后的物理金属总长度。

线长模式的所有 via 类型和数组使用同一个换层权重；电阻模式区分配置的单 cut
阻值，并按 cut 数理想并联。电阻模型仍不按电流能力或面积直接评分，没有额外
安全裕量奖励，spacing 继续用于合法性检查。

## 4. 如何寻找较好的整体方案

1. 对每个多端点 net 建立候选连接树，尝试不同根／端点顺序，以及用临时障碍
   引导的绕行通道。后续端点可接入已有树，避免预先固定成孤立的两点配对。
2. 初始为全部 net 生成候选，并计算候选之间的几何冲突。整体搜索优先选择兼容
   候选最少的 net；候选数相同则优先初始冲突更多的 net。
3. 选择一个 net 的树后仍保留此前其他全局选择；后续冲突时可回退。如果当前
   占用导致某 net 没有兼容候选，会带着其他已选 net 的占用重新生成候选。
4. 依据上述评分保留已发现的最好组合。底层按支路调用 A*，外层联合选择全体
   net 的连接树和通道。

搜索范围仍有限：树生长采用先找到可行端点／接入点的策略，默认仅考察前 6 个
接入候选；树线段的接入点取端点、1/4、1/2、3/4 等采样位置。它没有枚举所有树
拓扑及所有连续坐标。

底层默认采用 coarse → layered → detailed 的分阶段 A*；先找到可行路线就返回，
不会为了缩短它必然继续细化搜索图。因此也不能把一个已返回支路称为整个详细
搜索图上的最短路线。

## 5. 预算与“最优”的范围

| 选项 | 推荐 `run_plan.py` 入口默认值 | 含义 |
|---|---|---|
| `max_seconds` | 90 秒 | 外层预算，在支路调用之间检查 |
| `max_states` | 64 | 最多弹出多少个整体候选状态 |
| `max_route_calls` | 600 | 最多调用多少次支路寻路 |
| `candidates_per_net` | 3 | 每次生成／选择的每 net 候选上限 |
| `max_access_points` | 6 | 一个待连端点尝试的树接入点上限 |
| `max_nodes` | 来自实际配置 | 一次底层分阶段寻路共享的状态预算 |

直接运行 `batch_router.py` 的核心默认值为 60 秒、256 个整体状态；推荐 wrapper
会设为 90 秒、64 个状态。时间检查不能中断正在运行的一次 A*，因此 90 秒不是
精确的进程墙钟超时。

推荐入口可提高时间和状态预算：

```bash
python3 /home/meow/autoroute/multinet/run_plan.py \
  --job /你的任务绝对路径 --max-seconds 300 --max-states 256
```

其他外层选项可写在该 job 的 `planner_options.json`，按完整 JSON 保留全部五项。
`run_plan.py` 会从此文件恢复选项，但以命令行的时间／状态值覆盖对应两项；重新
执行障碍导出会清除该选项文件。候选／接入点允许的最大值为 8／32。单次 A* 的
`max_nodes` 应在原配置中设置，再重新导出；不要直接改已采集的配置副本。

提高预算通常能探索更多选择，不能保证任意规模都有解必找到。报告始终保留
`optimality_proven=false`。即使 `termination=search_exhausted`，也仅说明本次有限
候选搜索队列耗尽；它没有证明全部物理方案中的数学全局最优。

## 6. 从哪些文件查看结果

| 文件／字段 | 如何使用 |
|---|---|
| `batch_plan.report.json` 的 `status`、`completed_nets`、`unresolved_nets` | 首先确认所需 net 全部完成 |
| `connected_terminals`／`total_terminals` | 确认完整连接的端点覆盖率 |
| `total_cost`／`cost_unit` | 同一输入、同一模型下比较分支代价，电阻模式为 Ω |
| `cost_breakdown` | 分开查看导线和 via 贡献，电阻模式另报估计电阻 |
| `physical_via_count` | 预计去重后的原生 via 数，与分支换层次数区分 |
| `termination`、`global_states`、`route_calls`、`elapsed_seconds` | 判断是否因预算结束，以及实际探索规模 |
| `candidate_conflicts`、`adaptive_candidates`、`alternative_states` | 查看冲突筛除、适应占用重规划及备选规模 |
| `batch_plan.json` 的各 net `cost`／`branches` | 查看哪个 net 绕行或换层较多 |
| `batch_plan.validation_report.json` | 构建前的方案、输入快照和一致性复核 |
| `batch_plan.actual_report.json` | 实际 via 金属占地复核，成功应为 `status=clear` |
| `ciw_build_result.json` | 现有 CIW 是否已保存独立原生 layout |

不同配置权重或不同采集输入的 `total_cost` 不能直接比较。`status=complete` 表示
规划中所有 net 完成；还要经 CIW 构建及实际 via 复核，才得到可查看的新 OA layout。

当前没有评分或优化时序、RC、串扰、IR drop、EM、等长、net 优先级或完整工艺
DRC／LVS。对于这些要求，仍须在组合版图上执行项目对应的验证。

## 7. 已保存层次测试的具体数值

以下是 `cases/hierarchy_xl/split_release/` 保存的旧线长模式证据，采用该模式的
既有方案和报告。新电阻版的重新运行证据在 `resistance_release/`，不能混读：

| 项目 | 结果 |
|---|---|
| 完整 net | 5／5 |
| 完整 net 覆盖端点 | 20／20 |
| 分支中心线长度累计 | 378 个用户单位 |
| 分支 via 记录累计 | 35 |
| 默认总代价 | 378 + 5 × 35 = 553 |
| 去重后实际标准 via | 33 |
| 实际 via 复核 | `status=clear`，`native_scoped=33` |
| 支路搜索／整体状态 | 177／64 |
| 停止原因／最优证明 | `max_states`／`false` |

该 case 已在先前真实 Virtuoso XL 运行中保存并通过实际 via 复核。这个结果证明
当时找到了一份满足当前几何模型的完整方案；没有证明最短，也没有代替完整工艺
签核或解决历史缺失原始数据的 M2→M3 失败案例。
