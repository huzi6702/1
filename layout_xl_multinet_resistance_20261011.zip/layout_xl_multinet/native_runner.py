"""Run only this job's Virtuoso and optional private X display, with bounds."""
from __future__ import annotations
import os
import shutil
import signal
import subprocess
import time
import uuid
from pathlib import Path


def stop_process(proc):
    if proc and proc.poll() is None:
        os.killpg(proc.pid, signal.SIGTERM)
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait(timeout=3)


def run_native(script, cdslib, log, success, failure, timeout=180, xvfb=None):
    env = os.environ.copy()
    display_process = None
    process = None
    stdout = log.with_suffix('.stdout')
    display_log = None
    try:
        # An earlier successful log must never satisfy this new process's
        # completion check before Cadence has opened/truncated its own log.
        archive_suffix = '.previous.' + uuid.uuid4().hex[:12]
        for previous in (log,stdout):
            if previous.exists():
                previous.rename(previous.with_name(previous.name+archive_suffix))
        if xvfb:
            # -displayfd asks Xvfb to select an unused display, avoiding collisions
            # with both the user's desktop and other batch jobs.
            readfd, writefd = os.pipe()
            display_log = open(log.with_suffix('.xvfb.log'), 'wb')
            display_process = subprocess.Popen(
                [str(xvfb), '-displayfd', str(writefd), '-screen', '0', '1600x1100x24',
                 '-nolisten', 'tcp', '-ac'], pass_fds=(writefd,), stdout=display_log,
                stderr=subprocess.STDOUT, start_new_session=True)
            os.close(writefd)
            import select
            ready, _, _ = select.select([readfd], [], [], 10)
            if not ready:
                raise RuntimeError('Private Xvfb did not become ready')
            number = os.read(readfd, 80).decode().strip()
            os.close(readfd)
            if not number.isdigit():
                raise RuntimeError('Invalid Xvfb display')
            env['DISPLAY'] = ':' + number
        elif not env.get('DISPLAY'):
            raise RuntimeError('XL binding API requires DISPLAY or --xvfb /path/to/Xvfb')
        virtuoso = shutil.which('virtuoso')
        if not virtuoso:
            raise RuntimeError('virtuoso is not available in PATH')
        # -replay executes SKILL after the graphical XL infrastructure is ready.
        # A private virtual display is graphical mode without opening user windows.
        with stdout.open('wb') as output:
            process = subprocess.Popen(
                [virtuoso, '-nocdsinit', '-cdslib', str(cdslib), '-log', str(log),
                 '-replay', str(script)], cwd=Path.home(), env=env,
                stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
            deadline = time.monotonic() + timeout
            outcome = 'timeout'
            while time.monotonic() < deadline:
                content = (log.read_text(errors='replace') if log.exists() else '') + stdout.read_text(errors='replace')
                # Match printed marker lines, never the echoed script source.
                lines = [line for line in content.splitlines()
                         if line.startswith('\\o ') or line.startswith(success) or line.startswith(failure)]
                if any((line[3:] if line.startswith('\\o ') else line).startswith(failure) for line in lines):
                    outcome = 'failed'
                    break
                if any((line[3:] if line.startswith('\\o ') else line).startswith(success) for line in lines):
                    outcome = 'success'
                    break
                if process.poll() is not None:
                    outcome = 'exited_before_marker'
                    break
                time.sleep(.25)
        # Completion marker is emitted only after saving/purging/closing own
        # views. Old IC617 exit() can hang; terminate this process group only.
        if outcome == 'success':
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                pass
        return dict(status=outcome, log=str(log), stdout=str(stdout),
                    native_exit=process.poll(), private_display=bool(xvfb))
    finally:
        stop_process(process)
        stop_process(display_process)
        if display_log:
            display_log.close()
