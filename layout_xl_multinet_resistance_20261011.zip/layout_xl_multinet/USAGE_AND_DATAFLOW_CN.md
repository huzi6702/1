# 一体化入口 run_offline.py：使用与信息流

本文对应当前 `run_offline.py` 和 `hierarchy/auto_export.il`。

当前版本也支持电阻代价，填写阻值并生成新配置的方法见
[RESISTANCE_COST_CN.md](RESISTANCE_COST_CN.md)；此配置同样用于一体化入口。

**推荐使用分开入口**：terminal 使用 `run_plan.py` 只求解，现有 CIW 使用 `mnBuildFromPlan` 创建及复核 layout，无需另起 Virtuoso／Xvfb。完整命令、信息流、文件表及实际 via 复核解释见 [SPLIT_FLOW_CN.md](SPLIT_FLOW_CN.md)。下文保留原 `run_offline.py` 一体化入口的读写说明。方案评分见 [ROUTING_QUALITY_CN.md](ROUTING_QUALITY_CN.md)。

## 1. 入口、目录和前提

完整流程：**保存源 layout／schematic → CIW 加载脚本 → 导出障碍 → 导出连接 → terminal 联合求解并创建连线 layout → 人工实例化到源图**。

这三个路径承担不同作用：

| 路径 | 作用 |
|---|---|
| `/home/meow/autoroute/multinet` | 程序目录：Python、SKILL 和几何检查内核 |
| `--job` 指定的绝对目录 | 本次任务的配置副本、采集数据、方案、报告和日志 |
| `--cdslib` 中定义的输出库目录 | 最终连线 layout 的原生 OA 数据库 |

新版使用 `mnBaseDir`，不依赖旧两点程序的 `arSetDir`。从个人 home 启动 Virtuoso 时仍使用下文的绝对路径。

使用前须满足：

- 源 layout 在 **Virtuoso Layout XL** 中打开，并有真实 schematic connectivity reference 和实例／端口 binding。
- 先保存顶层和涉及的底层 layout、schematic、绑定关系。导出后、构建完成前保持这些数据不变。
- 物理 pin 的层、制造网格以及技术库须与所选实际配置相容。
- 当前支持本级一对一普通模块、矩形金属 pin；模块内部 schematic terminal 与 layout terminal 同名。不同模块的 pin 名可不同，归组依据顶层电路 net。
- 输出库已存在并在指定 `cds.lib` 中定义，technology、单位、DBU、制造网格与源库相容。
- terminal 能调用 `python3` 和 `virtuoso`；导出阶段 CIW 也会调用 `python3`。

## 2. 一套可以照着执行的测试流程

下列命令使用已经创建并验证的测试版图。`manual_hierarchy_01` 和 `hier_routes_manual_01` 是新运行示例名称；已有同名输出 view 时换一个名称。

### 2.1 Terminal：创建 job，启动或使用现有 Virtuoso

```bash
mkdir -p /home/meow/autoroute/multinet/jobs/manual_hierarchy_01
```

如果尚未启动 Virtuoso，在个人 home 执行：

```bash
cd /home/meow
virtuoso -cdslib /home/meow/autoroute/audit/batch_cds.lib
```

已经打开的 Virtuoso 可以继续使用，只需确认它能看到源库及输出库。当前测试库为 `AR_AUDIT_20261010`，实际目录是 `/home/meow/autoroute/audit/native_lib`。

在 Library Manager 打开：

| 字段 | 值 |
|---|---|
| Library | `AR_AUDIT_20261010` |
| Cell | `hier_top_xl20261011b` |
| View | `layout` |
| 编辑器 | `Virtuoso Layout XL` |
| Connectivity reference | `AR_AUDIT_20261010/hier_top_xl20261011b/schematic` |

打开原始 top，保存相关设计。`hier_assembly_xl20261011b` 是效果展示用父 cell；提取连接时应打开上述有绑定的原始 top。

### 2.2 CIW：先加载两个脚本

```lisp
mnBaseDir = "/home/meow/autoroute/multinet"
load(strcat(mnBaseDir "/autoroute_multinet.il"))
load(strcat(mnBaseDir "/hierarchy/auto_export.il"))
```

加载顺序必须如此：第一个文件定义公共过程，并自动加载 `kernel/geometry_helpers.il`；第二个文件提供自动提取入口。后续生成的 `batch_plan.config.il` 等文件由程序自动加载。

每次新开 Virtuoso 会话需执行这两次 load。同一会话已加载且程序没有更新时可以继续使用；重新加载会重置部分任务状态，因此应在两次导出之前完成加载。

### 2.3 CIW：确定源图并先导出障碍

先点击目标 layout 窗口，使其成为当前编辑窗口，再在 CIW 执行：

```lisp
mnExportCv = geGetEditCellView()
printf("Export source: %s/%s/%s\n"
       mnExportCv~>libName mnExportCv~>cellName mnExportCv~>viewName)
```

确认打印的是 `AR_AUDIT_20261010/hier_top_xl20261011b/layout`，然后执行：

```lisp
mnExportObstacles("/home/meow/autoroute/multinet/jobs/manual_hierarchy_01"
                  mnExportCv
                  "/home/meow/autoroute/multinet/cases/hierarchy_xl/route_config.json")
```

正常会看到 `HIER_OBSTACLES_EXPORTED`。这一步读取当前版图及配置，把配置逐字节复制到 job，并导出顶层／层次障碍、原有 via 和坐标窗口。

**用于自己的设计时，第三个参数改为你的实际配置绝对路径**，例如 `/home/meow/route_config.json`；这不意味着该 home 配置必然适用于本测试库。测试命令中的配置专供当前 TSMC 测试版图。不要省略这个参数后误用程序目录中的其他配置，也不要拿测试配置覆盖 home 配置。

### 2.4 CIW：再导出连接

在同一会话、同一源图、同一 job，且中间没有修改版图的情况下执行：

```lisp
mnExportConnections("/home/meow/autoroute/multinet/jobs/manual_hierarchy_01"
                    mnExportCv)
```

正常会看到 `HIER_CONNECTIONS_EXPORTED` 和最终的 **`HIER_EXPORT_READY`**。

这一步先重新采集并比较障碍，再读取真实 XL binding 和 schematic net；随后自动生成 `nets.json`、`batch_geometry.sexp`、`binding_report.json`、`export_ready.json`。看到 ready 后才能进入 terminal 求解。仅执行障碍导出不足以运行离线入口。

### 2.5 Terminal：联合求解并创建原生连线 layout

```bash
python3 /home/meow/autoroute/multinet/run_offline.py \
  --job /home/meow/autoroute/multinet/jobs/manual_hierarchy_01 \
  --cdslib /home/meow/autoroute/audit/batch_cds.lib \
  --output-lib AR_AUDIT_20261010 \
  --output-cell hier_routes_manual_01 \
  --xvfb /home/meow/autoroute/audit/xvfb_root/usr/bin/Xvfb
```

不要求先 `cd` 到程序目录。这条命令会：

1. 锁定该 job，验证两次导出完成及配置／原始采集哈希。
2. 从采集文件重新生成路由输入，写入本次搜索预算。
3. 调用 `batch_router.py`，统一规划所有 net 的多端点连接树，处理不同 net 的占用和候选冲突，并回退／重规划。
4. 若所有 net 均连通，生成 `offline_build.il`，启动独立真实 Virtuoso XL 会话。
5. 从保存的 OA 数据库只读重开源图，重新采集几何和连接／binding，与导出数据比较，复核方案快照和合法性。
6. 在新输出 view 中创建 path、pad 和技术库中的标准 via；读取实际 via 占地并复核。
7. 全部通过后保存新 layout，清理本次会话并写入最终结果。

成功应看到：

```text
Saved overlay: AR_AUDIT_20261010/hier_routes_manual_01/layout; place at 0:0 / R0 / magnification 1
```

同时 `offline_result.json` 的 `status` 应为 `complete`，`batch_plan.actual_report.json` 的 `status` 应为 `clear`。

`--xvfb` 使用本机已解压的独立显示程序。换机器时替换为当地 Xvfb 可执行文件路径；省略该参数则使用当前 `DISPLAY`，本次运行的窗口可能可见。这个入口需要真实 XL 编辑器上下文，不能改为普通 `-nograph` 绑定读取流程。

### 2.6 Virtuoso：查看并人工调入源图

输出是 `AR_AUDIT_20261010/hier_routes_manual_01/layout`，包含新增走线、pad、via 和 net 归属。它保存在输出库 OA 数据库中，不是 job 中的 PNG／SVG 或 `batch_plan.il`。

先打开输出 layout 查看，再打开原始 top，通过 **Create Instance** 放入该输出 cell：

| 放置参数 | 必须使用 |
|---|---|
| Origin | `0:0` |
| Orientation | `R0` |
| Magnification | `1` |

所有走线坐标已经是源 top 坐标，不能按新 cell 的 bbox 左下角另行对齐。程序只创建新输出 view，源图的插入和保存由你完成。插入后按项目流程核对物理连通性、XL 连接状态和 DRC/LVS；自动几何复核不是完整工艺签核。

## 3. 信息流

```mermaid
flowchart TD
    A[已保存的源 layout 和层次几何] --> B[CIW: mnExportObstacles]
    C[实际 route_config.json] --> B
    B --> D[obstacles.sexp + job 配置副本]
    A --> E[CIW: mnExportConnections]
    F[schematic net + XL binding] --> E
    D --> E
    E --> G[connections.sexp]
    D --> H[hierarchy_io.py]
    G --> H
    H --> I[nets.json + batch_geometry.sexp]
    H --> J[binding_report.json + export_ready.json]
    I --> K[Terminal: run_offline.py / batch_router.py]
    J --> K
    K --> L[batch_plan.json + batch_plan.il + 求解报告]
    L --> M[独立 Virtuoso XL 会话]
    A --> M
    F --> M
    M --> N[重新采集与快照核对]
    N --> O[创建新走线与标准 via]
    O --> P[实际 via 占地复核]
    P --> Q[通过后保存输出库中的 layout]
    Q --> R[人工以 0:0 / R0 / 1 调入源图]
```

连接推导示例：测试中 `U_FRONT/ALPHA`、`U_BACK/IN_B`、`U_MON/DATA_C` 和顶层 `EXT_IN` 都属于电路 `N_DATA`；导出后形成一个含 4 个端点的 net。其物理实例即使叫 `PHYS_LEFT` 等其他名字，也由 binding 找到对应关系。实例变换后的 pin 坐标用于求解，顶层对外 pin 也加入同一连接树。

## 4. run_offline.py 具体读取哪些文件

下表包括 Python 入口及它调用的路由器／原生 SKILL；均相对 `--job`，`cds.lib` 和 OA 数据库除外。

| 文件或数据 | 读取时机和作用 | 来源 |
|---|---|---|
| `route_config.json` | 所有阶段使用的层、H/V、宽度、间距、via、边界、网格等规则 | 第一次 CIW 导出复制实际配置 |
| `obstacles.sexp` | 原始几何采集；生成路由障碍并用于快照比较 | 第一次 CIW 导出 |
| `connections.sexp` | 原始 net／端点／binding 采集；生成连接树需求 | 第二次 CIW 导出 |
| `export_ready.json` | 必需；核对上述三个文件的 SHA256 | 第二次导出完成后自动写入 |
| `config_capture.json` | 存在时检查配置是否自第一次导出后发生变化；正常流程会生成 | 第一次导出 |
| `planner_options.json` | 已存在时读取搜索选项；随后按本次命令预算写回，供原生重采集比较 | 离线入口生成／更新 |
| `nets.json` | 路由器读取 net、端点、源 cell 身份、选项；入口会重新生成它 | `hierarchy_io.py` 自动生成 |
| `batch_geometry.sexp` | 路由器读取带端点归属的几何、障碍、单位、网格、窗口 | `hierarchy_io.py` 自动生成 |
| `binding_report.json` | 原生重新采集后比较逻辑／物理对应关系 | 自动生成；入口会重新生成 |
| `batch_plan.config.il` | 原生会话加载编译后的配置 | 自动生成 |
| `batch_plan.json`、`batch_plan.il` | 构建前检查方案、输入快照及 JSON／SKILL 一致性，再创建图形 | 联合求解生成 |
| `current_obstacles.sexp`、`current_connections.sexp` | 原生构建前读取新采集数据并和基线比较 | 当前运行的 native 会话生成 |
| `batch_actual_vias.txt` | 实际 via 定义、位置和各层实际占地，交给路由器复核 | 当前运行创建 via 后生成 |
| `batch_plan.actual_report.json` | 最后核对实际 via 复核状态 | 当前运行复核生成 |
| `--cdslib` 指定文件及其引用 | 查找源库、底层库、技术库和输出库 | 你的 Virtuoso 库配置 |
| 源 layout／底层 layout／schematic／binding／技术库 OA 数据 | 原生只读重开和重采集，查找真实标准 via 定义 | 已保存的 Virtuoso 数据库 |

另外程序目录的 Python 和 `.il` 文件属于执行依赖，包括 `batch_router.py`、`hierarchy_io.py`、`native_runner.py`、`autoroute_multinet.il`、`hierarchy/auto_export.il` 和 `kernel/`。

源 cell 身份由采集数据中的 `source` 自动传递，入口不读取你当前 GUI 中选中了哪个窗口。`--output-lib/cell/view` 仅指定新连线 layout 的保存位置。

**原始采集输入是 job 的配置副本、`obstacles.sexp`、`connections.sexp`。不要手工改自动生成的 `nets.json` 以改变连接需求：离线入口会从采集输入重新生成它。** 修改连接需求应先修改／保存原电路及绑定，再重新导出。

`run_offline.py` 不直接解析 `~/tsmc18/tech.tf` 来推断尺寸。求解规则来自指定配置；native 创建使用源／输出技术库中的实际 via definition。给定 tech.tf 用于建立、核对测试配置的阶段。

## 5. 采集信息、方案和日志分别承载在哪里

| 想查看什么 | 文件 |
|---|---|
| 导出了哪些障碍、在哪些层、什么坐标 | `obstacles.sexp`；易用于路由的转换结果是 `batch_geometry.sexp` |
| 原始电路 net 与物理端点、实例变换、binding | `connections.sexp` |
| 某个 net 要连接哪些点 | `nets.json` |
| 物理 pin 对应哪个电路实例／pin／net | `binding_report.json` |
| 是否已经完成两阶段导出及输入哈希 | `export_ready.json`、`config_capture.json` |
| 所有 net 的连线树、线段、via 方案和输入快照 | `batch_plan.json` |
| 供 SKILL 创建图形的同一方案 | `batch_plan.il` |
| 连上哪些 net、哪些未连、搜索次数和停止原因 | `batch_plan.report.json` |
| 创建前方案合法性复核 | `batch_plan.validation_report.json` |
| 实际 via 数据及复核结果 | `batch_actual_vias.txt`、`batch_plan.actual_report.json` |
| 本次任务最后是否成功、输出库／cell／view | `offline_result.json` |
| 原生 Virtuoso 过程及 SKILL 错误 | `offline_native.log`、`offline_native.stdout` |
| CIW 调用 Python 的信息及 native 阶段 Python 复核信息 | `batch_engine.log` |
| 虚拟显示启动问题 | 使用 Xvfb 时的 `offline_native.xvfb.log` |

注意：terminal 中首次准备／联合求解的输出直接显示在 terminal；`batch_engine.log` 收集的是从 CIW／native SKILL 发起的 Python 调用，不含所有 terminal 输出。

`.sexp` 是文本数据格式，可以用文本编辑器打开；它不需要在 CIW `load`。`batch_plan.request.il` 也会自动生成，自动提取流程无需手工加载它。

完整成功 job 的关键文件如下：

```text
manual_hierarchy_01/
  route_config.json
  config_capture.json
  obstacles.sexp
  connections.sexp
  export_ready.json
  nets.json
  binding_report.json
  batch_geometry.sexp
  planner_options.json
  batch_plan.config.il
  batch_plan.request.il
  batch_plan.json
  batch_plan.il
  batch_plan.report.json
  current_obstacles.sexp
  current_connections.sexp
  batch_plan.validation_report.json
  batch_actual_vias.txt
  batch_plan.actual_report.json
  offline_build.il
  offline_native.log
  offline_native.stdout
  batch_engine.log
  offline_result.json
```

已有真实测试数据可查看 `/home/meow/autoroute/multinet/cases/hierarchy_xl/release`。其中 `offline_result.json` 对应最终的 `hier_routes_xl20261011b_clean/layout`。已经实际运行 Virtuoso XL，5 个 net、20 个端点全部连接，33 颗标准 via 的实际占地复核通过；这不是对历史缺失 M2→M3 失败数据的闭环结论。

## 6. 参数与重跑

| 参数 | 默认／含义 |
|---|---|
| `--job` | 必填；同一次 CIW 导出使用的 job |
| `--cdslib` | 必填；供新 Virtuoso 会话读取的库配置 |
| `--output-lib`、`--output-cell` | 必填；输出库和新 cell |
| `--output-view` | 默认 `layout` |
| `--max-seconds` | 默认 `90`；路由搜索时间预算，仍受其他预算限制 |
| `--max-states` | 默认 `64`；整体候选组合搜索状态预算 |
| `--native-timeout` | 默认 `180` 秒；启动／复核／创建原生 view 的阶段超时 |
| `--xvfb` | 可选；独立 Xvfb 可执行文件路径 |

预算增大示例：在同一条 terminal 命令后增加 `--max-seconds 300 --max-states 256`。有限候选／状态搜索优先尽可能多地完整连接 net，再考虑端点数及线长／via 成本；没有数学最优保证。

- 同一份采集数据再次尝试，可以复用 job，但输出 view 必须全新。生成的方案／报告会更新，旧 native 日志自动归档。
- 改了配置、几何、pin、电路 net、模块变换或 binding，先保存，再从 **导出障碍 → 导出连接** 重做。推荐使用新 job 保留前次证据。
- 第一阶段重新导出会使旧连接文件和 ready 标记失效，必须再执行第二阶段。
- 同一 job 不可并发运行两个离线任务。
- 已把旧连线 layout 插入源图后，再次规划应先移除旧连线实例并保存；额外未绑定实例会被严格模块匹配拒绝。

## 7. 失败时看哪里

| 现象 | 处理 |
|---|---|
| `undefined function mnExportObstacles` 等 | 按顺序加载两个 `.il`，然后重新导出 |
| `Export obstacles first...` | 同一会话、同一源图和 job，先执行第一阶段 |
| 缺失／歧义 binding、物理 pin、外部端口 | 核对 XL reference、模块／端口对应关系和矩形金属 pin；修复保存后重新导出 |
| `Config/native manufacturing grid mismatch` | 换成与源技术匹配的实际配置，重新导出 |
| `Captured inputs changed...` 或源快照变化 | 保存源设计，从第一阶段重新导出，不手工篡改 ready 哈希 |
| `Global routing failed/incomplete` | 看 `batch_plan.report.json` 的未连 net／失败原因；必要时调整合法配置、版图资源或搜索预算 |
| `Output view already exists` | 选择新的输出 cell／view |
| `Native XL build did not complete` | 看 `offline_result.json`、`offline_native.log`；核对库、技术、显示、许可证和源快照 |
| 实际 via 复核失败 | 看 `batch_plan.actual_report.json` 和 `batch_actual_vias.txt`；本次新建未保存 view 会回滚 |

只有 `offline_result.json: status=complete` 且实际复核通过，才按本次输出身份调入源图。目录中存在旧方案文件、预览图片或旧日志，不能证明本次成功。
