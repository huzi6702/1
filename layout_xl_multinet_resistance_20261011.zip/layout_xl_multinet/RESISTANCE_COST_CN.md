# 按可配置电阻优化连线

新版本支持两种代价：实际配置未提供 `cost_model` 时沿用线长＋via 权重；明确启用
`cost_model.mode=resistance` 时，内层 A*、via 候选选择和外层整体方案使用同一套
电阻权重。操作与信息流仍按 [SPLIT_FLOW_CN.md](SPLIT_FLOW_CN.md) 执行。

## 1. 计算口径

```text
导线估计电阻 Rwire = 方块阻值 Rsheet × 中心线长度 L / 实际线宽 W
via 阵列估计电阻 Rvia = 单个 cut 阻值 / (cutRows × cutColumns)
总代价 = 所有分支的 Rwire 之和 + 所有分支的 Rvia 之和，单位 Ω
```

L 和 W 使用相同版图用户单位，比例 L/W 无量纲。Rs 的单位为 Ω/□，via 单 cut
阻值的单位为 Ω。端点直线延长使用真实端点线宽，不使用该层默认线宽替代。
via 使用该位置真实规划出的行列数，不统一假设只有一颗 cut。

**这个总代价是分支估计电阻之和，不是端点之间的等效电阻。** 多端点 net 没有
一个不依赖端口选择的单一等效电阻；本版本没有建立完整电阻网络并求解端口
电压／电流。它适合比较当前候选路径对金属层、线宽和 via 阵列的选择。

当前简化模型还包括：

- 同 net 的重叠分支记录会重复计入；原生 via 去重不会反向修改此评分。
- via 数组按 cut 理想并联，忽略电流分布及 spreading resistance。
- 未另算 pad/enclosure、拐角、原有 pin／走线的电阻及复杂宽度变化。
- 不含温度、宽度依赖的 Rs、RC 延迟、EM／IR drop，也不代替寄生提取或签核。

完整连通的 net 数、完整 net 覆盖的端点数仍优先于降低电阻。所有原有 H/V、
避障、间距、边界、快照、实际 via 复核和失败回滚继续执行；不完整方案不创建
overlay。有限搜索仍不保证数学全局最优。

## 2. 假设值与可编辑文件

独立文件 `resistance.example.json` 给出以下演示值，`assumed=true`。这些数字是
本次人为假设，**没有从 `~/tsmc18/tech.tf` 提取，也不代表该 PDK 的真实阻值**。
它们不改变任何 PDK 几何尺寸。

| 金属层 | 方块阻值 Ω/□ | 标准 via 定义 | 单 cut 阻值 Ω |
|---|---:|---|---:|
| METAL1 | 0.10 | M2_M1 | 1.0 |
| METAL2 | 0.08 | M3_M2 | 0.8 |
| METAL3 | 0.06 | M4_M3 | 0.6 |
| METAL4 | 0.05 | M5_M4 | 0.4 |
| METAL5 | 0.04 | M6_M5 | 0.3 |
| METAL6 | 0.02 | — | — |

文件结构：

```json
{
  "mode": "resistance",
  "assumed": true,
  "description": "演示假设，使用时替换为实际阻值",
  "sheet_resistance_ohm_per_square": {
    "METAL1": 0.10,
    "METAL2": 0.08,
    "METAL3": 0.06,
    "METAL4": 0.05,
    "METAL5": 0.04,
    "METAL6": 0.02
  },
  "via_resistance_ohm_per_cut": {
    "M2_M1": 1.0,
    "M3_M2": 0.8,
    "M4_M3": 0.6,
    "M5_M4": 0.4,
    "M6_M5": 0.3
  }
}
```

按自己的实际配置填写：金属键名取 `layers[].name`；via 键名取 `vias[].name`，
例如 `M3_M2`，不是 cut layer 名 `VIA23`。同一层对有多种 via 定义时分别填写。
每个配置中的金属层和 via 都必须有对应阻值，不能漏项或出现拼错／多余名字。
所有值必须为有限正数，不能写 0、负数、字符串、布尔值、NaN 或 Infinity。

获得实际数据后替换数字，设置 `assumed=false`，并在 `description` 记录来源／温度
等条件。此元数据只记录用户声明，程序不校验数据是否与 PDK 一致。

## 3. 用实际几何配置生成新配置

不用修改或覆盖自己的实际 `route_config.json`。先复制示例到新文件并编辑：

```bash
mkdir -p /home/meow/autoroute/multinet/configs
cp -n /home/meow/autoroute/multinet/resistance.example.json \
      /home/meow/autoroute/multinet/configs/resistance_user.json
```

编辑 `resistance_user.json` 后，把它与原实际几何配置合并到一个**新配置文件**：

```bash
python3 /home/meow/autoroute/multinet/prepare_resistance_config.py \
  --config /home/meow/route_config.json \
  --model /home/meow/autoroute/multinet/configs/resistance_user.json \
  --output /home/meow/autoroute/multinet/configs/route_config.resistance_v1.json
```

`--config` 换成自己当前实际配置的绝对路径。此工具逐项保留几何、H/V、via 定义
及已有配置字段，仅写入 `cost_model`；拒绝输入输出同名及覆盖已有输出。下一次
调整阻值时选择新的输出名，例如 `route_config.resistance_v2.json`。

若旧配置已有 `via_cost`，启用 resistance 后不再使用这个线长权重。回到旧模式可
使用原实际配置，或者明确设 `cost_model.mode=length_via`；不要直接改已导出的 job
配置副本，否则快照检查会拒绝。

## 4. CIW 采集 → terminal 求解 → CIW 创建

准备新 job，保存源电路／layout／绑定。在现有 CIW 中重新加载生产脚本：

```lisp
mnBaseDir = "/home/meow/autoroute/multinet"
load(strcat(mnBaseDir "/autoroute_multinet.il"))
load(strcat(mnBaseDir "/hierarchy/auto_export.il"))
mnExportCv = geGetEditCellView()
mnExportObstacles("/你的新任务绝对路径"
                  mnExportCv
                  "/home/meow/autoroute/multinet/configs/route_config.resistance_v1.json")
mnExportConnections("/你的新任务绝对路径" mnExportCv)
```

看到 `HIER_EXPORT_READY` 后，在 terminal 运行：

```bash
python3 /home/meow/autoroute/multinet/run_plan.py \
  --job /你的新任务绝对路径 --max-seconds 300 --max-states 256
```

Python 只计算方案，不启动 Virtuoso／Xvfb。默认预算仍为 90 秒／64 状态；电阻
权重差异大时可能需要更多搜索预算。检查所有 net 完成后，在现有 CIW 执行：

```lisp
mnBuildFromPlan("/你的新任务绝对路径" "你的输出库" "全新的连线cell")
```

实际 via 创建、复核通过后才保存独立 layout。用户手动以 **0:0／R0／倍率 1**
实例化到源图，并进行项目要求的验证。修改阻值、几何、逻辑连接或 binding 后，
必须重新执行两阶段导出和求解，不能复用旧 overlay。

## 5. 报告和代码

`batch_plan.report.json` 中：

- `cost_model.mode=resistance`、`cost_unit=ohm`：确认已启用电阻模型。
- `cost_model.assumed`：当前是否声明使用假设值。
- `total_cost`／`estimated_resistance_ohm`：分支估计电阻总代价。
- `cost_breakdown.wire_resistance_ohm`、`via_resistance_ohm`：导线／via 贡献。
- `cost_breakdown.wire_length`、`via_transitions`：仍保留几何长度和分支换层次数。
- `physical_via_count`：预计去重后实际 via 对象数，与上述次数可能不同。
- 每个 net 在 `batch_plan.json` 中另有 `cost` 和 `cost_breakdown`。

配置副本中的 `cost_model` 参与既有 SHA256 快照。它不会成为独立、未校验的 side
file；terminal 和 CIW 校验读取的是同一份 job 配置副本。

共同代价实现在 `kernel/routing_cost.py`。内层用实际线宽及实际 via 行列数计算
边权，用 H/V 各自最低单位长度电阻和 via 层图的反向 Dijkstra 作为估计下界。
相同层对的 via 按电阻排序，并保留非法候选之后的合法备选。已知直线端点连线
在电阻模式下也与搜索返回的方案比较，避免早返回遮蔽更低阻的上层通道。

整体评分顺序和其余搜索限制见 [ROUTING_QUALITY_CN.md](ROUTING_QUALITY_CN.md)。

## 6. 本次验证及可查看的版图

在真实 IC6.1.7 Virtuoso XL 中，从同一份已保存的层次源重新导出几何及连接。
新旧导出的几何／逻辑一致，使用上面的同一套假设阻值比较：

| 项目 | 旧线长模式保存方案，按本电阻模型重新评价 | 新电阻模式方案 |
|---|---:|---:|
| 完整 net／端点 | 5／20 | 5／20 |
| 分支估计电阻总代价 Ω | 121.319876 | 76.165000 |
| 分支中心线长度 | 378 | 422.125 |
| 分支 via 记录数 | 35 | 73 |
| 去重后实际 via 数 | 33 | 70 |

本 case 的估计电阻代价降低约 37.2%；它通过更多换层使用较低阻通道，导线总长
及 via 数增加。两方案的值都按分支记录累计，没有把 70 个物理 via 数替代 73 个
分支换层记录数。新搜索使用 64 个整体状态、356 次支路寻路，约 28.6 秒，因状态
预算停止，未证明全局最优。

41 项多 net Python 检查通过，其中 12 项为新增电阻测试；使用当前修改后的内核
另跑原有 130 项回归，全部通过。5 项真实原生断言覆盖创建、隔离组合版图、拒绝
覆盖已有输出、实际 via 数组不匹配时整份 view 回滚，以及恢复后重新创建。
实际 70 颗标准 via 的金属占地复核通过。原本地源码／配置与保存源数据库的
哈希核对未变；受控测试会话已结束，用户原 GUI 未操作。

在 `AR_AUDIT_20261010` 库中：

| Cell/view | 内容 |
|---|---|
| `hier_top_splitxl20261011a/layout` | 原有有绑定的源版图 |
| `hier_routes_resistance20261011a/layout` | 新电阻模式的独立连线版图 |
| `hier_assembly_resistance20261011a/layout` | 测试 source＋overlay 按 0:0／R0／1 叠加 |
| `hier_routes_resistance20261011a_recovered/layout` | 触发实际 via 失败后恢复创建的输出 |

从个人 home 启动时可沿用隔离库定义：

```bash
cd /home/meow
virtuoso -cdslib /home/meow/autoroute/audit/batch_cds.lib
```

证据在 `cases/hierarchy_xl/resistance_release/`：同次配置、原始采集、方案、报告、
实际 via 导出、native 原始日志及 `TEST_RESULTS.json` 均已保存。`preview/` 提供按
真实采集和方案绘制的 PNG／SVG，不能替代原生数据库或工艺验证。历史缺失原始
数据的 M2→M3 失败案例没有据此宣称闭环，也未执行完整 foundry DRC／LVS。
