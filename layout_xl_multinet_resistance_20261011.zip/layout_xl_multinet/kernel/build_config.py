#!/usr/bin/env python3
"""Read a Cadence ASCII techfile without evaluating SKILL; emit editable JSON.

Missing rules produce a draft and diagnostics. Only a complete config is compiled.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from pathlib import Path

from config_validation import config_fingerprint, config_issues, pad_size, validate_config

CALLS = {'layerRules', 'functions', 'routingDirections', 'preferredRoutingDir',
         'viaDefs', 'standardViaDefs', 'customViaDefs', 'constraintGroups',
         'spacings', 'spacingRules', 'spacingTables', 'orderedSpacings',
         'viaSpacings', 'techParams', 'techParam', 'controls', 'mfgGridResolution',
         'layerDefinitions', 'techLayers', 'viewTypeUnits', 'interconnect'}


def tokens(source):
    pattern = r'\s+|;[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|\(|\)|[^\s();]+'
    end = 0
    for match in re.finditer(pattern, source, re.S):
        if match.start() != end:
            raise ValueError(f'Unrecognized tech syntax at character {end}')
        word = match.group()
        end = match.end()
        if word.isspace() or word.startswith(';') or word.startswith('/*'):
            continue
        yield word, match.start(), match.end()
    if end != len(source):
        raise ValueError('Incomplete token in tech file')


def parse(source):
    root, stack = [], []
    current = root
    previous_end = -1
    previous_word = ''
    for token, start, end in tokens(source):
        if token == '(':
            child = []
            # Do not turn a quoted layer followed by a vector into a call.
            if (current and isinstance(current[-1], str) and
                    re.fullmatch(r'[A-Za-z_][\w:]*', previous_word) and
                    (start == previous_end or previous_word in CALLS)):
                child.append(current.pop())
            current.append(child)
            stack.append(current)
            current = child
        elif token == ')':
            if not stack:
                raise ValueError('Unbalanced closing parenthesis in tech file')
            current = stack.pop()
        else:
            current.append(json.loads(token) if token.startswith('"') else token)
        previous_end, previous_word = end, token
    if stack:
        raise ValueError('Unbalanced opening parenthesis in tech file')
    return root


def sections(tree, name):
    if not isinstance(tree, list):
        return
    if tree and tree[0] == name:
        yield tree
    for part in tree:
        if isinstance(part, list):
            yield from sections(part, name)


def number(value, params, seen=None):
    seen = set() if seen is None else seen
    if isinstance(value, list):
        if len(value) == 2 and value[0] == 'techParam':
            key = value[1]
            if not isinstance(key, str) or key in seen:
                return None
            return number(params.get(key), params, seen | {key})
        return None
    if isinstance(value, str) and value in params:
        if value in seen:
            return None
        return number(params[value], params, seen | {value})
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def natural(name):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r'(\d+)', name)]


def _single_layer(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list) and len(value) == 2 and value[1] == 'drawing':
        return value[0] if isinstance(value[0], str) else None
    return None


def _metadata_only(tail):
    return (len(tail) % 2 == 0 and
            all(tail[i] in ("'ref", "'description") for i in range(0, len(tail), 2)))


def _table_values(spec, data, params):
    """Recognize one/two-axis width/length tables; never treat indices as spacing.

    Unknown flags/axis layouts are left for manual review rather than flattened.
    """
    table_default = None
    # Cadence dumps can wrap the axis definitions with a table default:
    # (("width" nil nil "length" nil nil) 0.28). The default is a
    # spacing value, while the data indices remain width/length thresholds.
    if isinstance(spec, list) and len(spec) == 2 and isinstance(spec[0], list):
        table_default = number(spec[1], params)
        if table_default is None or table_default <= 0:
            return None
        spec = spec[0]
    if not isinstance(spec, list) or len(spec) not in (3, 6):
        return None
    axes = []
    for offset in range(0, len(spec), 3):
        axis, interpolation, default = spec[offset:offset+3]
        if (str(axis).lower() not in ('width', 'length', 'parallelrunlength') or
                interpolation not in ('nil', None) or default not in ('nil', None)):
            return None
        axes.append(axis)
    if not isinstance(data, list) or not data:
        return None
    # Both ((index value) ...) and (index value index value ...) are encountered.
    if all(isinstance(row, list) and len(row) == 2 for row in data):
        pairs = data
    elif len(data) % 2 == 0:
        pairs = list(zip(data[::2], data[1::2]))
    else:
        return None
    result = [table_default] if table_default is not None else []
    for index, value in pairs:
        indices = index if isinstance(index, list) else [index]
        v = number(value, params)
        if len(indices) != len(axes) or any(number(x, params) is None for x in indices) or v is None or v <= 0:
            return None
        result.append(v)
    return result


def via_catalog(tree):
    catalog = []
    for kind, section, fields in (('standard', 'standardViaDefs', (1, 2)),
                                  ('custom', 'customViaDefs', (4, 5))):
        for sec in sections(tree, section):
            for row in sec[1:]:
                if not isinstance(row, list) or not row or not isinstance(row[0], str):
                    continue
                a, b = fields
                entry = dict(name=row[0], kind=kind, raw=row, layers=None, routable=False)
                if len(row) > b and isinstance(row[a], str) and isinstance(row[b], str):
                    entry['layers'] = [row[a], row[b]]
                catalog.append(entry)
    return catalog


def metal_stack(names, catalog, explicit=None, pattern='odd-h-even-v'):
    """Infer chains from actual via edges, not layer spelling or mask numbers."""
    warnings = []
    if explicit is not None:
        if not explicit or len(set(explicit)) != len(explicit) or set(explicit)-set(names):
            raise ValueError('--stack must contain unique exact names discovered as metal')
        excluded = [name for name in names if name not in explicit]
        if excluded:
            warnings.append(f'Metals explicitly excluded by --stack: {excluded}')
        names = explicit
    rank = {name:i for i, name in enumerate(names)}
    graph = {name:set() for name in names}
    for entry in catalog:
        pair = entry['layers']
        if pair and pair[0] in graph and pair[1] in graph and pair[0] != pair[1]:
            graph[pair[0]].add(pair[1])
            graph[pair[1]].add(pair[0])
    components, pending = [], set(names)
    while pending:
        seed = min(pending, key=rank.get)
        todo, component = [seed], set()
        while todo:
            name = todo.pop()
            if name in component:
                continue
            component.add(name)
            todo.extend(graph[name]-component)
        pending -= component
        components.append(component)
    def suffix(name):
        match = re.fullmatch(r'(?:M|METAL)(\d+)', name, re.I)
        return int(match[1]) if match else None
    order, levels, review = [], {}, False
    if explicit is not None:
        order = list(explicit)
        anchors = [(i, suffix(name)) for i, name in enumerate(order) if suffix(name) is not None]
        bases = {number-i for i, number in anchors}
        base = bases.pop() if len(bases) == 1 else 1
        for i, name in enumerate(order):
            levels[name] = suffix(name) if suffix(name) is not None else base+i
    else:
        for component in components:
            ends = sorted((n for n in component if len(graph[n]) <= 1), key=rank.get)
            chain = []
            if len(component) == 1:
                chain = ends
            elif len(ends) == 2 and all(len(graph[n]) <= 2 for n in component):
                previous, name = None, ends[0]
                while name is not None:
                    chain.append(name)
                    following = graph[name]-({previous} if previous is not None else set())
                    previous, name = name, next(iter(following), None)
                anchors = [suffix(n) for n in chain if suffix(n) is not None]
                if len(anchors) >= 2 and anchors[0] > anchors[-1] or suffix(chain[-1]) == 1:
                    chain.reverse()
            if not chain:
                chain = sorted(component, key=rank.get)
                review = True
                warnings.append(f'Branched/cyclic via graph: {chain}; choose directions/allowed metals explicitly')
            anchors = [(i, suffix(n)) for i, n in enumerate(chain) if suffix(n) is not None]
            bases = {number-i for i, number in anchors}
            base = next(iter(bases)) if len(bases) == 1 else 1
            unnumbered = [n for n in chain if suffix(n) is None]
            if unnumbered and pattern != 'tech' and (not anchors or len(bases) != 1 or
                    len(anchors) == 1 and anchors[0][1] != 1):
                review = True
                warnings.append(f'Bottom-to-top orientation is ambiguous for {chain}; --stack or manual review required')
            for i, name in enumerate(chain):
                levels[name] = suffix(name) if suffix(name) is not None else base+i
            order.extend(chain)
        if len(components) > 1:
            review = True
            warnings.append('Multiple disconnected metal stacks found; select --stack or review all components')
    return order, levels, dict(order_source='explicit --stack' if explicit is not None else 'standard/custom via graph',
                              graph={n:sorted(graph[n], key=rank.get) for n in names},
                              components=[sorted(c, key=rank.get) for c in components],
                              review_required=review), warnings


def extract(path: Path, pattern='odd-h-even-v', stack=None):
    text = path.read_text(encoding='utf-8', errors='strict')
    tree = parse(text)
    warnings, ignored, skipped_vias = [], [], []
    params = {}
    for sec in sections(tree, 'techParams'):
        for row in sec[1:]:
            if isinstance(row, list) and len(row) >= 2:
                params[str(row[0])] = row[1]
    functions = {}
    for sec in sections(tree, 'functions'):
        for row in sec[1:]:
            if isinstance(row, list) and len(row) >= 2:
                functions[str(row[0])] = str(row[1]).lower()
    metals = [name for name, fn in functions.items() if fn == 'metal']
    if not metals:
        raise ValueError('No metal layers found in layerRules/functions; use a complete ASCII tech dump')
    catalog = via_catalog(tree)
    discovered_metals = list(metals)
    metals, levels, stack_report, stack_warnings = metal_stack(metals, catalog, stack, pattern)
    warnings.extend(stack_warnings)
    direction = {}
    for section in ('routingDirections', 'preferredRoutingDir'):
        for sec in sections(tree, section):
            for row in sec[1:]:
                if isinstance(row, list) and len(row) >= 2:
                    value = str(row[1]).lower()
                    if value in ('horizontal', 'vertical', 'h', 'v'):
                        direction[str(row[0])] = 'H' if value in ('horizontal', 'h') else 'V'
    widths, spaces = {}, {}
    for secname in ('spacings', 'spacingRules', 'orderedSpacings', 'viaSpacings'):
        for sec in sections(tree, secname):
            for row in sec[1:]:
                if not isinstance(row, list) or len(row) < 3 or row[0] not in ('minWidth', 'minSpacing'):
                    continue
                name = _single_layer(row[1])
                offset = 2
                # A scalar self-layer pair is equivalent to a single-layer spacing.
                if row[0] == 'minSpacing' and len(row) >= 4 and row[2] == name:
                    offset = 3
                value = number(row[offset], params)
                if name in metals and value is not None and value > 0 and _metadata_only(row[offset+1:]):
                    target = widths if row[0] == 'minWidth' else spaces
                    target[name] = max(value, target.get(name, 0))
                elif name in metals:
                    ignored.append({'section': secname, 'layer': name, 'raw': row})
    for sec in sections(tree, 'spacingTables'):
        for row in sec[1:]:
            if not isinstance(row, list) or len(row) < 2 or row[0] != 'minSpacing':
                continue
            name = _single_layer(row[1])
            if name not in metals:
                continue
            values = _table_values(row[2], row[3], params) if len(row) == 4 else None
            if values:
                spaces[name] = max(spaces.get(name, 0), *values)
                warnings.append(f'{name}: using maximum width/length table spacing {max(values):g}; review PDK conditions')
            else:
                ignored.append({'section': 'spacingTables', 'layer': name, 'raw': row})
    vias = []
    order = {name: i for i, name in enumerate(metals)}
    for sec in sections(tree, 'standardViaDefs'):
        for row in sec[1:]:
            if not isinstance(row, list) or len(row) < 3 or row[1] not in metals or row[2] not in metals:
                continue
            try:
                if len(row) != 10:
                    raise ValueError('expected 10 fields; extra implant/layer geometry is unsupported')
                cut, array, enc1, enc2, off1, off2, origin = row[3:10]
                if not (isinstance(cut, list) and len(cut) in (3, 4) and
                        isinstance(array, list) and len(array) == 3 and
                        all(isinstance(v, list) and len(v) == 2 for v in
                            (array[2], enc1, enc2, off1, off2, origin))):
                    raise ValueError('malformed geometry vectors')
                vals = [number(v, params) for v in (cut[1], cut[2], *array[2], *enc1, *enc2)]
                offsets = [number(v, params) for vector in (off1, off2, origin) for v in vector]
                if any(v is None for v in vals + offsets) or any(v != 0 for v in offsets):
                    raise ValueError('nonliteral geometry or nonzero offsets need a footprint adapter')
                if min(vals[:2]) <= 0 or min(vals[2:]) < 0:
                    raise ValueError('invalid dimensions')
                lower, upper = str(row[1]), str(row[2])
                ea, eb = vals[4:6], vals[6:8]
                if order[lower] > order[upper]:
                    lower, upper, ea, eb = upper, lower, eb, ea
                vias.append(dict(name=str(row[0]), lower=lower, upper=upper,
                                 cut_layer=str(cut[0]), cut=vals[:2], cut_space=vals[2:4],
                                 enc_lower=ea, enc_upper=eb))
            except (ValueError, IndexError, TypeError) as exc:
                skipped_vias.append({'name': str(row[0]), 'reason': str(exc), 'raw': row})
    usable_names = {v['name'] for v in vias}
    for entry in catalog:
        entry['routable'] = entry['kind'] == 'standard' and entry['name'] in usable_names
        if entry['kind'] == 'custom' and entry['layers'] and all(n in metals for n in entry['layers']):
            skipped_vias.append({'name': entry['name'], 'reason': 'custom via cell geometry needs a native footprint adapter',
                                 'raw': entry['raw']})
    grid = None
    for sec in sections(tree, 'mfgGridResolution'):
        if len(sec) == 2:
            value = sec[1]
            if isinstance(value, list) and len(value) == 1:
                value = value[0]
            candidate = number(value, params)
            if candidate is not None and candidate > 0:
                if grid is not None and not math.isclose(grid, candidate):
                    raise ValueError('Conflicting mfgGridResolution values; select the correct technology')
                grid = candidate
    layers = []
    for i, name in enumerate(metals, 1):
        parity = levels[name]
        preferred = direction.get(name) if pattern == 'tech' else (
            'H' if (parity % 2 == 1) == (pattern == 'odd-h-even-v') else 'V')
        width = widths.get(name)
        if width is not None and grid is not None:
            rounded = pad_size(width, grid)
            if not math.isclose(width, rounded, rel_tol=0, abs_tol=1e-12):
                warnings.append(f'{name}: width rounded outward {width:g} -> {rounded:g} to keep both edges on grid')
            width = rounded
        layers.append(dict(name=name, width=width, space=spaces.get(name), direction=preferred))
    for a in metals:
        for b in stack_report['graph'][a]:
            if order[a] < order[b] and not any({v['lower'], v['upper']} == {a, b} for v in vias):
                warnings.append(f'Via relationship {a} <-> {b} was discovered but has no usable footprint seed')
    warnings.append('Dimensions are technology user units; verify maskLayout units are microns. Text parsing is not signoff DRC.')
    if ignored:
        warnings.append('Unsupported/conditional rules are recorded; review them before using the configuration')
    return dict(techfile=str(path.resolve()), grid=grid, pitch=0.5, margin=20.0,
                max_distance=300.0, max_nodes=600000, max_array=6,
                extra_clearance=0.05, via_mode='auto_preferred',
                via_constraint_group='CURRENT', obstacle_purposes=['*'], route_bounds=None,
                stack_reviewed=stack is not None,
                layers=layers, vias=vias,
                _extract_report=dict(source_sha256=hashlib.sha256(text.encode()).hexdigest(),
                                     pattern=pattern, warnings=warnings, ignored_rules=ignored,
                                     discovered_metals=discovered_metals, via_catalog=catalog,
                                     metal_stack=stack_report, skipped_vias=skipped_vias, unresolved=[]))


def apply_overrides(config, overrides):
    if not isinstance(overrides, dict):
        raise ValueError('Overrides must be a JSON object')
    allowed = {'grid', 'pitch', 'margin', 'max_distance', 'max_nodes', 'max_array',
               'extra_clearance', 'via_mode', 'via_constraint_group',
               'obstacle_purposes', 'route_bounds', 'stack_reviewed'}
    unknown = set(overrides) - allowed - {'layers', 'vias'}
    if unknown:
        raise ValueError(f'Unknown override keys: {sorted(unknown)}')
    for key in allowed & set(overrides):
        config[key] = overrides[key]
    for kind, fields in (('layers', {'width', 'space', 'direction'}),
                         ('vias', {'cut_layer', 'cut', 'cut_space', 'enc_lower', 'enc_upper'})):
        edits = overrides.get(kind, {})
        if not isinstance(edits, dict):
            raise ValueError(f'Override {kind} must be keyed by exact names')
        lookup = {row['name']: row for row in config[kind]}
        for name, changes in edits.items():
            if name not in lookup:
                raise ValueError(f'Unknown {kind} override {name}; M5 and METAL5 are not automatic aliases')
            if not isinstance(changes, dict) or set(changes) - fields:
                raise ValueError(f'Unsupported fields in {kind} override {name}')
            lookup[name].update(changes)
    return config


def skill_string(s):
    return json.dumps(s, ensure_ascii=False)


def obstacle_query_halo(config):
    layers = {layer['name']: layer for layer in config['layers']}
    extra = config['extra_clearance']
    halo = max(layer['width'] / 2 + layer['space'] + extra for layer in layers.values())
    max_array = int(config['max_array'])
    for via in config['vias']:
        for name, enclosure in ((via['lower'], via['enc_lower']), (via['upper'], via['enc_upper'])):
            layer = layers[name]
            for axis in (0, 1):
                cut_span = max_array * via['cut'][axis] + (max_array-1)*via['cut_space'][axis]
                pad_span = pad_size(max(layer['width'], cut_span+2*enclosure[axis]), config['grid'])
                halo = max(halo, pad_span/2+layer['space']+extra)
    return halo + config['grid']


def atomic_text(path, text):
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(text, encoding='utf-8')
    temp.replace(path)


def compile_skill(config, target: Path):
    validate_config(config)
    purposes = config.get('obstacle_purposes', ['*'])
    bounds = config.get('route_bounds')
    lines = ['; Generated from route_config.json. Edit JSON and re-run --compile.', 'arLayers = list(']
    for layer in config['layers']:
        lines.append('    list(%s %.15g %.15g %s)' % (skill_string(layer['name']), layer['width'],
                     layer['space'], skill_string(layer['direction'])))
    lines += [')', 'arVias = list(']
    for via in config['vias']:
        lines.append('    list(%s %s %s %s %.15g %.15g %.15g %.15g %.15g %.15g %.15g %.15g)' % (
            skill_string(via['name']), skill_string(via['lower']), skill_string(via['upper']),
            skill_string(via['cut_layer']), *via['cut'], *via['cut_space'], *via['enc_lower'], *via['enc_upper']))
    lines += [')', f'arConfigSHA = {skill_string(config_fingerprint(config))}',
              f'arGrid = {config["grid"]:.15g}', f'arRouteMargin = {config["margin"]:.15g}',
              f'arObstacleQueryHalo = {obstacle_query_halo(config):.15g}',
              'arObstaclePurposes = list(%s)' % ' '.join(skill_string(p) for p in purposes),
              ('arRouteBounds = list(%s)' % ' '.join(f'{v:.15g}' for v in bounds) if bounds is not None else 'arRouteBounds = nil'),
              f'arExtraClearance = {config["extra_clearance"]:.15g}',
              f'arViaMode = {skill_string(config.get("via_mode", "auto_preferred"))}',
              f'arViaGroup = {skill_string(config.get("via_constraint_group", "CURRENT"))}']
    atomic_text(target, '\n'.join(lines) + '\n')


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--techfile', type=Path)
    ap.add_argument('--config', type=Path, default=Path('route_config.json'))
    ap.add_argument('--compile', action='store_true', help='compile edited JSON only')
    ap.add_argument('--overrides', type=Path, help='manual values keyed by exact layer/via names')
    ap.add_argument('--pattern', choices=('odd-h-even-v', 'even-h-odd-v', 'tech'), default='odd-h-even-v')
    ap.add_argument('--stack', help='explicit bottom-to-top comma-separated metal names; a subset may be selected')
    ap.add_argument('--force', action='store_true', help='replace existing JSON explicitly')
    ap.add_argument('--draft', action='store_true', help='write reviewable JSON without compiling SKILL')
    args = ap.parse_args(argv)
    if args.compile and (args.techfile or args.overrides or args.draft or args.stack):
        ap.error('--compile cannot be combined with --techfile, --overrides, --stack or --draft')
    try:
        if args.compile:
            config = json.loads(args.config.read_text(encoding='utf-8'))
        else:
            if not args.techfile:
                ap.error('--techfile is required unless --compile is given')
            if args.config.exists() and not args.force:
                ap.error(f'{args.config} already exists; use a different --config or --force to preserve manual edits')
            explicit = [n.strip() for n in args.stack.split(',')] if args.stack else None
            config = extract(args.techfile, args.pattern, explicit)
            if args.overrides:
                apply_overrides(config, json.loads(args.overrides.read_text(encoding='utf-8')))
            issues = config_issues(config)
            config['_extract_report']['unresolved'] = issues
            atomic_text(args.config, json.dumps(config, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
            for warning in config['_extract_report']['warnings']:
                print('WARNING: ' + warning, file=sys.stderr)
            if issues or args.draft:
                print(f'Wrote draft {args.config}; SKILL was not compiled.', file=sys.stderr)
                if issues:
                    print('Unresolved:\n  ' + '\n  '.join(issues), file=sys.stderr)
                    print('Fill this JSON, then run --compile --config ' + str(args.config), file=sys.stderr)
                return 2 if issues else 0
        compile_skill(config, args.config.with_name('route_config.il'))
        print(f'Wrote {args.config.with_name("route_config.il")} from {args.config}')
        return 0
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
