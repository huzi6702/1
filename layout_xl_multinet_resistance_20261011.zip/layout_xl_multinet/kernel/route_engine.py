#!/usr/bin/env python3
"""Conservative, net-agnostic multilayer rectilinear router for Virtuoso exports."""
from __future__ import annotations

import argparse
import bisect
import copy
import hashlib
import heapq
import json
import math
import sys
import time
from collections import defaultdict
from pathlib import Path

from config_validation import config_fingerprint, finite_number, pad_size, validate_config
from build_config import atomic_text, obstacle_query_halo
from routing_cost import RoutingCost


def intersects(a, b):
    return a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]


def get_route_bounds(cfg):
    bounds = cfg.get('route_bounds')
    if bounds is None:
        return None
    if (not isinstance(bounds, list) or len(bounds) != 4 or
            any(isinstance(value, bool) or not isinstance(value, (int, float)) or
                not math.isfinite(value) for value in bounds) or
            bounds[0] >= bounds[2] or bounds[1] >= bounds[3]):
        raise ValueError('route_bounds must be [xmin, ymin, xmax, ymax] or null')
    return tuple(bounds)


def inside_bounds(box, bounds):
    return (bounds is None or
            (bounds[0] <= box[0] and bounds[1] <= box[1] and
             box[2] <= bounds[2] and box[3] <= bounds[3]))


class Polygon:
    """A metal polygon; its bounding box is only a spatial-index filter."""
    __slots__ = ('points', 'bbox')

    def __init__(self, points):
        if len(points) < 3:
            raise ValueError('Metal polygon has fewer than three vertices')
        self.points = tuple(points)
        self.bbox = (min(p[0] for p in points), min(p[1] for p in points),
                     max(p[0] for p in points), max(p[1] for p in points))
        if not self.bbox[0] < self.bbox[2] or not self.bbox[1] < self.bbox[3]:
            raise ValueError('Metal polygon has zero area')


class EndpointPath:
    """Selected path centerline; only an unambiguous straight part is adapted."""
    def __init__(self, points, width):
        if not finite_number(width) or width <= 0 or len(points) < 2:
            raise ValueError('Invalid endpoint path width/points')
        self.points, self.width = tuple(points), width
        for a, b in zip(points, points[1:]):
            if (a[0] == b[0]) == (a[1] == b[1]):
                raise ValueError('Endpoint path must have nonzero Manhattan segments')
        r = width/2
        self.bbox = (min(p[0] for p in points)-r, min(p[1] for p in points)-r,
                     max(p[0] for p in points)+r, max(p[1] for p in points)+r)


def shape_bbox(shape):
    return shape.bbox if isinstance(shape, (Polygon, EndpointPath)) else shape


def point_in_shape(point, shape):
    if isinstance(shape, Polygon):
        return point_in_polygon(point, shape)
    if isinstance(shape, EndpointPath):
        r = shape.width/2
        return any(min(a[0], b[0])-r <= point[0] <= max(a[0], b[0])+r and
                   min(a[1], b[1])-r <= point[1] <= max(a[1], b[1])+r
                   for a, b in zip(shape.points, shape.points[1:]))
    return shape[0] <= point[0] <= shape[2] and shape[1] <= point[1] <= shape[3]


def point_on_edge(p, a, b):
    cross = (b[0]-a[0])*(p[1]-a[1]) - (b[1]-a[1])*(p[0]-a[0])
    return (abs(cross) <= 1e-9 and
            min(a[0], b[0])-1e-9 <= p[0] <= max(a[0], b[0])+1e-9 and
            min(a[1], b[1])-1e-9 <= p[1] <= max(a[1], b[1])+1e-9)


def point_in_polygon(p, polygon):
    inside = False
    for a, b in zip(polygon.points, polygon.points[1:] + polygon.points[:1]):
        if point_on_edge(p, a, b):
            return True
        if (a[1] > p[1]) != (b[1] > p[1]):
            x_crossing = a[0] + (p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])
            if p[0] < x_crossing:
                inside = not inside
    return inside


def segment_hits_rect(a, b, rect):
    """Liang-Barsky clipping, including a touch at the rectangle boundary."""
    dx, dy = b[0]-a[0], b[1]-a[1]
    low, high = 0.0, 1.0
    for p, q in ((-dx, a[0]-rect[0]), (dx, rect[2]-a[0]),
                 (-dy, a[1]-rect[1]), (dy, rect[3]-a[1])):
        if abs(p) <= 1e-12:
            if q < 0:
                return False
        else:
            t = q/p
            if p < 0:
                low = max(low, t)
            else:
                high = min(high, t)
            if low > high:
                return False
    return True


def polygon_hits_rect(polygon, rect):
    if not intersects(polygon.bbox, rect):
        return False
    x0, y0, x1, y1 = rect
    if any(x0 <= x <= x1 and y0 <= y <= y1 for x, y in polygon.points):
        return True
    if any(point_in_polygon(p, polygon) for p in
           ((x0, y0), (x0, y1), (x1, y0), (x1, y1))):
        return True
    return any(segment_hits_rect(a, b, rect) for a, b in
               zip(polygon.points, polygon.points[1:] + polygon.points[:1]))


def shape_hits_box(shape, box):
    return (polygon_hits_rect(shape, box) if isinstance(shape, Polygon)
            else intersects(box, shape))


class Index:
    """Static per-layer BVH; boxes prune candidates, exact shapes decide hits."""
    def __init__(self, shapes):
        self.shapes = shapes
        self.boxes = [shape_bbox(shape) for shape in shapes]
        self.nodes = []
        self.query_count = self.candidate_tests = 0
        def build(ids):
            boxes = self.boxes
            bounds = (min(boxes[i][0] for i in ids), min(boxes[i][1] for i in ids),
                      max(boxes[i][2] for i in ids), max(boxes[i][3] for i in ids))
            slot = len(self.nodes)
            self.nodes.append(None)
            if len(ids) <= 8:
                self.nodes[slot] = (bounds, None, None, tuple(ids))
            else:
                axis = 0 if bounds[2]-bounds[0] >= bounds[3]-bounds[1] else 1
                ids.sort(key=lambda i: boxes[i][axis]+boxes[i][axis+2])
                middle = len(ids)//2
                left, right = build(ids[:middle]), build(ids[middle:])
                self.nodes[slot] = (bounds, left, right, ())
            return slot
        if shapes:
            build(list(range(len(shapes))))

    def any(self, box):
        self.query_count += 1
        pending = [0] if self.nodes else []
        while pending:
            bounds, left, right, ids = self.nodes[pending.pop()]
            if not intersects(bounds, box):
                continue
            if left is not None:
                pending.extend((left, right))
                continue
            for i in ids:
                self.candidate_tests += 1
                if intersects(self.boxes[i], box) and shape_hits_box(self.shapes[i], box):
                    return True
        return False


class Geometry(tuple):
    def __new__(cls, source, target, metals, globals_, endpoint_shapes=None,
                metal_records=None, global_records=None, source_path=None):
        value = super().__new__(cls, (source, target, metals, globals_))
        value.endpoint_shapes = endpoint_shapes or {}
        value.metal_records = metal_records or {}
        value.global_records = global_records or []
        value.source_path = str(source_path) if source_path is not None else None
        value.endpoint_kinds = {}
        return value


def _values(parts):
    values = tuple(map(float, parts))
    if not all(math.isfinite(v) for v in values):
        raise ValueError('Nonfinite geometry coordinate')
    return values


def _box(parts):
    box = _values(parts)
    if len(box) != 4 or box[0] >= box[2] or box[1] >= box[3]:
        raise ValueError('Invalid geometry rectangle')
    return box


def read_geometry(path):
    source = target = None
    metals = defaultdict(list)
    globals_ = []
    endpoint_shapes = {}
    endpoint_kinds = {}
    metal_records = defaultdict(list)
    global_records = []
    for line_number, raw in enumerate(path.read_text().splitlines(), 1):
        parts = raw.split()
        if not parts:
            continue
        tag = parts[0]
        if tag == 'E' and len(parts) == 7:
            if source is not None:
                raise ValueError('Duplicate endpoint record')
            source = (parts[1], *_values(parts[2:4]))
            target = (parts[4], *_values(parts[5:7]))
        elif tag in ('O', 'VO') and len(parts) == 6:
            # VO is an existing via bbox on ONE actual conductor layer. It
            # deliberately shares the per-layer index and every safety check
            # with metal. Only legacy/unknown X boxes apply to all layers.
            metals[parts[1]].append(_box(parts[2:]))
            metal_records[parts[1]].append(dict(line=line_number, tag=tag))
        elif tag == 'P' and len(parts) >= 9:
            count = int(parts[2])
            if len(parts) != 3 + 2*count:
                raise ValueError(f'Bad polygon vertex count: {raw}')
            values = _values(parts[3:])
            metals[parts[1]].append(Polygon(tuple(zip(values[::2], values[1::2]))))
            metal_records[parts[1]].append(dict(line=line_number, tag=tag))
        elif tag == 'X' and len(parts) == 5:
            globals_.append(_box(parts[1:]))
            global_records.append(dict(line=line_number, tag=tag))
        elif tag in ('A', 'B', 'AR', 'BR') and len(parts) == 6:
            endpoint_shapes[tag[0]] = (parts[1], _box(parts[2:]))
            endpoint_kinds[tag[0]] = 'rect' if len(tag) == 2 else 'legacy_bbox'
        elif tag in ('AP', 'BP') and len(parts) >= 9:
            count = int(parts[2])
            if len(parts) != 3 + 2*count:
                raise ValueError('Bad endpoint polygon vertex count')
            values = _values(parts[3:])
            endpoint_shapes[tag[0]] = (parts[1], Polygon(tuple(zip(values[::2], values[1::2]))))
            endpoint_kinds[tag[0]] = 'polygon'
        elif tag in ('AT', 'BT') and len(parts) >= 8:
            width, = _values(parts[2:3])
            count = int(parts[3])
            if len(parts) != 4+2*count:
                raise ValueError('Bad endpoint path vertex count')
            values = _values(parts[4:])
            endpoint_shapes[tag[0]] = (parts[1], EndpointPath(tuple(zip(values[::2], values[1::2])), width))
            endpoint_kinds[tag[0]] = 'path'
        else:
            raise ValueError(f'Bad geometry record: {raw}')
    if source is None or target is None:
        raise ValueError('Missing endpoints')
    result = Geometry(source, target, metals, globals_, endpoint_shapes,
                      metal_records, global_records, path)
    result.endpoint_kinds = endpoint_kinds
    return result


def geometry_summary(geo):
    """Physical-layer counts before endpoint aliases; VO counts layer boxes."""
    via_boxes = {name: sum(record['tag'] == 'VO' for record in records)
                 for name, records in getattr(geo, 'metal_records', {}).items()}
    return dict(layer_shapes={name: len(shapes) for name, shapes in sorted(geo[2].items())},
                scoped_via_boxes={name: count for name, count in sorted(via_boxes.items()) if count},
                global_boxes=len(geo[3]))


def on_grid(value, grid):
    return math.isclose(value/grid, round(value/grid), rel_tol=0, abs_tol=1e-6)


def _endpoints(cfg, geo):
    for tag, endpoint in zip(('A', 'B'), geo[:2]):
        if not all(finite_number(v) for v in endpoint[1:]):
            raise ValueError('Nonfinite endpoint')
        if not all(on_grid(v, cfg['grid']) for v in endpoint[1:]):
            raise ValueError('Endpoint must be snapped to manufacturing grid before picking its metal')
        if tag in getattr(geo, 'endpoint_shapes', {}):
            name, shape = geo.endpoint_shapes[tag]
            point = endpoint[1:]
            inside = point_in_shape(point, shape)
            if name != endpoint[0] or not inside:
                raise ValueError('Endpoint no longer lies on its selected metal')


def _polygon_span(shape, point, axis):
    # axis=0 scans x at fixed y; axis=1 scans y at fixed x.
    other = 1-axis
    crossings = []
    for a, b in zip(shape.points, shape.points[1:]+shape.points[:1]):
        if a[0] != b[0] and a[1] != b[1]:
            raise ValueError('Endpoint polygon must be Manhattan')
        if (a[other] > point[other]) != (b[other] > point[other]):
            crossings.append(a[axis])
    crossings.sort()
    for low, high in zip(crossings[::2], crossings[1::2]):
        if low <= point[axis] <= high:
            return low, high
    raise ValueError('Pick inside a straight endpoint section, away from corners/edges')


def endpoint_section(shape, point, preferred):
    if isinstance(shape, EndpointPath):
        choices = []
        r = shape.width/2
        for a, b in zip(shape.points, shape.points[1:]):
            axis = 0 if a[1] == b[1] else 1
            other = 1-axis
            low, high = sorted((a[axis], b[axis]))
            if low < point[axis] < high and abs(point[other]-a[other]) <= r:
                anchor = list(point)
                anchor[other] = a[other]
                box = ((low, a[1]-r, high, a[1]+r) if axis == 0 else
                       (a[0]-r, low, a[0]+r, high))
                choices.append(('H' if axis == 0 else 'V', shape.width, tuple(anchor), box))
        if len(choices) != 1:
            raise ValueError('Endpoint path is ambiguous at this click; pick a straight section away from a bend/cap')
        return choices[0]
    if isinstance(shape, Polygon):
        x0,y0,x1,y1 = shape.bbox
        if set(shape.points) == {(x0,y0),(x0,y1),(x1,y0),(x1,y1)}:
            return endpoint_section(shape.bbox,point,preferred)
        xspan, yspan = _polygon_span(shape, point, 0), _polygon_span(shape, point, 1)
        lengths = (xspan[1]-xspan[0],yspan[1]-yspan[0])
        if max(lengths) <= 2*min(lengths):
            raise ValueError('Endpoint polygon direction is ambiguous; pick a straight narrow section away from a junction')
        direction = ('H' if xspan[1]-xspan[0] > yspan[1]-yspan[0] else
                     'V' if yspan[1]-yspan[0] > xspan[1]-xspan[0] else preferred)
        longitudinal = 0 if direction == 'H' else 1
        transverse = 1-longitudinal
        span = xspan if transverse == 0 else yspan
        values = sorted({p[longitudinal] for p in shape.points})
        if point[longitudinal] in values:
            raise ValueError('Endpoint polygon click is at a section boundary; pick inside its straight part')
        low = max(v for v in values if v < point[longitudinal])
        high = min(v for v in values if v > point[longitudinal])
        anchor = list(point)
        anchor[transverse] = (span[0]+span[1])/2
        box = (low, span[0], high, span[1]) if direction == 'H' else (span[0], low, span[1], high)
        return direction, span[1]-span[0], tuple(anchor), box
    x0, y0, x1, y1 = shape
    direction = 'V' if y1-y0 > x1-x0 else 'H' if x1-x0 > y1-y0 else preferred
    return (('V', x1-x0, ((x0+x1)/2, point[1]), shape) if direction == 'V' else
            ('H', y1-y0, (point[0], (y0+y1)/2), shape))


def endpoint_covered_obstacles(geo, fits, grid):
    """Remove only same-layer shapes entirely covered by selected real metal.

    The obstacle bbox is an upper bound on its occupied area. The fitted
    straight section is inside the endpoint metal, NOT its overall bbox.
    Containing that entire obstacle box therefore proves it adds no conductor
    area outside the selected endpoint. No connectivity flood-fill is done.
    """
    regions = []
    for fit in fits:
        box = list(fit['section'])
        shape = geo.endpoint_shapes[fit['tag']][1]
        if isinstance(shape, EndpointPath):
            # Use the straight interior only; do not exempt a shape using a
            # path's bend/cap or its much larger overall bounding rectangle.
            axis = 0 if fit['direction'] == 'H' else 1
            box[axis] += fit['width']/2
            box[axis+2] -= fit['width']/2
        if box[0] < box[2] and box[1] < box[3]:
            regions.append((fit['tag'], fit['layer'], tuple(box)))
    metals, records, covered = {}, {}, []
    for name, shapes in geo[2].items():
        source_records = getattr(geo, 'metal_records', {}).get(name, [])
        metals[name], records[name] = [], []
        for number, shape in enumerate(shapes):
            record = source_records[number] if number < len(source_records) else {}
            bbox = shape_bbox(shape)
            owner = None
            for tag, layer, region in regions:
                if name != layer:
                    continue
                # Account only for binary floating arithmetic in width/2 and
                # centerline calculations; do NOT use grid/spacing as tolerance.
                # The grid only caps tolerance at a tiny fraction of one step;
                # it does not grant a physical overhang at large coordinates.
                epsilon = min(grid*1e-6, 8*sys.float_info.epsilon*
                              max(abs(value) for value in (*bbox, *region)))
                if (region[0]-epsilon <= bbox[0] and region[1]-epsilon <= bbox[1] and
                        bbox[2] <= region[2]+epsilon and bbox[3] <= region[3]+epsilon):
                    owner = (tag, region)
                    break
            if owner:
                covered.append(dict(endpoint=owner[0], layer=name, line=record.get('line'),
                                    tag=record.get('tag', 'P' if isinstance(shape, Polygon) else 'O'),
                                    bbox=bbox, selected_section=owner[1],
                                    reason='entire_obstacle_bbox_inside_selected_metal_section'))
            else:
                metals[name].append(shape)
                records[name].append(record)
    return metals, records, covered


def prepare_route(cfg, geo):
    """Build source-only/target-only width profiles from true selected geometry."""
    validate_config(cfg)
    _endpoints(cfg, geo)
    if getattr(geo, 'prepared', False):
        return cfg, geo, geo.adapter
    base_layers = {x['name']: x for x in cfg['layers']}
    work = copy.deepcopy(cfg)
    physical = {name: name for name in base_layers}
    roles, fits = {}, []
    endpoints = list(geo[:2])
    shapes = dict(getattr(geo, 'endpoint_shapes', {}))
    used_names = set(physical)
    def unique(base, used):
        name = base
        while name in used:
            name += '_'
        used.add(name)
        return name
    for i, tag in enumerate(('A', 'B')):
        name, x, y = geo[i]
        if name not in base_layers:
            raise ValueError('Endpoint layer is absent from config')
        if tag not in shapes:
            # Explicit synthetic/manual E-only inputs retain their coordinates.
            continue
        if getattr(geo, 'endpoint_kinds', {}).get(tag) == 'legacy_bbox':
            raise ValueError('Endpoint '+tag+' is an old bbox-only record; update autoroute.il and rerun F8 to export real rect/path geometry')
        shape = shapes[tag][1]
        direction, width, anchor, section = endpoint_section(shape, (x, y), base_layers[name]['direction'])
        if not all(on_grid(v, cfg['grid']) for v in anchor) or not on_grid(width/2, cfg['grid']):
            raise ValueError('Endpoint '+tag+' centerline/half-width is off the configured grid; no offset or width rounding was applied')
        # Canonicalize only floating-point noise after proving exact grid fit.
        anchor = tuple(round(v/cfg['grid'])*cfg['grid'] for v in anchor)
        width = round(width/(2*cfg['grid']))*(2*cfg['grid'])
        if not point_in_shape(anchor, shape):
            raise ValueError('Endpoint centerline does not lie inside the selected actual metal')
        profile = unique('__ar_endpoint_'+tag, used_names)
        physical[profile] = name
        roles[profile] = dict(role='source' if i == 0 else 'target', anchor=anchor, direction=direction)
        work['layers'].append(dict(base_layers[name], name=profile, width=width, direction=direction))
        endpoints[i] = (profile, *anchor)
        shapes[tag] = (profile, shape)
        fits.append(dict(tag=tag, layer=name, clicked=[x,y], anchor=anchor,
                         width=width, direction=direction, configured_direction=base_layers[name]['direction'],
                         section=section, profile=profile))
    # There are no edges between profiles of the same physical metal. A width
    # change requires an actual via transition to another physical metal.
    via_map = {}
    expanded_vias = []
    used_vias = {v['name'] for v in cfg['vias']}
    for via in cfg['vias']:
        lowers = [key for key, name in physical.items() if name == via['lower']]
        uppers = [key for key, name in physical.items() if name == via['upper']]
        for lower in lowers:
            for upper in uppers:
                name = via['name'] if (lower,upper) == (via['lower'],via['upper']) else unique('__ar_via_'+via['name'], used_vias)
                expanded_vias.append(dict(via, name=name, lower=lower, upper=upper))
                via_map[name] = via['name']
    work['vias'] = expanded_vias
    work['_endpoint_roles'] = roles
    work['_physical_layers'] = physical
    work['_physical_vias'] = via_map
    work['_endpoint_fits'] = fits
    physical_metals, physical_records, covered = endpoint_covered_obstacles(geo, fits, cfg['grid'])
    metals = {key: physical_metals.get(name, []) for key, name in physical.items()}
    records = {key: physical_records.get(name, []) for key, name in physical.items()}
    prepared = Geometry(endpoints[0], endpoints[1], metals, geo[3], shapes, records,
                        getattr(geo,'global_records',[]), getattr(geo,'source_path',None))
    adapter = dict(physical=physical, vias=via_map, fits=fits,
                   physical_metals=physical_metals, physical_records=physical_records,
                   endpoint_covered=covered,
                   via_inverse={(via_map[v['name']],v['lower'],v['upper']):v['name'] for v in expanded_vias})
    prepared.prepared, prepared.adapter = True, adapter
    validate_config(work)
    return work, prepared, adapter


def external_route(items, adapter):
    result = copy.deepcopy(items)
    for item in result:
        if item['kind'] == 'segment':
            name = item['layer']
            item['layer'] = adapter['physical'][name]
            if name != item['layer']:
                item['routing_profile'] = name
        else:
            item['name'] = adapter['vias'][item['name']]
            profiles = [pad['layer'] for pad in item['pads']]
            for pad in item['pads']:
                pad['layer'] = adapter['physical'][pad['layer']]
            if profiles != [pad['layer'] for pad in item['pads']]:
                item['routing_profiles'] = profiles
    return result


def internal_route(items, adapter):
    if not isinstance(items, list):
        raise ValueError('Empty or malformed route')
    result = copy.deepcopy(items)
    for item in result:
        if not isinstance(item, dict):
            raise ValueError('Malformed route item')
        if item.get('kind') == 'segment':
            name = item.get('routing_profile', item.get('layer'))
            if adapter['physical'].get(name) != item.get('layer'):
                raise ValueError('Invalid route width profile')
            item['layer'] = name
        elif item.get('kind') == 'via':
            pads = item.get('pads', [])
            if len(pads) != 2 or any(not isinstance(p,dict) for p in pads):
                raise ValueError('Invalid via pads')
            profiles = item.get('routing_profiles', [p.get('layer') for p in pads])
            if not isinstance(profiles,list) or len(profiles) != 2:
                raise ValueError('Invalid via profiles')
            name = adapter['via_inverse'].get((item.get('name'), *profiles))
            if name is None or any(adapter['physical'].get(n) != p.get('layer') for n,p in zip(profiles,pads)):
                raise ValueError('Via profiles do not match current endpoint widths')
            item['name'] = name
            for name, pad in zip(profiles,pads):
                pad['layer'] = name
    return result


def endpoint_clearance_report(cfg, geo, max_examples=6):
    cfg, geo, adapter = prepare_route(cfg, geo)
    report = _endpoint_clearance_report(cfg, geo, max_examples)
    for item in report['endpoints']:
        item['layer'] = adapter['physical'][item['layer']]
    report['endpoint_fit'] = adapter['fits']
    report['endpoint_covered_count'] = len(adapter['endpoint_covered'])
    report['endpoint_covered_examples'] = adapter['endpoint_covered'][:12]
    return report


def _endpoint_clearance_report(cfg, geo, max_examples=6):
    """Use the router's collision predicate; never exempt a reported obstacle."""
    validate_config(cfg)
    _endpoints(cfg, geo)
    if isinstance(max_examples, bool) or not isinstance(max_examples, int) or max_examples < 1:
        raise ValueError('max_examples must be a positive integer')
    layers = {layer['name']: layer for layer in cfg['layers']}
    bounds = get_route_bounds(cfg)
    source, target, metals, globals_ = geo
    report = dict(geometry_file=getattr(geo, 'source_path', None), route_bounds=bounds,
                  endpoints=[], note='O records can be conservative path bounding boxes; '
                  'VO records are existing via boxes on the named layer only. '
                  'X records are global via/unknown bounding boxes applied to every routing layer. '
                  'The report identifies collisions in the exported model, not physical connectivity.')
    for role, endpoint in zip(('A/source', 'B/target'), (source, target)):
        name, x, y = endpoint
        if name not in layers:
            raise ValueError('Endpoint layer is absent from config')
        layer = layers[name]
        half_width = layer['width']/2
        radius = half_width+layer['space']+cfg['extra_clearance']
        footprint = (x-half_width, y-half_width, x+half_width, y+half_width)
        clearance_box = (x-radius, y-radius, x+radius, y+radius)
        endpoint_report = dict(role=role, layer=name, point=(x, y), width=layer['width'],
                               space=layer['space'], extra_clearance=cfg['extra_clearance'],
                               clearance_radius=radius, metal_footprint=footprint,
                               clearance_box=clearance_box,
                               inside_route_bounds=inside_bounds(footprint, bounds),
                               metal_blockers=0, global_blockers=0, blocker_examples=[])
        groups = (('metal', metals.get(name, []), getattr(geo, 'metal_records', {}).get(name, [])),
                  ('global', globals_, getattr(geo, 'global_records', [])))
        for category, shapes, records in groups:
            samples = []
            for index, shape in enumerate(shapes):
                if not shape_hits_box(shape, clearance_box):
                    continue
                endpoint_report[category+'_blockers'] += 1
                if len(samples) < max_examples:
                    record = records[index] if index < len(records) else {}
                    samples.append(dict(category=category, line=record.get('line'),
                                        tag=record.get('tag', 'P' if isinstance(shape, Polygon)
                                                       else 'X' if category == 'global' else 'O'),
                                        bbox=shape_bbox(shape),
                                        hits_metal_footprint=shape_hits_box(shape, footprint),
                                        representation='polygon' if isinstance(shape, Polygon)
                                        else 'rectangle_or_conservative_bbox'))
            endpoint_report['blocker_examples'].extend(samples)
        endpoint_report['clear'] = (endpoint_report['inside_route_bounds'] and
                                    not endpoint_report['metal_blockers'] and
                                    not endpoint_report['global_blockers'])
        report['endpoints'].append(endpoint_report)
    report['clear'] = all(item['clear'] for item in report['endpoints'])
    return report


def format_endpoint_report(report, failures_only=False):
    def coords(values):
        return '['+', '.join(f'{value:.12g}' for value in values)+']'
    lines = ['Endpoint clearance check '+('PASS' if report['clear'] else 'FAILED')]
    if report['geometry_file']:
        lines.append('  geometry: '+report['geometry_file'])
    if report.get('endpoint_covered_count'):
        lines.append(f"  endpoint-covered same-layer obstacles excluded: {report['endpoint_covered_count']}")
        for record in report['endpoint_covered_examples']:
            lines.append(f"    endpoint={record['endpoint']} layer={record['layer']} "
                         f"line={record['line']} tag={record['tag']} bbox={coords(record['bbox'])}")
    for item in report['endpoints']:
        if failures_only and item['clear']:
            continue
        lines.append(f"  {item['role']} {item['layer']} point={coords(item['point'])}: "
                     +('PASS' if item['clear'] else 'FAIL'))
        lines.append(f"    width={item['width']:.12g}, space={item['space']:.12g}, "
                     f"extra_clearance={item['extra_clearance']:.12g}, "
                     f"check_radius={item['clearance_radius']:.12g}")
        if report['route_bounds'] is None:
            lines.append('    route_bounds: null (no fixed boundary)')
        else:
            lines.append('    route_bounds: '+('PASS' if item['inside_route_bounds'] else 'FAIL')+
                         ' bounds='+coords(report['route_bounds'])+
                         ' metal_footprint='+coords(item['metal_footprint']))
        lines.append('    clearance_box='+coords(item['clearance_box']))
        lines.append(f"    blockers: same-layer metal/via={item['metal_blockers']}, "
                     f"global via/unknown bbox={item['global_blockers']}")
        for hit in item['blocker_examples']:
            location = f"line {hit['line']}" if hit['line'] is not None else 'line unknown'
            lines.append(f"      {location} tag={hit['tag']} bbox={coords(hit['bbox'])} "
                         +('intersects metal footprint' if hit['hits_metal_footprint']
                           else 'inside spacing/extra-clearance region only'))
        if item['global_blockers']:
            lines.append('    X has no layer/connectivity metadata; it may include a via on the '
                         'selected conductor or on unrelated layers. No automatic exemption was made.')
    lines.append('  O/VO/X bounding-box conflicts can be conservative; inspect the reported records '
                 'before changing routing rules.')
    return '\n'.join(lines)


def endpoint_line_ok(cfg, name, width, a, b):
    tolerance = cfg['grid']*1e-6
    role = cfg.get('_endpoint_roles', {}).get(name)
    if role:
        axis = 1 if role['direction'] == 'H' else 0
        if any(abs(p[axis]-role['anchor'][axis]) > tolerance for p in (a,b)):
            return False
    physical = cfg.get('_physical_layers', {}).get(name, name)
    footprint = (min(a[0],b[0])-width/2, min(a[1],b[1])-width/2,
                 max(a[0],b[0])+width/2, max(a[1],b[1])+width/2)
    for fit in cfg.get('_endpoint_fits', []):
        if fit['layer'] != physical or not intersects(footprint, fit['section']):
            continue
        axis = 1 if fit['direction'] == 'H' else 0
        if abs(width-fit['width']) > tolerance or any(abs(p[axis]-fit['anchor'][axis]) > tolerance for p in (a,b)):
            return False
    return True


def profile_transition_allowed(cfg, source_name, target_name):
    roles = cfg.get('_endpoint_roles', {})
    return (roles.get(source_name, {}).get('role') != 'target' and
            roles.get(target_name, {}).get('role') != 'source')


def direct_endpoint_route(cfg, geo, adapter):
    fits = adapter['fits']
    if len(fits) != 2:
        return None
    a,b = fits
    if (a['layer'], a['direction'], a['width']) != (b['layer'], b['direction'], b['width']):
        return None
    x,y = a['anchor']; u,v = b['anchor']
    if (x,y) == (u,v) or (a['direction'] == 'V' and x != u) or (a['direction'] == 'H' and y != v):
        return None
    layer = next(item for item in cfg['layers'] if item['name'] == geo[0][0])
    r = a['width']/2
    footprint = (min(x,u)-r, min(y,v)-r, max(x,u)+r, max(y,v)+r)
    if not inside_bounds(footprint, get_route_bounds(cfg)):
        return None
    clearance = layer['space']+cfg['extra_clearance']
    box = (footprint[0]-clearance, footprint[1]-clearance,
           footprint[2]+clearance, footprint[3]+clearance)
    if Index(geo[2].get(geo[0][0], [])+geo[3]).any(box):
        return None
    return [dict(kind='segment',layer=a['layer'],width=a['width'],x1=x,y1=y,x2=u,y2=v,
                 endpoint_direct=True)]


def via_geometry(via, cfg, rows=None, cols=None):
    layers = {layer['name']: layer for layer in cfg['layers']}
    a, b = layers[via['lower']], layers[via['upper']]
    usable = min(a['width'], b['width'])
    counts = []
    for axis in (0, 1):
        fit = (usable-2*max(via['enc_lower'][axis], via['enc_upper'][axis])+
               via['cut_space'][axis]) / (via['cut'][axis]+via['cut_space'][axis])
        counts.append(max(1, min(cfg['max_array'], math.floor(fit+1e-9))))
    cols = counts[0] if cols is None else cols
    rows = counts[1] if rows is None else rows
    spans = [counts_*via['cut'][axis]+(counts_-1)*via['cut_space'][axis]
             for axis, counts_ in enumerate((cols, rows))]
    pads = [dict(layer=name,
                 width=pad_size(max(layers[name]['width'], spans[0]+2*enc[0]), cfg['grid']),
                 height=pad_size(max(layers[name]['width'], spans[1]+2*enc[1]), cfg['grid']))
            for name, enc in ((via['lower'], via['enc_lower']), (via['upper'], via['enc_upper']))]
    return rows, cols, pads


class SearchExhausted(ValueError):
    def __init__(self, message, reason):
        super().__init__(message)
        self.reason = reason


def bounds_violations(box, bounds):
    if bounds is None:
        return []
    return [name for name, failed in zip(('xmin', 'ymin', 'xmax', 'ymax'),
            (box[0] < bounds[0], box[1] < bounds[1],
             box[2] > bounds[2], box[3] > bounds[3])) if failed]


def endpoint_via_report(cfg, geo):
    """Explain first/last via feasibility at anchors, without inferring no path.

    A failed anchor may still escape along its original centerline. Only a
    violation on the fixed axis proves that this candidate cannot be placed
    anywhere along that endpoint's permitted straight extension.
    """
    cfg, geo, adapter = prepare_route(cfg, geo)
    layers = {layer['name']: layer for layer in cfg['layers']}
    bounds = get_route_bounds(cfg)
    physical = adapter['physical']
    metals, records = adapter['physical_metals'], adapter['physical_records']
    indices = {name: Index(shapes) for name, shapes in metals.items()}
    globals_index = Index(geo[3])
    report = dict(route_bounds=bounds, endpoints=[],
                  note='Anchor checks only. A failed anchor may use an inline extension; '
                       'fixed-axis bounds violations cannot be fixed by that extension.')
    for tag, endpoint in zip(('A', 'B'), geo[:2]):
        name, x, y = endpoint
        direction = layers[name]['direction']
        fixed_axis = 0 if direction == 'V' else 1
        entry = dict(tag=tag, layer=physical[name], point=[x, y], direction=direction,
                     fixed_axis='x' if fixed_axis == 0 else 'y', candidates=[])
        for via in cfg['vias']:
            if name not in (via['lower'], via['upper']):
                continue
            other = via['upper'] if name == via['lower'] else via['lower']
            outgoing = (name, other) if tag == 'A' else (other, name)
            if not profile_transition_allowed(cfg, *outgoing):
                continue
            rows, cols, pads = via_geometry(via, cfg)
            candidate = dict(via=adapter['vias'][via['name']], other_layer=physical[other],
                             other_profile=other, rows=rows, cols=cols, pads=[])
            for pad in pads:
                layer_name = physical[pad['layer']]
                layer = layers[pad['layer']]
                wx, wy = pad['width'], pad['height']
                box = (x-wx/2, y-wy/2, x+wx/2, y+wy/2)
                clearance = layer['space']+cfg['extra_clearance']
                check = (box[0]-clearance, box[1]-clearance,
                         box[2]+clearance, box[3]+clearance)
                footprint = dict(layer=layer_name, width=wx, height=wy, bbox=box,
                                 bounds_violations=bounds_violations(box, bounds),
                                 space=layer['space'], extra_clearance=cfg['extra_clearance'],
                                 clearance_box=check, blockers=[], blocker_count=0)
                groups = ((metals.get(layer_name, []), records.get(layer_name, []),
                           indices.get(layer_name), 'O'),
                          (geo[3], getattr(geo, 'global_records', []), globals_index, 'X'))
                for shapes, metadata, index, fallback_tag in groups:
                    if index is None or not index.any(check):
                        continue
                    for i, shape in enumerate(shapes):
                        if shape_hits_box(shape, check):
                            footprint['blocker_count'] += 1
                            if len(footprint['blockers']) < 6:
                                record = metadata[i] if i < len(metadata) else {}
                                footprint['blockers'].append(dict(line=record.get('line'),
                                    tag=record.get('tag', fallback_tag), bbox=shape_bbox(shape)))
                candidate['pads'].append(footprint)
            fixed_sides = ('xmin', 'xmax') if fixed_axis == 0 else ('ymin', 'ymax')
            candidate['fixed_axis_bounds_blocked'] = any(
                side in pad['bounds_violations'] for side in fixed_sides for pad in candidate['pads'])
            candidate['clear_at_anchor'] = all(not pad['bounds_violations'] and
                                               not pad['blocker_count'] for pad in candidate['pads'])
            entry['candidates'].append(candidate)
        entry['clear_at_anchor_count'] = sum(c['clear_at_anchor'] for c in entry['candidates'])
        entry['all_candidates_fixed_axis_bounds_blocked'] = bool(entry['candidates']) and all(
            c['fixed_axis_bounds_blocked'] for c in entry['candidates'])
        report['endpoints'].append(entry)
    return report


def format_via_report(report):
    lines = ['Endpoint via access (anchor checks; an inline extension may find another site):',
             '  route_bounds='+str(report['route_bounds'])]
    for endpoint in report['endpoints']:
        lines.append(f'  {endpoint["tag"]} {endpoint["layer"]} point={endpoint["point"]} '
                     f'direction={endpoint["direction"]}: candidates={len(endpoint["candidates"])} '
                     f'clear_at_anchor={endpoint["clear_at_anchor_count"]}')
        if endpoint['all_candidates_fixed_axis_bounds_blocked']:
            lines.append(f'    ALL candidates violate route_bounds on fixed {endpoint["fixed_axis"]}; '
                         'moving along the permitted endpoint extension cannot fit these via pads.')
        failed = [c for c in endpoint['candidates'] if not c['clear_at_anchor']]
        for candidate in failed[:4]:
            lines.append(f'    via={candidate["via"]} other_layer={candidate["other_layer"]} '
                         f'array={candidate["rows"]}x{candidate["cols"]}')
            for pad in candidate['pads']:
                if pad['bounds_violations'] or pad['blocker_count']:
                    lines.append(f'      {pad["layer"]} pad={pad["width"]:g}x{pad["height"]:g} '
                                 f'bbox={list(pad["bbox"])} bounds_fail={pad["bounds_violations"]} '
                                 f'blockers={pad["blocker_count"]}')
                    for blocker in pad['blockers'][:2]:
                        lines.append(f'        line={blocker["line"]} tag={blocker["tag"]} '
                                     f'bbox={list(blocker["bbox"])}')
        if len(failed) > 4:
            lines.append('    More candidates are recorded in the search report.')
    return '\n'.join(lines)


def route(cfg, geo, stats=None, *, search_mode='staged', progress=None, progress_interval=5.0):
    effective, prepared, adapter = prepare_route(cfg, geo)
    if stats is not None:
        stats['endpoint_covered_count'] = len(adapter['endpoint_covered'])
        stats['endpoint_covered_examples'] = adapter['endpoint_covered'][:12]
    if math.hypot(prepared[0][1]-prepared[1][1], prepared[0][2]-prepared[1][2]) > cfg['max_distance']:
        raise ValueError('Point distance exceeds max_distance')
    metrics = stats if stats is not None else {}
    metrics['endpoint_fit'] = adapter['fits']
    direct = direct_endpoint_route(effective, prepared, adapter)
    if direct is not None and RoutingCost(cfg).mode == 'length_via':
        metrics.update(stage='direct',status='found',total_stored_states=0,total_expanded_states=0,attempts=[])
        return direct
    try:
        items = _route_stages(effective, prepared, metrics, search_mode=search_mode,
                             progress=progress, progress_interval=progress_interval)
    except ValueError as exc:
        if direct is not None:
            metrics.update(stage='direct', status='found', direct_fallback=True)
            return direct
        if metrics.get('status') == 'no_path':
            report = endpoint_via_report(effective, prepared)
            metrics['endpoint_via_access'] = report
            raise ValueError(str(exc)+'\n'+format_via_report(report)) from None
        raise
    items = external_route(items, adapter)
    if direct is not None and RoutingCost(cfg).items(direct) <= RoutingCost(cfg).items(items):
        metrics.update(stage='direct', status='found', direct_lower_cost=True)
        return direct
    return items


def _route_stages(cfg, geo, stats=None, *, search_mode='staged', progress=None, progress_interval=5.0):
    """Try smaller search graphs first, with one total state budget across passes.

    Every pass checks all obstacles. Coarse/layer-local graphs may miss a route;
    only the detailed pass uses the previous full coordinate graph. A returned
    route is feasible, not a promise of the shortest route on that full graph.
    """
    validate_config(cfg)
    if search_mode not in ('staged', 'coarse', 'layered', 'detailed'):
        raise ValueError('Unknown search mode')
    if not finite_number(progress_interval) or progress_interval < 0:
        raise ValueError('progress_interval must be finite and nonnegative')
    metrics = stats if stats is not None else {}
    attempts = []
    metrics.update(search_mode=search_mode, attempts=attempts,
                   total_stored_states=0, total_expanded_states=0, max_nodes=cfg['max_nodes'])
    started = time.monotonic()
    index_cache = {}
    modes = (['coarse', 'layered', 'detailed'] if search_mode == 'staged' and
             cfg['max_nodes'] >= 128 else
             ['detailed'] if search_mode == 'staged' else [search_mode])
    used = expanded = 0
    def announce(stage_stats, event):
        if progress is not None and progress_interval > 0:
            progress(dict(stage_stats, event=event,
                          elapsed_seconds=round(time.monotonic()-started, 3),
                          total_stored_states=used+stage_stats.get('stored_states', 0),
                          total_expanded_states=expanded+stage_stats.get('expanded_states', 0)))
    try:
        for mode in modes:
            remaining = cfg['max_nodes']-used
            limit = remaining
            if len(modes) > 1 and mode == 'coarse':
                limit = min(50000, max(1, remaining//8))
            elif len(modes) > 1 and mode == 'layered':
                limit = min(150000, max(1, remaining//3))
            stage_stats = dict(stage=mode, stage_node_limit=limit)
            status = 'error'
            retry = None
            announce(stage_stats, 'start')
            try:
                items = _route_search(cfg, geo, stage_stats, mode, limit,
                                      index_cache, announce, progress_interval)
                status = 'found'
                return items
            except SearchExhausted as exc:
                status = exc.reason
                retry = str(exc)
                if mode == modes[-1]:
                    if exc.reason == 'budget':
                        raise ValueError('Search exceeded max_nodes: '
                                         f'total_stored_states={used+stage_stats.get("stored_states", 0)}, '
                                         f'limit={cfg["max_nodes"]}; final stage: {exc}') from None
                    raise ValueError(str(exc)) from None
            finally:
                announce(stage_stats, status)
                used += stage_stats.get('stored_states', 0)
                expanded += stage_stats.get('expanded_states', 0)
                stage_stats['status'] = status
                if retry is not None:
                    stage_stats['reason'] = retry
                attempts.append(copy.deepcopy(stage_stats))
                metrics.update(stage_stats, total_stored_states=used, total_expanded_states=expanded)
    finally:
        indices = list(set(index_cache.get('metals', {}).values()))
        if 'global' in index_cache:
            indices.append(index_cache['global'])
        metrics.update(elapsed_seconds=round(time.monotonic()-started, 3),
                       collision_queries=sum(index.query_count for index in indices),
                       collision_candidates=sum(index.candidate_tests for index in indices))


def _route_search(cfg, geo, metrics, coordinate_mode, node_limit,
                  index_cache, announce, progress_interval):
    validate_config(cfg)
    _endpoints(cfg, geo)
    source, target, metals, globals_ = geo
    layers = cfg['layers']
    names = [layer['name'] for layer in layers]
    if source[0] not in names or target[0] not in names:
        raise ValueError('Endpoint layer is absent from config')
    if math.hypot(source[1]-target[1], source[2]-target[2]) > cfg['max_distance']:
        raise ValueError('Point distance exceeds max_distance')
    endpoint_report = endpoint_clearance_report(cfg, geo)
    if not endpoint_report['clear']:
        raise ValueError(format_endpoint_report(endpoint_report, failures_only=True))
    # Unreachable layers cannot be used by this route. Their tracks must not
    # inflate its coordinate axes; obstacles on every reachable layer remain.
    layer_graph = defaultdict(set)
    for via in cfg['vias']:
        layer_graph[via['lower']].add(via['upper'])
        layer_graph[via['upper']].add(via['lower'])
    reachable = {source[0]}
    pending = [source[0]]
    for name in pending:
        for other in layer_graph[name]:
            if other not in reachable:
                reachable.add(other)
                pending.append(other)
    if target[0] not in reachable:
        raise ValueError('No usable via path connects the endpoint layers')
    layers = [layer for layer in layers if layer['name'] in reachable]
    names = [layer['name'] for layer in layers]
    physical_layers = cfg.get('_physical_layers', {})
    metrics.update(active_layers=len({physical_layers.get(name,name) for name in names}),
                   routing_profiles=len(layers), expanded_states=0, stored_states=0,
                   peak_heap_entries=0, max_nodes=cfg['max_nodes'])
    sx, sy, tx, ty = source[1], source[2], target[1], target[2]
    pitch = float(cfg['pitch'])
    margin = float(cfg['margin'])
    bounds = get_route_bounds(cfg)
    xmin, xmax = min(sx, tx)-margin, max(sx, tx)+margin
    ymin, ymax = min(sy, ty)-margin, max(sy, ty)+margin
    if bounds is not None:
        xmin, xmax = max(xmin, bounds[0]), min(xmax, bounds[2])
        ymin, ymax = max(ymin, bounds[1]), min(ymax, bounds[3])
    grid = float(cfg['grid'])
    def snap(v):
        return round(v/grid)*grid
    sample_x = max(0, math.ceil(xmax/pitch)-math.floor(xmin/pitch)+1)
    sample_y = max(0, math.ceil(ymax/pitch)-math.floor(ymin/pitch)+1)
    # Only the two coordinate axes are materialized. The Cartesian product
    # is implicit: A* creates records for reached states, never the whole grid.
    # Bound the actual axis storage separately from the search-state budget.
    axis_limit = max(4096, min(200000, cfg['max_nodes']))
    metrics.update(sample_x=sample_x, sample_y=sample_y, axis_coordinate_limit=axis_limit)
    if sample_x+sample_y+4 > axis_limit:
        raise ValueError('Search grid is too large to build coordinate axes: '
                         f'sampled_x={sample_x}, sampled_y={sample_y}, '
                         f'coordinate_limit={axis_limit}, pitch={pitch:g}; '
                         'increase pitch or reduce margin')
    xs = {snap(sx), snap(tx)}
    ys = {snap(sy), snap(ty)}
    def check_axis_budget():
        if len(xs)+len(ys) > axis_limit:
            raise ValueError('Search grid is too large to store obstacle-edge coordinates: '
                             f'X={len(xs)}, Y={len(ys)}, coordinate_limit={axis_limit}; '
                             'reduce the search window or explicitly limit usable layers. '
                             'Increasing pitch alone may not reduce obstacle-edge coordinates.')
    for i in range(math.floor(xmin/pitch), math.ceil(xmax/pitch)+1):
        value = snap(i*pitch)
        if xmin <= value <= xmax:
            xs.add(value)
    for i in range(math.floor(ymin/pitch), math.ceil(ymax/pitch)+1):
        value = snap(i*pitch)
        if ymin <= value <= ymax:
            ys.add(value)
    # Local axes retain regular tracks and endpoints on every layer. Other
    # layers' obstacles no longer subdivide a straight run in the layered pass.
    local_x = {name: set(xs) for name in names}
    local_y = {name: set(ys) for name in names}
    # The coarse pass changes only the graph, never the collision geometry.
    for layer in layers if coordinate_mode != 'coarse' else ():
        clearance = layer['width']/2 + layer['space'] + cfg['extra_clearance']
        for shape in metals.get(layer['name'], []):
            box = shape_bbox(shape)
            if isinstance(shape, Polygon):
                x_lanes = (x + offset for x, _ in shape.points
                           for offset in (-clearance-grid, clearance+grid))
                y_lanes = (y + offset for _, y in shape.points
                           for offset in (-clearance-grid, clearance+grid))
            else:
                x_lanes = (box[0]-clearance-grid, box[2]+clearance+grid)
                y_lanes = (box[1]-clearance-grid, box[3]+clearance+grid)
            for x in x_lanes:
                value = snap(x)
                if xmin <= value <= xmax:
                    xs.add(value)
                    local_x[layer['name']].add(value)
                    check_axis_budget()
            for y in y_lanes:
                value = snap(y)
                if ymin <= value <= ymax:
                    ys.add(value)
                    local_y[layer['name']].add(value)
                    check_axis_budget()
    metrics.update(x_coordinates=len(xs), y_coordinates=len(ys),
                   implicit_grid_nodes=len(xs)*len(ys)*len(layers))
    xs, ys = sorted(xs), sorted(ys)
    x_idx, y_idx = {v:i for i,v in enumerate(xs)}, {v:i for i,v in enumerate(ys)}
    layer_x = [sorted(x_idx[x] for x in local_x[name]) for name in names]
    layer_y = [sorted(y_idx[y] for y in local_y[name]) for name in names]
    if not index_cache:
        index_started = time.monotonic()
        shared_indices = {}
        index_cache['metals'] = {}
        for name in names:
            physical_name = physical_layers.get(name,name)
            if physical_name not in shared_indices:
                shared_indices[physical_name] = Index(metals.get(name,[]))
            index_cache['metals'][name] = shared_indices[physical_name]
        index_cache['global'] = Index(globals_)
        index_cache['build_seconds'] = round(time.monotonic()-index_started, 3)
    indices, global_index = index_cache['metals'], index_cache['global']
    metrics['index_build_seconds'] = index_cache['build_seconds']
    announce(metrics, 'search')
    # Every reviewed definition remains a candidate. Never overwrite one
    # cut/enclosure option with the last definition for the same layer pair.
    via_by_pair = defaultdict(list)
    via_by_name = {}
    for via in cfg['vias']:
        if via['lower'] in names and via['upper'] in names:
            a, b = names.index(via['lower']), names.index(via['upper'])
            via_by_pair[frozenset((a,b))].append(via)
            via_by_name[via['name']] = via
    via_geom = {name: via_geometry(via, cfg) for name, via in via_by_name.items()}
    weights = RoutingCost(cfg)
    via_costs = {name: weights.via(name, rows, cols) for name, (rows, cols, _) in via_geom.items()}
    for candidates in via_by_pair.values():
        candidates.sort(key=lambda via: (
            via_costs[via['name']],
            sum(pad['width']*pad['height'] for pad in via_geom[via['name']][2]), via['name']))
    via_neighbors = defaultdict(dict)
    for pair, candidates in via_by_pair.items():
        a, b = tuple(pair)
        if profile_transition_allowed(cfg,names[a],names[b]):
            via_neighbors[a][b] = candidates
        if profile_transition_allowed(cfg,names[b],names[a]):
            via_neighbors[b][a] = candidates
    incoming = defaultdict(set)
    for li, neighbors in via_neighbors.items():
        for nli in neighbors:
            incoming[nli].add(li)
    # Reverse Dijkstra supplies a lower bound on required via resistance/penalty.
    # Obstacles are ignored here; this never overestimates a legal route.
    layer_distance = {names.index(target[0]): 0}
    todo = [(0.0, names.index(target[0]))]
    while todo:
        value, li = heapq.heappop(todo)
        if value != layer_distance[li]:
            continue
        for nli in incoming[li]:
            next_value = value+min(via_costs[v['name']] for v in via_neighbors[nli][li])
            if next_value < layer_distance.get(nli, math.inf):
                layer_distance[nli] = next_value
                heapq.heappush(todo, (next_value, nli))
    if names.index(source[0]) not in layer_distance:
        raise ValueError('No usable via path connects the endpoint layers')

    def clear(layer_i, box):
        return not global_index.any(box) and not indices[names[layer_i]].any(box)

    def segment_ok(li, ax, ay, bx, by):
        layer = layers[li]
        if not endpoint_line_ok(cfg, names[li], layer['width'], (ax,ay), (bx,by)):
            return False
        half_width = layer['width']/2
        if not inside_bounds((min(ax,bx)-half_width, min(ay,by)-half_width,
                              max(ax,bx)+half_width, max(ay,by)+half_width), bounds):
            return False
        radius = layer['width']/2 + layer['space'] + cfg['extra_clearance']
        return clear(li, (min(ax,bx)-radius, min(ay,by)-radius,
                          max(ax,bx)+radius, max(ay,by)+radius))

    metrics.update(via_attempts=0, via_accepted=0, source_escape_attempts=0,
                   source_escape_accepted=0, via_rejections={}, via_rejection_examples=[])
    rejection_keys = set()
    def reject_via(reason, via, pad, x, y, box):
        counts = metrics['via_rejections']
        counts[reason] = counts.get(reason, 0)+1
        physical_name = physical_layers.get(pad['layer'], pad['layer'])
        key = (reason, via['name'], physical_name)
        if key not in rejection_keys and len(metrics['via_rejection_examples']) < 8:
            rejection_keys.add(key)
            original = getattr(geo, 'adapter', {}).get('vias', {}).get(via['name'], via['name'])
            metrics['via_rejection_examples'].append(dict(reason=reason, via=original,
                point=[x,y], layer=physical_name, pad_width=pad['width'], pad_height=pad['height'],
                bbox=box, route_bounds=bounds,
                bounds_fail=bounds_violations(box, bounds) if reason == 'route_bounds' else []))
        return False

    def via_ok(via, x, y):
        rows, cols, pads = via_geom[via['name']]
        metrics['via_attempts'] += 1
        for pad in pads:
            li = names.index(pad['layer'])
            wx, wy = pad['width'], pad['height']
            layer = layers[li]
            box = (x-wx/2, y-wy/2, x+wx/2, y+wy/2)
            if not inside_bounds(box, bounds):
                return reject_via('route_bounds', via, pad, x, y, box)
            rx = wx/2 + layer['space'] + cfg['extra_clearance']
            ry = wy/2 + layer['space'] + cfg['extra_clearance']
            check_box = (x-rx,y-ry,x+rx,y+ry)
            if global_index.any(check_box):
                return reject_via('global_obstacle', via, pad, x, y, box)
            if indices[names[li]].any(check_box):
                return reject_via('same_layer_obstacle', via, pad, x, y, box)
        metrics['via_accepted'] += 1
        return True

    # The old last-via bit no longer controls moves (via stacks are allowed),
    # so it must not duplicate otherwise identical physical search states.
    start = (x_idx[snap(sx)], y_idx[snap(sy)], names.index(source[0]))
    goal = (x_idx[snap(tx)], y_idx[snap(ty)], names.index(target[0]))
    reached_layers = {physical_layers.get(source[0], source[0])}
    metrics['reached_layers'] = sorted(reached_layers)
    pq = []
    dist = {start: 0.0}
    previous = {}
    serial = 0
    def heuristic(node):
        i,j,li = node
        return (wire_lower_bounds['H']*abs(xs[i]-tx)+wire_lower_bounds['V']*abs(ys[j]-ty)
                +layer_distance.get(li, math.inf))
    # Every H/V move pays at least the respective directional minimum. Using
    # one minimum for both axes makes a wide cheap V layer weaken all H search.
    wire_lower_bounds = {axis: min((weights.segment_rate(l['name'], l['width']) for l in layers
                                  if l['direction'] == axis), default=0.0) for axis in ('H', 'V')}
    # Smaller remaining distance breaks equal-f-score ties toward the goal.
    # The admissible f-score remains the primary key.
    heapq.heappush(pq, (heuristic(start),heuristic(start),serial,start))
    metrics.update(stored_states=1, peak_heap_entries=1)
    visited = 0
    final = None
    closed = set()
    def enqueue(nxt, value, cur, via_name=None):
        nonlocal serial
        if value >= dist.get(nxt, math.inf):
            return
        if nxt not in dist and len(dist) >= node_limit:
            raise SearchExhausted('Search exceeded stage budget: '
                             f'stored_states={len(dist)}, expanded_states={visited}, '
                             f'limit={node_limit}, X={len(xs)}, Y={len(ys)}, '
                             f'layers={len(layers)}', 'budget')
        dist[nxt] = value
        previous[nxt] = (cur, via_name)
        reached_name = physical_layers.get(names[nxt[2]], names[nxt[2]])
        if reached_name not in reached_layers:
            reached_layers.add(reached_name)
            metrics['reached_layers'] = sorted(reached_layers)
        serial += 1
        remaining = heuristic(nxt)
        heapq.heappush(pq, (value+remaining,remaining,serial,nxt))
        metrics['stored_states'] = len(dist)
        metrics['peak_heap_entries'] = max(metrics['peak_heap_entries'], len(pq))
        # Improved costs leave stale heap entries. Compact them when needed;
        # one live entry per stored state is sufficient.
        if len(pq) > 2*node_limit:
            pq[:] = [entry for entry in pq
                     if entry[3] not in closed and
                     entry[0] == dist[entry[3]]+heuristic(entry[3])]
            heapq.heapify(pq)
    next_report = time.monotonic()+progress_interval
    while pq:
        score,_,_,cur = heapq.heappop(pq)
        if score != dist[cur]+heuristic(cur):
            continue
        if cur in closed:
            continue
        closed.add(cur)
        if cur == goal:
            final = cur
            break
        visited += 1
        metrics['expanded_states'] = visited
        if visited % 256 == 0 and time.monotonic() >= next_report:
            metrics['open_heap_entries'] = len(pq)
            metrics['collision_queries'] = sum(index.query_count for index in set(indices.values()))+global_index.query_count
            metrics['collision_candidates'] = sum(index.candidate_tests for index in set(indices.values()))+global_index.candidate_tests
            announce(metrics, 'progress')
            next_report = time.monotonic()+progress_interval
        i,j,li = cur
        x,y = xs[i],ys[j]
        preferred = layers[li]['direction'].upper()
        if coordinate_mode == 'layered':
            # A via can enter at a coordinate absent from this layer's own
            # axes. Bisect from that exact point; never snap a via transition.
            x_tracks, y_tracks = layer_x[li], layer_y[li]
            xl, xr = bisect.bisect_left(x_tracks, i), bisect.bisect_right(x_tracks, i)
            yl, yr = bisect.bisect_left(y_tracks, j), bisect.bisect_right(y_tracks, j)
            options = []
            if xl: options.append((x_tracks[xl-1], j, 'H'))
            if xr < len(x_tracks): options.append((x_tracks[xr], j, 'H'))
            if yl: options.append((i, y_tracks[yl-1], 'V'))
            if yr < len(y_tracks): options.append((i, y_tracks[yr], 'V'))
        else:
            options = ((i-1,j,'H'),(i+1,j,'H'),(i,j-1,'V'),(i,j+1,'V'))
        for ni,nj,axis in options:
            if ni < 0 or ni >= len(xs) or nj < 0 or nj >= len(ys):
                continue
            nx,ny = xs[ni],ys[nj]
            if axis != preferred:
                continue
            nxt = (ni,nj,li)
            cost = (abs(nx-x)+abs(ny-y))*weights.segment_rate(names[li], layers[li]['width'])
            value = dist[cur]+cost
            if nxt in closed or value >= dist.get(nxt, math.inf):
                continue
            if not segment_ok(li,x,y,nx,ny):
                continue
            enqueue(nxt, value, cur)
        # Adjacent via stacks connect through their explicit metal pads.
        for nli, candidates in via_neighbors[li].items():
            nxt = (i,j,nli)
            if nxt in closed:
                continue
            for via in candidates:
                value = dist[cur]+via_costs[via['name']]
                if value >= dist.get(nxt, math.inf):
                    break
                if li == start[2]:
                    metrics['source_escape_attempts'] += 1
                if via_ok(via,x,y):
                    if li == start[2]:
                        metrics['source_escape_accepted'] += 1
                    enqueue(nxt, value, cur, via['name'])
                    # Candidates are cost ordered: persist the cheapest legal
                    # edge, retaining larger-cost alternatives when blocked.
                    break
    if final is None:
        raise SearchExhausted('No clear route found on '+coordinate_mode+' search graph', 'no_path')
    nodes = [final]
    while nodes[-1] != start:
        nodes.append(previous[nodes[-1]][0])
    nodes.reverse()
    items = []
    for a,b in zip(nodes,nodes[1:]):
        ax,ay,al = xs[a[0]],ys[a[1]],a[2]
        bx,by,bl = xs[b[0]],ys[b[1]],b[2]
        if al != bl:
            via = via_by_name[previous[b][1]]
            rows,cols,pads = via_geom[via['name']]
            items.append(dict(kind='via',name=via['name'],x=ax,y=ay,rows=rows,cols=cols,
                              pads=pads))
        else:
            if items and items[-1]['kind']=='segment' and items[-1]['layer']==names[al]:
                old=items[-1]
                if (old['x2']==ax and old['y2']==ay and
                    ((old['x1']==old['x2']==bx) or (old['y1']==old['y2']==by))):
                    old['x2'],old['y2']=bx,by
                    continue
            items.append(dict(kind='segment',layer=names[al],width=layers[al]['width'],
                              x1=ax,y1=ay,x2=bx,y2=by))
    return items


def validate(items, cfg, geo):
    effective, prepared, adapter = prepare_route(cfg, geo)
    if isinstance(items,list) and len(items) == 1 and isinstance(items[0],dict) and items[0].get('endpoint_direct'):
        expected = direct_endpoint_route(effective,prepared,adapter)
        if (expected is None or any(items[0].get(k) != v for k,v in expected[0].items()) or
                math.hypot(prepared[0][1]-prepared[1][1],prepared[0][2]-prepared[1][2]) > cfg['max_distance']):
            raise ValueError('Invalid direct endpoint extension')
        return
    _validate(internal_route(items,adapter),effective,prepared)


def _validate(items, cfg, geo):
    validate_config(cfg)
    _endpoints(cfg, geo)
    if not isinstance(items, list) or not items:
        raise ValueError('Empty or malformed route; no endpoint connection')
    source, target, metals, globals_ = geo
    layers = {x['name']:x for x in cfg['layers']}
    vias = {x['name']:x for x in cfg['vias']}
    bounds = get_route_bounds(cfg)
    idx = {name:Index(metals.get(name,[])+globals_) for name in layers}
    current_layer, x, y = source
    tolerance = cfg['grid']*1e-6
    def same(a, b):
        return math.isclose(a, b, rel_tol=0, abs_tol=tolerance)
    def coordinates(item, keys):
        if any(not finite_number(item.get(k)) or not on_grid(item[k], cfg['grid']) for k in keys):
            raise ValueError('Route coordinates must be finite and on manufacturing grid')
    for item in items:
        if not isinstance(item, dict):
            raise ValueError('Malformed route item')
        if item.get('kind')=='segment':
            coordinates(item, ('x1', 'y1', 'x2', 'y2'))
            if (item.get('layer') != current_layer or not same(item['x1'], x) or
                    not same(item['y1'], y)):
                raise ValueError('Route is disconnected from endpoint or preceding item')
            if current_layer not in layers:
                raise ValueError('Unknown route layer')
            layer = layers[current_layer]
            if not finite_number(item.get('width')) or not same(item['width'], layer['width']):
                raise ValueError('Route segment width differs from current config')
            horizontal = same(item['y1'], item['y2'])
            vertical = same(item['x1'], item['x2'])
            if horizontal == vertical:
                raise ValueError('Route segment must be a nonzero Manhattan line')
            axis = 'H' if horizontal else 'V'
            if axis != layer['direction']:
                raise ValueError('Wrong-way segment is not an inline endpoint extension')
            if not endpoint_line_ok(cfg,current_layer,item['width'],(x,y),(item['x2'],item['y2'])):
                raise ValueError('Endpoint extension has wrong width or centerline')
            half_width = item['width']/2
            footprint = (min(item['x1'],item['x2'])-half_width,
                         min(item['y1'],item['y2'])-half_width,
                         max(item['x1'],item['x2'])+half_width,
                         max(item['y1'],item['y2'])+half_width)
            if not inside_bounds(footprint, bounds):
                raise ValueError('Route segment exceeds route_bounds')
            r=item['width']/2+layer['space']+cfg['extra_clearance']
            box=(min(item['x1'],item['x2'])-r,min(item['y1'],item['y2'])-r,
                 max(item['x1'],item['x2'])+r,max(item['y1'],item['y2'])+r)
            if idx[item['layer']].any(box):
                raise ValueError(f"Route now conflicts with {item['layer']} obstacle")
            x, y = item['x2'], item['y2']
        elif item.get('kind')=='via':
            coordinates(item, ('x', 'y'))
            via = vias.get(item.get('name'))
            if (via is None or current_layer not in (via['lower'], via['upper']) or
                    not same(item['x'], x) or not same(item['y'], y)):
                raise ValueError('Via is disconnected or absent from config')
            for key in ('rows', 'cols'):
                if (isinstance(item.get(key), bool) or not isinstance(item.get(key), int) or
                        not 1 <= item[key] <= cfg['max_array']):
                    raise ValueError('Invalid via array count')
            _, _, expected = via_geometry(via, cfg, item['rows'], item['cols'])
            pads = item.get('pads')
            if (not isinstance(pads, list) or len(pads) != 2 or
                    any(not isinstance(pad, dict) for pad in pads) or
                    {pad.get('layer') for pad in pads} != {via['lower'], via['upper']}):
                raise ValueError('Via pads do not match its two metals')
            minimum = {pad['layer']:pad for pad in expected}
            for pad in item['pads']:
                layer=layers[pad['layer']]
                for key in ('width', 'height'):
                    if (not finite_number(pad.get(key)) or
                            pad[key]+tolerance < minimum[pad['layer']][key] or
                            not on_grid(pad[key]/2, cfg['grid'])):
                        raise ValueError('Via pad is undersized or off grid')
                if not inside_bounds((item['x']-pad['width']/2,
                                      item['y']-pad['height']/2,
                                      item['x']+pad['width']/2,
                                      item['y']+pad['height']/2), bounds):
                    raise ValueError('Route via pad exceeds route_bounds')
                rx=pad['width']/2+layer['space']+cfg['extra_clearance']
                ry=pad['height']/2+layer['space']+cfg['extra_clearance']
                if idx[pad['layer']].any((item['x']-rx,item['y']-ry,item['x']+rx,item['y']+ry)):
                    raise ValueError('Route via now conflicts with metal or via')
            next_layer = via['upper'] if current_layer == via['lower'] else via['lower']
            if not profile_transition_allowed(cfg,current_layer,next_layer):
                raise ValueError('Endpoint extension may only precede the first via or follow the last via')
            current_layer = next_layer
        else:
            raise ValueError('Unknown route item kind')
    if current_layer != target[0] or not same(x, target[1]) or not same(y, target[2]):
        raise ValueError('Route does not reach destination endpoint')


def read_actual_vias(path):
    """AV/AO preserve each native via's per-layer boxes; legacy rows stay safe."""
    records, by_id = [], {}
    def integer(token, minimum=0):
        value = int(token)
        if value < minimum:
            raise ValueError('Invalid actual via index/count')
        return value
    for line_number, raw in enumerate(path.read_text().splitlines(), 1):
        parts = raw.split()
        if not parts:
            continue
        if parts[0] == 'AV' and len(parts) == 12:
            index, uid = integer(parts[1]), integer(parts[2])
            if uid in by_id:
                raise ValueError('Duplicate actual via instance identifier')
            record = dict(index=index, uid=uid, name=parts[3], layers=parts[4:6],
                          rows=integer(parts[6], 1), cols=integer(parts[7], 1),
                          bbox=_box(parts[8:]), boxes=[], representation='per_layer',
                          raw=raw, line=line_number)
            by_id[uid] = record
            records.append(record)
        elif parts[0] == 'AO' and len(parts) == 7:
            uid = integer(parts[1])
            if uid not in by_id:
                raise ValueError('Actual via layer box has no preceding AV header')
            by_id[uid]['boxes'].append(dict(layer=parts[2], bbox=_box(parts[3:]), line=line_number))
        elif len(parts) in (6, 7) and parts[0] not in ('AV', 'AO'):
            index = integer(parts.pop(0)) if len(parts) == 7 else None
            box = _box(parts[2:])
            records.append(dict(index=index, uid=None, name=None, layers=parts[:2],
                                bbox=box, boxes=[dict(layer=n, bbox=box, line=line_number)
                                                for n in parts[:2]],
                                representation='legacy_union', raw=raw, line=line_number))
        else:
            raise ValueError(f'Bad actual via footprint: {raw}')
    return records


def validate_actual_vias(path, cfg, geo, items=None, *, report=None):
    """Never project a wide upper pad onto a narrow lower pad when native data exists."""
    result = report if report is not None else {}
    result.update(status='checking', actual_file=str(path),
                  geometry_file=getattr(geo, 'source_path', None), checks=[])
    try:
        _validate_actual_vias(path, cfg, geo, items, result)
    except (ValueError, TypeError, KeyError, OSError) as exc:
        result.update(status='failed', error=str(exc))
        raise
    result['status'] = 'clear'
    return result


def _validate_actual_vias(path, cfg, geo, items, report):
    validate_config(cfg)
    effective, prepared, adapter = prepare_route(cfg,geo)
    source, target = prepared[:2]
    metals, globals_ = adapter['physical_metals'], geo[3]
    metal_records = adapter['physical_records']
    report['endpoint_covered_count'] = len(adapter['endpoint_covered'])
    report['endpoint_covered_examples'] = adapter['endpoint_covered'][:12]
    layers = {layer['name']: layer for layer in cfg['layers']}
    bounds = get_route_bounds(cfg)
    obstacles = {name: Index(metals.get(name, []) + globals_) for name in layers}
    halo = obstacle_query_halo(effective)
    query = [min(source[1], target[1])-cfg['margin']-halo,
             min(source[2], target[2])-cfg['margin']-halo,
             max(source[1], target[1])+cfg['margin']+halo,
             max(source[2], target[2])+cfg['margin']+halo]
    if bounds is not None:
        query = [max(query[0], bounds[0]-halo), max(query[1], bounds[1]-halo),
                 min(query[2], bounds[2]+halo), min(query[3], bounds[3]+halo)]
    expected = {i: item for i, item in enumerate(items or []) if item.get('kind') == 'via'}
    via_defs = {via['name']: via for via in cfg['vias']}
    seen = set()
    actuals = read_actual_vias(path)
    report.update(global_boxes=len(globals_), actual_vias=len(actuals),
                  native_scoped=sum(a['representation'] == 'per_layer' for a in actuals),
                  legacy_union=sum(a['representation'] == 'legacy_union' for a in actuals))
    for actual in actuals:
        pair, box, index = actual['layers'], actual['bbox'], actual['index']
        if pair[0] not in layers or pair[1] not in layers or pair[0] == pair[1]:
            raise ValueError(f'Bad actual via footprint: {actual["raw"]}')
        if not inside_bounds(box, bounds):
            raise ValueError(f'Actual Cadence via exceeds route_bounds: {actual["raw"]}')
        if actual['representation'] == 'per_layer':
            definition = via_defs.get(actual['name'])
            if not definition or set(pair) != {definition['lower'], definition['upper']}:
                raise ValueError('Actual via definition/layer pair is absent from the reviewed configuration')
            if not all(any(b['layer'] == name for b in actual['boxes']) for name in pair):
                raise ValueError('Actual via is missing a terminal-layer footprint')
            eps = cfg['grid']*1e-6
            outer = (box[0]-eps, box[1]-eps, box[2]+eps, box[3]+eps)
            if any(b['layer'] not in layers or not inside_bounds(b['bbox'], outer)
                   for b in actual['boxes']):
                raise ValueError('Actual via layer footprint is unknown or outside its instance bbox')
        plan = expected.get(index)
        if items is not None:
            if (plan is None or set(pair) != {pad['layer'] for pad in plan['pads']} or
                    not all(any(b['layer'] == name and
                                b['bbox'][0] < plan['x'] < b['bbox'][2] and
                                b['bbox'][1] < plan['y'] < b['bbox'][3]
                                for b in actual['boxes']) for name in pair)):
                raise ValueError('Actual via does not cover its planned transition')
            seen.add(index)
        for footprint in actual['boxes']:
            name = footprint['layer']
            x0, y0, x1, y1 = footprint['bbox']
            clearance = layers[name]['space'] + cfg['extra_clearance']
            check_box = (x0-clearance, y0-clearance, x1+clearance, y1+clearance)
            pad = next((p for p in plan['pads'] if p['layer'] == name), None) if plan else None
            planned_box = ((plan['x']-pad['width']/2, plan['y']-pad['height']/2,
                            plan['x']+pad['width']/2, plan['y']+pad['height']/2) if pad else None)
            tolerance = cfg['grid']*1e-6
            planned_limit = ((planned_box[0]-tolerance, planned_box[1]-tolerance,
                              planned_box[2]+tolerance, planned_box[3]+tolerance)
                             if planned_box else None)
            check = dict(plan_index=index, actual_instance=actual['uid'], via_name=actual['name'],
                         rows=actual.get('rows'), cols=actual.get('cols'),
                         representation=actual['representation'], layer=name,
                         actual_bbox=footprint['bbox'], union_bbox=box, planned_bbox=planned_box,
                         planned_via_name=plan['name'] if plan else None,
                         exceeds_planned_pad=(not inside_bounds(footprint['bbox'], planned_limit)
                                              if planned_box else None),
                         space=layers[name]['space'], extra_clearance=cfg['extra_clearance'],
                         clearance_box=check_box, blockers=[])
            report['checks'].append(check)
            if not inside_bounds(check_box, query):
                raise ValueError('Actual via extends beyond the exported obstacle query window')
            if obstacles[name].any(check_box):
                # Detailed enumeration happens only after a failed BVH query.
                groups = ((metals.get(name, []), metal_records.get(name, []), 'metal'),
                          (globals_, getattr(geo, 'global_records', []), 'global'))
                count = 0
                for shapes, records, category in groups:
                    for number, shape in enumerate(shapes):
                        if shape_hits_box(shape, check_box):
                            count += 1
                            if len(check['blockers']) < 6:
                                record = records[number] if number < len(records) else {}
                                check['blockers'].append(dict(category=category,
                                    line=record.get('line'), tag=record.get('tag', 'X' if category == 'global' else 'O'),
                                    bbox=shape_bbox(shape),
                                    hits_metal_footprint=shape_hits_box(shape, footprint['bbox'])))
                check['blocker_count'] = count
                details = [f'Actual Cadence via conflicts with existing metal/via: {actual["raw"]}',
                           f'  index={index} layer={name} representation={actual["representation"]}',
                           f'  actual_bbox={list(footprint["bbox"])} space={layers[name]["space"]} '
                           f'extra_clearance={cfg["extra_clearance"]}',
                           f'  planned_pad={planned_box} exceeds_planned_pad={check["exceeds_planned_pad"]}']
                for hit in check['blockers']:
                    details.append(f'  obstacle line={hit["line"]} tag={hit["tag"]} bbox={list(hit["bbox"])} '
                                   + ('intersects actual metal' if hit['hits_metal_footprint']
                                      else 'inside spacing/extra-clearance region only'))
                if actual['representation'] == 'legacy_union':
                    details.append('  Legacy union bbox is conservative on both layers; '
                                   'update autoroute.il or inspect AR_ACTUAL_VIA_FALLBACK.')
                raise ValueError('\n'.join(details))
    if items is not None and seen != set(expected):
        raise ValueError('Missing actual via for a planned layer transition')


def skill_literal(value):
    if isinstance(value,str):
        return json.dumps(value)
    if isinstance(value,(int,float)):
        return f'{value:.15g}'
    if isinstance(value,list):
        return 'list('+ ' '.join(skill_literal(x) for x in value)+')'
    raise TypeError(value)


def output(items, il_path, json_path):
    records=[]
    for item in items:
        if item['kind']=='segment':
            records.append(['S',item['layer'],item['width'],item['x1'],item['y1'],item['x2'],item['y2']])
        else:
            a,b=item['pads']
            records.append(['V',item['name'],item['x'],item['y'],item['rows'],item['cols'],
                            a['layer'],a['width'],a['height'],b['layer'],b['width'],b['height']])
    atomic_text(json_path, json.dumps(items,indent=2,allow_nan=False)+'\n')
    atomic_text(il_path, 'arCandidate = '+skill_literal(records)+'\n')


def _digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def geometry_fingerprint(path):
    lines = sorted(line.strip() for line in path.read_text().splitlines() if line.strip())
    return hashlib.sha256('\n'.join(lines).encode()).hexdigest()


def save_snapshot(path, cfg, geometry_path, il_path):
    data = dict(config_sha256=config_fingerprint(cfg), geometry_sha256=geometry_fingerprint(geometry_path),
                route_il_sha256=_digest(il_path), route_json_sha256=_digest(il_path.with_suffix('.json')))
    atomic_text(path, json.dumps(data, indent=2)+'\n')


def check_snapshot(path, cfg, geometry_path, il_path):
    expected = json.loads(path.read_text())
    current = dict(config_sha256=config_fingerprint(cfg), geometry_sha256=geometry_fingerprint(geometry_path),
                   route_il_sha256=_digest(il_path), route_json_sha256=_digest(il_path.with_suffix('.json')))
    if expected != current:
        raise ValueError('Preview/config/layout files changed; discard preview and rerun arStart()')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config',type=Path,required=True)
    ap.add_argument('--geometry',type=Path,required=True)
    ap.add_argument('--output',type=Path,
                    default=Path('route_result.il'))
    ap.add_argument('--validate',type=Path,help='validate an existing route JSON')
    ap.add_argument('--check-vias',type=Path,help='check actual Cadence via bounding boxes')
    ap.add_argument('--snapshot',type=Path,help='write a preview snapshot after routing')
    ap.add_argument('--check-snapshot',type=Path,help='reject a modified preview/config/layout')
    ap.add_argument('--config-hash',help='expected fingerprint of loaded SKILL config')
    ap.add_argument('--search-mode', choices=('staged', 'coarse', 'layered', 'detailed'),
                    default='staged', help='staged tries coarse, per-layer, then full axes')
    ap.add_argument('--progress-interval', type=float, default=5.0,
                    help='seconds between search progress reports; 0 disables reports')
    ap.add_argument('--prepare-endpoints', action='store_true',
                    help='write centerline/width/query-halo SKILL plan before obstacle export')
    ap.add_argument('--diagnose-endpoints', action='store_true',
                    help='report endpoint bounds and obstacle conflicts without routing')
    ap.add_argument('--diagnostics-json', type=Path,
                    help='write the endpoint report as JSON (requires --diagnose-endpoints)')
    args=ap.parse_args()
    if not math.isfinite(args.progress_interval) or args.progress_interval < 0:
        ap.error('--progress-interval must be finite and nonnegative')
    if args.diagnostics_json and not args.diagnose_endpoints:
        ap.error('--diagnostics-json requires --diagnose-endpoints')
    if args.diagnose_endpoints and any((args.validate, args.check_vias, args.snapshot, args.check_snapshot)):
        ap.error('--diagnose-endpoints cannot be combined with routing/preview validation modes')
    if args.prepare_endpoints and any((args.diagnose_endpoints,args.validate,args.check_vias,args.snapshot,args.check_snapshot)):
        ap.error('--prepare-endpoints cannot be combined with routing/validation modes')
    cfg=json.loads(args.config.read_text())
    validate_config(cfg)
    if args.config_hash and args.config_hash != config_fingerprint(cfg):
        raise ValueError('JSON differs from loaded SKILL config; rerun arStart()')
    geo=read_geometry(args.geometry)
    if not args.prepare_endpoints:
        print('Geometry stats: '+json.dumps(geometry_summary(geo), sort_keys=True), flush=True)
        if geo[3]:
            print(f'WARNING: {len(geo[3])} X record(s) block EVERY routing layer. '
                  'Old exports lose via layer information: update autoroute.il and rerun F8. '
                  'In a new export, inspect AR_VIA_GLOBAL for unresolved vias; '
                  'do not delete X records to bypass clearance.', file=sys.stderr, flush=True)
    if args.prepare_endpoints:
        effective, prepared, adapter = prepare_route(cfg,geo)
        layers = {layer['name']:layer for layer in effective['layers']}
        plan = [[adapter['physical'][point[0]],point[1],point[2],layers[point[0]]['width']]
                for point in prepared[:2]]
        atomic_text(args.output, 'arEndpointPlan = '+skill_literal(plan)+'\n'+
                    'arEffectiveQueryHalo = '+skill_literal(obstacle_query_halo(effective))+'\n')
        print('Endpoint fit: '+json.dumps(adapter['fits'],sort_keys=True))
        return
    if args.diagnose_endpoints:
        report = endpoint_clearance_report(cfg, geo)
        if args.diagnostics_json:
            atomic_text(args.diagnostics_json, json.dumps(report, indent=2)+'\n')
        print(format_endpoint_report(report))
        raise SystemExit(0 if report['clear'] else 2)
    if args.check_snapshot:
        check_snapshot(args.check_snapshot,cfg,args.geometry,args.output)
    if args.check_vias:
        items=json.loads(args.output.with_suffix('.json').read_text())
        validate(items,cfg,geo)
        report = {}
        report_path = args.check_vias.with_suffix('.report.json')
        try:
            validate_actual_vias(args.check_vias,cfg,geo,items,report=report)
        finally:
            atomic_text(report_path, json.dumps(report,indent=2,allow_nan=False)+'\n')
            print('Actual via report: '+str(report_path), flush=True)
        print(f'Actual vias clear: native_scoped={report["native_scoped"]}, '
              f'legacy_union={report["legacy_union"]}')
    elif args.validate:
        items=json.loads(args.validate.read_text())
        validate(items,cfg,geo)
        print('Route clear')
    else:
        stats = {}
        search_error = None
        try:
            def report_progress(event):
                print('Search progress: '+json.dumps(event, sort_keys=True), flush=True)
            items=route(cfg,geo,stats, search_mode=args.search_mode,
                        progress=report_progress, progress_interval=args.progress_interval)
        except (ValueError, TypeError, KeyError) as exc:
            search_error = str(exc)
            raise
        finally:
            report_path = args.output.with_suffix('.search_report.json')
            atomic_text(report_path, json.dumps(dict(status='failed' if search_error else 'found',
                error=search_error, config=str(args.config), geometry=str(args.geometry), stats=stats),
                indent=2, allow_nan=False)+'\n')
            print('Search report: '+str(report_path), flush=True)
            if stats:
                console_stats = {key:value for key,value in stats.items() if key != 'endpoint_via_access'}
                print('Search stats: '+json.dumps(console_stats, sort_keys=True), flush=True)
        validate(items,cfg,geo)
        output(items,args.output,args.output.with_suffix('.json'))
        if args.snapshot:
            save_snapshot(args.snapshot,cfg,args.geometry,args.output)
        print(f'Route: {len(items)} segments/vias')


if __name__=='__main__':
    try:
        main()
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print('ERROR: '+str(exc), file=sys.stderr)
        raise SystemExit(2)
