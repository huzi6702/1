"""Shared routing weights. Resistance is an estimate over branch records, in ohms."""
from __future__ import annotations
import math


def positive(value):
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and value > 0)


def cost_model_issues(cfg):
    model = cfg.get('cost_model')
    if model is None:
        return [] if positive(cfg.get('via_cost', 5.0)) else ['via_cost: finite positive number required']
    if not isinstance(model, dict) or model.get('mode') not in ('length_via', 'resistance'):
        return ['cost_model.mode: expected length_via or resistance']
    issues = []
    allowed = {'mode', 'assumed', 'description', 'sheet_resistance_ohm_per_square',
               'via_resistance_ohm_per_cut'}
    if set(model)-allowed:
        issues.append('cost_model: unknown fields: '+', '.join(sorted(set(model)-allowed)))
    if 'assumed' in model and not isinstance(model['assumed'], bool):
        issues.append('cost_model.assumed: expected boolean')
    if 'description' in model and not isinstance(model['description'], str):
        issues.append('cost_model.description: expected string')
    if model['mode'] == 'length_via':
        if not positive(cfg.get('via_cost', 5.0)):
            issues.append('via_cost: finite positive number required')
        return issues
    for field, records, aliases in (
            ('sheet_resistance_ohm_per_square', cfg.get('layers', []), cfg.get('_physical_layers', {})),
            ('via_resistance_ohm_per_cut', cfg.get('vias', []), cfg.get('_physical_vias', {}))):
        expected = {aliases.get(r['name'], r['name']) for r in records
                    if isinstance(r, dict) and isinstance(r.get('name'), str)}
        values = model.get(field)
        if not isinstance(values, dict):
            issues.append('cost_model.'+field+': expected a name-to-resistance object')
            continue
        missing, extra = expected-set(values), set(values)-expected
        if missing:
            issues.append('cost_model.'+field+': missing '+', '.join(sorted(missing)))
        if extra:
            issues.append('cost_model.'+field+': unknown '+', '.join(sorted(extra)))
        for name, value in values.items():
            if not positive(value):
                issues.append('cost_model.'+field+'.'+name+': finite positive resistance required')
    return issues


class RoutingCost:
    def __init__(self, cfg):
        self.cfg = cfg
        self.model = cfg.get('cost_model') or {}
        self.mode = self.model.get('mode', 'length_via')
        self.unit = 'ohm' if self.mode == 'resistance' else 'user_unit'

    def segment_rate(self, layer, width):
        if self.mode != 'resistance':
            return 1.0
        physical = self.cfg.get('_physical_layers', {}).get(layer, layer)
        return self.model['sheet_resistance_ohm_per_square'][physical]/width

    def via(self, name, rows, cols):
        if self.mode != 'resistance':
            return self.cfg.get('via_cost', 5.0)
        physical = self.cfg.get('_physical_vias', {}).get(name, name)
        return self.model['via_resistance_ohm_per_cut'][physical]/(rows*cols)

    def minimum_segment_rate(self):
        return min(self.segment_rate(l['name'], l['width']) for l in self.cfg['layers'])

    def access_estimate(self, source, target):
        length = abs(source['point'][0]-target['point'][0])+abs(source['point'][1]-target['point'][1])
        transition = 0.0
        if source['layer'] != target['layer']:
            transition = (min(self.model['via_resistance_ohm_per_cut'].values(), default=0.0)/
                          self.cfg['max_array']**2 if self.mode == 'resistance'
                          else self.cfg.get('via_cost', 5.0))
        return length*self.minimum_segment_rate()+transition

    def breakdown(self, items):
        length = wire = vias = 0.0
        transitions = 0
        for item in items:
            if item['kind'] == 'segment':
                distance = abs(item['x2']-item['x1'])+abs(item['y2']-item['y1'])
                length += distance
                wire += distance*self.segment_rate(item['layer'], item['width'])
            else:
                transitions += 1
                vias += self.via(item['name'], item['rows'], item['cols'])
        result = dict(wire_length=length, via_transitions=transitions,
                      wire_cost=wire, via_cost=vias, total_cost=wire+vias, cost_unit=self.unit)
        if self.mode == 'resistance':
            result.update(wire_resistance_ohm=wire, via_resistance_ohm=vias,
                          estimated_resistance_ohm=wire+vias)
        return result

    def items(self, items):
        return self.breakdown(items)['total_cost']

    def describe(self):
        result = dict(mode=self.mode, unit=self.unit, aggregation='sum_over_branch_records')
        if self.mode == 'resistance':
            result.update(assumed=self.model.get('assumed', False),
                          description=self.model.get('description', ''),
                          wire_formula='Rsheet * centerline_length / actual_segment_width',
                          via_formula='Rsingle_cut / (rows * cols)')
        else:
            result['via_penalty'] = self.cfg.get('via_cost', 5.0)
        return result
