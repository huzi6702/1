"""Shared validation for the JSON compiler and the routing engine."""
from __future__ import annotations

import math
import hashlib
import json
from routing_cost import cost_model_issues


def finite_number(value):
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value))


def valid_name(value):
    # These names are also written to a whitespace-delimited geometry file.
    return (isinstance(value, str) and bool(value) and
            not any(c.isspace() or ord(c) < 32 for c in value))


def config_issues(cfg):
    issues = []
    if not isinstance(cfg, dict):
        return ['config must be a JSON object']
    report = cfg.get('_extract_report', {})
    if not isinstance(report, dict) or not isinstance(report.get('metal_stack', {}), dict):
        issues.append('_extract_report: expected object with a metal_stack object')
        report = {}
    if (report.get('metal_stack', {}).get('review_required') and
            cfg.get('stack_reviewed') is not True):
        issues.append('metal_stack: ambiguous/branched/disconnected; use --stack or review and set stack_reviewed=true')
    for key in ('grid', 'pitch', 'margin', 'max_distance'):
        if not finite_number(cfg.get(key)) or cfg[key] <= 0:
            issues.append(f'{key}: required finite positive number')
    for key in ('max_nodes', 'max_array'):
        if (isinstance(cfg.get(key), bool) or not isinstance(cfg.get(key), int)
                or cfg[key] <= 0):
            issues.append(f'{key}: required positive integer')
    if not finite_number(cfg.get('extra_clearance')) or cfg['extra_clearance'] < 0:
        issues.append('extra_clearance: required finite nonnegative number')
    if cfg.get('via_mode', 'auto_preferred') not in ('standard', 'auto_preferred', 'auto_required'):
        issues.append('via_mode: expected standard, auto_preferred or auto_required')
    if not isinstance(cfg.get('via_constraint_group', 'CURRENT'), str):
        issues.append('via_constraint_group: expected string')
    purposes = cfg.get('obstacle_purposes', ['*'])
    if (not isinstance(purposes, list) or not purposes or
            any(not valid_name(p) for p in purposes) or
            len(set(purposes)) != len(purposes) or ('*' in purposes and len(purposes) != 1)):
        issues.append('obstacle_purposes: unique purpose names or ["*"] required')
    bounds = cfg.get('route_bounds')
    if bounds is not None:
        if (not isinstance(bounds, list) or len(bounds) != 4 or
                not all(finite_number(x) for x in bounds) or
                bounds[0] >= bounds[2] or bounds[1] >= bounds[3]):
            issues.append('route_bounds: expected [xmin, ymin, xmax, ymax] or null')
    layers = cfg.get('layers')
    if not isinstance(layers, list) or not layers:
        return issues + ['layers: at least one layer required']
    names = []
    for layer in layers:
        if not isinstance(layer, dict) or not valid_name(layer.get('name')):
            issues.append('layers: each layer needs a valid name')
            continue
        name = layer['name']
        if name in names:
            issues.append(f'{name}: duplicate layer name')
        names.append(name)
        for field in ('width', 'space'):
            if not finite_number(layer.get(field)) or layer[field] <= 0:
                issues.append(f'{name}.{field}: required finite positive number; fill manually')
        if layer.get('direction') not in ('H', 'V'):
            issues.append(f'{name}.direction: expected H or V')
        if (finite_number(cfg.get('grid')) and cfg['grid'] > 0 and
                finite_number(layer.get('width')) and layer['width'] > 0):
            steps = layer['width'] / (2 * cfg['grid'])
            if not math.isclose(steps, round(steps), rel_tol=0, abs_tol=1e-7):
                issues.append(f'{name}.width: use a multiple of 2*grid so both edges are on grid')
    vias = cfg.get('vias')
    if not isinstance(vias, list):
        return issues + ['vias: expected list']
    seen = set()
    pairs = set()
    for via in vias:
        if not isinstance(via, dict) or not valid_name(via.get('name')):
            issues.append('vias: each via needs a valid name')
            continue
        name = via['name']
        if name in seen:
            issues.append(f'{name}: duplicate via name')
        seen.add(name)
        a, b = via.get('lower'), via.get('upper')
        if a not in names or b not in names or a == b:
            issues.append(f'{name}: lower/upper must be distinct configured metals')
        else:
            pairs.add(frozenset((a, b)))
        if not valid_name(via.get('cut_layer')):
            issues.append(f'{name}.cut_layer: required layer name')
        for field in ('cut', 'cut_space', 'enc_lower', 'enc_upper'):
            vector = via.get(field)
            if (not isinstance(vector, list) or len(vector) != 2 or
                    not all(finite_number(x) and (x > 0 if field == 'cut' else x >= 0)
                            for x in vector)):
                issues.append(f'{name}.{field}: required two-number geometry vector')
    # Disconnected layer sets remain usable for same-layer routes; report in extraction.
    return issues + cost_model_issues(cfg)


def validate_config(cfg):
    issues = config_issues(cfg)
    if issues:
        raise ValueError('Config is not ready:\n  ' + '\n  '.join(issues))
    return cfg


def config_fingerprint(cfg):
    return hashlib.sha256(json.dumps(cfg, sort_keys=True, separators=(',', ':'),
                                    ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def pad_size(value, grid):
    """Round a centered landing pad outward, keeping both edges on grid."""
    return math.ceil(value / (2*grid) - 1e-9) * (2*grid)
