# 从 Layout XL 绑定自动提取 net，离线整体连线

完整加载顺序、逐步操作、文件读写及信息流见 [使用与信息流说明](USAGE_AND_DATAFLOW_CN.md)。

推荐的分开入口见 [SPLIT_FLOW_CN.md](SPLIT_FLOW_CN.md)：**人工打开并保存版图 → 导出障碍 → 导出连接 → terminal 的 run_plan.py 求解 → 当前 CIW 的 mnBuildFromPlan 创建 layout → 人工实例化到原图**。Python 求解不启动 Virtuoso、不需要 Xvfb。
下文继续记录原一体化入口及测试版图。
无需填写 net—端点清单。保留旧手写清单入口；旧 F8 程序、home 配置和本地源码没有覆盖。

## 先看已经保存的测试版图

库 **AR_AUDIT_20261010**，位于 /home/meow/autoroute/audit/native_lib。
从个人 home 启动：

    virtuoso -cdslib /home/meow/autoroute/audit/batch_cds.lib

| Cell | View | 内容 |
|---|---|---|
| hier_top_xl20261011b | schematic | 4 个不同模块，5 个 net，4 个对外 pin |
| hier_top_xl20261011b | layout | 原始层次版图：模块 pin／障碍、顶层 pin／障碍，真实 XL 绑定 |
| hier_routes_xl20261011b | layout | 首轮新增连线、pad、33 颗标准 via，5 个 net |
| hier_routes_xl20261011b_clean | layout | 最终代码从 terminal 生成并复核的同一方案 |
| hier_assembly_xl20261011b | layout | 查看效果：SOURCE 与 ROUTES 两个实例，均为 0:0／R0／倍率 1 |

assembly 是查看用父 cell；其 SOURCE master 是有绑定的原始 top。
查看／导出绑定时打开 **hier_top_xl20261011b/layout**，使用 Layout XL。

底层分别是 hier_frontend_xl20261011b、hier_backend_xl20261011b、
hier_monitor_xl20261011b、hier_driver_xl20261011b。
每个均有 schematic、symbol、layout。每个电路只含 4 个真实数据库 pin；
版图含 4 个金属 pin 及 2 根匿名障碍线。顶层还有 3 根障碍线、
1 个 polygon 障碍、1 颗原有标准 via。实例使用 R0、MY、R90、MX；
电路实例名与版图实例名不同，使用真实 bnd 对应关系。

| 电路 net | 各模块 pin（不同名字） | 顶层对外 pin | 端点数 |
|---|---|---|---|
| N_DATA | ALPHA、IN_B、DATA_C | EXT_IN | 4 |
| N_CTRL | BETA、CTRL_B、ENABLE_D | CTRL_IO | 4 |
| N_REF | GAMMA、REF_C、SENSE_D | REF_OUT | 4 |
| N_POWER | POWER、PWR_B、SUPPLY_C、VDD_D | VDD_IO | 5 |
| N_LOOP | OUT_B、RESET_C、INPUT_D | 无 | 3 |

预览：cases/hierarchy_xl 下的 source_preview.png、assembly_preview.png、
routing_layers.svg/png。PNG 用图片查看器；SVG 用 Firefox/Chrome。
总览按 net 上色，叠加多个金属层；交叉是否同层请看分层图或原生版图。

## 人工重新跑此测试

### 1. 建 job 目录，打开并保存源图

    mkdir -p /home/meow/autoroute/multinet/jobs/manual_hierarchy_test

在 Virtuoso 打开上述 top layout，使用 Layout XL，connectivity reference
指向同 cell 的 schematic。真实设计同样需要已有 XL 绑定及对应物理 pin。
先人工保存版图及电路；terminal 从磁盘重新打开，未保存的数据将被拒绝。

### 2. CIW 先导出障碍，再导出连接

    mnBaseDir = "/home/meow/autoroute/multinet"
    load(strcat(mnBaseDir "/autoroute_multinet.il"))
    load(strcat(mnBaseDir "/hierarchy/auto_export.il"))
    mnExportObstacles("/home/meow/autoroute/multinet/jobs/manual_hierarchy_test"
                      geGetEditCellView()
                      "/home/meow/autoroute/multinet/cases/hierarchy_xl/route_config.json")
    mnExportConnections("/home/meow/autoroute/multinet/jobs/manual_hierarchy_test"
                        geGetEditCellView())

看到 HIER_EXPORT_READY 后进入 terminal。两次导出之间不能移动／修改障碍；
第二步会再次核对障碍。重新导出第一步会使旧连接清单和 ready 标志失效。
配置逐字节复制到 job，之后修改它须重新从第一步导出。
实际设计请替换第三个参数为自己的**实际配置**；示例配置仅用于新测试，
不会覆盖 ~/route_config.json。给定 tech.tf 与 techfile 的 SHA256 相同，
测试配置来自这个实际 TSMC 工艺，没有猜测 via 尺寸。

### 3. terminal 一条命令完成整体求解及原生 layout 创建

    python3 /home/meow/autoroute/multinet/run_offline.py \
      --job /home/meow/autoroute/multinet/jobs/manual_hierarchy_test \
      --cdslib /home/meow/autoroute/audit/batch_cds.lib \
      --output-lib AR_AUDIT_20261010 \
      --output-cell hier_routes_manual_new \
      --xvfb /home/meow/autoroute/audit/xvfb_root/usr/bin/Xvfb

output cell 必须全新。输出库必须与源图 technology、单位、DBU、grid 相容。
成功打印 Saved overlay。默认 --max-seconds 90、--max-states 64，可提高预算。
全部 net 共用占用、候选冲突图、回退与自适应重规划；优先最多完整 net，
然后最低线长／via 成本。有限预算不保证数学全局最优；未连完就禁止建 layout。

IC6.1.7 的 bnd/lx 绑定 API 依赖 XL 编辑器上下文，-nograph 不能读取。
此命令启动真实 Virtuoso，在独立 Xvfb 显示中只读打开源图的 XL 上下文，
复核后用 dbCreatePath、dbCreateRect、dbCreateVia 建立新 view。
本机 Xvfb 仅解压在 audit 目录，未安装系统软件；其他机器可换系统 Xvfb 路径。
省略 --xvfb 则使用当前 DISPLAY，会出现本次程序的窗口。
脚本退出前会 purge 本次会话打开的辅助数据库，避免遗留未保存的空 constraint view。
只清理自己启动的进程组，不停止用户已有 Virtuoso。
同一 job 使用互斥锁防止并发改写；重跑时原生旧日志归档，不能把旧成功标志当作本次成功。

### 4. 人工调入源图

Create Instance 选择新 routing cell，**origin=0:0，orientation=R0，magnification=1**。
坐标是源版图坐标，不能按 overlay bbox 左下角对齐。源图未由脚本自动修改。
插入后按项目流程检查实际连通性、DRC/LVS；几何检查不是完整工艺签核。
再次规划应先移除旧 overlay，使用原始待连线版图；当前严格模块匹配会将
已插入的额外 routing 实例报为未绑定。

## 自动读取及保护范围

- source schematic 来自 lxGetLXInfo("srcView" cv)，实例／顶层 term 来自
  bndGetBoundObjects；绝不按名字相近或距离猜测 net。
- 同模块内部按对应 terminal 名找到物理 pin；不同模块 pin 名可以不同，
  最终按**顶层电路实际 net**归组。对外 pin 参与同一连接树。
- 检查全部电路实例端点和顶层 term 均有物理对应；缺失、未绑定、歧义都拒绝。
- 障碍按源 bbox 加 margin/halo 导出，受 route_bounds 限制。层次坐标使用实际
  transform。只有选中的精确 pin figure 获得 net 归属，该模块其他匿名走线
  仍是障碍。原有 via 按真实层范围保守阻挡。
- 当前支持本级一对一普通模块、矩形金属 pin、同模块 terminal 名对应。
  多端点、多 pin figure、旋转／镜像仍受几何检查。单端点 net 无需新增连线，
  其金属仍是障碍。polygon/path pin、mosaic/array、bus 表达式展开、
  多对多复杂 binding、实例 pin permutation 均明确拒绝，需专门适配。
- 严格 H/V；反向只允许原 pin 的同宽、同中心线直线延长，
  限于支路首颗 via 前／末颗 via 后。普通树接入点没有反向特权。
- 创建前重新读取磁盘源，比对几何、逻辑分组、真实 binding、配置快照。
  创建后用原生 AV/AO 各层实际 via 占地检查间距、障碍、其他 net；
  全部通过才保存。native 创建失败撤销整份新 view，源图不写入。

## 证据与重建

主 case 在 cases/hierarchy_xl/release：

- obstacles.sexp、connections.sexp：先后两次真实原生导出。
- nets.json：自动生成；binding_report.json：物理／逻辑实例及 pin 所属 net。
- export_ready.json、config_capture.json：顺序与原始输入哈希。
- batch_geometry.sexp、batch_plan.json/il、batch_plan.report.json：整体方案。
- batch_actual_vias.txt、batch_plan.actual_report.json：实际孔复核。
- offline_native.log、batch_engine.log、offline_result.json：原始运行证据。

重建程序 hierarchy/create_case.il：设置唯一 MH_TOKEN、已有绝对目录 MH_JOB，
使用 native_runner.run_native() 启动 Virtuoso/Xvfb，成功标志 HIER_CASE_COMPLETE。
程序拒绝已有底层／顶层 cell。hierarchy/native_checks.il 仅用于本测试，
不要对用户设计执行。最终断言、快照核对及限制见 cases/hierarchy_xl/TEST_RESULTS.json。
