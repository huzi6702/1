@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "MNA_PYTHON="
set "MNA_PYTHON_ARGS="
if defined VIRTUAL_ENV if exist "%VIRTUAL_ENV%\Scripts\python.exe" set "MNA_PYTHON=%VIRTUAL_ENV%\Scripts\python.exe"
if defined MNA_PYTHON goto python_ready
if defined CONDA_PREFIX if exist "%CONDA_PREFIX%\python.exe" set "MNA_PYTHON=%CONDA_PREFIX%\python.exe"
if defined MNA_PYTHON goto python_ready
where python >nul 2>nul
if not errorlevel 1 set "MNA_PYTHON=python"
if defined MNA_PYTHON goto python_ready
where py >nul 2>nul
if errorlevel 1 goto no_python
set "MNA_PYTHON=py"
set "MNA_PYTHON_ARGS=-3"
:python_ready
"%MNA_PYTHON%" %MNA_PYTHON_ARGS% "MNA_GUI.py" %*
set "MNA_EXIT=%ERRORLEVEL%"
if not "%MNA_EXIT%"=="0" (
  echo.
  echo GUI did not complete. Read the error above.
  echo Configure Python and dependencies manually; see code\docs\使用说明.txt.
  pause
)
exit /b %MNA_EXIT%
:no_python
echo Python was not found. Activate your configured Python environment and retry.
echo See code\docs\使用说明.txt.
pause
exit /b 1
