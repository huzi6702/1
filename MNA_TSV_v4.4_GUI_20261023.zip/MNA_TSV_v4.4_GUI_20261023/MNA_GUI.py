#!/usr/bin/env python3
"""MNA TSV 工作台唯一桌面入口。"""
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HOME = Path(__file__).resolve().parent
if (HOME/"code").is_dir():
    sys.path.insert(0,str(HOME/"code"))


if __name__ == "__main__":
    try:
        from mna_workbench import main
        raise SystemExit(main(app_root=HOME))
    except Exception:
        import traceback
        detail = traceback.format_exc()
        log = HOME/"code/startup_error.log"
        log.parent.mkdir(parents=True,exist_ok=True)
        log.write_text(detail,encoding="utf-8")
        try:
            import tkinter as tk
            from tkinter import messagebox
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("MNA 启动失败",f"{detail[-2200:]}\n\n详细日志：{log}",parent=root)
            root.destroy()
        except Exception:
            if sys.stderr:
                sys.stderr.write(detail)
        raise SystemExit(1)
