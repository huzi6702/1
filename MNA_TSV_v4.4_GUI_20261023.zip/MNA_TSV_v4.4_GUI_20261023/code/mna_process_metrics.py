"""Sample or stop only one explicitly identified job process tree.

Requires psutil >= 5.9.  Missing psutil is reported in the returned dictionaries;
there is no fallback that searches for or stops unrelated Python processes.

The memory metric is the sum of resident set sizes (RSS) of the requested root
and its recursive descendants.  One MiB is 1024**2 bytes.  Shared resident pages
can be counted in more than one process, so this is not unique physical memory.
Taking a snapshot and reading each process are separate operations: processes
that exit between them are ignored, while access errors are reported as partial.
"""
from __future__ import annotations

import math
import os
import threading
from time import perf_counter

try:
    import psutil as _psutil
except ImportError:  # The Tk application can still explain a missing dependency.
    _psutil = None


MIB = 1024 ** 2
MEMORY_METRIC = "RSS sum"
DEPENDENCY_ERROR = "Process-tree monitoring requires psutil>=5.9; install requirements-core.txt"
SUSPEND_CONFIRM_TIMEOUT = 0.5


def _confirm_suspension(process, timeout=SUSPEND_CONFIRM_TIMEOUT):
    """Wait for the OS to report completion of the suspension request.

    In particular on Windows, returning from suspend() is not a useful test
    assertion that the separately queried thread states are already stopped.
    Never enumerate a spawn coordinator's children before confirming this.
    """
    deadline = perf_counter() + timeout
    pause = threading.Event()
    while process.status() != _psutil.STATUS_STOPPED:
        remaining = deadline - perf_counter()
        if remaining <= 0:
            raise _psutil.TimeoutExpired(timeout, pid=process.pid,
                                        name="waiting for coordinator suspension")
        pause.wait(min(.005, remaining))


def _checked_pid(root_pid):
    if isinstance(root_pid, bool) or not isinstance(root_pid, (int, str, float)):
        return None
    try:
        value = int(root_pid)
        if value <= 0 or (isinstance(root_pid, float) and root_pid != value):
            return None
        return value
    except (TypeError, ValueError, OverflowError):
        return None


def _snapshot(root_pid, include_parent, root_process=None):
    """Return leaf-first psutil.Process objects without enumerating other jobs."""
    errors = []
    try:
        parent = root_process if root_process is not None else _psutil.Process(root_pid)
    except _psutil.NoSuchProcess:
        return [], errors
    except _psutil.Error as exc:
        return [], [f"PID {root_pid}: {exc}"]
    try:
        children = parent.children(recursive=True)
    except _psutil.NoSuchProcess:
        # No process tree remains to inspect under this PID.  In particular,
        # do not search globally for Python workers after a root has exited.
        children = []
    except _psutil.Error as exc:
        children = []
        errors.append(f"PID {root_pid} children: {exc}")
    by_pid = {child.pid: child for child in children if child.pid != root_pid}
    parent_pids = {}
    for child in by_pid.values():
        try:
            parent_pids[child.pid] = child.ppid()
        except _psutil.NoSuchProcess:
            continue
        except _psutil.Error as exc:
            errors.append(f"PID {child.pid} parent: {exc}")

    def depth(process):
        result, ancestor, seen = 1, parent_pids.get(process.pid), {process.pid}
        while ancestor in by_pid and ancestor not in seen:
            seen.add(ancestor)
            result += 1
            ancestor = parent_pids.get(ancestor)
        return result

    ordered = sorted(by_pid.values(), key=depth, reverse=True)
    if include_parent:
        ordered.append(parent)
    return ordered, errors


def process_tree_memory(root_pid, include_parent=True):
    """Return RSS bytes/MiB, readable process count, and availability.

    An already-exited PID returns an available zero-sized sample.  Invalid
    input and a missing dependency return ``available=False``.  An access
    error sets ``partial=True`` and preserves memory read from other members.
    """
    result = dict(rss_bytes=0, rss_mib=0.0, process_count=0,
                  available=False, metric=MEMORY_METRIC, partial=False, errors=[])
    pid = _checked_pid(root_pid)
    if pid is None:
        result["errors"] = ["root_pid must be an explicit positive integer PID"]
        return result
    if _psutil is None:
        result["errors"] = [DEPENDENCY_ERROR]
        return result
    processes, errors = _snapshot(pid, include_parent)
    result["errors"] = errors
    for process in processes:
        try:
            rss = process.memory_info().rss
        except _psutil.NoSuchProcess:
            continue
        except _psutil.Error as exc:
            errors.append(f"PID {process.pid} memory: {exc}")
            continue
        result["rss_bytes"] += int(rss)
        result["process_count"] += 1
    result["rss_mib"] = result["rss_bytes"] / MIB
    result["partial"] = bool(errors)
    result["available"] = bool(result["process_count"] or not errors)
    return result


def terminate_process_tree(root_pid, include_parent=True, timeout=2):
    """Terminate this PID's descendants leaf-first, then optionally the PID.

    ``timeout`` is the maximum wait in seconds for each of the terminate and
    kill phases.  Surviving targeted processes are killed, then waited for.
    psutil's Process identity checks guard against signalling a reused PID.
    The result distinguishes signal requests from confirmed exited processes;
    remaining PIDs and access errors are returned rather than hidden.

    For a foreign root that is itself being stopped, suspend the coordinator
    before enumerating children so it cannot spawn workers after the snapshot.
    Failure to suspend aborts cancellation with an error.  Any surviving root
    suspended by this call is resumed in finally; an already-stopped root keeps
    its original state.  A children-only request does not suspend its parent.
    """
    result = dict(available=False, process_count=0, terminated_pids=[],
                  killed_pids=[], gone_pids=[], alive_pids=[], errors=[])
    pid = _checked_pid(root_pid)
    if pid is None:
        result["errors"] = ["root_pid must be an explicit positive integer PID"]
        return result
    try:
        timeout = float(timeout)
    except (TypeError, ValueError, OverflowError):
        timeout = float("nan")
    if not math.isfinite(timeout) or timeout < 0:
        result["errors"] = ["timeout must be finite and nonnegative"]
        return result
    if _psutil is None:
        result["errors"] = [DEPENDENCY_ERROR]
        return result
    return ProcessTreeStopController(pid, include_parent=include_parent).stop(timeout)


class ProcessTreeStopController:
    """Retain captured Process identities across cancellation retries.

    Construct once for each job, immediately after starting its coordinator,
    and reuse the controller.  A live coordinator is frozen before each tree
    snapshot.  Once it exits, previously captured worker identities can still
    be stopped without looking up a replacement process at its old PID.
    Children that were never captured before their parent disappeared cannot
    reliably be attributed to a job; this class never guesses using global
    process names.  Each stop report describes only that attempt.
    """

    def __init__(self, root_pid, include_parent=True):
        self.root_pid = _checked_pid(root_pid)
        if self.root_pid is None:
            raise ValueError("root_pid must be an explicit positive integer PID")
        self.include_parent = include_parent
        self._lock = threading.Lock()
        self._root = None
        self._targets = {}
        self._initial_error = None
        if _psutil is not None:
            try:
                self._root = _psutil.Process(self.root_pid)
            except _psutil.NoSuchProcess:
                pass
            except _psutil.Error as exc:
                self._initial_error = f"PID {self.root_pid}: {exc}"
        if self._root is not None and include_parent:
            self._targets[self.root_pid] = self._root

    @staticmethod
    def _is_running(process, errors):
        try:
            # psutil verifies the original Process identity here; a reused
            # PID is reported as not running rather than targeted again.
            return process.is_running()
        except _psutil.NoSuchProcess:
            return False
        except _psutil.Error as exc:
            errors.append(f"PID {process.pid} identity check: {exc}")
            return True  # Retain an unconfirmed target for signal/wait checks.

    def stop(self, timeout=1):
        result = dict(available=False, process_count=0, terminated_pids=[],
                      killed_pids=[], gone_pids=[], alive_pids=[], errors=[])
        try:
            timeout = float(timeout)
        except (TypeError, ValueError, OverflowError):
            timeout = float("nan")
        if not math.isfinite(timeout) or timeout < 0:
            result["errors"] = ["timeout must be finite and nonnegative"]
            return result
        if _psutil is None:
            result["errors"] = [DEPENDENCY_ERROR]
            return result
        result["available"] = True
        if self._initial_error is not None:
            result.update(errors=[self._initial_error], alive_pids=[self.root_pid])
            return result
        with self._lock:
            return self._stop_locked(timeout, result)

    def _stop_locked(self, timeout, result):
        errors = result["errors"]
        resume_parent = None
        try:
            current = []
            root_alive = self._root is not None and self._is_running(self._root, errors)
            if root_alive:
                if self.include_parent and self.root_pid != os.getpid():
                    try:
                        if self._root.status() != _psutil.STATUS_STOPPED:
                            self._root.suspend()
                            resume_parent = self._root
                            _confirm_suspension(self._root)
                    except _psutil.NoSuchProcess:
                        root_alive = False
                    except _psutil.Error as exc:
                        errors.append(f"PID {self.root_pid} suspend: {exc}")
                        result.update(process_count=len(self._targets) or 1,
                                      alive_pids=sorted(set(self._targets) | {self.root_pid}))
                        return result
                if root_alive:
                    current, snapshot_errors = _snapshot(
                        self.root_pid, self.include_parent, root_process=self._root)
                    errors.extend(snapshot_errors)
            previous = [process for process in self._targets.values()
                        if self._is_running(process, errors)]
            # Current children retain snapshot leaf order.  Orphaned workers
            # remembered from earlier attempts follow; the root stays last.
            merged = {process.pid: process for process in current
                      if process.pid != self.root_pid}
            for process in previous:
                if process.pid != self.root_pid:
                    merged.setdefault(process.pid, process)
            if root_alive and self.include_parent:
                merged[self.root_pid] = self._root
            self._targets = merged
            return _stop_snapshot(list(merged.values()), timeout, result)
        finally:
            if resume_parent is not None:
                try:
                    if resume_parent.is_running():
                        resume_parent.resume()
                except _psutil.NoSuchProcess:
                    pass
                except _psutil.Error as exc:
                    errors.append(f"PID {self.root_pid} resume after cancellation: {exc}")


def _stop_snapshot(processes, timeout, result):
    """Signal captured Process identities; never look up replacement PIDs."""
    errors = result["errors"]
    result["process_count"] = len(processes)
    if not processes:
        return result
    gone = set()
    for process in processes:
        try:
            process.terminate()
            result["terminated_pids"].append(process.pid)
        except _psutil.NoSuchProcess:
            gone.add(process.pid)
        except _psutil.Error as exc:
            errors.append(f"PID {process.pid} terminate: {exc}")
    try:
        exited, alive = _psutil.wait_procs(processes, timeout=timeout)
        gone.update(process.pid for process in exited)
    except _psutil.Error as exc:
        errors.append(f"Waiting after terminate: {exc}")
        alive = processes
    for process in alive:
        try:
            process.kill()
            result["killed_pids"].append(process.pid)
        except _psutil.NoSuchProcess:
            gone.add(process.pid)
        except _psutil.Error as exc:
            errors.append(f"PID {process.pid} kill: {exc}")
    try:
        exited, alive = _psutil.wait_procs(alive, timeout=timeout)
        gone.update(process.pid for process in exited)
    except _psutil.Error as exc:
        errors.append(f"Waiting after kill: {exc}")
    # wait_procs accounts for exited/non-child processes without using PIDs
    # to create new Process objects, preserving the original identities.
    result["gone_pids"] = sorted(gone)
    result["alive_pids"] = sorted(process.pid for process in alive if process.pid not in gone)
    return result


class MemorySampler:
    """Sample one process tree until stop; the returned peak is sampled RSS.

    ``root_pid=None`` means the current process.  ``start()`` returns this
    sampler and ``stop()`` returns a frozen statistics dictionary.  A sampler
    is one-shot; repeated stop calls return equal independent copies.  The
    context manager starts/stops automatically and preserves body exceptions.
    Sampling happens immediately at start, periodically in a daemon thread,
    and once at stop.  Peaks between samples can therefore still be missed;
    this is not an operating-system high-water-mark or unique-memory metric.
    Stop before output/plotting to measure only a calculation interval.
    """

    def __init__(self, root_pid=None, interval=0.05, include_parent=True):
        self.root_pid = os.getpid() if root_pid is None else _checked_pid(root_pid)
        if self.root_pid is None:
            raise ValueError("root_pid must be an explicit positive integer PID")
        try:
            self.interval = float(interval)
        except (TypeError, ValueError, OverflowError):
            self.interval = float("nan")
        if not math.isfinite(self.interval) or self.interval <= 0:
            raise ValueError("interval must be finite and positive")
        self.include_parent = include_parent
        self._stop_event = threading.Event()
        self._thread = None
        self._started = None
        self._frozen = None
        self._statistics = dict(peak_sampled_rss_bytes=0, peak_sampled_rss_mib=0.0,
                                peak_sampled_process_count=0, sample_count=0,
                                available=False, metric=MEMORY_METRIC,
                                interval_s=self.interval, elapsed_s=0.0,
                                partial=False, errors=[])

    def _take_sample(self):
        sample = process_tree_memory(self.root_pid, include_parent=self.include_parent)
        stats = self._statistics
        if sample["available"]:
            stats["available"] = True
            stats["sample_count"] += 1
            stats["peak_sampled_rss_bytes"] = max(stats["peak_sampled_rss_bytes"], sample["rss_bytes"])
            stats["peak_sampled_process_count"] = max(stats["peak_sampled_process_count"], sample["process_count"])
        stats["partial"] = stats["partial"] or sample["partial"]
        for error in sample["errors"]:
            if error not in stats["errors"]:
                stats["errors"].append(error)

    def _sample_loop(self):
        while not self._stop_event.wait(self.interval):
            self._take_sample()

    def start(self):
        if self._frozen is not None:
            raise RuntimeError("A stopped MemorySampler cannot be restarted")
        if self._started is not None:
            return self
        self._started = perf_counter()
        self._take_sample()
        self._thread = threading.Thread(target=self._sample_loop,
                                        name="MNA memory sampler", daemon=True)
        self._thread.start()
        return self

    def stop(self):
        if self._frozen is None:
            self._stop_event.set()
            if self._thread is not None and self._thread is not threading.current_thread():
                self._thread.join()
            if self._started is not None:
                self._take_sample()
                self._statistics["elapsed_s"] = perf_counter() - self._started
            self._statistics["peak_sampled_rss_mib"] = self._statistics["peak_sampled_rss_bytes"] / MIB
            self._frozen = dict(self._statistics, errors=list(self._statistics["errors"]))
        return dict(self._frozen, errors=list(self._frozen["errors"]))

    def __enter__(self):
        return self.start()

    def __exit__(self, exc_type, exc_value, traceback):
        self.stop()
        return False
