import copy
import importlib.util
import io
import json
import sys
import tempfile
import threading
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

import matplotlib
matplotlib.use('Agg')
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import mna_ir_dual as base
import mna_ir_stack as stack


SIMPLE = '''[stack]
layers=2
[mesh]
xgrid=1
ygrid=1
rh=.01
rv=.01
xpitch=10
ypitch=10
[bump]
xpn=0
ypn=0
rz=.1
rz_vss=.2
powerv=.8
[bumploc]
bumplocvdd=[[1,1]]
bumplocvss=[[1,1]]
[current]
currentmode=1
i=-.2
mul=1
[current.1]
currentmode=1
i=-.3
[tsv.0_1]
lower=0
upper=1
rz=.05
rz_vss=.07
locvdd=[[1,1]]
locvss=[[1,1]]
'''


def read_text(text):
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / 'case.ini'
        path.write_text(text, encoding='utf-8')
        return stack.read_stack_config(path)


def full_mna_reference(p, rail):
    """Independent voltage-form MNA with ideal source current as an unknown."""
    size = p['node_count']
    matrix = np.zeros((size + 2, size + 2))
    rhs = np.zeros(size + 2)
    def resistor(a, b, r):
        g = 1 / r
        matrix[a, a] += g
        matrix[b, b] += g
        matrix[a, b] -= g
        matrix[b, a] -= g
    for layer in p['layers']:
        m, n, offset = layer['xgrid'], layer['ygrid'], layer['offset']
        for y in range(n):
            for x in range(m):
                a = offset + y * m + x
                if x + 1 < m:
                    resistor(a, a + 1, layer['rh'])
                if y + 1 < n:
                    resistor(a, a + m, layer['rv'])
    # Deliberately rebuild each footprint without using assemble_rail/build_vloc.
    for source in p['sources'][rail]:
        for node in source['nodes']:
            resistor(int(node), size, source['branch_r'])
    for link in p['links']:
        for row in link[rail]:
            resistor(row['a'], row['b'], row['r'])
    matrix[size, size + 1] = matrix[size + 1, size] = 1
    voltage = p['powerv'] if rail == 'vdd' else 0.
    rhs[:size] = p['load'] if rail == 'vdd' else -p['load']
    rhs[size + 1] = voltage
    return np.linalg.solve(matrix, rhs)[:size]


class StackTests(unittest.TestCase):
    def test_legacy_path_plot_keeps_resistors_and_destination_coordinates(self):
        p = read_text(SIMPLE)
        with tempfile.TemporaryDirectory() as d:
            fig = stack.plot_vertical_layout(p,Path(d))
            try:
                self.assertEqual([len(ax.collections[0].get_offsets()) for ax in fig.axes[:4]],
                                 [1,1,1,1])
                for ax,resistance in zip(fig.axes[:4],(.1,.2,.05,.07)):
                    np.testing.assert_allclose(ax.collections[0].get_offsets(),[[10,10]])
                    np.testing.assert_allclose(ax.collections[0].get_array(),[resistance])
                    self.assertIn('1 paths',ax.get_title())
                self.assertTrue(all(ax.get_ylabel()=='Path R (ohm)' for ax in fig.axes[4:]))
            finally:
                stack.plt.close(fig)

    def test_two_layer_hand_calculation_and_tsv_polarity(self):
        p = read_text(SIMPLE)
        (vdd, vss), _ = stack.solve_stack(p)
        # Bottom paths carry both loads, upper TSVs carry upper load only.
        np.testing.assert_allclose(vdd[0], [.5 * .1, .5 * .1 + .3 * .05], atol=1e-15)
        np.testing.assert_allclose(vss[0], [.5 * .2, .5 * .2 + .3 * .07], atol=1e-15)
        self.assertAlmostEqual(vdd[1][0]['current_A'], .5)
        self.assertAlmostEqual(vss[1][0]['current_A'], -.5)
        self.assertAlmostEqual(vdd[2][0]['current_A'], .3)
        self.assertAlmostEqual(vss[2][0]['current_A'], -.3)

    def test_three_layers_and_distinct_interface_resistance(self):
        text = SIMPLE.replace('layers=2', 'layers=3') + '''
[current.2]
i=-.4
[tsv.1_2]
lower=1
upper=2
rz=.03
rz_vss=.04
locvdd=[[1,1]]
locvss=[[1,1]]
'''
        p = read_text(text)
        (vdd, vss), _ = stack.solve_stack(p)
        np.testing.assert_allclose(vdd[0], [.09, .09 + .7*.05, .09 + .7*.05 + .4*.03])
        np.testing.assert_allclose(vss[0], [.18, .18 + .7*.07, .18 + .7*.07 + .4*.04])
        np.testing.assert_allclose([r['current_A'] for r in vdd[2]], [.7, .4])

    def heterogeneous_case(self):
        text = SIMPLE.replace('xgrid=1', 'xgrid=3').replace('ygrid=1', 'ygrid=2')
        text = text.replace('\nlocvdd=[[1,1]]', '\nlocvdd=[[2,1,1,2,.09],[3,2,2,3,.12]]')
        text = text.replace('\nlocvss=[[1,1]]', '\nlocvss=[[1,2,2,1,.08]]')
        text = text.replace('bumplocvdd=[[1,1]]', 'bumplocvdd=[[1,1,.11],[3,2,.18]]')
        text = text.replace('bumplocvss=[[1,1]]', 'bumplocvss=[[3,1,.23]]')
        text += '''
[mesh.1]
xgrid=2
ygrid=3
rh=.034
rv=.027
xpitch=15
ypitch=20
'''
        return read_text(text)

    def test_heterogeneous_mesh_vs_independent_full_mna(self):
        p = self.heterogeneous_case()
        results, _ = stack.solve_stack(p)
        for rail, result in zip(('vdd', 'vss'), results):
            actual = p['powerv'] - result[0] if rail == 'vdd' else result[0]
            np.testing.assert_allclose(actual, full_mna_reference(p, rail), rtol=0, atol=1e-13)
            self.assertLess(max(abs(np.array(result[3]['layer_current_balance_error_A']))), 1e-12)

    def test_single_layer_matches_v2_all_nodes_and_source_footprints(self):
        legacy = base.read_config(ROOT / 'pginfo2.ini')
        text = '[stack]\nlayers=1\n' + (ROOT / 'pginfo2.ini').read_text()
        p = read_text(text)
        old_results = base.solve_network(legacy, p['load'], solver='direct')
        results, _ = stack.solve_stack(p)
        np.testing.assert_allclose(p['powerv'] - results[0][0], old_results[0][0].ravel(), atol=1e-12)
        np.testing.assert_allclose(results[1][0], old_results[1][0].ravel(), atol=1e-12)
        for index in (0, 1):
            np.testing.assert_allclose([r['current_mA'] for r in results[index][1]],
                                       old_results[index][1]['I(mA):'], atol=1e-9)

    def test_no_upper_load_no_tsv_current(self):
        p = read_text(SIMPLE.replace('i=-.3', 'i=0'))
        results, _ = stack.solve_stack(p)
        for result in results:
            self.assertAlmostEqual(result[0][0], result[0][1])
            self.assertAlmostEqual(result[2][0]['current_A'], 0)

    def test_upper_load_changes_lower_source_current_and_drop(self):
        p = read_text(SIMPLE.replace('i=-.2', 'i=0'))
        results, _ = stack.solve_stack(p)
        self.assertAlmostEqual(results[0][1][0]['current_A'], .3)
        self.assertAlmostEqual(results[0][0][0], .03)

    def test_uniform_and_regional_power_conversion_and_overlap(self):
        text = SIMPLE.replace('xgrid=1', 'xgrid=3').replace('ygrid=1', 'ygrid=3')
        text = text.replace('currentmode=1\ni=-.2\nmul=1', 'currentmode=3\npower_w=.16')
        text = text.replace('currentmode=1\ni=-.3',
                             'currentmode=4\npmap=[[.08,1,1,3,3],[.16,3,3,3,3]]')
        p = read_text(text)
        self.assertAlmostEqual(p['layers'][0]['load_current_A'], .2)
        self.assertAlmostEqual(p['layers'][1]['load_current_A'], .3)
        self.assertAlmostEqual(p['layers'][1]['load'][-1], -.1/9 - .2)

    def test_regional_negative_current_is_independent_per_layer(self):
        text = SIMPLE.replace('xgrid=1', 'xgrid=3').replace('ygrid=1', 'ygrid=3')
        text = text.replace('currentmode=1\ni=-.3',
                             'currentmode=2\nimap=[[-.3,2,2,3,3]]\nmul=9')
        p = read_text(text)
        self.assertAlmostEqual(p['layers'][1]['load_current_A'], .3)
        self.assertEqual(np.count_nonzero(p['layers'][1]['load']), 4)

    def test_missing_and_disconnected_rail_rejected(self):
        with self.assertRaisesRegex(ValueError, 'VSS layers'):
            read_text(SIMPLE.replace('\nlocvss=[[1,1]]', '\nlocvss=[]'))
        with self.assertRaisesRegex(ValueError, 'specify each layer'):
            read_text(SIMPLE.replace('[current.1]', '[unused]'))
        with self.assertRaisesRegex(ValueError, 'VDD layers'):
            read_text(SIMPLE.split('[tsv.0_1]')[0])

    def test_invalid_resistance_coordinates_current_and_power(self):
        for before, after in (('rz=.05', 'rz=0'), ('rz=.05', 'rz=-.1'),
                              ('\nlocvdd=[[1,1]]', '\nlocvdd=[[2,1]]'),
                              ('i=-.3', 'i=.3'), ('i=-.3', 'i=nan'),
                              ('\nlocvdd=[[1,1]]', '\nlocvdd=[[1.2,1]]'),
                              ('upper=1', 'upper=2')):
            with self.subTest(after=after), self.assertRaises(ValueError):
                read_text(SIMPLE.replace(before, after))
        with self.assertRaises(ValueError):
            read_text(SIMPLE.replace('currentmode=1\ni=-.3', 'currentmode=3\npower_w=-.1'))

    def test_per_path_parallel_resistors(self):
        text = SIMPLE.replace('\nlocvdd=[[1,1]]', '\nlocvdd=[[1,1,1,1,.06],[1,1,1,1,.03]]')
        p = read_text(text)
        results, _ = stack.solve_stack(p)
        self.assertAlmostEqual(results[0][0][1] - results[0][0][0], .3 * .02)
        np.testing.assert_allclose([r['current_A'] for r in results[0][2]], [.1, .2])

    @unittest.skipUnless(importlib.util.find_spec('pyamg'), 'PyAMG is not installed')
    def test_amg_matches_direct_at_every_layer_node(self):
        p = stack.read_stack_config(ROOT / 'pginfo_stack.ini')
        direct, _ = stack.solve_stack(p, solver='direct')
        amg, _ = stack.solve_stack(p, solver='amg')
        for a, b in zip(direct, amg):
            np.testing.assert_allclose(a[0], b[0], rtol=0, atol=1e-10)

    @unittest.skipUnless(importlib.util.find_spec('pyamg'), 'PyAMG is not installed')
    def test_nonconverged_amg_rejected(self):
        p = stack.read_stack_config(ROOT / 'pginfo_stack.ini')
        with self.assertRaisesRegex(RuntimeError, 'did not converge'):
            stack.solve_stack(p, solver='amg', rtol=1e-14, maxiter=1)

    def test_default_parallel_and_serial_agreement(self):
        p = self.heterogeneous_case()
        original = stack.solve_stack_rail
        barrier = threading.Barrier(2, timeout=10)
        names = []
        def synchronized(*args):
            names.append(threading.current_thread().name)
            barrier.wait()
            return original(*args)
        with patch.object(stack, 'solve_stack_rail', side_effect=synchronized):
            parallel, timing = stack.solve_stack(p)
        serial, _ = stack.solve_stack(p, parallel=False)
        self.assertEqual(len(set(names)), 2)
        self.assertTrue(timing['parallel_rails'])
        for a, b in zip(parallel, serial):
            np.testing.assert_array_equal(a[0], b[0])

    def test_cli_dispatch_full_resolution_csv_power_and_peak(self):
        with tempfile.TemporaryDirectory() as d, redirect_stdout(io.StringIO()):
            with patch.object(stack, 'plot_stack'):
                summary = base.run(ROOT / 'pginfo_stack.ini', d, plot_max_axis=8)
            frame = pd.read_csv(Path(d) / 'node_results.csv')
            self.assertEqual(len(frame), 44 * 30 * 2)
            self.assertEqual(set(frame['layer']), {0, 1})
            self.assertAlmostEqual(summary['load_current_A'], 1.48)
            self.assertLess(abs(summary['power_balance']['balance_error_W']), 1e-10)
            tsvs = pd.read_csv(Path(d) / 'tsv_current.csv')
            self.assertAlmostEqual(tsvs[tsvs.rail == 'VDD'].current_A.sum(), .5, places=10)
            self.assertAlmostEqual(tsvs[tsvs.rail == 'VSS'].current_A.sum(), -.5, places=10)
            for layer in summary['layers']:
                data = frame[frame.layer == layer['id']]
                self.assertAlmostEqual(data.total_loss_mV.max(), layer['max_total_loss']['value']*1000)
            self.assertEqual(json.loads((Path(d) / 'summary.json').read_text())['layer_count'], 2)
            self.assertEqual(summary['original_spec_metrics']['spec'], 11.2)


if __name__ == '__main__':
    unittest.main()
