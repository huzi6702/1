import ast
import importlib.util
import json
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

import matplotlib
matplotlib.use("Agg")
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import mna_ir_dual as new

spec = importlib.util.spec_from_file_location("reference_v1", ROOT / "tests/reference_v1.py")
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)


class SolverTests(unittest.TestCase):
    def setUp(self):
        self.p = new.read_config(ROOT / "pginfo2.ini")

    def test_region_coverage_overlap_reverse_and_bounds(self):
        z = np.zeros(25)
        new.gen_imap([[-1, 1, 1, 3, 3], [-.5, 3, 3, 3, 3]], 5, 5, z, 1)
        self.assertEqual(np.count_nonzero(z), 9)
        self.assertAlmostEqual(z.sum(), -1.5)
        self.assertAlmostEqual(z.reshape(5, 5)[2, 2], -1 / 9 - .5)
        reversed_z = np.zeros(25)
        new.gen_imap([[-1, 3, 3, 1, 1], [-.5, 3, 3, 3, 3]], 5, 5, reversed_z, 1)
        np.testing.assert_array_equal(z, reversed_z)
        untouched = np.zeros(25)
        with self.assertRaises(ValueError):
            new.gen_imap([[-1, 1, 1, 3, 3], [-1, 1, 1, 6, 3]], 5, 5, untouched, 1)
        np.testing.assert_array_equal(untouched, 0)

    def test_single_node_analytic(self):
        p = dict(xgrid=1, ygrid=1, rh=.015, rv=.015, rz=.39, xpn=0, ypn=0)
        G, _ = new.gfunc(1, 1, 1 / .015, 1 / .015)
        for voltage, current in ((.8, -.98), (0., .98)):
            actual, _, diag = new.solve_rail(p, G, np.array([[1, 1]]), voltage,
                                             np.array([current]))
            self.assertAlmostEqual(actual[0, 0], voltage + current * .39, places=14)
            self.assertLess(abs(diag["current_balance_error_A"]), 1e-14)

    def compare_models(self, load, solver):
        p = self.p
        G, _ = old.gfunc(p["xgrid"], p["ygrid"], 1 / p["rh"], 1 / p["rv"])
        actual = new.solve_network(p, load, solver=solver)
        for index, (rail, voltage, injection) in enumerate(
                (("vdd", p["powerv"], load), ("vss", 0., -load))):
            expected = old.solve_rail(p, G, p["bump" + rail], voltage, injection)
            np.testing.assert_allclose(actual[index][0], expected[0], rtol=0, atol=1e-10)
            np.testing.assert_allclose(actual[index][1]["I(mA):"],
                                       expected[1]["I(mA):"], rtol=0, atol=1e-7)
            self.assertLess(abs(actual[index][2]["current_balance_error_A"]), 1e-9)

    def test_uniform_against_previous_mna(self):
        self.compare_models(np.full(1320, -.98 / 1320), "direct")

    def test_nonuniform_anisotropic_against_previous_mna(self):
        self.p["rh"], self.p["rv"] = .005, .075
        load = np.zeros(1320)
        new.gen_imap([[-.6, 1, 1, 44, 30], [-.3, 14, 9, 29, 24],
                      [-.08, 22, 15, 22, 15]], 44, 30, load, 1)
        self.compare_models(load, "direct")

    @unittest.skipUnless(importlib.util.find_spec("pyamg"), "PyAMG is not installed")
    def test_amg_full_node_and_bump_agreement(self):
        rng = np.random.default_rng(321)
        load = -rng.uniform(.1, 1., size=1320)
        load *= .98 / abs(load.sum())
        self.compare_models(load, "amg")

    @unittest.skipUnless(importlib.util.find_spec("pyamg"), "PyAMG is not installed")
    def test_nonconverged_amg_rejected(self):
        p = self.p
        G, _ = new.gfunc(44, 30, 1 / p["rh"], 1 / p["rv"])
        with self.assertRaisesRegex(RuntimeError, "did not converge"):
            new.solve_rail(p, G, p["bumpvdd"], .8, np.full(1320, -.98 / 1320),
                            solver="amg", rtol=1e-14, maxiter=1)

    def test_default_really_runs_two_rail_workers(self):
        original = new.solve_rail
        barrier = threading.Barrier(2, timeout=10)
        names = []
        def both_workers(*args):
            names.append(threading.current_thread().name)
            barrier.wait()
            return original(*args)
        with patch.object(new, "solve_rail", side_effect=both_workers):
            _, _, timing = new.solve_network(self.p, np.full(1320, -.98 / 1320))
        self.assertTrue(timing["parallel_rails"])
        self.assertEqual(len(set(names)), 2)

    def test_serial_matches_parallel(self):
        load = np.full(1320, -.98 / 1320)
        serial = new.solve_network(self.p, load, parallel=False, solver="direct")
        parallel = new.solve_network(self.p, load, solver="direct")
        for index in (0, 1):
            np.testing.assert_array_equal(serial[index][0], parallel[index][0])

    def test_display_keeps_extent_peak_and_original_data(self):
        field = np.zeros((17, 29))
        field[6, 3] = 1000
        before = field.copy()
        xedge, yedge, sample = new.display_grid(field, 10, 20, max_axis=8,
                                               x_offset=4, y_offset=3)
        self.assertLessEqual(max(sample.shape), 8)
        self.assertEqual(sample.max(), field.max())
        self.assertEqual(xedge[0], 45.)
        self.assertEqual(xedge[-1], 335.)
        self.assertEqual(yedge[0], 70.)
        self.assertEqual(yedge[-1], 410.)
        np.testing.assert_array_equal(field, before)

    def test_full_node_csv_and_extrema_independent_of_display_limit(self):
        captured = []
        def fake_plot(p, vdd_ir, vss, total, *args):
            captured.append(total.shape)
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(new, "plot_results", side_effect=fake_plot):
                result = new.run(ROOT / "pginfo2.ini", directory, plot_max_axis=8,
                                 surface_max_axis=4)
            frame = pd.read_csv(Path(directory) / "node_results.csv")
            self.assertEqual(len(frame), 1320)
            self.assertEqual(captured, [(30, 44)])
            self.assertAlmostEqual(frame["total_loss_mV"].max(),
                                   result["max_total_loss"]["value"] * 1000, places=10)
            self.assertAlmostEqual(result["max_total_loss"]["value"], .0149569547154, places=10)
            self.assertAlmostEqual(result["original_spec_metrics"]["spec"], 11.2)
            saved = json.loads((Path(directory) / "summary.json").read_text())
            self.assertTrue(saved["performance"]["parallel_rails"])

    def test_amg_selection_and_absent_dependency(self):
        self.assertEqual(new.select_solver("auto", 1320, 250000), "direct")
        with patch.object(new.importlib.util, "find_spec", return_value=None):
            self.assertEqual(new.select_solver("auto", 1000000, 250000), "direct")
            with self.assertRaises(ImportError):
                new.select_solver("amg", 1000000, 250000)

    def test_active_show_call(self):
        tree = ast.parse((ROOT / "mna_ir_dual.py").read_text())
        self.assertTrue(any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                            and isinstance(node.func.value, ast.Name)
                            and node.func.value.id == "plt" and node.func.attr == "show"
                            for node in ast.walk(tree)))


if __name__ == "__main__":
    unittest.main()
