"""Windows-spawn scans preserve distributed electrical results and failures."""
from __future__ import annotations

from contextlib import redirect_stdout
import importlib.util
import io
import json
import multiprocessing
import os
from pathlib import Path
import tempfile
from time import perf_counter
import unittest
from unittest.mock import patch

import mna_workbench_jobs as jobs


ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("intentionally_dynamic_spacing_module",ROOT/"studies/two_column_spacing.py")
study=importlib.util.module_from_spec(spec)
spec.loader.exec_module(study)


def temporary():
    folder=ROOT/".local_validation/tmp"
    folder.mkdir(parents=True,exist_ok=True)
    return tempfile.TemporaryDirectory(prefix="scan_parallel_",dir=folder)


@unittest.skipIf((os.cpu_count() or 1)<2,"requires two available CPUs")
class ParallelScanTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=temporary()
        cls.addClassCleanup(cls.temp.cleanup)
        cls.home=Path(cls.temp.name)
        cls.results={}
        for workers in (1,2):
            out=cls.home/f"workers{workers}"
            with redirect_stdout(io.StringIO()):
                summary=jobs.run_scan(dict(spacings=[320,330,350,360],workers=workers,export_ir=False),out)
            cls.results[workers]=(summary,study.read_csv(out/"sweep_results.csv"),out)

    def test_eight_real_points_match_ir_peak_positions_counts_and_conservation(self):
        _,serial,_=self.results[1]
        _,parallel,_=self.results[2]
        self.assertEqual(len(serial),8)
        self.assertEqual(len(parallel),8)
        ignored={"compute_excluding_output_s","numeric_wall_s","worker_pid","worker_started_perf_s",
                 "worker_finished_perf_s","peak_compute_rss_bytes","peak_compute_rss_MiB","compute_rss_available"}
        for first,second in zip(serial,parallel):
            self.assertEqual(first["scenario"],second["scenario"])
            self.assertEqual(first["spacing_um"],second["spacing_um"])
            for key in first:
                if key in ignored or key=="scenario":
                    continue
                with self.subTest(scenario=first["scenario"],spacing=first["spacing_um"],field=key):
                    self.assertAlmostEqual(first[key],second[key],delta=1e-8)
            self.assertLess(second["max_relative_residual"],1e-9)
            self.assertLess(abs(second["power_balance_error_W"]),1e-8)

    def test_concurrent_workers_use_two_child_pids_and_distinct_projects(self):
        summary,rows,out=self.results[2]
        pids={int(r["worker_pid"]) for r in rows}
        self.assertEqual(len(pids),2)
        self.assertNotIn(os.getpid(),pids)
        self.assertEqual(summary["workers_requested"],2)
        self.assertEqual(summary["workers_effective"],2)
        self.assertEqual(summary["new_points_computed"],8)
        projects=list((out/"scratch").rglob("project.ini"))
        self.assertEqual(len(projects),8)
        self.assertEqual(len({p.parent.name for p in projects}),8)
        self.assertEqual([(r["scenario"],r["spacing_um"]) for r in rows],
                         sorted((r["scenario"],r["spacing_um"]) for r in rows))

    def test_computation_memory_and_wall_vs_accumulated_times_are_separate(self):
        for workers,(summary,rows,out) in self.results.items():
            self.assertGreater(summary["new_sweep_wall_s_excluding_final_exports"],0)
            self.assertAlmostEqual(summary["new_points_compute_s_sum"],
                                   sum(r["compute_excluding_output_s"] for r in rows),places=10)
            self.assertAlmostEqual(summary["max_individual_point_compute_rss_MiB"],
                                   max(r["peak_compute_rss_MiB"] for r in rows),places=10)
            for row in rows:
                self.assertGreater(row["worker_finished_perf_s"],row["worker_started_perf_s"])
                self.assertAlmostEqual(row["compute_excluding_output_s"],
                    row["worker_finished_perf_s"]-row["worker_started_perf_s"],places=6)
                if row["compute_rss_available"]:
                    self.assertGreater(row["peak_compute_rss_bytes"],0)
                    self.assertAlmostEqual(row["peak_compute_rss_MiB"],row["peak_compute_rss_bytes"]/1024**2,places=8)

    def test_real_worker_failure_keeps_completed_csv_and_stops_children(self):
        before={p.pid for p in multiprocessing.active_children()}
        with temporary() as directory:
            out=Path(directory)/"failure"
            started=perf_counter()
            # Both D=350 tasks are valid; later D=357.5 has a width that
            # cannot be represented by the 10-um mesh and fails in a worker.
            with redirect_stdout(io.StringIO()),self.assertRaises(RuntimeError):
                study.main(["--out",str(out),"--large-cols","3","--r-ohm","12",
                            "--small-rows","20","--small-cols","4","--spacings","350,357.5","--workers","2"])
            self.assertLess(perf_counter()-started,30)
            rows=study.read_csv(out/"sweep_results.csv")
            self.assertGreaterEqual(len(rows),1)
            self.assertTrue(all(r["spacing_um"]==350 for r in rows))
            self.assertFalse((out/"comparison.json").exists())
            self.assertFalse({p.pid for p in multiprocessing.active_children()}-before)


class ScanCompatibilityTests(unittest.TestCase):
    def test_old_rows_and_new_metrics_share_a_csv_without_truncating_or_extras(self):
        old=dict(scenario="large_only",spacing_um=320,mesh_pitch_um=10,max_total_IR_mV=11,
                 pass_strict_11p2mV=True,compute_excluding_output_s=.2)
        new=dict(old,spacing_um=330,peak_compute_rss_bytes=1024**2,peak_compute_rss_MiB=1,
                 compute_rss_available=1,worker_pid=123,worker_started_perf_s=1,worker_finished_perf_s=1.2)
        with temporary() as directory:
            path=Path(directory)/"rows.csv"
            study.write_csv(path,[old,new])
            rows=study.read_csv(path)
            self.assertEqual(rows[0]["peak_compute_rss_bytes"],0)
            self.assertEqual(rows[0]["worker_pid"],0)
            self.assertEqual(rows[1]["peak_compute_rss_bytes"],1024**2)
            self.assertEqual(rows[1]["worker_pid"],123)
            self.assertFalse(list(path.parent.glob("*.tmp")))

    def test_sampler_stops_if_configuration_reading_fails(self):
        from mna_process_metrics import MemorySampler
        with patch("mna_process_metrics.MemorySampler",spec=MemorySampler) as sampler, \
             patch.object(study,"read_stack_config",side_effect=ValueError("bad input")):
            instance=sampler.return_value
            instance.start.return_value=instance
            with self.assertRaises(ValueError):
                study.calculate("missing.ini",350,10,"upper_small",12,20,4,2,3)
            instance.start.assert_called_once()
            instance.stop.assert_called_once()

    def test_worker_count_must_be_positive_before_creating_outputs(self):
        with temporary() as directory:
            out=Path(directory)/"not_created"
            with self.assertRaises(ValueError):
                study.main(["--out",str(out),"--workers","0"])
            self.assertFalse(out.exists())


if __name__=="__main__":
    unittest.main()
