"""Embedded workbench saves and fresh, headless distributed-TSV jobs."""
from __future__ import annotations

import copy
from contextlib import redirect_stdout, redirect_stderr
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import mna_workbench_jobs as jobs


ROOT = Path(__file__).resolve().parents[1]
INI = """[stack]
layers=2
[mode]
mode=2
[bump]
powerv=.8
[mesh]
xgrid=2
ygrid=2
xpitch=10
ypitch=10
rh=.061
rv=.061
[mesh.1]
xgrid=2
ygrid=2
xpitch=10
ypitch=10
rh=.061
rv=.061
[current]
currentmode=1
i=0
mul=1
[current.1]
currentmode=1
i=-.01
mul=1
[components]
layout=missing_original.layout.json
"""


def configuration(active="scan"):
    placements = []
    for interface, prefix in (("source", "S"), ("0_1", "U")):
        for rail, coordinate in (("vdd", 10), ("vss", 20)):
            placements.append(dict(id=prefix+rail, type="ONE", interface=interface,
                                   rail=rail, x_um=coordinate, y_um=coordinate, rotation_deg=0))
    layout = dict(schema="mna-tsv-components-1", boundary_policy="strict",
                  types={"ONE":dict(rows=1, cols=1, pitch_x_um=1.5, pitch_y_um=1.5, r_ohm=12)},
                  placements=placements)
    return dict(schema=jobs.SCHEMA, name="三列 扫描验证", active_tab=active,
                layout=dict(ini_text=INI, components=layout), scan=dict(jobs.SCAN_DEFAULTS))


def temporary():
    folder = ROOT / ".local_validation" / "tmp"
    folder.mkdir(parents=True, exist_ok=True)
    return tempfile.TemporaryDirectory(prefix="workbench_jobs_", dir=folder)


class WorkbenchConfigTests(unittest.TestCase):
    def test_plan_has_actual_two_and_three_column_counts_and_boundaries(self):
        three = jobs.plan_scan({})
        self.assertEqual(three["point_count"], 124)
        self.assertEqual(three["spacing_count"], 62)
        self.assertEqual(three["spacings"], list(range(40, 651, 10)))
        self.assertAlmostEqual(three["finite_bound_spacing_um"]["large_only"], 621.25)
        self.assertAlmostEqual(three["finite_bound_spacing_um"]["upper_small"], 643.7821888412018)
        self.assertEqual(jobs.plan_scan(dict(large_cols=2))["point_count"], 160)
        self.assertEqual(jobs.plan_scan(dict(large_cols=2, r_ohm=5, small_rows=10, small_cols=3))["point_count"], 406)
        self.assertEqual(jobs.validate_scan({})["workers"],1)
        self.assertEqual(jobs.validate_scan(dict(workers="2"))["workers"],2)

    def test_explicit_points_and_aligned_custom_range(self):
        clean = jobs.validate_scan(dict(spacings="360, 350", export_ir=False))
        self.assertEqual(clean["spacings"], [350, 360])
        self.assertEqual(jobs.plan_scan(clean)["point_count"], 4)
        self.assertEqual(jobs.plan_scan(dict(minimum=45, maximum=75, step=10, pitch=5))["spacings"], [45,55,65,75])
        # D=40 is allowed: the staggered small footprint can be wider than
        # D-36 without overlapping the large components along Y.
        self.assertEqual(jobs.plan_scan(dict(spacings=[40]))["point_count"], 2)

    def test_rejects_invalid_numbers_mesh_ranges_and_unfit_shapes(self):
        invalid = [dict(large_cols=1), dict(large_cols=True), dict(large_cols=2.5),
                   dict(r_ohm=0), dict(r_ohm=float("nan")), dict(current_density=-1),
                   dict(current_density=float("inf")), dict(small_rows=0), dict(small_cols=1.5),
                   dict(step=0), dict(pitch=3), dict(pitch=20), dict(minimum=36),
                   dict(maximum=30), dict(maximum=55), dict(spacings=[]),
                   dict(spacings=[350,350]), dict(spacings=[False]), dict(spacings=[35]),
                   dict(small_rows=68), dict(small_cols=80), dict(export_ir="yes"),
                   dict(r_ohm=5e-324), dict(current_density=5e-324), dict(step=5e-324),
                   dict(workers=0), dict(workers=True), dict(workers=1.5),
                   dict(unknown=1)]
        for value in invalid:
            with self.subTest(value=value), self.assertRaises(ValueError):
                jobs.validate_scan(value)

    def test_single_file_roundtrip_retains_both_tabs_without_original_project(self):
        value = configuration("layout")
        with temporary() as directory:
            path = Path(directory) / "中文 空格" / "工作台.json"
            jobs.save_config(path, value)
            read = jobs.load_config(path)
            self.assertEqual(read, value)
            self.assertIn("missing_original.layout.json", read["layout"]["ini_text"])
            self.assertFalse((path.parent/"missing_original.layout.json").exists())
            read["active_tab"] = "scan"
            read["scan"]["current_density"] = 3
            jobs.save_config(path, read)
            self.assertEqual(jobs.load_config(path), read)
            self.assertFalse(list(path.parent.glob("*.tmp")))

    def test_old_configuration_without_workers_loads_with_one(self):
        value=configuration()
        value["scan"].pop("workers")
        with temporary() as directory:
            path=Path(directory)/"old.json"
            path.write_text(json.dumps(value),encoding="utf-8")
            self.assertEqual(jobs.load_config(path)["scan"]["workers"],1)

    def test_invalid_save_preserves_existing_bytes(self):
        with temporary() as directory:
            path = Path(directory) / "saved.json"
            jobs.save_config(path, configuration())
            before = path.read_bytes()
            for key, bad in (("schema", "wrong"), ("name", ""), ("active_tab", "unknown")):
                value = configuration()
                value[key] = bad
                with self.subTest(key=key), self.assertRaises(ValueError):
                    jobs.save_config(path, value)
                self.assertEqual(path.read_bytes(), before)
            value = configuration()
            value["layout"]["components"]["placements"][0]["interface"] = "1_2"
            with self.assertRaises(ValueError):
                jobs.save_config(path, value)
            self.assertEqual(path.read_bytes(), before)

    def test_invalid_embedded_ini_and_schema_are_rejected_on_load(self):
        with temporary() as directory:
            path = Path(directory) / "bad.json"
            for ini in ("not an INI", "[stack]\nlayers=0\n"):
                value = configuration()
                value["layout"]["ini_text"] = ini
                path.write_text(json.dumps(value), encoding="utf-8")
                with self.subTest(ini=ini), self.assertRaises(ValueError):
                    jobs.load_config(path)

    def test_write_layout_rewrites_only_relative_layout_reference_and_preserves_input(self):
        value = configuration()["layout"]
        before = copy.deepcopy(value)
        with temporary() as directory:
            ini = jobs.write_layout(Path(directory)/"项目", value)
            self.assertIn("layout = project.layout.json", ini.read_text(encoding="utf-8"))
            self.assertEqual(json.loads(ini.with_suffix(".layout.json").read_text()), value["components"])
            self.assertEqual(value, before)
            original = ini.read_bytes()
            with self.assertRaises(FileExistsError):
                jobs.write_layout(ini.parent, value)
            self.assertEqual(ini.read_bytes(), original)

    def test_new_output_is_unique_and_never_uses_name_as_path(self):
        with temporary() as directory:
            first = jobs.new_output(directory, "scan", "../中文/案例")
            second = jobs.new_output(directory, "scan", "../中文/案例")
            self.assertNotEqual(first, second)
            self.assertEqual(first.parent, Path(directory).resolve()/"results")
            self.assertTrue(first.is_dir() and second.is_dir())
            self.assertIn("_scan_", first.name)
            with self.assertRaises(ValueError):
                jobs.new_output(directory, "../../", "unsafe")


class WorkbenchExecutionTests(unittest.TestCase):
    def test_real_scan_runs_two_topologies_and_saves_curves_without_export(self):
        with temporary() as directory:
            out = Path(directory)/"扫描 空格"
            with redirect_stdout(io.StringIO()):
                summary = jobs.run_scan(dict(spacings=[350], export_ir=False), out)
            self.assertEqual(summary["large_cols"], 3)
            self.assertEqual(summary["workbench_plan"]["point_count"], 2)
            self.assertAlmostEqual(summary["scenarios"]["upper_small"]["best"]["max_total_IR_mV"],
                                   10.92734805254864, places=7)
            self.assertTrue((out/"spacing_comparison.png").is_file())
            with (out/"sweep_results.csv").open(encoding="utf-8-sig") as stream:
                self.assertEqual(len(stream.readlines()), 3)
            self.assertFalse((out/"upper_small_max_pass").exists())

    def test_real_layout_runs_embedded_project_and_preserves_all_node_results(self):
        with temporary() as directory:
            out = Path(directory)/"layout"
            with redirect_stdout(io.StringIO()):
                summary = jobs.run_layout(configuration("layout")["layout"], out)
            self.assertEqual(summary["node_count_per_rail"], 8)
            self.assertAlmostEqual(summary["load_current_A"], .01)
            self.assertGreater(summary["global_max_total_loss"]["value"], 0)
            self.assertTrue((out/"ir"/"summary.json").is_file())
            with (out/"ir"/"node_results.csv").open() as stream:
                self.assertEqual(len(stream.readlines()), 9)

    def test_nonempty_output_rejects_before_loading_numerical_code(self):
        with temporary() as directory:
            out = Path(directory)
            marker = out/"keep.txt"
            marker.write_text("original", encoding="utf-8")
            with patch.object(jobs, "_headless", side_effect=AssertionError("must not load")), \
                 patch.object(jobs, "_study_module", side_effect=AssertionError("must not load")):
                with self.assertRaises(FileExistsError):
                    jobs.run_scan(dict(spacings=[350]), out)
                with self.assertRaises(FileExistsError):
                    jobs.run_layout(configuration()["layout"], out)
            self.assertEqual(marker.read_text(), "original")
            self.assertEqual(list(out.iterdir()), [marker])

    def test_cli_dispatches_active_tab_and_writes_config_snapshot_and_job_summary(self):
        for tab in ("scan", "layout"):
            with self.subTest(tab=tab), temporary() as directory:
                path, out = Path(directory)/"job.json", Path(directory)/"out"
                value = configuration(tab)
                jobs.save_config(path, value)
                result = {"mocked":tab}
                with patch.object(jobs, "run_scan", return_value=result) as scan, \
                     patch.object(jobs, "run_layout", return_value=result) as layout, \
                     redirect_stdout(io.StringIO()):
                    self.assertEqual(jobs.main(["--job-file",str(path),"--out",str(out)]), 0)
                self.assertEqual(scan.call_count, int(tab=="scan"))
                self.assertEqual(layout.call_count, int(tab=="layout"))
                summary = json.loads((out/"job_summary.json").read_text())
                self.assertEqual(summary["status"], "PASS")
                self.assertEqual(summary["mode"], tab)
                self.assertEqual(summary["summary"], result)
                self.assertEqual(jobs.load_config(out/"workbench_config.json"), value)

    def test_failed_job_retains_snapshot_and_failure_summary(self):
        with temporary() as directory:
            path, out = Path(directory)/"job.json", Path(directory)/"out"
            jobs.save_config(path, configuration())
            with patch.object(jobs, "run_scan", side_effect=RuntimeError("deliberate failure")), \
                 redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                self.assertEqual(jobs.main(["--job-file",str(path),"--out",str(out)]), 1)
            result = json.loads((out/"job_summary.json").read_text())
            self.assertEqual(result["status"], "FAIL")
            self.assertEqual(result["error"], "deliberate failure")
            self.assertTrue((out/"workbench_config.json").is_file())


if __name__ == "__main__":
    unittest.main()
