"""Real Tk construction and cross-tab state tests; separate from screen QA."""
import copy
import json
import tempfile
import threading
from time import monotonic
from pathlib import Path
import tkinter as tk
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import mna_workbench as gui
import mna_workbench_jobs as jobs

ROOT=Path(__file__).resolve().parents[1]


class WorkbenchGuiTests(unittest.TestCase):
    def setUp(self):
        folder=ROOT/".local_validation/tmp"
        folder.mkdir(parents=True,exist_ok=True)
        self.temporary=tempfile.TemporaryDirectory(dir=folder,prefix="gui_")
        self.addCleanup(self.temporary.cleanup)
        self.home=Path(self.temporary.name)
        try:
            self.root=tk.Tk()
        except tk.TclError as error:
            self.skipTest(f"Tk display unavailable: {error}")
        self.root.withdraw()
        self.addCleanup(self.destroy)
        self.app=gui.Workbench(self.root,self.home)
        self.root.update_idletasks()

    def destroy(self):
        if self.root.winfo_exists():
            for pending in self.root.tk.call("after","info"):
                self.root.tk.call("after","cancel",pending)
            self.root.destroy()

    def test_construct_twice_and_reload_never_overwrites_an_existing_editor_project(self):
        first=self.app.editor.path
        initial=first.read_bytes()
        data=self.app.snapshot()
        self.assertTrue(self.app.apply_config(data,discard=False))
        second=self.app.editor.path
        self.assertNotEqual(first,second)
        self.assertEqual(first.read_bytes(),initial)
        self.assertEqual(len(self.app.tabs.tabs()),2)
        self.assertEqual(self.app.editor.root,self.root)
        self.assertEqual(self.app.editor.container,self.app.editor_host)
        self.assertEqual(self.root.title(),"MNA TSV 工作台 v4.4")

    def test_single_json_round_trip_restores_layout_templates_scan_and_selected_tab(self):
        self.app.tabs.select(self.app.scan_tab)
        self.app.scan_vars["r_ohm"].set("15")
        self.app.scan_vars["small_rows"].set("24")
        self.app.scan_vars["small_cols"].set("6")
        self.app.scan_vars["current_density"].set("3")
        snapshot=self.app.snapshot()
        path=self.home/"configs/中文 配置.json"
        jobs.save_config(path,snapshot)
        original=copy.deepcopy(snapshot["layout"]["components"])
        self.app.scan_vars["r_ohm"].set("99")
        self.app.editor.layout["placements"].pop()
        self.app.load_path(path) if not self.app.has_changes() else self.app.apply_config(jobs.load_config(path),path,discard=False)
        self.assertEqual(self.app.current_mode(),"scan")
        self.assertEqual(self.app.scan_values()["r_ohm"],15)
        self.assertEqual(self.app.scan_values()["current_density"],3)
        self.assertEqual(self.app.editor.layout,original)
        self.assertFalse(self.app.has_changes())
        self.assertEqual(jobs.plan_scan(self.app.scan_values())["large_cols"],3)

    def test_editor_delete_and_select_shortcuts_are_scoped_to_the_layout_canvas_tab(self):
        self.app.tabs.select(self.app.scan_tab)
        with patch.object(self.app.editor,"delete_key") as delete,patch.object(self.app.editor,"select_all_key") as select:
            self.app.editor_shortcut("delete_key",object())
            self.app.editor_shortcut("select_all_key",object())
            delete.assert_not_called()
            select.assert_not_called()
            self.app.tabs.select(self.app.layout_tab)
            self.app.layout_tabs.select(self.app.editor_host)
            self.app.editor_shortcut("delete_key",object())
            delete.assert_called_once()
            self.app.layout_tabs.select(self.app.layout_results)
            self.app.editor_shortcut("select_all_key",object())
            select.assert_not_called()

    def test_run_saves_frozen_configuration_and_starts_background_worker(self):
        self.app.tabs.select(self.app.scan_tab)
        with patch.object(gui.subprocess,"Popen") as process:
            process.return_value.poll.return_value=None
            process.return_value.pid=7654321
            self.app.run_job()
            command=process.call_args.args[0]
            self.assertIn("--job-file",command)
            saved=jobs.load_config(command[command.index("--job-file")+1])
            self.app.scan_vars["r_ohm"].set("99")
            self.assertEqual(saved["scan"]["r_ohm"],12)
            self.assertEqual(saved["active_tab"],"scan")
            self.assertEqual(str(self.app.run_button.cget("state")),"disabled")
            process.return_value.pid=7654321
            with patch.object(self.app.stop_controller,"stop",return_value=dict(available=True,alive_pids=[],errors=[])) as terminate:
                self.app.stop()
                self.app.stop_thread.join(2)
                terminate.assert_called_once_with(timeout=1)
            self.assertTrue(self.app.cancelled)
            self.app.log_handle.close()
            self.app.log_handle=None
            self.app.process=None

    def test_invalid_scan_is_not_silently_discarded_when_saving_from_layout_tab(self):
        self.app.tabs.select(self.app.layout_tab)
        self.app.scan_vars["current_density"].set("bad input")
        with patch.object(self.app,"error") as error,patch.object(gui.filedialog,"asksaveasfilename") as picker:
            self.assertFalse(self.app.save_dialog())
            error.assert_called_once()
            picker.assert_not_called()
        self.assertTrue(self.app.has_changes())
        self.assertEqual(self.app.scan_vars["current_density"].get(),"bad input")
        self.assertEqual(self.app.snapshot("layout",allow_scan_fallback=True)["scan"]["current_density"],2)

    def test_f_fits_only_visible_layout_canvas_and_preserves_text_input(self):
        canvas_event=SimpleNamespace(widget=self.app.editor.canvas,state=0)
        entry=tk.Entry(self.app.editor_host)
        entry_event=SimpleNamespace(widget=entry,state=0)
        with patch.object(self.app.editor,"fit") as fit:
            self.app.tabs.select(self.app.scan_tab)
            self.app.editor_shortcut("fit_key",canvas_event)
            fit.assert_not_called()
            self.app.tabs.select(self.app.layout_tab)
            self.app.layout_tabs.select(self.app.editor_host)
            self.app.editor_shortcut("fit_key",entry_event)
            fit.assert_not_called()
            self.assertEqual(self.app.editor_shortcut("fit_key",canvas_event),"break")
            fit.assert_called_once()

    def test_memory_log_merges_without_writing_over_worker_progress(self):
        self.app.tabs.select(self.app.scan_tab)
        sample=dict(available=True,rss_bytes=512*1024**2,process_count=4,partial=False,errors=[])
        with patch.object(gui.subprocess,"Popen") as process,patch.object(gui.metrics,"process_tree_memory",return_value=sample):
            process.return_value.poll.return_value=None
            process.return_value.pid=7654321
            self.app.run_job()
            self.app.log_handle.write("[1/4] worker progress\n")
            self.app.log_handle.flush()
            jobs._atomic_json(self.app.output/"job_summary.json",dict(status="PASS",mode="scan",summary=dict(scenarios={})))
            process.return_value.poll.return_value=0
            self.app.poll_job()
        self.assertIsNone(self.app.process)
        text=(self.app.output/"console.log").read_text(encoding="utf-8")
        self.assertIn("worker progress",text)
        self.assertIn("[内存",text)
        self.assertIn("512.0 MiB",text)
        self.assertNotIn("[内存",self.app.log_path.read_text(encoding="utf-8"))
        import json
        usage=json.loads((self.app.output/"resource_usage.json").read_text(encoding="utf-8"))
        self.assertEqual(usage["peak_sampled_rss_bytes"],512*1024**2)
        self.assertEqual(usage["peak_sampled_process_count"],4)

    def test_close_during_stop_waits_asynchronously_and_finalizes_cancelled_logs(self):
        self.app.tabs.select(self.app.scan_tab)
        sample=dict(available=True,rss_bytes=384*1024**2,process_count=3,
                    partial=False,errors=[])
        release=threading.Event()
        entered=threading.Event()
        termination=dict(available=True,alive_pids=[],errors=[],gone_pids=[7654321])
        try:
            with patch.object(gui.subprocess,"Popen") as process, \
                 patch.object(gui.metrics,"process_tree_memory",return_value=sample), \
                 patch.object(gui.messagebox,"askyesno",return_value=True), \
                 patch.object(self.app,"discard_allowed",return_value=True), \
                 patch.object(self.app,"error") as error, \
                 patch.object(self.app,"poll_job",wraps=self.app.poll_job) as poll, \
                 patch.object(self.root,"destroy") as destroy, \
                 patch.object(self.root,"after",wraps=self.root.after) as after:
                process.return_value.poll.return_value=None
                process.return_value.pid=7654321
                self.app.run_job()
                self.app.log_handle.write("[1/4] worker progress before cancellation\n")
                self.app.log_handle.flush()

                def terminate(*args,**kwargs):
                    entered.set()
                    if not release.wait(3):
                        return dict(available=True,alive_pids=[7654321],errors=["test release timed out"])
                    process.return_value.poll.return_value=-15
                    return termination

                with patch.object(self.app.stop_controller,"stop",side_effect=terminate) as stop_tree:
                    self.app.stop()
                    self.assertTrue(entered.wait(1))
                    self.assertTrue(self.app.stop_thread.is_alive())
                    scheduled_before=after.call_count
                    started=monotonic()
                    self.app.close()
                    # A synchronous second cancellation or join would wait
                    # on release and block Tk, rather than schedule a retry.
                    self.assertLess(monotonic()-started,.5)
                    self.assertGreater(after.call_count,scheduled_before)
                    destroy.assert_not_called()
                    stop_tree.assert_called_once_with(timeout=1)
                    heartbeat=[]
                    self.root.after(0,lambda:heartbeat.append(True))
                    self.root.update()
                    self.assertEqual(heartbeat,[True])
                    self.assertTrue(self.app.stop_thread.is_alive())
                    destroy.assert_not_called()

                    release.set()
                    self.app.stop_thread.join(2)
                    self.assertFalse(self.app.stop_thread.is_alive())
                    deadline=monotonic()+3
                    idle=threading.Event()
                    while not destroy.called and monotonic()<deadline:
                        self.root.update()
                        idle.wait(.01)
                    destroy.assert_called_once_with()
                    stop_tree.assert_called_once_with(timeout=1)
                    self.assertTrue(poll.called)
                    self.assertIsNone(self.app.process)
                    self.assertIsNone(self.app.log_handle)
                    error.assert_not_called()
                console=(self.app.output/"console.log").read_text(encoding="utf-8")
                self.assertIn("worker progress before cancellation",console)
                self.assertIn("[任务内存汇总]",console)
                self.assertIn("384.0 MiB",console)
                usage=json.loads((self.app.output/"resource_usage.json").read_text(encoding="utf-8"))
                self.assertEqual(usage["peak_sampled_rss_bytes"],384*1024**2)
                self.assertEqual(usage["peak_sampled_process_count"],3)
                self.assertTrue(usage["samples"])
                summary=json.loads((self.app.output/"job_summary.json").read_text(encoding="utf-8"))
                self.assertEqual(summary["status"],"CANCELLED")
                self.assertEqual(summary["termination"],termination)
                self.assertEqual(summary["resource_usage"],usage)
                self.assertEqual(jobs.load_config(self.app.output/summary["config_snapshot"])["active_tab"],"scan")
        finally:
            release.set()
            thread=getattr(self.app,"stop_thread",None)
            if thread is not None:
                thread.join(4)
            if self.app.log_handle is not None:
                self.app.log_handle.close()
                self.app.log_handle=None
            self.app.process=None

    def test_failed_stop_keeps_window_open_and_does_not_repeat_cancellation_on_close(self):
        self.app.tabs.select(self.app.scan_tab)
        failure=dict(available=True,alive_pids=[7654321],errors=["coordinator suspend denied"])
        try:
            with patch.object(gui.subprocess,"Popen") as process, \
                 patch.object(gui.metrics.ProcessTreeStopController,"stop",return_value=failure) as terminate, \
                 patch.object(gui.messagebox,"askyesno",return_value=True), \
                 patch.object(self.app,"discard_allowed",return_value=True), \
                 patch.object(self.app,"error") as error, \
                 patch.object(self.root,"destroy") as destroy:
                process.return_value.poll.return_value=None
                process.return_value.pid=7654321
                self.app.run_job()
                self.app.stop()
                self.app.stop_thread.join(2)
                self.assertFalse(self.app.stop_thread.is_alive())
                self.app.close()
                deadline=monotonic()+2
                idle=threading.Event()
                while not error.called and monotonic()<deadline:
                    self.root.update()
                    idle.wait(.01)
                error.assert_called_once()
                self.assertIn("未能确认全部计算进程退出",str(error.call_args.args[0]))
                terminate.assert_called_once_with(timeout=1)
                destroy.assert_not_called()
                self.assertFalse(self.app.closing)
                self.assertIs(self.app.process,process.return_value)
                self.assertFalse((self.app.output/"job_summary.json").exists())
        finally:
            if self.app.log_handle is not None:
                self.app.log_handle.close()
                self.app.log_handle=None
            self.app.process=None

    def test_exited_coordinator_keeps_run_locked_until_same_controller_clears_workers(self):
        self.app.tabs.select(self.app.scan_tab)
        failure=dict(available=True,alive_pids=[7654322],errors=["worker still running"])
        success=dict(available=True,alive_pids=[],errors=[],gone_pids=[7654322])
        try:
            with patch.object(gui.subprocess,"Popen") as process,patch.object(self.app,"error") as error:
                process.return_value.poll.return_value=None
                process.return_value.pid=7654321
                self.app.run_job()
                controller=self.app.stop_controller
                with patch.object(controller,"stop",side_effect=[failure,success]) as stop:
                    self.app.stop()
                    self.app.stop_thread.join(2)
                    process.return_value.poll.return_value=-15
                    self.app.poll_job()
                    self.assertIs(self.app.process,process.return_value)
                    self.assertIs(self.app.stop_controller,controller)
                    self.assertEqual(str(self.app.run_button.cget("state")),"disabled")
                    self.assertEqual(str(self.app.stop_button.cget("state")),"normal")
                    self.assertIsNotNone(self.app.log_handle)
                    before=self.app.merged_log
                    self.app.poll_job()
                    self.assertEqual(self.app.merged_log,before)
                    self.assertFalse((self.app.output/"job_summary.json").exists())
                    self.app.run_job()
                    self.assertEqual(process.call_count,1)
                    error.assert_called_once()
                    self.app.stop()
                    self.app.stop_thread.join(2)
                    self.assertIs(self.app.stop_controller,controller)
                    self.app.poll_job()
                    self.assertEqual(stop.call_count,2)
                    self.assertTrue(all(call.kwargs=={"timeout":1} for call in stop.call_args_list))
                self.assertIsNone(self.app.process)
                self.assertIsNone(self.app.log_handle)
                self.assertEqual(str(self.app.run_button.cget("state")),"normal")
                summary=json.loads((self.app.output/"job_summary.json").read_text(encoding="utf-8"))
                self.assertEqual(summary["status"],"CANCELLED")
                self.assertEqual(summary["termination"],success)
        finally:
            thread=getattr(self.app,"stop_thread",None)
            if thread is not None:
                thread.join(2)
            if self.app.log_handle is not None:
                self.app.log_handle.close()
                self.app.log_handle=None
            self.app.process=None

    def test_malformed_result_is_rejected_before_clearing_existing_result_table(self):
        pane=self.app.scan_results
        pane.table.insert("","end",iid="keep",values=("existing",320,11.08,330))
        for summary in (None,dict(scenarios=[]),dict(scenarios={"large_only":dict(best=None)})):
            with self.subTest(summary=summary),self.assertRaises(ValueError):
                pane.show_result(self.home,"scan",summary)
            self.assertTrue(pane.table.exists("keep"))


if __name__=="__main__":
    unittest.main()
