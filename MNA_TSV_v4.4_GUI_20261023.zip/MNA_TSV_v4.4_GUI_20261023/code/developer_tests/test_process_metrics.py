"""Real worker-tree accounting and cancellation, including exit races."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import mna_process_metrics as metrics


PARENT_CODE = r'''
import json, subprocess, sys, time
child = subprocess.Popen([sys.executable, '-c',
    'import time; allocation=bytearray(4*1024*1024); time.sleep(120)'],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
allocation = bytearray(2*1024*1024)
print(json.dumps({'child_pid': child.pid}), flush=True)
time.sleep(120)
'''


def fake_process(pid):
    process=MagicMock(pid=pid)
    process.status.return_value=metrics._psutil.STATUS_RUNNING
    process.suspend.side_effect=lambda:setattr(process.status,'return_value',metrics._psutil.STATUS_STOPPED)
    process.resume.side_effect=lambda:setattr(process.status,'return_value',metrics._psutil.STATUS_RUNNING)
    return process


@unittest.skipIf(metrics._psutil is None, "requires psutil>=5.9")
class ProcessMetricsTests(unittest.TestCase):
    def start_tree(self):
        parent = subprocess.Popen([sys.executable, '-c', PARENT_CODE],
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  text=True, encoding='utf-8', cwd=ROOT)
        self.addCleanup(self.cleanup_popen, parent)
        report = json.loads(parent.stdout.readline())
        child = metrics._psutil.Process(report['child_pid'])
        self.addCleanup(self.cleanup_process, child)
        return parent, child

    @staticmethod
    def cleanup_process(process):
        try:
            process.kill()
            process.wait(timeout=3)
        except metrics._psutil.NoSuchProcess:
            pass

    @staticmethod
    def cleanup_popen(process):
        if process.poll() is None:
            process.kill()
        process.wait(timeout=3)
        if process.stdout:
            process.stdout.close()
        if process.stderr:
            process.stderr.close()

    def test_real_parent_child_rss_and_cancellation_leave_other_jobs_alive(self):
        parent, child = self.start_tree()
        unrelated = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(120)'],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.addCleanup(self.cleanup_popen, unrelated)
        all_processes = metrics.process_tree_memory(parent.pid)
        only_children = metrics.process_tree_memory(parent.pid, include_parent=False)
        self.assertTrue(all_processes['available'])
        self.assertFalse(all_processes['partial'])
        self.assertEqual(all_processes['metric'], 'RSS sum')
        self.assertEqual(all_processes['process_count'], 2)
        self.assertEqual(only_children['process_count'], 1)
        self.assertGreater(all_processes['rss_bytes'], only_children['rss_bytes'])
        self.assertGreater(only_children['rss_bytes'], 0)
        self.assertAlmostEqual(all_processes['rss_mib'], all_processes['rss_bytes'] / 1024**2)
        stopped = metrics.terminate_process_tree(parent.pid, timeout=3)
        parent.wait(timeout=3)
        self.assertTrue(stopped['available'])
        self.assertEqual(stopped['process_count'], 2)
        self.assertEqual(set(stopped['gone_pids']), {parent.pid, child.pid})
        self.assertEqual(stopped['alive_pids'], [])
        self.assertEqual(stopped['errors'], [])
        self.assertFalse(child.is_running())
        self.assertIsNone(unrelated.poll())

    def test_include_parent_false_stops_worker_but_preserves_coordinator(self):
        parent, child = self.start_tree()
        stopped = metrics.terminate_process_tree(parent.pid, include_parent=False, timeout=3)
        self.assertEqual(stopped['process_count'], 1)
        self.assertEqual(stopped['gone_pids'], [child.pid])
        self.assertEqual(stopped['alive_pids'], [])
        self.assertIsNone(parent.poll())
        self.assertFalse(child.is_running())

    def test_exit_race_is_ignored_for_snapshot_memory_and_termination(self):
        root = fake_process(100)
        child = fake_process(101)
        root.children.return_value = [child]
        child.ppid.side_effect = metrics._psutil.NoSuchProcess(101)
        child.memory_info.side_effect = metrics._psutil.NoSuchProcess(101)
        root.memory_info.return_value = SimpleNamespace(rss=123456)
        with patch.object(metrics._psutil, 'Process', return_value=root):
            sample = metrics.process_tree_memory(100)
            self.assertTrue(sample['available'])
            self.assertEqual(sample['rss_bytes'], 123456)
            self.assertEqual(sample['process_count'], 1)
            self.assertFalse(sample['partial'])
            child.terminate.side_effect = metrics._psutil.NoSuchProcess(101)
            root.terminate.side_effect = metrics._psutil.NoSuchProcess(100)
            with patch.object(metrics._psutil, 'wait_procs', return_value=([child, root], [])):
                stopped = metrics.terminate_process_tree(100)
            self.assertEqual(stopped['alive_pids'], [])
            self.assertEqual(stopped['gone_pids'], [100, 101])
            self.assertEqual(stopped['errors'], [])

    def test_missing_or_invalid_pid_cannot_target_any_process(self):
        for pid in (None, '', 'not-a-pid', 0, -1, 1.25, float('nan'), float('inf'), True):
            with self.subTest(pid=pid), patch.object(metrics._psutil, 'Process') as process:
                self.assertFalse(metrics.process_tree_memory(pid)['available'])
                self.assertFalse(metrics.terminate_process_tree(pid)['available'])
                process.assert_not_called()
        with patch.object(metrics._psutil, 'Process',
                          side_effect=metrics._psutil.NoSuchProcess(123456789)):
            sample = metrics.process_tree_memory(123456789)
            self.assertTrue(sample['available'])
            self.assertEqual(sample['process_count'], 0)
            self.assertEqual(sample['rss_bytes'], 0)
            stopped = metrics.terminate_process_tree(123456789)
            self.assertEqual(stopped['process_count'], 0)
            self.assertEqual(stopped['alive_pids'], [])

    def test_leaf_first_order_and_timeout_kill_are_limited_to_snapshot(self):
        root, child, leaf = (fake_process(pid) for pid in (100, 101, 102))
        root.children.return_value = [child, leaf]
        child.ppid.return_value, leaf.ppid.return_value = 100, 101
        events = []
        for process in (root, child, leaf):
            process.terminate.side_effect = lambda p=process:events.append(('terminate', p.pid))
            process.kill.side_effect = lambda p=process:events.append(('kill', p.pid))
        with patch.object(metrics._psutil, 'Process', return_value=root) as lookup, \
             patch.object(metrics._psutil, 'wait_procs',
                          side_effect=[([], [leaf, child, root]), ([leaf, child, root], [])]) as wait:
            stopped = metrics.terminate_process_tree(100, timeout=.25)
        lookup.assert_called_once_with(100)
        root.children.assert_called_once_with(recursive=True)
        self.assertEqual(events, [('terminate', 102), ('terminate', 101), ('terminate', 100),
                                  ('kill', 102), ('kill', 101), ('kill', 100)])
        self.assertEqual([call.kwargs['timeout'] for call in wait.call_args_list], [.25, .25])
        self.assertEqual(stopped['gone_pids'], [100, 101, 102])
        self.assertEqual(stopped['alive_pids'], [])

    def test_coordinator_is_suspended_before_descendant_snapshot(self):
        root, child = fake_process(100), fake_process(101)
        root.status.return_value = metrics._psutil.STATUS_RUNNING
        root.is_running.side_effect = [True, True, False]
        child.ppid.return_value = 100
        events = []
        def suspend():
            events.append('suspend root')
            root.status.return_value=metrics._psutil.STATUS_STOPPED
        root.suspend.side_effect = suspend
        root.children.side_effect = lambda **kwargs:events.append('snapshot children') or [child]
        child.terminate.side_effect = lambda:events.append('terminate child')
        root.terminate.side_effect = lambda:events.append('terminate root')
        with patch.object(metrics._psutil, 'Process', return_value=root) as lookup, \
             patch.object(metrics._psutil, 'wait_procs', return_value=([child, root], [])):
            metrics.terminate_process_tree(100)
        lookup.assert_called_once_with(100)
        self.assertEqual(events, ['suspend root', 'snapshot children',
                                  'terminate child', 'terminate root'])
        root.resume.assert_not_called()

    def test_surviving_coordinator_is_resumed_on_cancellation_failure(self):
        for initially_stopped in (False, True):
            with self.subTest(initially_stopped=initially_stopped):
                root = fake_process(100)
                root.children.return_value = []
                root.status.return_value = (metrics._psutil.STATUS_STOPPED if initially_stopped
                                            else metrics._psutil.STATUS_RUNNING)
                root.is_running.return_value = True
                root.terminate.side_effect = metrics._psutil.AccessDenied(100)
                root.kill.side_effect = metrics._psutil.AccessDenied(100)
                with patch.object(metrics._psutil, 'Process', return_value=root), \
                     patch.object(metrics._psutil, 'wait_procs', return_value=([], [root])):
                    result = metrics.terminate_process_tree(100)
                self.assertEqual(result['alive_pids'], [100])
                self.assertTrue(result['errors'])
                if initially_stopped:
                    root.suspend.assert_not_called()
                    root.resume.assert_not_called()
                else:
                    root.suspend.assert_called_once_with()
                    root.resume.assert_called_once_with()

    def test_suspend_failure_aborts_before_any_descendant_or_signal_operation(self):
        root = fake_process(100)
        root.status.return_value = metrics._psutil.STATUS_RUNNING
        root.suspend.side_effect = metrics._psutil.AccessDenied(100)
        with patch.object(metrics._psutil, 'Process', return_value=root):
            result = metrics.terminate_process_tree(100)
        self.assertEqual(result['alive_pids'], [100])
        self.assertTrue(result['errors'])
        self.assertIn('suspend', result['errors'][0])
        root.children.assert_not_called()
        root.terminate.assert_not_called()
        root.kill.assert_not_called()
        root.resume.assert_not_called()

    def test_suspension_confirmation_waits_for_transient_running_state(self):
        root=fake_process(100)
        root.is_running.side_effect=[True,True,False]
        root.children.return_value=[]
        root.suspend.side_effect=None
        root.status.side_effect=[metrics._psutil.STATUS_RUNNING,
                                 metrics._psutil.STATUS_RUNNING,
                                 metrics._psutil.STATUS_RUNNING,
                                 metrics._psutil.STATUS_STOPPED]
        with patch.object(metrics._psutil,'Process',return_value=root), \
             patch.object(metrics._psutil,'wait_procs',side_effect=[([root],[]),([],[])]):
            result=metrics.terminate_process_tree(100)
        self.assertEqual(result['errors'],[])
        self.assertEqual(root.status.call_count,4)
        root.children.assert_called_once_with(recursive=True)

    def test_unconfirmed_suspension_aborts_snapshot_and_resumes_coordinator(self):
        root=fake_process(100)
        root.is_running.return_value=True
        root.suspend.side_effect=None
        root.status.return_value=metrics._psutil.STATUS_RUNNING
        original=metrics._confirm_suspension
        with patch.object(metrics._psutil,'Process',return_value=root), \
             patch.object(metrics,'_confirm_suspension',side_effect=lambda process:original(process,timeout=.01)):
            result=metrics.terminate_process_tree(100)
        self.assertEqual(result['alive_pids'],[100])
        self.assertTrue(result['errors'])
        root.children.assert_not_called()
        root.terminate.assert_not_called()
        root.resume.assert_called_once_with()

    def test_controller_retries_captured_worker_after_its_coordinator_has_exited(self):
        root, worker = fake_process(100), fake_process(101)
        state={'root_alive':True}
        root.is_running.side_effect=lambda:state['root_alive']
        root.status.return_value=metrics._psutil.STATUS_RUNNING
        root.children.return_value=[worker]
        worker.ppid.return_value=100
        worker.is_running.return_value=True
        root.terminate.side_effect=lambda:state.update(root_alive=False)
        worker.terminate.side_effect=metrics._psutil.AccessDenied(101)
        worker.kill.side_effect=metrics._psutil.AccessDenied(101)
        with patch.object(metrics._psutil,'Process',return_value=root) as lookup:
            controller=metrics.ProcessTreeStopController(100)
            with patch.object(metrics._psutil,'wait_procs',side_effect=[([root],[worker]),([],[worker])]):
                first=controller.stop(timeout=.01)
            self.assertEqual(first['alive_pids'],[101])
            self.assertTrue(first['errors'])
            self.assertFalse(state['root_alive'])
            worker.terminate.side_effect=None
            worker.kill.side_effect=None
            lookup.side_effect=AssertionError('must not look up a replacement root PID')
            with patch.object(metrics._psutil,'wait_procs',side_effect=[([worker],[]),([],[])]):
                second=controller.stop(timeout=.01)
        self.assertEqual(second['alive_pids'],[])
        self.assertEqual(second['gone_pids'],[101])
        self.assertEqual(second['errors'],[])
        self.assertEqual(worker.terminate.call_count,2)
        root.children.assert_called_once_with(recursive=True)
        root.terminate.assert_called_once_with()

    def test_controller_does_not_capture_or_signal_a_reused_root_pid(self):
        original=fake_process(100)
        original.is_running.return_value=False  # psutil identity check detects reuse.
        replacement=fake_process(100)
        with patch.object(metrics._psutil,'Process',return_value=original) as lookup:
            controller=metrics.ProcessTreeStopController(100)
            lookup.return_value=replacement
            result=controller.stop()
            lookup.assert_called_once_with(100)
        self.assertEqual(result['alive_pids'],[])
        self.assertEqual(result['process_count'],0)
        original.children.assert_not_called()
        original.suspend.assert_not_called()
        original.terminate.assert_not_called()
        replacement.suspend.assert_not_called()
        replacement.children.assert_not_called()
        replacement.terminate.assert_not_called()

    def test_live_controller_recaptures_new_workers_and_retains_existing_orphans(self):
        root, first_worker, new_worker=(fake_process(pid) for pid in (100,101,102))
        root.status.return_value=metrics._psutil.STATUS_RUNNING
        root.is_running.return_value=True
        root.children.side_effect=[[first_worker],[new_worker]]
        for worker in (first_worker,new_worker):
            worker.ppid.return_value=100
            worker.is_running.return_value=True
        with patch.object(metrics._psutil,'Process',return_value=root):
            controller=metrics.ProcessTreeStopController(100)
            with patch.object(metrics._psutil,'wait_procs',return_value=([],[first_worker,root])):
                first=controller.stop(timeout=0)
            self.assertEqual(first['alive_pids'],[100,101])
            with patch.object(metrics._psutil,'wait_procs',side_effect=[([first_worker,new_worker,root],[]),([],[])]):
                second=controller.stop(timeout=0)
        self.assertEqual(second['gone_pids'],[100,101,102])
        self.assertEqual(second['alive_pids'],[])
        self.assertEqual(first_worker.terminate.call_count,2)
        new_worker.terminate.assert_called_once_with()
        self.assertEqual(root.suspend.call_count,2)

    def test_real_coordinator_spawning_workers_is_frozen_before_snapshot(self):
        code = r'''
import json, subprocess, sys, time
for index in range(100):
    child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(120)'],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print(json.dumps({'child_pid': child.pid}), flush=True)
    time.sleep(.002)
time.sleep(120)
'''
        parent = subprocess.Popen([sys.executable, '-c', code],
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  text=True, encoding='utf-8', cwd=ROOT)
        self.addCleanup(self.cleanup_popen, parent)
        first_children = [json.loads(parent.stdout.readline())['child_pid'] for _ in range(3)]
        for pid in first_children:
            self.addCleanup(self.cleanup_process, metrics._psutil.Process(pid))
        def cleanup_spawn_tree():
            if parent.poll() is None:
                metrics.ProcessTreeStopController(parent.pid).stop(timeout=1)
        # This runs before the individual child cleanups: a failed callback
        # can cause production finally to resume a still-spawning parent.
        self.addCleanup(cleanup_spawn_tree)
        original_snapshot = metrics._snapshot
        captured = []

        def capture_while_frozen(pid, include_parent, root_process=None):
            result = original_snapshot(pid, include_parent, root_process=root_process)
            captured.extend(result[0])
            for process in result[0]:
                if process.pid != parent.pid:
                    self.addCleanup(self.cleanup_process, process)
            self.addCleanup(cleanup_spawn_tree)
            # Register every discovered identity before an assertion can
            # fail, so a failed freeze check cannot strand our test workers.
            self.assertEqual(root_process.status(), metrics._psutil.STATUS_STOPPED)
            before={child.pid for child in root_process.children(recursive=True)}
            threading.Event().wait(.03)
            self.assertEqual(root_process.status(), metrics._psutil.STATUS_STOPPED)
            self.assertEqual({child.pid for child in root_process.children(recursive=True)},before)
            return result

        with patch.object(metrics, '_snapshot', side_effect=capture_while_frozen):
            result = metrics.terminate_process_tree(parent.pid, timeout=3)
        parent.wait(timeout=3)
        self.assertTrue(set(first_children).issubset(result['gone_pids']))
        self.assertGreaterEqual(result['process_count'], 4)
        self.assertEqual(result['alive_pids'], [])
        self.assertEqual(result['errors'], [])
        self.assertTrue(all(not process.is_running() for process in captured))

    def test_memory_access_failure_is_reported_without_losing_other_samples(self):
        root, child = fake_process(100), fake_process(101)
        root.children.return_value = [child]
        child.ppid.return_value = 100
        child.memory_info.side_effect = metrics._psutil.AccessDenied(101)
        root.memory_info.return_value = SimpleNamespace(rss=1000)
        with patch.object(metrics._psutil, 'Process', return_value=root):
            sample = metrics.process_tree_memory(100)
        self.assertTrue(sample['available'])
        self.assertTrue(sample['partial'])
        self.assertEqual(sample['rss_bytes'], 1000)
        self.assertEqual(sample['process_count'], 1)
        self.assertTrue(sample['errors'])

    def test_invalid_timeout_does_not_signal_any_process(self):
        for timeout in (-1, float('inf'), float('nan'), 'bad', None):
            with self.subTest(timeout=timeout), patch.object(metrics._psutil, 'Process') as process:
                result = metrics.terminate_process_tree(123456789, timeout=timeout)
                self.assertFalse(result['available'])
                self.assertTrue(result['errors'])
                process.assert_not_called()


class MissingDependencyTests(unittest.TestCase):
    def test_missing_dependency_is_explicit_and_never_uses_a_global_fallback(self):
        with patch.object(metrics, '_psutil', None):
            sample = metrics.process_tree_memory(100)
            stopped = metrics.terminate_process_tree(100)
        self.assertFalse(sample['available'])
        self.assertFalse(stopped['available'])
        self.assertIn('psutil>=5.9', sample['errors'][0])
        self.assertIn('psutil>=5.9', stopped['errors'][0])


class MemorySamplerTests(unittest.TestCase):
    @staticmethod
    def sample(rss, count=1, available=True, errors=None):
        return dict(rss_bytes=rss, rss_mib=rss / metrics.MIB,
                    process_count=count, available=available,
                    metric=metrics.MEMORY_METRIC, partial=False, errors=errors or [])

    def test_periodic_peak_and_stop_are_frozen_before_later_output(self):
        observed_background_sample = threading.Event()
        call_count = 0

        def sample(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return self.sample(1024, count=1)
            if call_count == 2:
                observed_background_sample.set()
                return self.sample(8192, count=3)
            return self.sample(2048, count=2)

        with patch.object(metrics, 'process_tree_memory', side_effect=sample) as read:
            sampler = metrics.MemorySampler(100, interval=.01)
            self.assertIs(sampler.start(), sampler)
            self.assertTrue(observed_background_sample.wait(2))
            frozen = sampler.stop()
            self.assertEqual(frozen['peak_sampled_rss_bytes'], 8192)
            self.assertEqual(frozen['peak_sampled_rss_mib'], 8192 / metrics.MIB)
            self.assertEqual(frozen['peak_sampled_process_count'], 3)
            self.assertGreaterEqual(frozen['sample_count'], 3)
            self.assertTrue(frozen['available'])
            self.assertGreater(frozen['elapsed_s'], 0)
            calls_before_output = read.call_count
            read.return_value = self.sample(999999999)
            self.assertEqual(sampler.stop(), frozen)
            self.assertEqual(read.call_count, calls_before_output)
            self.assertFalse(sampler._thread.is_alive())
            with self.assertRaises(RuntimeError):
                sampler.start()

    def test_context_preserves_body_exception_and_finishes_thread(self):
        with patch.object(metrics, 'process_tree_memory', return_value=self.sample(4096)):
            sampler = metrics.MemorySampler(100, interval=10)
            with self.assertRaisesRegex(ValueError, 'solver failed'):
                with sampler as running:
                    self.assertIs(running, sampler)
                    raise ValueError('solver failed')
            self.assertFalse(sampler._thread.is_alive())
            self.assertEqual(sampler.stop()['peak_sampled_rss_bytes'], 4096)

    def test_missing_dependency_and_stop_before_start_have_no_sampled_peak(self):
        stopped = metrics.MemorySampler(100)
        with patch.object(metrics, 'process_tree_memory') as read:
            self.assertEqual(stopped.stop()['sample_count'], 0)
            self.assertFalse(stopped.stop()['available'])
            read.assert_not_called()
        with patch.object(metrics, '_psutil', None):
            with metrics.MemorySampler(100, interval=10) as sampler:
                pass
            result = sampler.stop()
        self.assertFalse(result['available'])
        self.assertEqual(result['peak_sampled_rss_bytes'], 0)
        self.assertIn('psutil>=5.9', result['errors'][0])
        result['errors'].append('external mutation')
        self.assertNotIn('external mutation', sampler.stop()['errors'])

    def test_invalid_interval_or_pid_is_rejected_before_starting_a_thread(self):
        for interval in (0, -1, float('inf'), float('nan'), None, 'bad'):
            with self.subTest(interval=interval), self.assertRaises(ValueError):
                metrics.MemorySampler(100, interval=interval)
        for pid in (0, -1, 1.5, True, 'bad'):
            with self.subTest(pid=pid), self.assertRaises(ValueError):
                metrics.MemorySampler(pid)

    @unittest.skipIf(metrics._psutil is None, "requires psutil>=5.9")
    def test_real_current_process_defaults_and_immediate_samples(self):
        import os
        with metrics.MemorySampler(interval=10) as sampler:
            self.assertEqual(sampler.root_pid, os.getpid())
        result = sampler.stop()
        self.assertTrue(result['available'])
        self.assertGreater(result['peak_sampled_rss_bytes'], 0)
        self.assertGreaterEqual(result['peak_sampled_process_count'], 1)
        self.assertEqual(result['sample_count'], 2)


if __name__ == '__main__':
    unittest.main()
