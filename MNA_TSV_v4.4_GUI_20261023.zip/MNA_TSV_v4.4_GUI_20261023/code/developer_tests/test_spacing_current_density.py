"""Physical current-density scaling and safe continuation of spacing studies."""
from __future__ import annotations

import copy
import csv
from contextlib import redirect_stderr, redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("spacing_current_density_study", ROOT/"studies/two_column_spacing.py")
study = importlib.util.module_from_spec(spec)
spec.loader.exec_module(study)


def workspace_temporary_directory():
    """Keep temporary model writes within the checked-out project on Windows."""
    folder = ROOT/".local_validation"/"tmp"
    folder.mkdir(parents=True, exist_ok=True)
    return tempfile.TemporaryDirectory(prefix="spacing_density_", dir=folder)


class SpacingCurrentDensityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = workspace_temporary_directory()
        cls.addClassCleanup(cls.temporary.cleanup)
        cls.folder = Path(cls.temporary.name)
        cls.rows, cls.fields, cls.loads, cls.layouts = {}, {}, {}, {}
        solve = study.solve_stack
        for density in (2.0, 3.0):
            # The first case intentionally omits the new argument, providing a
            # real numerical compatibility check of the historical default.
            keywords = {} if density == 2 else dict(current_density=density)
            ini = study.write_case(cls.folder/f"J{density:g}", 400, 10,
                                   "upper_small", 15, 24, 6, **keywords)
            cls.layouts[density] = json.loads(ini.with_suffix(".layout.json").read_text(encoding="utf-8"))

            def capture(model, _density=density, **solver_options):
                cls.loads[_density] = [layer["load"].copy() for layer in model["layers"]]
                result, timing = solve(model, **solver_options)
                # Preserve every node on both rails, rather than checking only
                # a peak that could hide an incorrectly scaled load region.
                cls.fields[_density] = [item[0].copy() for item in result]
                return result, timing

            with patch.object(study, "solve_stack", side_effect=capture):
                cls.rows[density] = study.calculate(ini, 400, 10, "upper_small", 15, 24, 6, **keywords)

    def test_default_two_keeps_historical_geometry_load_and_numeric_result(self):
        implicit_config, implicit_layout = study.project_values(400, 10, "upper_small", 15, 24, 6)
        explicit_config, explicit_layout = study.project_values(400, 10, "upper_small", 15, 24, 6,
                                                                current_density=2)
        self.assertEqual(implicit_layout, explicit_layout)
        self.assertEqual({s:dict(implicit_config[s]) for s in implicit_config.sections()},
                         {s:dict(explicit_config[s]) for s in explicit_config.sections()})
        row = self.rows[2.0]
        self.assertEqual(row["current_density_A_mm2"], 2)
        self.assertAlmostEqual(row["top_current_A"], .752, places=12)
        # Recorded from the original fixed-2-A/mm2 implementation, using the
        # same full distributed-TSV circuit and sparse direct solver.
        self.assertAlmostEqual(row["layer0_max_total_IR_mV"], 5.741749315140689, places=7)
        self.assertAlmostEqual(row["layer1_max_total_IR_mV"], 12.028115913235604, places=7)
        self.assertAlmostEqual(row["max_total_IR_mV"], 12.028115913235604, places=7)
        self.assertEqual(study.vertical_bound_spacing("large_only"), 2030)

    def test_three_scales_uniform_load_and_every_solved_node_by_one_and_half(self):
        self.assertEqual(self.layouts[2.0], self.layouts[3.0])
        for density in (2.0, 3.0):
            row = self.rows[density]
            self.assertEqual(row["current_density_A_mm2"], density)
            self.assertAlmostEqual(row["top_current_A"], density*470*800/1e6, places=12)
            self.assertEqual(row["physical_tsv_count"], 24000+8*24*6)
            np.testing.assert_array_equal(self.loads[density][0], 0)
            self.assertTrue(np.all(self.loads[density][1] < 0))
            self.assertEqual(len(np.unique(self.loads[density][1])), 1)
        np.testing.assert_allclose(self.loads[3.0][1], 1.5*self.loads[2.0][1], rtol=1e-13, atol=1e-15)
        for two, three in zip(self.fields[2.0], self.fields[3.0]):
            self.assertEqual(two.size, self.rows[2.0]["nodes_per_rail"])
            np.testing.assert_allclose(three, 1.5*two, rtol=1e-9, atol=1e-12)
        for key in ("max_total_IR_mV", "layer0_max_total_IR_mV", "layer1_max_total_IR_mV",
                    "vertical_ideal_lower_bound_mV"):
            self.assertAlmostEqual(self.rows[3.0][key], 1.5*self.rows[2.0][key], places=8)

    def test_density_changes_only_the_upper_current_in_saved_configuration(self):
        lower, layout2 = study.project_values(400, 10, "upper_small", 15, 24, 6, current_density=2)
        higher, layout3 = study.project_values(400, 10, "upper_small", 15, 24, 6, current_density=3)
        self.assertEqual(layout2, layout3)
        values2 = {s:dict(lower[s]) for s in lower.sections()}
        values3 = {s:dict(higher[s]) for s in higher.sections()}
        self.assertEqual(float(values2["current"]["i"]), 0)
        self.assertEqual(float(values3["current"]["i"]), 0)
        self.assertAlmostEqual(float(values3["current.1"]["i"]), 1.5*float(values2["current.1"]["i"]), places=12)
        values2["current.1"].pop("i")
        values3["current.1"].pop("i")
        self.assertEqual(values2, values3)

    def test_ideal_vertical_bound_tracks_density_for_both_topologies(self):
        for scenario in study.SCENARIOS:
            with self.subTest(scenario=scenario):
                d2 = study.vertical_bound_spacing(scenario, 15, 24, 6, current_density=2)
                d3 = study.vertical_bound_spacing(scenario, 15, 24, 6, current_density=3)
                self.assertAlmostEqual((d3+70)*3, (d2+70)*2, places=10)
                upper_tsvs = 6000+(4*24*6 if scenario == "upper_small" else 0)
                total_current = 3*(d3+70)*800/1e6
                self.assertAlmostEqual(2*total_current*(15/6000+15/upper_tsvs)*1000, 11.2, places=11)

    def test_summary_records_density_and_rejects_a_mixture(self):
        row = dict(scenario="upper_small", spacing_um=100, mesh_pitch_um=10,
                   tsv_resistance_ohm=15, small_rows=24, small_cols=6,
                   current_density_A_mm2=3, max_total_IR_mV=10, pass_strict_11p2mV=True)
        summary = study.summarize([row], 10)
        self.assertEqual(summary["current_density_A_mm2"], 3)
        self.assertAlmostEqual(summary["scenarios"]["upper_small"]["vertical_ideal_upper_spacing_um"],
                               study.vertical_bound_spacing("upper_small", 15, 24, 6, current_density=3), places=11)
        with self.assertRaises(ValueError):
            study.summarize([self.rows[2.0], self.rows[3.0]], 10)

    def test_legacy_csv_without_density_is_still_two(self):
        with workspace_temporary_directory() as directory:
            path = Path(directory)/"old.csv"
            old = {key:value for key,value in self.rows[2.0].items() if key != "current_density_A_mm2"}
            with path.open("w", encoding="utf-8-sig", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=list(old))
                writer.writeheader()
                writer.writerow(old)
            original = path.read_bytes()
            rows = study.read_csv(path)
            self.assertEqual(rows[0]["current_density_A_mm2"], 2)
            self.assertEqual(study.summarize(rows, 10)["current_density_A_mm2"], 2)
            self.assertEqual(path.read_bytes(), original)

    def test_density_mismatch_rejects_continuation_before_any_saved_file_changes(self):
        for legacy in (False, True):
            with self.subTest(legacy_csv=legacy), workspace_temporary_directory() as directory:
                out = Path(directory)/"existing"
                out.mkdir()
                row = copy.deepcopy(self.rows[2.0])
                if legacy:
                    row.pop("current_density_A_mm2")
                study.write_csv(out/"sweep_results.csv", [row])
                (out/"study_inputs.json").write_text('{"keep":"original inputs"}\n', encoding="utf-8")
                (out/"comparison.json").write_text('{"keep":"original summary"}\n', encoding="utf-8")
                before = {str(p.relative_to(out)):p.read_bytes() for p in out.rglob("*") if p.is_file()}
                with patch.object(study,"calculate", side_effect=AssertionError("must not solve")), \
                     patch.object(study,"write_case", side_effect=AssertionError("must not rewrite models")), \
                     patch.object(study,"plot_sweep", side_effect=AssertionError("must not rewrite figures")):
                    with self.assertRaises(ValueError):
                        study.main(["--out",str(out),"--current-density","3","--r-ohm","15",
                                    "--small-rows","24","--small-cols","6","--spacings","400"])
                after = {str(p.relative_to(out)):p.read_bytes() for p in out.rglob("*") if p.is_file()}
                self.assertEqual(after, before)

    def test_cli_passes_density_to_model_and_metadata(self):
        with workspace_temporary_directory() as directory:
            out = Path(directory)/"fresh"
            actual = study.calculate

            def reuse_validated_solve(ini, *args, **kwargs):
                # Check the actual saved electrical input without repeating
                # the two full solves already validated in setUpClass.
                model = study.read_stack_config(ini)
                self.assertEqual(model["layers"][0]["load_current_A"], 0)
                self.assertAlmostEqual(model["layers"][1]["load_current_A"], 1.128, places=12)
                import inspect
                bound = inspect.signature(actual).bind(ini, *args, **kwargs)
                bound.apply_defaults()
                self.assertEqual(bound.arguments["current_density"], 3)
                return copy.deepcopy(self.rows[3.0])

            with patch.object(study,"calculate", side_effect=reuse_validated_solve) as calculate, \
                 patch.object(study,"plot_sweep"), redirect_stdout(io.StringIO()):
                study.main(["--out",str(out),"--current-density","3","--r-ohm","15",
                            "--small-rows","24","--small-cols","6","--spacings","400",
                            "--scenarios","upper_small"])
            self.assertEqual(calculate.call_count, 1)
            inputs = json.loads((out/"study_inputs.json").read_text(encoding="utf-8"))
            self.assertEqual(inputs["upper_current_density_A_mm2"], 3)
            self.assertAlmostEqual(inputs["finite_bound_spacing_um"]["upper_small"],
                                   study.vertical_bound_spacing("upper_small", 15, 24, 6, current_density=3), places=11)
            self.assertEqual(study.read_csv(out/"sweep_results.csv")[0]["current_density_A_mm2"], 3)
            self.assertEqual(json.loads((out/"comparison.json").read_text(encoding="utf-8"))["current_density_A_mm2"], 3)

    def test_density_must_be_positive_and_finite(self):
        self.assertEqual(study.checked_current_density("3"), 3)
        for value in (0, -1, float("nan"), float("inf"), -float("inf")):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    study.checked_current_density(value)
                with workspace_temporary_directory() as directory:
                    out = Path(directory)/"invalid"
                    with redirect_stderr(io.StringIO()), self.assertRaises((ValueError, SystemExit)):
                        study.main(["--out",str(out),"--current-density",str(value),"--spacings","400"])
                    self.assertFalse(out.exists())


if __name__ == "__main__":
    unittest.main()
