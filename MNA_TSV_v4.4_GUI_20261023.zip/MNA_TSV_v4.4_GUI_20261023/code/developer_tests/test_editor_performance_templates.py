import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import tsv_layout_editor as view
from tsv_components import expand_components, physical_tsvs
from tsv_template_io import (TEMPLATE_SCHEMA, load_templates, merge_templates, save_templates)
from test_editor import Value, editor, event, positions


class InteractionPerformanceTests(unittest.TestCase):
    def test_configure_during_group_drag_preserves_model_and_single_commit(self):
        e = editor()
        prototype = e.layout['placements'][0]
        e.layout['placements'].extend(dict(prototype,id=f'D{i}',x_um=20+i)
                                      for i in range(3,100))
        e.rebuild()
        e.select_all_key(event(e))
        self.assertEqual(len(e.selected),100)
        before = positions(e)
        e.press(event(e))
        drag, original, expanded = e.drag, e.layout, e.expanded
        e.canvas.reset_mock()
        with patch.object(view,'move_components',wraps=view.move_components) as move, \
             patch.object(view,'expand_components',wraps=expand_components) as mapping, \
             patch.object(e,'draw',wraps=e.draw) as redraw:
            e.canvas_configured(event(e))  # Geometry can settle just after press.
            for i in range(1,21):
                e.motion(event(e,20+i,20+i/2))
                e.canvas_configured(event(e))
            e.flush_drag_preview()
            self.assertIs(e.drag,drag)
            self.assertIs(e.layout,original)
            self.assertIs(e.expanded,expanded)
            self.assertEqual(positions(e),before)
            self.assertFalse(e.undo_stack)
            move.assert_not_called()
            mapping.assert_not_called()
            redraw.assert_not_called()
            e.canvas.delete.assert_not_called()
            e.canvas.create_oval.assert_not_called()
            e.release(event(e,43,29))
            self.assertEqual(move.call_count,1)
            self.assertEqual(mapping.call_count,1)
            self.assertEqual(redraw.call_count,1)
        after = positions(e)
        for identity in drag['ids']:
            self.assertEqual(after[identity],(before[identity][0]+23,before[identity][1]+9))
        for identity in set(before)-drag['ids']:
            self.assertEqual(after[identity],before[identity])
        self.assertEqual(len(e.undo_stack),1)
        e.undo()
        self.assertEqual(positions(e),before)

    def test_configure_during_box_keeps_selection_rectangle(self):
        e = editor()
        e.press(event(e,9,9))
        e.motion(event(e,40,25))
        box = e.selection_box
        e.canvas.reset_mock()
        with patch.object(e,'draw',wraps=e.draw) as redraw:
            e.canvas_configured(event(e))
            e.motion(event(e,75,29))
            e.canvas_configured(event(e))
            self.assertIs(e.selection_box,box)
            self.assertTrue(box['drawn'])
            e.canvas.coords.assert_called_once_with('selection_box',9.,241.,75.,221.)
            e.canvas.delete.assert_not_called()
            e.canvas.create_rectangle.assert_not_called()
            redraw.assert_not_called()
            e.release(event(e,75,29))
            self.assertEqual(redraw.call_count,1)
        self.assertEqual(e.selected,{'A','B'})
        self.assertIsNone(e.selection_box)
        self.assertFalse(e.undo_stack)

    def test_idle_configure_redraws_and_explicit_draw_still_cancels_drag(self):
        e = editor()
        with patch.object(e,'draw',wraps=e.draw) as redraw:
            e.canvas_configured(event(e))
            redraw.assert_called_once()
        e.press(event(e))
        e.motion(event(e,40,25))
        original = e.layout
        e.draw()
        self.assertIsNone(e.drag)
        self.assertIs(e.layout,original)
        self.assertFalse(e.undo_stack)

    def test_many_motion_events_coalesce_without_model_copy_or_full_redraw(self):
        e = editor()
        e.set_selection({'A','B'})
        e.press(event(e))
        original, expanded = e.layout, e.expanded
        e.canvas.reset_mock()
        with patch.object(view,'move_components',wraps=view.move_components) as move, \
             patch.object(view,'expand_components',wraps=expand_components) as mapping, \
             patch.object(e,'draw',wraps=e.draw) as redraw:
            for i in range(100):
                e.motion(event(e,20+i/10,22))
            self.assertIs(e.layout,original)
            self.assertIs(e.expanded,expanded)
            self.assertEqual(e.root.after.call_count,1)
            move.assert_not_called()
            mapping.assert_not_called()
            redraw.assert_not_called()
            e.canvas.delete.assert_not_called()
            e.canvas.create_oval.assert_not_called()
            e.flush_drag_preview()
            self.assertEqual(e.canvas.move.call_count,1)
            # Mouse release wins over the last rendered/pending frame.
            e.release(event(e,43,29))
            self.assertEqual(move.call_count,1)
            self.assertEqual(mapping.call_count,1)
            self.assertEqual(redraw.call_count,1)
        self.assertEqual(positions(e)['A'],(43,29))
        self.assertEqual(positions(e)['B'],(83,29))

    def test_preview_only_moves_its_shared_tag_and_cancel_keeps_original(self):
        e = editor()
        e.select_all_key(event(e))
        original = copy.deepcopy(e.layout)
        e.press(event(e));e.motion(event(e,40,25))
        e.flush_drag_preview()
        self.assertEqual(e.canvas.move.call_args.args,('drag_preview',20.,-5.))
        self.assertEqual(e.layout,original)
        e.motion(event(e,50,30))
        e.cancel_drag()
        e.root.after_cancel.assert_called_once()
        e.flush_drag_preview()  # A late callback must be harmless.
        self.assertEqual(e.layout,original)
        self.assertFalse(e.undo_stack)
        self.assertIsNone(e.drag)

    def test_frame_deltas_accumulate_without_position_drift(self):
        e = editor()
        e.set_selection({'A','B'})
        e.press(event(e))
        e.motion(event(e,30,22));e.flush_drag_preview()
        e.motion(event(e,35,28));e.flush_drag_preview()
        self.assertEqual([c.args for c in e.canvas.move.call_args_list],
                         [('drag_preview',10.,-2.),('drag_preview',5.,-6.)])
        e.release(event(e,35,28))
        self.assertEqual(positions(e)['B'],(75,28))

    def test_box_motion_updates_only_selection_rectangle(self):
        e = editor()
        e.press(event(e,9,9))
        with patch.object(e,'draw',wraps=e.draw) as redraw:
            e.motion(event(e,40,25));e.motion(event(e,75,29))
            redraw.assert_not_called()
            e.canvas.coords.assert_called_with('selection_box',9.,241.,75.,221.)
        e.release(event(e,75,29))
        self.assertEqual(e.selected,{'A','B'})

    def test_display_sampling_preserves_exact_physical_tsv_coordinates(self):
        p = dict(x_um=17.5,y_um=25.,rotation_deg=90)
        t = dict(rows=12,cols=26,pitch_x_um=1.5,pitch_y_um=2.,r_ohm=5.)
        all_rows = list(physical_tsvs(p,t))
        self.assertEqual(len(all_rows),312)
        self.assertEqual(list(physical_tsvs(p,t,7)),all_rows[::7])


class TemplateLibraryTests(unittest.TestCase):
    def types(self):
        return {'Dense':dict(rows=12,cols=26,pitch_x_um=1.5,pitch_y_um=1.5,r_ohm=5),
                'Wide':dict(rows=4,cols=6,pitch_x_um=3,pitch_y_um=3,r_ohm=5.5)}

    def test_current_or_all_templates_roundtrip_without_placement_data(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)/'templates.json'
            payload = save_templates(path,self.types())
            self.assertEqual(payload['schema'],TEMPLATE_SCHEMA)
            self.assertEqual(set(payload),{'schema','units','types'})
            self.assertEqual(load_templates(path),self.types())
            save_templates(path,self.types(),['Wide'])
            self.assertEqual(set(load_templates(path)),{'Wide'})

    def test_extract_templates_from_existing_layout_json(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)/'old.layout.json'
            layout = editor().layout
            path.write_text(json.dumps(layout),encoding='utf-8')
            self.assertEqual(load_templates(path),layout['types'])

    def test_name_conflict_defaults_to_rename_and_preserves_instances(self):
        e = editor()
        original = copy.deepcopy(e.layout)
        incoming = {'T':dict(e.layout['types']['T'],r_ohm=9)}
        candidate,report = merge_templates(e.layout,incoming)
        self.assertEqual(e.layout,original)
        self.assertEqual(candidate['placements'],original['placements'])
        self.assertEqual(candidate['types']['T']['r_ohm'],5)
        self.assertEqual(candidate['types']['T_imported']['r_ohm'],9)
        self.assertEqual(report['names'],{'T':'T_imported'})

    def test_keep_replace_and_identical_types(self):
        e = editor()
        incoming = {'T':dict(e.layout['types']['T'],r_ohm=9)}
        kept,report = merge_templates(e.layout,incoming,'keep')
        self.assertEqual(kept,e.layout)
        self.assertEqual(report['skipped'],['T'])
        replaced,report = merge_templates(e.layout,incoming,'replace')
        self.assertEqual(replaced['types']['T']['r_ohm'],9)
        self.assertEqual(report['replaced'],['T'])
        identical,report = merge_templates(e.layout,e.layout['types'])
        self.assertEqual(identical,e.layout)
        self.assertEqual(report['skipped'],['T'])

    def test_rename_avoids_existing_and_incoming_names(self):
        e = editor()
        e.layout['types']['T_imported'] = dict(e.layout['types']['T'])
        incoming = {'T':dict(e.layout['types']['T'],r_ohm=9),
                    'T_imported_2':dict(e.layout['types']['T'],r_ohm=8)}
        candidate,report = merge_templates(e.layout,incoming)
        self.assertEqual(report['names']['T'],'T_imported_3')
        self.assertEqual(candidate['types']['T_imported_2']['r_ohm'],8)

    def test_invalid_bundle_is_rejected_atomically(self):
        e = editor()
        before = copy.deepcopy(e.layout)
        incoming = self.types()
        incoming['Bad'] = dict(incoming['Dense'],rows=0)
        with self.assertRaises(ValueError):
            merge_templates(e.layout,incoming)
        self.assertEqual(e.layout,before)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)/'bad.json'
            path.write_text(json.dumps({'schema':TEMPLATE_SCHEMA,'types':self.types(),
                                        'units':{'pitch':'nm','resistance':'ohm'}}))
            with self.assertRaisesRegex(ValueError,'单位'):
                load_templates(path)

    def test_gui_import_is_undoable_and_does_not_move_components(self):
        e = editor()
        e.vars['template_policy'] = Value('同名自动改名')
        before = copy.deepcopy(e.layout)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)/'library.json'
            save_templates(path,{'T':dict(e.layout['types']['T'],r_ohm=7)})
            with patch.object(view.filedialog,'askopenfilename',return_value=str(path)):
                e.import_templates()
        self.assertEqual(e.layout['placements'],before['placements'])
        self.assertEqual(e.vars['type'].get(),'T_imported')
        self.assertEqual(len(e.undo_stack),1)
        e.undo()
        self.assertEqual(e.layout,before)

    def test_gui_export_does_not_change_project(self):
        e = editor()
        before = copy.deepcopy(e.layout)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)/'library.json'
            with patch.object(view.filedialog,'asksaveasfilename',return_value=str(path)):
                e.export_templates(True)
            self.assertEqual(load_templates(path),e.layout['types'])
        self.assertEqual(e.layout,before)
        self.assertFalse(e.dirty)


if __name__=='__main__':
    unittest.main()
