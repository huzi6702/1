import copy
import io
import json
import sys
import tempfile
import unittest
from configparser import ConfigParser
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

import matplotlib
matplotlib.use('Agg')
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import mna_ir_dual as base
import mna_ir_stack as stack
from tsv_components import (SCHEMA, compile_components, expand_components,
    import_bump_positions, nearest_node, normalize_layout, physical_tsvs,
    read_meshes, save_project)
from tsv_layout_editor import make_array, read_project
from test_stack import full_mna_reference


def template(rows=2,cols=3,pitch=1,r=6):
    return {'rows':rows,'cols':cols,'pitch_x_um':pitch,'pitch_y_um':pitch,'r_ohm':r}


def placement(identity='B',name='T',interface='source',rail='vdd',x=10,y=10,rotation=0):
    return {'id':identity,'type':name,'interface':interface,'rail':rail,
            'x_um':x,'y_um':y,'rotation_deg':rotation}


def project(two=True):
    return {'schema':SCHEMA,'types':{'T':template(),'U':template(2,2,1,4)},'placements':[
        placement('Bv'),placement('Bg',rail='vss'),
        *([placement('Uv','U','0_1'),placement('Ug','U','0_1','vss')] if two else [])]}


def config(two=True,grid=1):
    c = ConfigParser()
    c.read_string(f'''[stack]
layers={2 if two else 1}
[mesh]
xgrid={grid}
ygrid={grid}
rh=.03
rv=.07
xpitch=10
ypitch=10
[bump]
powerv=.8
[current]
currentmode=1
i=-.2
[current.1]
currentmode=1
i=-.3
''')
    return c


def load_model(c,layout):
    with tempfile.TemporaryDirectory() as d:
        path = Path(d)/'model.ini'
        save_project(c,layout,path)
        return stack.read_stack_config(path)


class ComponentTests(unittest.TestCase):
    def test_even_array_center_and_90_degree_rotation(self):
        p = placement(x=50,y=30)
        t = template(2,4,2)
        points = list(physical_tsvs(p,t))
        self.assertEqual(points[0],(1,1,47,29))
        self.assertEqual(points[-1],(2,4,53,31))
        points = list(physical_tsvs(dict(p,rotation_deg=90),t))
        self.assertEqual(points[0],(1,1,51,27))
        self.assertEqual(points[-1],(2,4,49,33))

    def test_nearest_anisotropic_and_midpoint_tie(self):
        layer = {'id':1,'offset':50,'xgrid':5,'ygrid':4,'xpitch':10,'ypitch':20}
        self.assertEqual(nearest_node(25,50,layer),(62,3,3))
        self.assertEqual(nearest_node(21,41,layer),(56,2,2))
        self.assertEqual(nearest_node(5,10,layer),(50,1,1))
        self.assertEqual(nearest_node(55,90,layer),(69,5,4))

    def test_out_of_domain_rejected_instead_of_clamped(self):
        layers = read_meshes(config())
        for x,y in ((4.9,10),(10,15.1),(100,10)):
            with self.subTest(x=x,y=y),self.assertRaisesRegex(ValueError,'outside'):
                nearest_node(x,y,layers[0])

    def test_edge_tsv_uses_nearest_boundary_with_optional_strict_mode(self):
        c,layout = config(False),project(False)
        layout['types']['T'] = template(8,10,2,5)
        _,_,data = compile_components(layout,read_meshes(c))
        self.assertEqual(len(data['records']),160)
        self.assertTrue(any('boundary node' in w for w in data['warnings']))
        self.assertTrue(all(r['b']==0 for r in data['records']))
        layout['boundary_policy']='strict'
        with self.assertRaisesRegex(ValueError,'outside'):
            compile_components(layout,read_meshes(c))

    def test_many_physical_tsvs_preserved_on_same_node(self):
        layout = project(False)
        sources,_,expanded = compile_components(layout,read_meshes(config(False)))
        self.assertEqual(len(expanded['records']),12)
        self.assertEqual(sources['vdd'][0]['nodes'],[0]*6)
        self.assertEqual(sources['vdd'][0]['branch_r'],6)
        self.assertEqual(expanded['summaries'][0]['unique_upper_nodes'],1)
        self.assertEqual(expanded['summaries'][0]['max_tsvs_same_node_pair'],6)

    def test_single_node_all_tsvs_parallel_hand_calculation(self):
        p = load_model(config(),project())
        results,timing = stack.solve_stack(p)
        # Source: 6 TSVs of 6 ohm -> 1 ohm. Upper: 4 of 4 -> 1 ohm.
        for index,result in enumerate(results):
            np.testing.assert_allclose(result[0],[.5,.8],atol=1e-14)
            currents = result[3]['physical_tsv_currents']
            sign = 1 if index==0 else -1
            np.testing.assert_allclose([r['current_A'] for r in currents[:6]],sign*.5/6)
            np.testing.assert_allclose([r['current_A'] for r in currents[6:]],sign*.3/4)
        self.assertTrue(timing['parallel_rails'])

    def test_mixed_types_share_current_by_conductance(self):
        c,layout = config(),project()
        layout['types']['W'] = template(1,2,1,4)
        layout['placements'].append(placement('U2','W','0_1'))
        p = load_model(c,layout)
        results,_ = stack.solve_stack(p)
        vdd = results[0]
        self.assertAlmostEqual(vdd[0][1]-vdd[0][0],.3/(1+.5))
        physical = pd.DataFrame(vdd[3]['physical_tsv_currents'])
        self.assertAlmostEqual(physical[physical.component_id=='Uv'].current_A.sum(),.2)
        self.assertAlmostEqual(physical[physical.component_id=='U2'].current_A.sum(),.1)

    def test_independent_bump_identity_and_total_current(self):
        c,layout = config(False),project(False)
        layout['types']['W'] = template(1,2,1,4)
        layout['placements'].append(placement('B2','W'))
        p = load_model(c,layout)
        results,_ = stack.solve_stack(p)
        sources = {r['component_id']:r['current_A'] for r in results[0][1]}
        self.assertAlmostEqual(sources['Bv'],.2/1.5)
        self.assertAlmostEqual(sources['B2'],.2*.5/1.5)

    def test_array_footprint_reaches_multiple_mesh_nodes(self):
        c,layout = config(False,6),project(False)
        layout['types']['T'] = template(8,10,2,5)
        for p in layout['placements']:
            p.update(x_um=30,y_um=30)
        _,_,expanded = compile_components(layout,read_meshes(c))
        self.assertEqual(expanded['summaries'][0]['tsv_count'],80)
        self.assertEqual(expanded['summaries'][0]['unique_upper_nodes'],9)
        rows = expanded['records'][:80]
        count = {}
        for row in rows:
            count[row['b']] = count.get(row['b'],0)+1
        self.assertEqual(sum(count.values()),80)

    def heterogeneous(self):
        c,layout = config(True,5),project()
        c.add_section('mesh.1')
        c['mesh.1'].update({'xgrid':'4','ygrid':'4','xpitch':'12.5','ypitch':'12.5','rh':'.05'})
        layout['types']['T'] = template(3,4,2,5)
        layout['types']['U'] = template(4,6,1.5,4.9)
        layout['placements'] = [placement('Bv',x=20,y=20),placement('Bg',rail='vss',x=40,y=40),
             placement('Uv','U','0_1',x=30,y=30,rotation=90),
             placement('Ug','U','0_1','vss',x=40,y=20)]
        return c,layout

    def test_different_layer_pitch_maps_each_endpoint_independently(self):
        c,layout = self.heterogeneous()
        _,_,data = compile_components(layout,read_meshes(c))
        links = [r for r in data['records'] if r['interface']=='0_1']
        self.assertTrue(any((r['xl'],r['yl'])!=(r['xu'],r['yu']) for r in links))
        self.assertTrue(all(r['r']==4.9 for r in links))
        for r in links:
            self.assertLessEqual(abs(r['xl']*10-r['x_um']),5+1e-12)
            self.assertLessEqual(abs(r['xu']*12.5-r['x_um']),6.25+1e-12)

    def test_path_plot_uses_component_points_and_reference_resistance_on_both_layers(self):
        c,layout = self.heterogeneous()
        layout['types']['Small'] = template(4,4,1.5,5)
        # Two distinct components sharing a center must remain two plot points.
        layout['placements'].append(placement('U2','Small','0_1',x=30,y=30))
        p = load_model(c,layout)
        original_sources,original_links = copy.deepcopy(p['sources']),copy.deepcopy(p['links'])
        with tempfile.TemporaryDirectory() as d:
            fig = stack.plot_vertical_layout(p,Path(d))
            try:
                source_vdd,source_vss,upper_vdd,upper_vss = fig.axes[:4]
                self.assertEqual([len(ax.collections[0].get_offsets()) for ax in fig.axes[:4]],
                                 [1,1,2,1])
                np.testing.assert_allclose(source_vdd.collections[0].get_array(),[5/12])
                np.testing.assert_allclose(upper_vdd.collections[0].get_array(),[4.9/24,5/16])
                # The upper destination pitch is 12.5 um; the lower pitch is 10.
                np.testing.assert_allclose(upper_vdd.collections[0].get_offsets(),[[25,25],[25,25]])
                self.assertIn('2 components | 40 TSVs',upper_vdd.get_title())
                self.assertTrue(all(ax.get_ylabel()=='R/N reference (ohm)' for ax in fig.axes[4:]))
                self.assertTrue((Path(d)/'stack_tsv_layout.png').is_file())
            finally:
                stack.plt.close(fig)
        self.assertEqual(p['sources'],original_sources)
        self.assertEqual(p['links'],original_links)
        self.assertEqual(len(p['component_data']['records']),88)
        self.assertEqual(len(p['links'][0]['vdd']),40)

    def test_heterogeneous_all_nodes_against_full_voltage_mna(self):
        p = load_model(*self.heterogeneous())
        results,_ = stack.solve_stack(p)
        for rail,result in zip(('vdd','vss'),results):
            voltage = p['powerv']-result[0] if rail=='vdd' else result[0]
            np.testing.assert_allclose(voltage,full_mna_reference(p,rail),atol=2e-13,rtol=0)
            self.assertLess(max(abs(np.array(result[3]['layer_current_balance_error_A']))),1e-12)

    def test_export_roundtrip_and_paths_relative_to_ini(self):
        c,layout = self.heterogeneous()
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)/'my design.ini'
            _,json_path = save_project(c,layout,path)
            parsed,actual,layers = read_project(path)
            self.assertEqual(actual,normalize_layout(layout,2))
            self.assertEqual(len(layers),2)
            self.assertEqual(parsed.getfloat('current.1','i'),-.3)
            self.assertEqual(parsed.get('components','layout'),json_path.name)
            p = stack.read_stack_config(path)
            self.assertEqual(p['node_count'],41)

    def test_bulk_placement_unique_ids_and_counts(self):
        layout = make_array(project(False),placement(x=30,y=30),3,2,10,20)
        self.assertEqual(len(layout['placements']),8)
        self.assertEqual(len({p['id'] for p in layout['placements']}),8)
        self.assertEqual(layout['placements'][-1]['x_um'],50)
        self.assertEqual(layout['placements'][-1]['y_um'],50)
        with self.assertRaises(ValueError):
            make_array(project(False),placement(),3,2,0,20)

    def test_import_old_bump_centers_to_physical_um(self):
        c = config(False,4)
        c['mesh']['xpitch']='12'
        c.add_section('bumploc')
        c['bumploc'].update({'bumplocvdd':'[[2,3,.39]]','bumplocvss':'[[3,1]]'})
        layout = import_bump_positions(c,project(False),'T')
        self.assertEqual(len(layout['placements']),2)
        self.assertEqual(layout['placements'][0]['x_um'],24)
        self.assertEqual(layout['placements'][0]['y_um'],30)
        self.assertEqual(layout['types']['T']['r_ohm'],6)

    def test_single_layer_bump_import_preserves_target_interlayer_components(self):
        old = config(False,4)
        old['mesh'].update({'xpitch':'12','ypitch':'8'})
        old.add_section('bumploc')
        old['bumploc'].update({'bumplocvdd':'[[2,3,.39]]','bumplocvss':'[[3,1]]'})
        target = project(True)
        before = copy.deepcopy(target)
        imported = import_bump_positions(old,target,'T',layer_count=2)
        self.assertEqual(target,before)
        self.assertEqual(imported['types'],before['types'])
        self.assertEqual([p for p in imported['placements'] if p['interface']!='source'],
                         [p for p in before['placements'] if p['interface']!='source'])
        sources = [p for p in imported['placements'] if p['interface']=='source']
        self.assertEqual([(p['rail'],p['x_um'],p['y_um']) for p in sources],
                         [('vdd',24,24),('vss',36,8)])
        self.assertEqual(imported['types']['T']['r_ohm'],6)

    def test_invalid_types_ids_rotations_and_rails_rejected(self):
        for key,value in (('rows',0),('cols',2.5),('r_ohm',-2),('pitch_x_um',0),('r_ohm','nan')):
            layout = project(False)
            layout['types']['T'][key]=value
            with self.subTest(key=key,value=value),self.assertRaises(ValueError):
                normalize_layout(layout,1)
        for key,value in (('interface','0_2'),('rotation_deg',45),('rail','power'),('type','missing')):
            layout = project()
            layout['placements'][0][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):
                normalize_layout(layout,2)
        layout = project(False)
        layout['placements'].append(copy.deepcopy(layout['placements'][0]))
        with self.assertRaisesRegex(ValueError,'Duplicate'):
            normalize_layout(layout,1)

    def test_overlap_is_reported_and_not_electrically_deduplicated(self):
        layout = project(False)
        layout['placements'].append(placement('B2'))
        sources,_,data = compile_components(layout,read_meshes(config(False)))
        self.assertEqual(len(sources['vdd']),2)
        self.assertEqual(len(data['records']),18)
        self.assertTrue(any('overlap another' in s for s in data['warnings']))

    def test_missing_source_and_disconnected_upper_rejected(self):
        layout = project(False)
        layout['placements'] = layout['placements'][:1]
        with self.assertRaisesRegex(ValueError,'VSS'):
            load_model(config(False),layout)
        with self.assertRaisesRegex(ValueError,'VDD layers'):
            load_model(config(),project(False))

    def test_component_mode_owns_paths_and_ignores_legacy_entries(self):
        c,layout = config(False),project(False)
        c.add_section('bumploc')
        c['bumploc'].update({'bumplocvdd':'[[999,999]]','bumplocvss':'[]'})
        c['bump']['rz']='.0000001'
        c['bump']['xpn']='999'
        p = load_model(c,layout)
        self.assertEqual(len(p['sources']['vdd']),1)
        self.assertEqual(p['sources']['vdd'][0]['branch_r'],6)

    def test_three_layers_component_interfaces(self):
        c,layout = config(),project()
        c['stack']['layers']='3'
        c.add_section('current.2')
        c['current.2'].update({'currentmode':'1','i':'-.4'})
        layout['placements'].extend([placement('Tv','U','1_2'),placement('Tg','U','1_2','vss')])
        p = load_model(c,layout)
        results,_ = stack.solve_stack(p)
        for result in results:
            np.testing.assert_allclose(result[0],[.9,1.6,2.0],atol=1e-13)

    def test_full_export_single_tsv_component_and_node_counts_and_power(self):
        c,layout = self.heterogeneous()
        with tempfile.TemporaryDirectory() as d,redirect_stdout(io.StringIO()):
            path = Path(d)/'case.ini'
            save_project(c,layout,path)
            out = Path(d)/'out'
            with patch.object(stack,'plot_stack'):
                summary = base.run(path,out,plot_max_axis=3)
            physical = pd.read_csv(out/'physical_tsv_current.csv')
            aggregate = pd.read_csv(out/'component_current.csv')
            geometry = pd.read_csv(out/'component_geometry.csv')
            nodes = pd.read_csv(out/'node_results.csv')
            mapping = pd.read_csv(out/'tsv_node_mapping.csv')
            self.assertEqual(len(physical),72)
            self.assertEqual(len(physical.tsv_id.unique()),72)
            self.assertEqual(len(mapping),72)
            self.assertEqual(len(aggregate),4)
            self.assertEqual(len(geometry),4)
            self.assertEqual(len(nodes),41)
            self.assertAlmostEqual(physical[(physical.rail=='VDD')&(physical.interface=='source')].current_A.sum(),.5)
            self.assertAlmostEqual(physical[(physical.rail=='VSS')&(physical.interface=='0_1')].current_A.sum(),-.3)
            self.assertLess(abs(summary['power_balance']['balance_error_W']),1e-12)
            self.assertTrue(summary['plotting']['full_resolution_csv'])
            self.assertEqual(summary['original_spec_metrics']['spec'],11.2)


if __name__=='__main__':
    unittest.main()
