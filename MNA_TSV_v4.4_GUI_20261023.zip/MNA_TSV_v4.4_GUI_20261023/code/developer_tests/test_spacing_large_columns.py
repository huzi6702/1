"""Three-column geometry, distributed TSV accounting, and safe scan reuse."""
from __future__ import annotations

import copy
from contextlib import redirect_stderr, redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "spacing_large_columns_study", ROOT / "studies/two_column_spacing.py")
study = importlib.util.module_from_spec(spec)
spec.loader.exec_module(study)


def workspace_temporary_directory():
    folder = ROOT / ".local_validation" / "tmp"
    folder.mkdir(parents=True, exist_ok=True)
    return tempfile.TemporaryDirectory(prefix="spacing_columns_", dir=folder)


class SpacingLargeColumnsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = workspace_temporary_directory()
        cls.addClassCleanup(cls.temporary.cleanup)
        cls.folder = Path(cls.temporary.name)
        cls.ini = study.write_case(cls.folder / "three_columns", 300, 10,
                                   "upper_small", 12, 20, 4, 2, large_cols=3)
        cls.model = study.read_stack_config(cls.ini)
        # This is a real full-node, distributed-TSV direct solve.  Geometry
        # and conservation checks below inspect independent loaded inputs.
        cls.row = study.calculate(cls.ini, 300, 10, "upper_small", 12, 20, 4,
                                  2, large_cols=3)

    def test_three_columns_have_two_midpoints_with_reversed_power_ground_order(self):
        for pitch in (10, 5):
            with self.subTest(mesh_pitch=pitch):
                config, layout = study.project_values(
                    300, pitch, "upper_small", 12, 20, 4, 2, large_cols=3)
                shift = (pitch - 10) / 2
                placements = layout["placements"]
                small_types = {name for name, value in layout["types"].items()
                               if (value["rows"], value["cols"]) == (20, 4)}
                big_types = set(layout["types"]) - small_types
                self.assertEqual(len(small_types), 1)
                self.assertEqual(len(big_types), 1)
                self.assertEqual(len(placements), 64)
                self.assertEqual(len({p["id"] for p in placements}), 64)
                self.assertEqual(int(config["mesh"]["xgrid"]), 670 / pitch)
                self.assertEqual(int(config["mesh.1"]["xgrid"]), 670 / pitch)
                for rail, big_y0, small_y0 in (("vdd", 55, 155), ("vss", 155, 55)):
                    with self.subTest(rail=rail):
                        source = {(p["x_um"], p["y_um"], p["type"], p["rotation_deg"])
                                  for p in placements if p["rail"] == rail
                                  and p["interface"] == "source"}
                        upper = {(p["x_um"], p["y_um"], p["type"], p["rotation_deg"])
                                 for p in placements if p["rail"] == rail
                                 and p["interface"] == "0_1" and p["type"] in big_types}
                        self.assertEqual(source, upper)
                        self.assertEqual(len(source), 12)
                        self.assertEqual({p[0] for p in source},
                                         {40 + shift, 340 + shift, 640 + shift})
                        self.assertEqual({p[1] for p in source},
                                         {big_y0 + 200*k + shift for k in range(4)})
                        small = [p for p in placements if p["rail"] == rail
                                 and p["type"] in small_types]
                        self.assertEqual(len(small), 8)
                        self.assertTrue(all(p["interface"] == "0_1" for p in small))
                        self.assertEqual({(p["x_um"], p["y_um"]) for p in small},
                                         {(x + shift, small_y0 + 200*k + shift)
                                          for x in (190, 490) for k in range(4)})
                self.assertTrue(all(t["r_ohm"] == 12 and t["pitch_x_um"] == 1.5
                                    and t["pitch_y_um"] == 1.5
                                    for t in layout["types"].values()))

    def test_large_only_contains_no_upper_small_components(self):
        _, layout = study.project_values(300, 10, "large_only", 12, 20, 4,
                                         2, large_cols=3)
        self.assertEqual(len(layout["placements"]), 48)
        self.assertEqual(len(layout["types"]), 1)
        self.assertTrue(all((value["rows"], value["cols"]) == (30, 25)
                            for value in layout["types"].values()))

    def test_real_three_column_solve_preserves_every_tsv_and_area_load(self):
        model, row = self.model, self.row
        self.assertFalse(model["component_data"]["warnings"])
        self.assertEqual(len(model["component_data"]["records"]), 37280)
        for rail in ("vdd", "vss"):
            self.assertEqual(len(model["sources"][rail]), 12)
            self.assertEqual(sum(len(source["nodes"]) for source in model["sources"][rail]), 9000)
            self.assertEqual(len(model["links"][0][rail]), 9640)
            self.assertTrue(all(source["branch_r"] == 12 for source in model["sources"][rail]))
            self.assertTrue(all(link["r"] == 12 for link in model["links"][0][rail]))
        self.assertEqual(model["layers"][0]["load_current_A"], 0)
        np.testing.assert_array_equal(model["layers"][0]["load"], 0)
        self.assertEqual(len(np.unique(model["layers"][1]["load"])), 1)
        self.assertTrue(np.all(model["layers"][1]["load"] < 0))
        self.assertAlmostEqual(model["layers"][1]["load_current_A"], 1.072, places=12)
        self.assertEqual(row["large_cols"], 3)
        self.assertEqual(row["components"], 64)
        self.assertEqual(row["physical_tsv_count"], 37280)
        self.assertEqual(row["width_um"], 670)
        self.assertAlmostEqual(row["top_current_A"], 1.072, places=12)
        self.assertEqual(row["nodes_per_rail"], 2 * 67 * 80)
        self.assertGreater(row["max_total_IR_mV"], 0)
        self.assertGreaterEqual(row["max_total_IR_mV"] + 1e-8,
                                row["vertical_ideal_lower_bound_mV"])
        self.assertLess(row["max_relative_residual"], 1e-9)
        self.assertLess(row["max_layer_current_balance_error_A"], 1e-8)
        self.assertLess(abs(row["power_balance_error_W"]), 1e-8)

    def test_vertical_bound_uses_all_source_and_middle_columns(self):
        for large_cols in (2, 3, 4):
            for scenario in study.SCENARIOS:
                with self.subTest(large_cols=large_cols, scenario=scenario):
                    spacing = study.vertical_bound_spacing(scenario, 12, 20, 4,
                                                            2, large_cols=large_cols)
                    total_current = 2 * ((large_cols - 1) * spacing + 70) * 800 / 1e6
                    source = 3000 * large_cols
                    upper = source + (4 * (large_cols - 1) * 20 * 4
                                      if scenario == "upper_small" else 0)
                    self.assertAlmostEqual(2 * total_current * (12/source + 12/upper) * 1000,
                                           11.2, places=10)

    def test_default_two_preserves_existing_geometry_config_and_bound(self):
        for scenario in study.SCENARIOS:
            with self.subTest(scenario=scenario):
                config, layout = study.project_values(300, 10, scenario, 12, 20, 4)
                explicit_config, explicit_layout = study.project_values(
                    300, 10, scenario, 12, 20, 4, 2, large_cols=2)
                self.assertEqual(layout, explicit_layout)
                self.assertEqual({s:dict(config[s]) for s in config.sections()},
                                 {s:dict(explicit_config[s]) for s in explicit_config.sections()})
                self.assertEqual(len(layout["placements"]), 40 if scenario == "upper_small" else 32)
                self.assertEqual(int(config["mesh"]["xgrid"]), 37)
                self.assertAlmostEqual(float(config["current.1"]["i"]), -.592, places=12)
                self.assertEqual(study.vertical_bound_spacing(scenario, 12, 20, 4),
                                 study.vertical_bound_spacing(scenario, 12, 20, 4, 2, large_cols=2))
        self.assertEqual(study.vertical_bound_spacing("large_only"), 2030)

    def test_legacy_csv_defaults_to_two_columns_without_modifying_the_file(self):
        with workspace_temporary_directory() as directory:
            path = Path(directory) / "old.csv"
            old = copy.deepcopy(self.row)
            old.pop("large_cols")
            study.write_csv(path, [old])
            before = path.read_bytes()
            rows = study.read_csv(path)
            self.assertEqual(rows[0]["large_cols"], 2)
            self.assertEqual(study.summarize(rows, 10)["large_cols"], 2)
            self.assertEqual(path.read_bytes(), before)

    def test_summary_keeps_column_count_and_refuses_mixed_scans(self):
        row = copy.deepcopy(self.row)
        row["pass_strict_11p2mV"] = True
        row["max_total_IR_mV"] = 10
        summary = study.summarize([row], 10)
        self.assertEqual(summary["large_cols"], 3)
        self.assertAlmostEqual(summary["scenarios"]["upper_small"]["vertical_ideal_upper_spacing_um"],
                               study.vertical_bound_spacing("upper_small", 12, 20, 4, 2, large_cols=3),
                               places=11)
        with self.assertRaises(ValueError):
            study.summarize([row, dict(row, large_cols=2)], 10)

    def test_mismatched_column_continuation_preserves_all_existing_bytes(self):
        for saved_cols, requested_cols in ((None, 3), (2, 3), (3, 2)):
            with self.subTest(saved_cols=saved_cols, requested_cols=requested_cols), \
                 workspace_temporary_directory() as directory:
                out = Path(directory) / "existing"
                out.mkdir()
                row = dict(self.row, large_cols=saved_cols)
                if saved_cols is None:
                    row.pop("large_cols")
                study.write_csv(out / "sweep_results.csv", [row])
                (out / "study_inputs.json").write_text('{"keep":"inputs"}\n', encoding="utf-8")
                (out / "comparison.json").write_text('{"keep":"comparison"}\n', encoding="utf-8")
                (out / "spacing_comparison.png").write_bytes(b"keep original figure")
                before = {str(p.relative_to(out)):p.read_bytes()
                          for p in out.rglob("*") if p.is_file()}
                with patch.object(study, "calculate", side_effect=AssertionError("must not solve")), \
                     patch.object(study, "write_case", side_effect=AssertionError("must not alter cases")), \
                     patch.object(study, "plot_sweep", side_effect=AssertionError("must not alter figures")), \
                     self.assertRaises(ValueError):
                    study.main(["--out", str(out), "--large-cols", str(requested_cols),
                                "--r-ohm", "12", "--small-rows", "20", "--small-cols", "4",
                                "--current-density", "2", "--spacings", "300"])
                after = {str(p.relative_to(out)):p.read_bytes()
                         for p in out.rglob("*") if p.is_file()}
                self.assertEqual(after, before)

    def test_cli_passes_three_columns_to_geometry_and_metadata(self):
        with workspace_temporary_directory() as directory:
            out = Path(directory) / "fresh"
            actual = study.calculate

            def reuse_validated_solve(ini, *args, **kwargs):
                # Re-read the actual CLI-created circuit, but reuse the real
                # solve already made above instead of calculating it twice.
                model = study.read_stack_config(ini)
                self.assertAlmostEqual(model["layers"][1]["load_current_A"], 1.072, places=12)
                self.assertEqual(len(model["component_data"]["records"]), 37280)
                import inspect
                bound = inspect.signature(actual).bind(ini, *args, **kwargs)
                bound.apply_defaults()
                self.assertEqual(bound.arguments["large_cols"], 3)
                return copy.deepcopy(self.row)

            with patch.object(study, "calculate", side_effect=reuse_validated_solve) as calculate, \
                 patch.object(study, "plot_sweep"), redirect_stdout(io.StringIO()):
                study.main(["--out", str(out), "--large-cols", "3", "--r-ohm", "12",
                            "--small-rows", "20", "--small-cols", "4", "--current-density", "2",
                            "--spacings", "300", "--scenarios", "upper_small"])
            self.assertEqual(calculate.call_count, 1)
            inputs = json.loads((out / "study_inputs.json").read_text(encoding="utf-8"))
            self.assertEqual(inputs["large_cols"], 3)
            self.assertEqual(inputs["source_big_per_rail"], 12)
            self.assertEqual(inputs["upper_big_per_rail"], 12)
            self.assertEqual(inputs["upper_small_per_rail"], 8)
            self.assertAlmostEqual(inputs["finite_bound_spacing_um"]["upper_small"],
                                   study.vertical_bound_spacing("upper_small", 12, 20, 4, 2, large_cols=3),
                                   places=11)
            self.assertEqual(study.read_csv(out / "sweep_results.csv")[0]["large_cols"], 3)
            self.assertEqual(json.loads((out / "comparison.json").read_text(encoding="utf-8"))["large_cols"], 3)

    def test_exported_projects_keep_three_columns_and_independent_templates(self):
        with workspace_temporary_directory() as directory:
            out = Path(directory)
            best = dict(self.row, max_total_IR_mV=10, pass_strict_11p2mV=True)
            failed = dict(best, spacing_um=310, max_total_IR_mV=12,
                          pass_strict_11p2mV=False)
            summary = study.summarize([best, failed], 10)
            with patch.object(study, "run", return_value={
                    "global_max_total_loss": {"value": .010}}) as run, \
                 redirect_stdout(io.StringIO()):
                study.export_cases(out, summary)
            # The full IR export was requested exactly for the passing case;
            # both passing and failing projects remain available to reload.
            self.assertEqual(run.call_count, 1)
            for label, current in (("max_pass", 1.072), ("next_fail", 1.104)):
                folder = out / f"upper_small_{label}"
                loaded = study.read_stack_config(folder / "project.ini")
                self.assertEqual(len(loaded["component_data"]["records"]), 37280)
                self.assertAlmostEqual(loaded["layers"][1]["load_current_A"], current, places=12)
                saved = json.loads((folder / "study_case.json").read_text(encoding="utf-8"))
                self.assertEqual(saved["large_cols"], 3)
                self.assertTrue((folder / "tsv_templates.json").is_file())
                layout = json.loads((folder / "project.layout.json").read_text(encoding="utf-8"))
                self.assertEqual(len(layout["placements"]), 64)
                from tsv_template_io import load_templates
                self.assertEqual(load_templates(folder / "tsv_templates.json"), layout["types"])

    def test_column_count_is_an_integer_at_least_two_before_output_creation(self):
        self.assertEqual(study.checked_large_cols(3), 3)
        for value in (0, 1, -1, 2.5):
            with self.subTest(value=value), workspace_temporary_directory() as directory:
                with self.assertRaises(ValueError):
                    study.checked_large_cols(value)
                out = Path(directory) / "invalid"
                with redirect_stderr(io.StringIO()), self.assertRaises((ValueError, SystemExit)):
                    study.main(["--out", str(out), "--large-cols", str(value), "--spacings", "300"])
                self.assertFalse(out.exists())


if __name__ == "__main__":
    unittest.main()
