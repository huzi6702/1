"""Viewing saved scans must not invoke a fresh circuit calculation."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("spacing_results_viewer",ROOT/"studies/show_spacing_results.py")
viewer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(viewer)


class SpacingResultsViewerTests(unittest.TestCase):
    def fixture(self,root,name="r12_20x4"):
        folder = root/name/"mesh10"
        folder.mkdir(parents=True)
        (folder/"spacing_comparison.png").write_bytes(b"existing saved PNG")
        summary = dict(mesh_pitch_um=10,scenarios=dict(upper_small=dict(
            best=dict(spacing_um=400,max_total_IR_mV=11.057554603),
            next_failed=dict(spacing_um=410))))
        (folder/"comparison.json").write_text(json.dumps(summary),encoding="utf-8")
        return folder

    def test_saved_figures_build_relative_page_without_replot_or_data_changes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            folder = self.fixture(root)
            before = {p:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir()}
            with patch.object(viewer,"regenerate_plot",side_effect=AssertionError("must not replot")):
                page = viewer.build_report(root)
            content = page.read_text(encoding="utf-8")
            self.assertIn('src="r12_20x4/mesh10/spacing_comparison.png"',content)
            self.assertIn("11.057555",content)
            self.assertIn("20×4",content)
            self.assertEqual(before,{p:hashlib.sha256(p.read_bytes()).hexdigest() for p in before})

    def test_missing_png_redraws_csv_without_any_solve(self):
        sys.path.insert(0,str(ROOT/"studies")) if str(ROOT/"studies") not in sys.path else None
        import two_column_spacing as study
        reference = ROOT/"studies/reference_spacing/r12_20x4/mesh10.csv"
        if not reference.is_file():
            reference = next((ROOT/"studies/reference_spacing/r12_20x4").glob("*mesh10*.csv"))
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            csv_path = root/"sweep_results.csv"
            shutil.copy2(reference,csv_path)
            before = csv_path.read_bytes()
            with patch.object(study,"calculate",side_effect=AssertionError("must not calculate")), \
                 patch.object(study,"solve_stack",side_effect=AssertionError("must not solve")), \
                 patch.object(study,"run",side_effect=AssertionError("must not export/solve")):
                page = viewer.build_report(root)
            self.assertTrue((root/"spacing_comparison.png").read_bytes().startswith(b"\x89PNG"))
            self.assertIn("11.057555",page.read_text(encoding="utf-8"))
            self.assertEqual(csv_path.read_bytes(),before)
            self.assertFalse((root/"comparison.json").exists())

    def test_escaped_labels_encoded_links_and_offline_html(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.fixture(root,'中文 空格&图')
            (root/"verification.json").write_text(json.dumps(dict(profile='<script>alert("x")</script>')),encoding="utf-8")
            content = viewer.build_report(root).read_text(encoding="utf-8")
            self.assertNotIn("<script>",content)
            self.assertIn("&lt;script&gt;",content)
            self.assertIn("%E4%B8%AD%E6%96%87%20%E7%A9%BA%E6%A0%BC%26%E5%9B%BE/mesh10/",content)
            self.assertNotIn('src="http',content)

    def test_latest_existing_run_and_no_open_option(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name,mtime in (("old",100),("new",200)):
                run = root/"reproduced"/name
                self.fixture(run)
                marker = run/"verification.json"
                marker.write_text('{}',encoding="utf-8")
                os.utime(marker,(mtime,mtime))
            (root/"reproduced/empty_in_progress").mkdir()
            with patch.object(viewer,"ROOT",root),patch.object(viewer,"open_report") as opened:
                self.assertEqual(viewer.main(["--no-open"]),0)
                opened.assert_not_called()
            self.assertTrue((root/"reproduced/new"/viewer.PAGE_NAME).is_file())
            self.assertFalse((root/"reproduced/old"/viewer.PAGE_NAME).exists())
            with self.assertRaises(FileNotFoundError):
                viewer.latest_results(root/"missing")

    def test_browser_receives_escaped_file_uri_and_failure_is_nonfatal(self):
        page = ROOT/"中文 空格"/viewer.PAGE_NAME
        with patch.object(viewer.webbrowser,"open",return_value=True) as opened:
            self.assertTrue(viewer.open_report(page))
            opened.assert_called_once_with(page.resolve().as_uri())
        with patch.object(viewer.webbrowser,"open",side_effect=OSError("no browser")):
            self.assertFalse(viewer.open_report(page))


if __name__ == "__main__":
    unittest.main()
