"""Exercise real editor event handlers with headless Tk view adapters."""
import copy
import sys
import tempfile
import unittest
from configparser import ConfigParser
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tsv_components import SCHEMA, read_meshes
from tsv_layout_editor import Editor
import mna_ir_dual as base
import mna_ir_stack as stack


class Value:
    def __init__(self, value=''):
        self.value = value

    def get(self):
        return self.value

    def set(self, value):
        self.value = value


class Control(dict):
    def config(self, **kwargs):
        self.update(kwargs)

    configure = config


class Table:
    def __init__(self):
        self.rows = {}
        self.chosen = ()
        self.focused = ''

    def get_children(self):
        return tuple(self.rows)

    def delete(self, *items):
        for item in items:
            self.rows.pop(item, None)
        self.chosen = tuple(i for i in self.chosen if i in self.rows)

    def insert(self, parent, index, iid, **kwargs):
        self.rows[iid] = kwargs

    def exists(self, item):
        return item in self.rows

    def selection_set(self, items):
        self.chosen = tuple(items)

    def selection(self):
        return self.chosen

    def focus(self, item=None):
        if item is not None:
            self.focused = item
        return self.focused

    def see(self, item):
        pass


def point(identity, interface='source', rail='vdd', x=20, y=20, rotation=0):
    return dict(id=identity, type='T', interface=interface, rail=rail,
                x_um=x, y_um=y, rotation_deg=rotation)


def editor():
    e = Editor.__new__(Editor)
    e.layout = {'schema': SCHEMA, 'types': {'T': dict(rows=1, cols=1,
                pitch_x_um=2, pitch_y_um=2, r_ohm=5)},
                'placements': [point('A'), point('B', rail='vss', x=60),
                               point('C', x=100, y=50, rotation=90),
                               point('U', '0_1'), point('V', '0_1', x=120, y=70)]}
    c = ConfigParser()
    c.read_string('[stack]\nlayers=2\n[mesh]\nxgrid=20\nygrid=20\nxpitch=10\nypitch=10\n')
    e.layers = read_meshes(c)
    e.root = MagicMock()
    e.path = ROOT / 'headless.ini'
    e.selected, e.primary = set(), None
    e.drag = e.selection_box = e.pan = None
    e.undo_stack, e.redo_stack = [], []
    e.dirty, e._syncing_table = False, False
    e.expanded = e.geometry_error = None
    e.scale, e.ox, e.oy = 1., 0., 250.
    e.vars = {key: Value() for key in ('type', 'new_type', 'rows', 'cols',
        'pitch_x_um', 'pitch_y_um', 'r_ohm', 'interface', 'rail', 'rotation_deg',
        'x_um', 'y_um', 'id', 'nx', 'ny', 'step_x', 'step_y', 'mode', 'endpoint',
        'status', 'copy_target')}
    for key, value in {'type':'T', 'interface':'source', 'rail':'vdd', 'rotation_deg':'0',
                       'x_um':'20', 'y_um':'20', 'mode':'select', 'endpoint':'upper',
                       'copy_target':'0_1'}.items():
        e.vars[key].set(value)
    e.show_tsv, e.show_links, e.show_grid, e.show_other_layers = [Value(True) for _ in range(4)]
    e.type_combo = Control(values=('T',))
    e.interface_combo = Control(values=('source','0_1'))
    e.copy_target_combo = Control(values=('0_1',))
    e.copy_button = Control()
    e.type_info, e.info, e.table, e.canvas = Control(), Control(), Table(), MagicMock()
    e.rebuild()
    return e


def event(e, x=20, y=20, state=0, widget_class='Canvas'):
    a, b = e.screen(x, y)
    return SimpleNamespace(x=a, y=b, state=state,
                           widget=SimpleNamespace(winfo_class=lambda:widget_class))


def positions(e):
    return {p['id']:(p['x_um'],p['y_um']) for p in e.layout['placements']}


class EditorTests(unittest.TestCase):
    def test_ctrl_a_selects_both_rails_only_on_editable_interface(self):
        e = editor()
        self.assertEqual(e.select_all_key(event(e)), 'break')
        self.assertEqual(e.selected, {'A','B','C'})
        self.assertEqual(set(e.table.selection()), e.selected)
        self.assertEqual(set(e.table.rows), {'A','B','C'})

    def test_text_field_shortcuts_do_not_select_or_delete_components(self):
        e = editor()
        e.select('A')
        before = copy.deepcopy(e.layout)
        for widget_class in ('TEntry','Text','TCombobox'):
            self.assertIsNone(e.select_all_key(event(e,widget_class=widget_class)))
            self.assertIsNone(e.delete_key(event(e,widget_class=widget_class)))
        self.assertEqual(e.layout, before)
        self.assertEqual(e.selected, {'A'})

    def test_control_click_toggles_and_shift_click_adds(self):
        e = editor()
        e.press(event(e)); e.release(event(e))
        e.press(event(e,60,20,state=4))
        self.assertEqual(e.selected, {'A','B'})
        e.press(event(e,100,50,state=1))
        self.assertEqual(e.selected, {'A','B','C'})
        e.press(event(e,60,20,state=4))
        self.assertEqual(e.selected, {'A','C'})

    def test_drag_moves_selected_group_and_preserves_other_layers_and_undo(self):
        e = editor()
        e.set_selection({'A','B'})
        before = positions(e)
        e.press(event(e,20,20))
        e.motion(event(e,33,28))
        e.release(event(e,33,28))
        after = positions(e)
        self.assertEqual(after['A'], (33,28))
        self.assertEqual(after['B'], (73,28))
        for item in ('C','U','V'):
            self.assertEqual(after[item],before[item])
        self.assertEqual(e.selected, {'A','B'})
        self.assertEqual(len(e.undo_stack),1)
        e.undo()
        self.assertEqual(positions(e),before)
        e.redo()
        self.assertEqual(positions(e),after)

    def test_no_move_click_keeps_group_without_dirtying_layout(self):
        e = editor()
        e.set_selection({'A','B'})
        e.press(event(e));e.release(event(e))
        self.assertEqual(e.selected,{'A','B'})
        self.assertFalse(e.dirty)
        self.assertFalse(e.undo_stack)

    def test_box_selects_both_rails_and_excludes_gray_background(self):
        e = editor()
        e.press(event(e,9,9))
        e.motion(event(e,75,29))
        e.release(event(e,75,29))
        self.assertEqual(e.selected, {'A','B'})
        self.assertIsNone(e.selection_box)

    def test_clicking_gray_component_cannot_select_or_drag_it(self):
        e = editor()
        before = copy.deepcopy(e.layout)
        e.press(event(e,120,70))
        self.assertIsNone(e.drag)
        e.release(event(e,120,70))
        self.assertFalse(e.selected)
        self.assertEqual(e.layout,before)
        e.set_selection({'U','V'})
        self.assertFalse(e.selected)

    def test_delete_key_deletes_group_and_undo_restores_it(self):
        e = editor()
        e.set_selection({'A','B'})
        self.assertEqual(e.delete_key(event(e)),'break')
        self.assertEqual(set(positions(e)),{'C','U','V'})
        self.assertFalse(e.selected)
        e.undo()
        self.assertEqual(set(positions(e)),{'A','B','C','U','V'})

    def test_table_multi_selection_updates_canvas_selection(self):
        e = editor()
        e.table.selection_set(('A','B'))
        e.table.focus('B')
        e.table_select()
        self.assertEqual(e.selected,{'A','B'})
        self.assertEqual(e.primary,'B')

    def test_cross_interface_copy_preserves_coordinates_types_rails_and_rotation(self):
        e = editor()
        original = copy.deepcopy(e.layout)
        e.set_selection({'A','B','C'})
        e.copy_to_interface()
        created = [p for p in e.layout['placements'] if p['id'] not in {'A','B','C','U','V'}]
        self.assertEqual(len(created),3)
        for source,target in zip(original['placements'][:3],created):
            for key in ('type','x_um','y_um','rail','rotation_deg'):
                self.assertEqual(target[key],source[key])
            self.assertEqual(target['interface'],'0_1')
        self.assertEqual(len({p['id'] for p in e.layout['placements']}),8)
        self.assertEqual(e.vars['interface'].get(),'source')
        self.assertEqual(e.selected,{'A','B','C'})
        e.undo()
        self.assertEqual(e.layout,original)

    def test_cross_interface_copy_rejects_invalid_target_without_mutation(self):
        e = editor()
        e.set_selection({'A'})
        before = copy.deepcopy(e.layout)
        for target in ('source','1_2'):
            e.vars['copy_target'].set(target)
            with self.assertRaises(ValueError):
                e.copy_to_interface()
        self.assertEqual(e.layout,before)

    def test_single_layer_bump_import_refreshes_cross_interface_copy_and_is_undoable(self):
        e = editor()
        e.vars['interface'].set('0_1')
        e.filter_changed()
        e.select('U')
        before = copy.deepcopy(e.layout)
        original_layers = copy.deepcopy(e.layers)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)/'old.ini'
            path.write_text('[mesh]\nxgrid=20\nygrid=20\nxpitch=12\nypitch=8\n'
                            '[bumploc]\nbumplocvdd=[[2,3,.39]]\nbumplocvss=[[3,1]]\n',
                            encoding='utf-8')
            with patch('tsv_layout_editor.filedialog.askopenfilename',return_value=str(path)):
                e.import_bumps()
        self.assertEqual(e.layers,original_layers)
        self.assertEqual(e.vars['interface'].get(),'source')
        self.assertEqual(list(e.copy_target_combo['values']),['0_1'])
        self.assertEqual(e.vars['copy_target'].get(),'0_1')
        self.assertEqual([p for p in e.layout['placements'] if p['interface']!='source'],
                         [p for p in before['placements'] if p['interface']!='source'])
        self.assertEqual(positions(e)['BUMP_vdd_1'],(24,24))
        self.assertEqual(e.layout['types'],before['types'])
        e.select('BUMP_vdd_1')
        e.copy_to_interface()
        copied = [p for p in e.layout['placements']
                  if p['interface']=='0_1' and p['id'] not in {'U','V'}]
        self.assertEqual(len(copied),1)
        self.assertEqual((copied[0]['x_um'],copied[0]['y_um']),(24,24))
        e.undo()
        e.undo()
        self.assertEqual(e.layout,before)

    def test_failed_strict_group_move_rolls_back_whole_group(self):
        e = editor()
        e.layout['boundary_policy']='strict'
        e.rebuild()
        e.set_selection({'A','B'})
        before = copy.deepcopy(e.layout)
        e.press(event(e))
        e.motion(event(e,-20,20))
        e.release(event(e,-20,20))
        self.assertEqual(e.layout,before)
        self.assertFalse(e.undo_stack)
        self.assertIn('整组移动已撤销',e.vars['status'].get())

    def test_group_duplicate_gets_new_ids_and_keeps_spacing(self):
        e = editor()
        e.set_selection({'A','B'})
        e.duplicate()
        self.assertEqual(len(e.selected),2)
        created = [p for p in e.layout['placements'] if p['id'] in e.selected]
        self.assertEqual([(p['x_um'],p['y_um']) for p in created],[(30,20),(70,20)])
        self.assertEqual(set(positions(e)) & {'A','B','C','U','V'}, {'A','B','C','U','V'})

    def test_numeric_group_update_translates_relative_to_primary(self):
        e = editor()
        e.set_selection({'A','B'},'B')
        e.vars['x_um'].set('65')
        e.vars['y_um'].set('27')
        e.update_properties()
        self.assertEqual(positions(e)['A'],(25,27))
        self.assertEqual(positions(e)['B'],(65,27))

    def test_apply_current_template_preserves_single_placement_and_rebuilds_mapping(self):
        e = editor()
        e.layout['boundary_policy']='nearest'
        e.layout['types']['Small'] = dict(rows=4,cols=4,pitch_x_um=1.5,pitch_y_um=1.5,r_ohm=7)
        e.rebuild()
        e.select('C')
        before = copy.deepcopy(e.layout)
        e.vars['type'].set('Small')
        # Uncommitted placement fields and template edits must not be applied.
        for key,value in dict(id='replacement',x_um='bad coordinate',y_um='999',
                              rail='vss',rotation_deg='180',rows='99',r_ohm='100').items():
            e.vars[key].set(value)
        e.update_selected()
        expected = copy.deepcopy(before)
        expected['placements'][2]['type']='Small'
        self.assertEqual(e.layout,expected)
        self.assertEqual(e.selected,{'C'})
        self.assertEqual(e.primary,'C')
        self.assertEqual(e.vars['type'].get(),'Small')
        self.assertEqual(e.vars['rows'].get(),'4')
        self.assertEqual(len([r for r in e.expanded['records'] if r['component_id']=='C']),16)
        self.assertEqual(e.table.rows['C']['values'][0],'Small')
        self.assertEqual(len(e.undo_stack),1)
        self.assertTrue(e.dirty)
        e.undo()
        self.assertEqual(e.layout,before)
        e.redo()
        self.assertEqual(e.layout,expected)

    def test_apply_current_template_updates_mixed_group_and_excludes_gray_components(self):
        e = editor()
        e.layout['boundary_policy']='nearest'
        e.layout['types']['Small'] = dict(rows=4,cols=4,pitch_x_um=1.5,pitch_y_um=1.5,r_ohm=5)
        e.layout['placements'][1]['type']='Small'
        e.rebuild()
        e.set_selection({'A','B','C'},'B')
        before = copy.deepcopy(e.layout)
        e.selected.add('U')  # Stale gray-layer ID is filtered again by the action.
        e.vars['type'].set('Small')
        e.vars['x_um'].set('300')
        e.vars['rail'].set('vss')
        e.vars['rotation_deg'].set('180')
        e.update_selected()
        expected = copy.deepcopy(before)
        for p in expected['placements'][:3]:
            p['type']='Small'
        self.assertEqual(e.layout,expected)
        self.assertEqual(e.selected,{'A','B','C'})
        self.assertEqual(e.primary,'B')
        self.assertEqual(len(e.undo_stack),1)
        self.assertEqual(len([r for r in e.expanded['records'] if r['interface']=='source']),48)
        e.undo()
        self.assertEqual(e.layout,before)

    def test_apply_current_template_rejects_missing_selection_or_template_without_changes(self):
        e = editor()
        before = copy.deepcopy(e.layout)
        with self.assertRaisesRegex(ValueError,'选择'):
            e.update_selected()
        e.select('A')
        e.vars['type'].set('missing')
        with self.assertRaisesRegex(ValueError,'模板'):
            e.update_selected()
        self.assertEqual(e.layout,before)
        self.assertFalse(e.undo_stack)
        self.assertFalse(e.dirty)

    def test_apply_current_template_noop_does_not_add_history_or_clear_redo(self):
        e = editor()
        e.select('A')
        e.redo_stack=[copy.deepcopy(e.layout)]
        redo = copy.deepcopy(e.redo_stack)
        e.update_selected()
        self.assertFalse(e.undo_stack)
        self.assertFalse(e.dirty)
        self.assertEqual(e.redo_stack,redo)

    def test_apply_current_template_strict_geometry_failure_is_atomic(self):
        e = editor()
        e.layout['boundary_policy']='strict'
        e.layout['types']['Wide'] = dict(rows=4,cols=40,pitch_x_um=10,pitch_y_um=10,r_ohm=5)
        e.rebuild()
        e.set_selection({'A','B'},'B')
        before = copy.deepcopy(e.layout)
        e.vars['type'].set('Wide')
        with self.assertRaisesRegex(ValueError,'outside'):
            e.update_selected()
        self.assertEqual(e.layout,before)
        self.assertEqual(e.selected,{'A','B'})
        self.assertFalse(e.undo_stack)
        self.assertFalse(e.dirty)

    def test_gray_overlay_is_drawn_first_and_can_be_hidden(self):
        e = editor()
        with patch.object(e,'draw_component',wraps=e.draw_component) as draw:
            e.draw()
            self.assertEqual([c.args[0]['id'] for c in draw.call_args_list],['U','V','A','B','C'])
            self.assertTrue(all(c.kwargs.get('background') for c in draw.call_args_list[:2]))
        colors = [c.kwargs.get('outline') for c in e.canvas.create_rectangle.call_args_list]
        self.assertIn('#b5bdc7',colors)
        e.show_other_layers.set(False)
        with patch.object(e,'draw_component',wraps=e.draw_component) as draw:
            e.draw()
            self.assertEqual([c.args[0]['id'] for c in draw.call_args_list],['A','B','C'])

    def test_switching_interface_clears_old_selection(self):
        e = editor()
        e.select_all_key(event(e))
        e.vars['interface'].set('0_1')
        e.filter_changed()
        self.assertFalse(e.selected)
        self.assertEqual(e.vars['copy_target'].get(),'source')
        e.select_all_key(event(e))
        self.assertEqual(e.selected,{'U','V'})

    def test_default_config_matches_user_mesh_and_current_loads(self):
        p = stack.read_stack_config(ROOT/'pginfo_components.ini')
        self.assertEqual(p['node_count'],127*80*2)
        for layer in p['layers']:
            self.assertEqual((layer['xgrid'],layer['ygrid']),(127,80))
            self.assertEqual((layer['xpitch'],layer['ypitch']),(10,10))
            self.assertEqual((layer['rh'],layer['rv']),(.061,.061))
            self.assertEqual(layer['currentmode'],1)
        self.assertAlmostEqual(p['layers'][0]['load_current_A'],.98)
        self.assertAlmostEqual(p['layers'][1]['load_current_A'],.5)
        with patch.object(sys,'argv',['mna_ir_dual.py']),patch.object(base,'run') as run,patch.object(base.plt,'show'):
            base.main()
            self.assertEqual(Path(run.call_args.args[0]),ROOT/'pginfo_components.ini')


if __name__=='__main__':
    unittest.main()
