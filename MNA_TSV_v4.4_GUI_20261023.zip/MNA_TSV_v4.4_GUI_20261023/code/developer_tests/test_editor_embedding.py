"""Window ownership and widget parenting when embedding the existing editor."""
from contextlib import ExitStack
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import tsv_layout_editor as view


class Value:
    def __init__(self, master=None, value=''):
        self.master = master
        self.value = value

    def set(self, value):
        self.value = value

    def get(self):
        return self.value


class EditorEmbeddingTests(unittest.TestCase):
    def construct(self, **options):
        root = MagicMock(name='real_tk_toplevel')
        with ExitStack() as stack:
            stack.enter_context(patch.object(view.ttk, 'Style'))
            stack.enter_context(patch.object(view.tk, 'StringVar', side_effect=Value))
            stack.enter_context(patch.object(view.tk, 'BooleanVar', side_effect=Value))
            for method in ('build_ui', 'refresh_types', 'refresh_interfaces', 'rebuild'):
                stack.enter_context(patch.object(view.Editor, method))
            path=ROOT / 'pginfo_components.ini'
            if not path.is_file():
                path=ROOT / 'data/scan_base/project.ini'
            editor = view.Editor(root, path, **options)
        return root, editor

    def test_default_constructor_retains_standalone_window_and_shortcuts(self):
        root, editor = self.construct()
        self.assertIs(editor.root, root)
        self.assertIs(editor.container, root)
        self.assertTrue(editor.manage_window)
        root.title.assert_called_once_with('MNA TSV 组件布局器 v4.2')
        root.geometry.assert_called_once_with('1420x900')
        root.minsize.assert_called_once_with(1140, 760)
        root.protocol.assert_called_once_with('WM_DELETE_WINDOW', editor.close)
        bindings = {call.args[0]:call.args[1] for call in root.bind.call_args_list}
        self.assertEqual(set(bindings), {'<Control-z>', '<Control-y>', '<Control-s>',
                                         '<Control-a>', '<Control-A>', '<Delete>', '<KeyPress-f>', '<KeyPress-F>'})
        editor.undo, editor.redo, editor.save = MagicMock(), MagicMock(), MagicMock()
        for key, callback in (('<Control-z>', editor.undo), ('<Control-y>', editor.redo),
                              ('<Control-s>', editor.save)):
            bindings[key](SimpleNamespace())
            callback.assert_called_once_with()
        self.assertEqual(bindings['<Control-a>'], editor.select_all_key)
        self.assertEqual(bindings['<Control-A>'], editor.select_all_key)
        self.assertEqual(bindings['<Delete>'], editor.delete_key)
        self.assertEqual(bindings['<KeyPress-f>'], editor.fit_key)
        self.assertEqual(bindings['<KeyPress-F>'], editor.fit_key)
        root.after.assert_called_once_with(120, editor.fit)

    def test_embedded_constructor_keeps_host_window_and_root_bindings_untouched(self):
        container = MagicMock(name='notebook_tab')
        root, editor = self.construct(container=container, manage_window=False,
                                       bind_shortcuts=False)
        self.assertIs(editor.root, root)
        self.assertIs(editor.container, container)
        root.title.assert_not_called()
        root.geometry.assert_not_called()
        root.minsize.assert_not_called()
        root.protocol.assert_not_called()
        root.bind.assert_not_called()
        root.after.assert_called_once_with(120, editor.fit)
        container.after.assert_not_called()
        for variable in [*editor.vars.values(), editor.show_tsv, editor.show_links,
                         editor.show_grid, editor.show_other_layers]:
            self.assertIs(variable.master, root)

    def test_window_management_and_shortcuts_can_be_disabled_independently(self):
        for manage_window, bind_shortcuts in ((False, True), (True, False)):
            with self.subTest(manage_window=manage_window, bind_shortcuts=bind_shortcuts):
                root, editor = self.construct(manage_window=manage_window,
                                               bind_shortcuts=bind_shortcuts)
                self.assertEqual(root.protocol.called, manage_window)
                self.assertEqual(root.title.called, manage_window)
                self.assertEqual(root.geometry.called, manage_window)
                self.assertEqual(root.minsize.called, manage_window)
                self.assertEqual(root.bind.call_count, 8 if bind_shortcuts else 0)
                self.assertIs(editor.container, root)

    def test_fit_shortcut_ignores_windows_numlock_but_not_ctrl_or_alt(self):
        editor=view.Editor.__new__(view.Editor)
        editor.fit=MagicMock()
        canvas=MagicMock()
        canvas.winfo_class.return_value='Canvas'
        with patch.object(view.sys,'platform','win32'):
            self.assertEqual(editor.fit_key(SimpleNamespace(widget=canvas,state=0x0008)),'break')
            editor.fit.assert_called_once_with()
            editor.fit.reset_mock()
            for state in (0x0004,0x000c,0x20000,0x20008):
                self.assertIsNone(editor.fit_key(SimpleNamespace(widget=canvas,state=state)))
            editor.fit.assert_not_called()
        with patch.object(view.sys,'platform','linux'):
            self.assertIsNone(editor.fit_key(SimpleNamespace(widget=canvas,state=0x0008)))
            editor.fit.assert_not_called()

    def test_toolbar_body_and_status_are_hosted_in_container_and_run_is_exposed(self):
        root, editor = self.construct(container=MagicMock(name='notebook_tab'),
                                       manage_window=False, bind_shortcuts=False)
        editor.run = MagicMock(name='outer_application_run_override')
        with ExitStack() as stack:
            widgets = {}
            for name in ('Frame', 'Panedwindow', 'Scrollbar', 'LabelFrame', 'Combobox',
                         'Label', 'Entry', 'Button', 'Menubutton', 'Radiobutton',
                         'Checkbutton', 'Treeview'):
                factory = MagicMock(side_effect=lambda *args, **kwargs:MagicMock())
                widgets[name] = stack.enter_context(patch.object(view.ttk, name, factory))
            stack.enter_context(patch.object(view.ttk, 'Style'))
            stack.enter_context(patch.object(view.tk, 'Canvas', side_effect=lambda *a, **kw:MagicMock()))
            stack.enter_context(patch.object(view.tk, 'Menu'))
            view.Editor.build_ui(editor)
            self.assertEqual(widgets['Frame'].call_args_list[0].args, (editor.container,))
            self.assertEqual(widgets['Panedwindow'].call_args.args, (editor.container,))
            status = [call for call in widgets['Label'].call_args_list
                      if call.kwargs.get('textvariable') is editor.vars['status']]
            self.assertEqual(len(status), 1)
            self.assertIs(status[0].args[0], editor.container)
            run_calls = [call for call in widgets['Button'].call_args_list
                         if call.kwargs.get('text') == '运行 IR 求解']
            self.assertEqual(len(run_calls), 1)
            self.assertIs(run_calls[0].args[0], editor.toolbar)
            self.assertIsNotNone(editor.run_button)
            run_calls[0].kwargs['command']()
            editor.run.assert_called_once_with()
        root.bind.assert_not_called()
        root.protocol.assert_not_called()

    def test_hover_updates_cursor_without_overwriting_host_title(self):
        for manage_window in (False, True):
            with self.subTest(manage_window=manage_window):
                root, editor = self.construct(manage_window=manage_window,
                                               bind_shortcuts=False)
                editor.canvas = MagicMock()
                editor.world = MagicMock(return_value=(120, 85))
                editor.vars['mode'].set('place')
                root.title.reset_mock()
                editor.hover(SimpleNamespace(x=10, y=20))
                editor.canvas.config.assert_called_once_with(cursor='crosshair')
                if manage_window:
                    root.title.assert_called_once_with(
                        'MNA TSV 组件布局器 v4.2 | X=120.00, Y=85.00 μm')
                else:
                    root.title.assert_not_called()

    def test_embedded_guarded_dialog_uses_the_real_toplevel(self):
        root, editor = self.construct(container=MagicMock(), manage_window=False,
                                       bind_shortcuts=False)
        with patch.object(view.messagebox, 'showerror') as showerror:
            failing_operation = MagicMock(side_effect=ValueError('invalid template'))
            self.assertIsNone(editor.guarded(failing_operation))
            showerror.assert_called_once_with('未完成操作', 'invalid template', parent=root)


if __name__ == '__main__':
    unittest.main()
