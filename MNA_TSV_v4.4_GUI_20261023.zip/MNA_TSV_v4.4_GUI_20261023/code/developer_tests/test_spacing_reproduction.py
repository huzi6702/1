"""Reference and fresh-output integrity checks for the reproduction entry."""
import copy
import hashlib
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("spacing_reproduction",ROOT/"studies/reproduce_spacing.py")
reproduce = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reproduce)


class SpacingReproductionTests(unittest.TestCase):
    def setUp(self):
        self.manifest = reproduce.load_manifest()
        self.case = reproduce.selected_cases(self.manifest,"latest")[0]
        self.stage = next(s for s in self.case["stages"] if s["id"] == "mesh10")

    def sample(self):
        expected = reproduce.load_reference(self.stage)[("upper_small",400.0)]
        actual = dict(expected,max_relative_residual=0.0,
                      max_layer_current_balance_error_A=0.0,power_balance_error_W=0.0)
        return actual,expected

    def test_exact_profile_coverage_and_no_extra_fine_cartesian_product(self):
        self.assertEqual(len(reproduce.build_plan(self.manifest,"all","quick")),12)
        self.assertEqual(len(reproduce.build_plan(self.manifest,"all","scan")),724)
        self.assertEqual(len(reproduce.build_plan(self.manifest,"all","full")),870)
        latest = reproduce.build_plan(self.manifest,"latest","quick")
        self.assertEqual({(p["scenario"],p["spacing"]) for p in latest},
                         {("large_only",360),("large_only",370),("upper_small",400),("upper_small",410)})

    def test_electrical_change_is_detected(self):
        actual,expected = self.sample()
        self.assertEqual(reproduce.compare_point(actual,expected,1e-6)["status"],"PASS")
        actual["layer0_max_total_IR_mV"] += .01
        self.assertEqual(reproduce.compare_point(actual,expected,1e-6)["status"],"FAIL")

    def test_comparison_tolerance_does_not_relax_strict_spec(self):
        actual,expected = self.sample()
        actual["max_total_IR_mV"] = 11.200001
        actual["pass_strict_11p2mV"] = False
        self.assertEqual(reproduce.compare_point(actual,expected,100)["status"],"FAIL")

    def test_reference_point_omission_is_detected(self):
        incomplete = copy.deepcopy(self.stage)
        incomplete["points_um"]["upper_small"].pop()
        with self.assertRaisesRegex(ValueError,"覆盖范围不同"):
            reproduce.load_reference(incomplete)

    def test_reference_corruption_is_detected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reference = root/"reference.csv"
            reference.write_text("verified",encoding="utf-8")
            stage = dict(reference_csv="reference.csv",
                         reference_sha256=hashlib.sha256(reference.read_bytes()).hexdigest())
            reference.write_text("changed",encoding="utf-8")
            with patch.object(reproduce,"ROOT",root):
                with self.assertRaisesRegex(ValueError,"参考数据校验失败"):
                    reproduce.load_reference(stage)

    def test_existing_output_and_reference_tree_are_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            marker = root/"keep.txt"
            marker.write_text("keep",encoding="utf-8")
            with self.assertRaises(FileExistsError):
                reproduce.fresh_output(root)
            self.assertEqual(marker.read_text(encoding="utf-8"),"keep")
            with patch.object(reproduce,"ROOT",root):
                with self.assertRaises(ValueError):
                    reproduce.fresh_output(root/"studies/reference_spacing/forbidden")
            self.assertFalse((root/"studies").exists())

    def test_existing_output_rejected_before_environment_or_compute(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(reproduce,"check_environment",side_effect=AssertionError("must not import/solve")):
                with self.assertRaises(FileExistsError):
                    reproduce.main(["--out",directory])


if __name__ == "__main__":
    unittest.main()
