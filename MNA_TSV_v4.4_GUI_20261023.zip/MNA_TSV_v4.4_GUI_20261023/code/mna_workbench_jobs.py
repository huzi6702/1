#!/usr/bin/env python3
"""Configuration and isolated, headless jobs for the local MNA workbench.

The configuration embeds the INI and component layout, so reopening a saved
workbench does not depend on paths to the user's original project files.
Numerical packages are imported only when a calculation actually starts.
"""
from __future__ import annotations

import argparse
from configparser import ConfigParser, Error as ConfigError
from datetime import datetime
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile

from tsv_components import MAX_TSVS, normalize_layout, read_meshes


SCHEMA = "mna-workbench-1"
ROOT = Path(__file__).resolve().parent
SCAN_DEFAULTS = dict(large_cols=3, r_ohm=12.0, small_rows=20, small_cols=4,
                     current_density=2.0, pitch=10.0, minimum=40.0,
                     maximum=None, step=10.0, spacings=None, export_ir=True, workers=1)
SCENARIOS = ("large_only", "upper_small")


def _number(value, label, *, positive=False, integer=False, minimum=None):
    if isinstance(value, bool):
        raise ValueError(f"{label} 必须是数值")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        raise ValueError(f"{label} 必须是有限数值") from None
    if not math.isfinite(result) or (positive and result <= 0):
        raise ValueError(f"{label} 必须是有限{'正' if positive else ''}数值")
    if integer and not result.is_integer():
        raise ValueError(f"{label} 必须是整数")
    if minimum is not None and result < minimum:
        raise ValueError(f"{label} 必须不小于 {minimum:g}")
    return int(result) if integer else result


def _normalize_scan(value):
    if not isinstance(value, dict):
        raise ValueError("scan 必须是参数对象")
    unknown = set(value) - set(SCAN_DEFAULTS)
    if unknown:
        raise ValueError("未知扫描参数：" + ", ".join(sorted(unknown)))
    clean = dict(SCAN_DEFAULTS, **value)
    clean["large_cols"] = _number(clean["large_cols"], "大组件列数", integer=True, minimum=2)
    clean["workers"] = _number(clean["workers"], "并发进程数", integer=True, minimum=1)
    for key, label in (("small_rows", "小组件行数"), ("small_cols", "小组件列数")):
        clean[key] = _number(clean[key], label, integer=True, minimum=1)
    for key, label in (("r_ohm", "单根TSV电阻"), ("current_density", "顶层电流密度"),
                       ("pitch", "Mesh pitch"), ("step", "扫描步长")):
        clean[key] = _number(clean[key], label, positive=True)
    clean["minimum"] = _number(clean["minimum"], "最小间距", positive=True)
    if clean["minimum"] <= 36:
        raise ValueError("最小间距必须大于大组件的36 μm中心跨度")
    if clean["maximum"] is not None:
        clean["maximum"] = _number(clean["maximum"], "最大间距", positive=True)
        if clean["maximum"] < clean["minimum"]:
            raise ValueError("最大间距不能小于最小间距")
    if type(clean["export_ir"]) is not bool:
        raise ValueError("export_ir 必须是 true 或 false")
    points = clean["spacings"]
    if isinstance(points, str):
        points = None if not points.strip() else points.split(",")
    if points is not None:
        if not isinstance(points, (list, tuple)) or not points:
            raise ValueError("指定间距应为非空数值列表或逗号分隔文本")
        points = [_number(v, "指定间距", positive=True) for v in points]
        if len(set(points)) != len(points):
            raise ValueError("指定间距不能重复")
        if min(points) <= 36:
            raise ValueError("指定间距必须大于36 μm")
        points = sorted(points)
    clean["spacings"] = points
    physical_tsvs = (12000 * clean["large_cols"] +
                     8 * (clean["large_cols"] - 1) * clean["small_rows"] * clean["small_cols"])
    if physical_tsvs > MAX_TSVS:
        raise ValueError(f"扫描布局超过 {MAX_TSVS:,} 根物理TSV上限")
    return clean


def _plan(clean):
    columns = clean["large_cols"]
    source = 3000 * columns
    upper = source + 4 * (columns - 1) * clean["small_rows"] * clean["small_cols"]
    bounds = {}
    for scenario, count in (("large_only", source), ("upper_small", upper)):
        try:
            current_limit = .0112 / (2 * clean["r_ohm"] * (1 / source + 1 / count))
            bound = (current_limit / (clean["current_density"] * 800 / 1e6) - 70) / (columns - 1)
        except (OverflowError, ZeroDivisionError):
            raise ValueError("电阻或电流密度超出可计算数值范围") from None
        if not math.isfinite(bound):
            raise ValueError("电阻或电流密度对应的扫描上界超出数值范围")
        bounds[scenario] = bound
    if clean["spacings"] is not None:
        points = list(clean["spacings"])
    else:
        minimum, step = clean["minimum"], clean["step"]
        maximum = clean["maximum"]
        if maximum is None:
            bound = max(bounds.values())
            if bound < minimum:
                raise ValueError("电流密度对应的必要间距上界小于最小间距；请调整扫描范围")
            intervals_float = (bound - minimum) / step
            if not math.isfinite(intervals_float) or intervals_float > 100000:
                raise ValueError("扫描间距点超过100000，请缩小范围或增大步长")
            intervals = math.ceil(intervals_float - 1e-12)
        else:
            intervals_float = (maximum - minimum) / step
            if not math.isfinite(intervals_float) or intervals_float > 100000:
                raise ValueError("扫描间距点超过100000，请缩小范围或增大步长")
            intervals = round(intervals_float)
            if not math.isclose(intervals_float, intervals, rel_tol=1e-10, abs_tol=1e-8):
                raise ValueError("最大间距减最小间距必须是扫描步长的整数倍")
        if intervals > 100000:
            raise ValueError("扫描间距点超过100000，请缩小范围或增大步长")
        points = [minimum + k * step for k in range(intervals + 1)]
    pitch = clean["pitch"]
    if not math.isclose(800 / pitch, round(800 / pitch), rel_tol=1e-12, abs_tol=1e-8):
        raise ValueError("800 μm区域高度必须能被Mesh pitch整除")
    for distance in points:
        width = (columns - 1) * distance + 70
        if not math.isclose(width / pitch, round(width / pitch), rel_tol=1e-12, abs_tol=1e-8):
            raise ValueError(f"D={distance:g} μm时区域宽度不能被Mesh pitch整除")
    # The common h/2 origin shift cancels the mesh pitch from these physical
    # edge tests.  Do not require the X footprint to fit D-36: the small
    # components are staggered along Y relative to the large ones.
    half_height = (clean["small_rows"] - 1) * 1.5 / 2
    half_width = (clean["small_cols"] - 1) * 1.5 / 2
    if half_height > 50 + 1e-9 or half_width > 35 + min(points) / 2 + 1e-9:
        raise ValueError("小组件的物理TSV范围超出供电区域，请减小行列数或增大间距")
    if columns > 2 and 2 * half_width >= min(points) - 1e-9:
        raise ValueError("相邻小组件列的物理范围重叠，请减小小组件列数或增大间距")
    return dict(point_count=2 * len(points), spacing_count=len(points),
                large_cols=columns, scenarios=list(SCENARIOS), minimum=min(points),
                maximum=max(points), spacings=points, finite_bound_spacing_um=bounds)


def validate_scan(value):
    """Return canonical scan parameters after geometry and range checks."""
    clean = _normalize_scan(value)
    _plan(clean)
    return clean


def plan_scan(value):
    """Plan both topologies without importing numerical libraries or solving."""
    return _plan(_normalize_scan(value))


def _layout_payload(value):
    if not isinstance(value, dict) or not isinstance(value.get("ini_text"), str):
        raise ValueError("layout 需要完整ini_text与components对象")
    config = ConfigParser()
    try:
        config.read_string(value["ini_text"])
        meshes = read_meshes(config)
        components = normalize_layout(value.get("components"), len(meshes))
    except (KeyError, TypeError, AttributeError, ConfigError) as error:
        raise ValueError(f"布局配置不完整：{error}") from None
    return dict(ini_text=value["ini_text"], components=components), config


def _config(value):
    if not isinstance(value, dict) or value.get("schema") != SCHEMA:
        raise ValueError(f"工作台配置schema必须为 {SCHEMA}")
    name = value.get("name")
    if not isinstance(name, str) or not name.strip():
        raise ValueError("工作台配置需要非空name")
    active = value.get("active_tab")
    if active not in ("layout", "scan"):
        raise ValueError("active_tab必须为layout或scan")
    layout, _ = _layout_payload(value.get("layout"))
    return dict(schema=SCHEMA, name=name.strip(), active_tab=active,
                layout=layout, scan=validate_scan(value.get("scan")))


def load_config(path):
    """Load an embedded workbench snapshot; relative project files are unused."""
    return _config(json.loads(Path(path).read_text(encoding="utf-8-sig")))


def _atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n",
                                         prefix=f".{path.name}.", suffix=".tmp",
                                         dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def save_config(path, value):
    clean = _config(value)
    _atomic_json(path, clean)
    return Path(path)


def write_layout(folder, layout_payload):
    """Materialize an embedded layout as a self-contained project pair."""
    payload, config = _layout_payload(layout_payload)
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    ini, layout = folder / "project.ini", folder / "project.layout.json"
    if ini.exists() or layout.exists():
        raise FileExistsError("目标目录已有project.ini或project.layout.json，不会覆盖")
    if not config.has_section("components"):
        config.add_section("components")
    config.set("components", "layout", layout.name)
    _atomic_json(layout, payload["components"])
    with ini.open("x", encoding="utf-8", newline="\n") as stream:
        config.write(stream)
    return ini


def new_output(app_root, kind, name):
    """Reserve a unique result directory, including for concurrent launches."""
    if kind not in ("layout", "scan"):
        raise ValueError("任务类型必须是layout或scan")
    slug = re.sub(r"[^\w\-]+", "_", str(name), flags=re.UNICODE).strip("_.")[:48]
    stem = datetime.now().strftime("%Y%m%d_%H%M%S_%f") + "_" + kind
    if slug:
        stem += "_" + slug
    parent = Path(app_root).resolve() / "results"
    parent.mkdir(parents=True, exist_ok=True)
    for index in range(10000):
        folder = parent / (stem + (f"_{index}" if index else ""))
        try:
            folder.mkdir()
            return folder
        except FileExistsError:
            pass
    raise FileExistsError("无法创建唯一结果目录")


def _fresh_output(out):
    out = Path(out).resolve()
    if out.exists():
        if not out.is_dir() or any(out.iterdir()):
            raise FileExistsError("计算输出必须是新目录或空目录，不会续算或覆盖已有结果")
    else:
        out.mkdir(parents=True, exist_ok=False)
    return out


def _headless():
    os.environ["MPLBACKEND"] = "Agg"
    import matplotlib
    matplotlib.use("Agg", force=True)


def _study_module():
    locations = (ROOT / "studies", ROOT / "code" / "studies",
                 ROOT.parent / "code" / "studies")
    path = next((p / "two_column_spacing.py" for p in locations
                 if (p / "two_column_spacing.py").is_file()), None)
    if path is None:
        raise FileNotFoundError("找不到间距扫描脚本studies/two_column_spacing.py")
    spec = importlib.util.spec_from_file_location("mna_workbench_spacing_study", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_scan(scan_config, out):
    """Run a fresh scan with the same distributed-TSV study as the CLI."""
    clean = validate_scan(scan_config)
    plan = _plan(clean)
    out = _fresh_output(out)
    _headless()
    study = _study_module()
    original_base = study.BASE
    candidates = (ROOT / "data" / "scan_base" / "project.ini",
                  ROOT / "code" / "data" / "scan_base" / "project.ini",
                  ROOT.parent / "code" / "data" / "scan_base" / "project.ini",
                  study.ROOT / "data" / "scan_base" / "project.ini")
    try:
        study.BASE = next((p for p in candidates if p.is_file()), original_base)
        args = ["--out", str(out), "--large-cols", str(clean["large_cols"]),
                "--r-ohm", str(clean["r_ohm"]), "--small-rows", str(clean["small_rows"]),
                "--small-cols", str(clean["small_cols"]), "--current-density", str(clean["current_density"]),
                "--pitch", str(clean["pitch"]), "--step", str(clean["step"]), "--workers",str(clean["workers"]),
                "--min", str(clean["minimum"]), "--spacings", ",".join(format(d, ".17g") for d in plan["spacings"])]
        if clean["export_ir"]:
            args.append("--export")
        study.main(args)
        summary = json.loads((out / "comparison.json").read_text(encoding="utf-8"))
        summary["workbench_plan"] = plan
        return summary
    finally:
        study.BASE = original_base


def run_layout(layout_payload, out):
    """Solve a saved layout in a fresh output folder without GUI figures."""
    payload, _ = _layout_payload(layout_payload)
    out = _fresh_output(out)
    ini = write_layout(out, payload)
    _headless()
    from mna_ir_stack import run
    import matplotlib.pyplot as plt
    try:
        result = run(str(ini), str(out / "ir"), solver="direct")
        return {key: result[key] for key in ("version", "mode", "layer_count",
                "node_count_per_rail", "load_current_A", "global_max_total_loss") if key in result}
    finally:
        plt.close("all")


def _artifacts(out):
    return dict(images=[p.relative_to(out).as_posix() for p in sorted(out.rglob("*.png"))],
                tables=[p.relative_to(out).as_posix() for p in sorted(out.rglob("*.csv"))],
                project_files=[p.relative_to(out).as_posix() for p in sorted(out.rglob("*.ini"))])


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        if getattr(stream, "reconfigure", None):
            stream.reconfigure(encoding="utf-8", errors="backslashreplace")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--job-file", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    config = load_config(args.job_file)
    out = _fresh_output(args.out)
    status = dict(status="RUNNING", mode=config["active_tab"], kind=config["active_tab"], name=config["name"],
                  config_snapshot="workbench_config.json")
    try:
        function = run_scan if config["active_tab"] == "scan" else run_layout
        value = config["scan"] if config["active_tab"] == "scan" else config["layout"]
        status["summary"] = function(value, out)
        status["status"] = "PASS"
    except Exception as error:
        status.update(status="FAIL", error=str(error), error_type=type(error).__name__)
        print(f"任务失败：{error}", file=sys.stderr, flush=True)
    finally:
        save_config(out / "workbench_config.json", config)
        status["artifacts"] = _artifacts(out)
        _atomic_json(out / "job_summary.json", status)
    print(f"任务{status['status']}：{out / 'job_summary.json'}", flush=True)
    return 0 if status["status"] == "PASS" else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError) as error:
        print(f"无法启动任务：{error}", file=sys.stderr)
        raise SystemExit(1)
