#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Standalone TSV template libraries; no placement or third-party dependency."""
import argparse
import copy
import json
from pathlib import Path

from tsv_components import SCHEMA, normalize_layout

TEMPLATE_SCHEMA = 'mna-tsv-templates-1'
UNITS = {'pitch': 'um', 'resistance': 'ohm'}


def checked_types(types):
    try:
        return normalize_layout({'schema': SCHEMA, 'types': types, 'placements': []}, 1)['types']
    except KeyError as exc:
        raise ValueError(f'模板缺少参数：{exc.args[0]}') from None


def load_templates(path):
    payload = json.loads(Path(path).read_text(encoding='utf-8-sig'))
    if not isinstance(payload, dict) or payload.get('schema') not in (TEMPLATE_SCHEMA, SCHEMA):
        raise ValueError('请选择 TSV 模板 JSON 或已有 .layout.json 文件')
    if payload.get('schema') == TEMPLATE_SCHEMA and payload.get('units', UNITS) != UNITS:
        raise ValueError('模板单位必须为 pitch=um、resistance=ohm')
    return checked_types(payload.get('types'))


def save_templates(path, types, names=None):
    types = checked_types(types)
    if names is not None:
        names = list(dict.fromkeys(names))
        if not names or any(name not in types for name in names):
            raise ValueError('请选择至少一个存在的模板')
        types = {name: types[name] for name in names}
    payload = {'schema': TEMPLATE_SCHEMA, 'units': UNITS, 'types': types}
    Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return payload


def merge_templates(layout, incoming, policy='rename'):
    """Validate the entire bundle before merging; leave input objects untouched."""
    if policy not in ('rename', 'keep', 'replace'):
        raise ValueError('同名模板处理方式必须为 rename/keep/replace')
    incoming = checked_types(incoming)
    existing = checked_types(layout['types'])
    result = copy.deepcopy(layout)
    result['types'] = existing
    report = {'added': [], 'replaced': [], 'skipped': [], 'names': {}}
    for name, item in incoming.items():
        target = name
        if name in existing:
            if existing[name] == item or policy == 'keep':
                report['skipped'].append(name)
                report['names'][name] = name
                continue
            if policy == 'rename':
                target = name + '_imported'
                suffix = 2
                while target in result['types'] or target in incoming:
                    target = name + f'_imported_{suffix}'
                    suffix += 1
            else:
                report['replaced'].append(name)
        if target not in result['types']:
            report['added'].append(target)
        result['types'][target] = copy.deepcopy(item)
        report['names'][name] = target
    return result, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--from-layout', required=True, help='Layout or template JSON')
    parser.add_argument('--out', required=True, help='Independent template library JSON')
    parser.add_argument('--name', action='append', help='Export this type; repeat for multiple types')
    args = parser.parse_args()
    result = save_templates(args.out, load_templates(args.from_layout), args.name)
    print(f"Exported {len(result['types'])} template(s): {args.out}")


if __name__ == '__main__':
    main()
