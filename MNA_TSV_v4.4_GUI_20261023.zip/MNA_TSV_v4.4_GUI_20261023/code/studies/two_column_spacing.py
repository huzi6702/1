#!/usr/bin/env python3
"""Reproducible multi-column TSV spacing study; leave the production solver intact.

The sweep uses maximum VDD-drop + VSS-rise over *all* nodes/layers.  The
historical spec_result_A_per_mm2 heuristic is deliberately not the criterion.
Widths and current grow together: W = (columns-1)*D + 70 um, H = 800 um.
Defaults remain two large columns and J = 2 A/mm2.
The original discrete circuit uses a 10 um mesh.  Smaller-pitch studies assume
an equivalent resistive sheet (constant square-cell R); retain their results
separately if the original mesh represents fixed physical metal lines.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import multiprocessing
import os
from configparser import ConfigParser
from pathlib import Path
import platform
import sys
import tempfile
from queue import Empty
from time import perf_counter

os.environ.setdefault("MPLBACKEND", "Agg")
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import matplotlib.pyplot as plt
import numpy as np
import scipy

from mna_ir_stack import read_stack_config, run, solve_stack

BASE = ROOT / "data/scan_base/project.ini"
BIG = "TSV_30x25_P1p5_R5"
SMALL = "TSV_10x3_P1p5_R5"
SCENARIOS = ("large_only", "upper_small")
SPEC_MV = 11.2
J_A_MM2 = 2.0
HEIGHT_UM = 800.0
WIDTH_MARGIN_UM = 70.0


def checked_resistance(r_ohm):
    r_ohm = float(r_ohm)
    if not math.isfinite(r_ohm) or r_ohm <= 0:
        raise ValueError("Single-TSV resistance must be finite and positive")
    return r_ohm


def checked_current_density(current_density):
    current_density = float(current_density)
    if not math.isfinite(current_density) or current_density <= 0:
        raise ValueError("Top current density must be finite and positive (A/mm2)")
    return current_density


def checked_small_shape(rows, cols):
    if int(rows) != rows or int(cols) != cols or rows <= 0 or cols <= 0:
        raise ValueError("Small TSV rows and cols must be positive integers")
    return int(rows), int(cols)


def checked_large_cols(large_cols):
    value = float(large_cols)
    if not math.isfinite(value) or value < 2 or int(value) != value:
        raise ValueError("Large component columns must be an integer >= 2")
    return int(value)


def vertical_bound_spacing(scenario, r_ohm=5, small_rows=10, small_cols=3, current_density=J_A_MM2, large_cols=2):
    """Beyond this D even zero-resistance meshes cannot meet the strict spec.

    Every interface/rail carries total I.  Cauchy-Schwarz gives P >= I^2 R/N
    for its physical TSVs.  P_total/I is load-current-weighted average total
    IR, so max IR >= 2 I (R/Nsource + R/Nupper).  This is a necessary condition,
    not an approximation used in the actual distributed-TSV solves.
    """
    r_ohm = checked_resistance(r_ohm)
    current_density = checked_current_density(current_density)
    large_cols = checked_large_cols(large_cols)
    small_rows, small_cols = checked_small_shape(small_rows, small_cols)
    if scenario not in SCENARIOS:
        raise ValueError("Invalid scenario")
    source = 3000 * large_cols
    upper = source + (4 * (large_cols-1) * small_rows * small_cols if scenario == "upper_small" else 0)
    current_limit = (SPEC_MV / 1000) / (2 * (r_ohm / source + r_ohm / upper))
    return (current_limit / (current_density * HEIGHT_UM / 1e6) - WIDTH_MARGIN_UM)/(large_cols-1)


def project_values(spacing, pitch, scenario, r_ohm=5, small_rows=10, small_cols=3, current_density=J_A_MM2, large_cols=2):
    r_ohm = checked_resistance(r_ohm)
    current_density = checked_current_density(current_density)
    large_cols = checked_large_cols(large_cols)
    small_rows, small_cols = checked_small_shape(small_rows, small_cols)
    tag = f"{r_ohm:g}".replace(".", "p")
    big, small = f"TSV_30x25_P1p5_R{tag}", f"TSV_{small_rows}x{small_cols}_P1p5_R{tag}"
    if scenario not in SCENARIOS or spacing <= 36 or pitch <= 0:
        raise ValueError("Invalid scenario, spacing or mesh pitch")
    width = (large_cols-1)*spacing + WIDTH_MARGIN_UM
    nx, ny = round(width / pitch), round(HEIGHT_UM / pitch)
    if not (math.isclose(nx * pitch, width, abs_tol=1e-8)
            and math.isclose(ny * pitch, HEIGHT_UM, abs_tol=1e-8)):
        raise ValueError("(columns-1)*D+70 and 800 must be integer multiples of mesh pitch")
    config = ConfigParser()
    if not config.read(BASE, encoding="utf-8-sig"):
        raise FileNotFoundError(BASE)
    for section in ("mesh", "mesh.1"):
        for key, value in dict(xgrid=nx, ygrid=ny, xpitch=pitch, ypitch=pitch,
                               rh=0.061, rv=0.061).items():
            config.set(section, key, str(value))
    current = current_density * width * HEIGHT_UM / 1e6
    for section, amps in (("current", 0), ("current.1", -current)):
        for key, value in dict(currentmode=1, i=amps, mul=1).items():
            config.set(section, key, str(value))
    # Align the finite-volume domain at every resolution.  At h=10 the old
    # centers are exactly unchanged.  For other h translate origin with h/2,
    # keeping all TSV-to-edge distances and all physical spans unchanged.
    origin_shift = (pitch - 10) / 2
    xleft = 40 + origin_shift
    types = {big: dict(rows=30, cols=25, pitch_x_um=1.5, pitch_y_um=1.5, r_ohm=r_ohm)}
    if scenario == "upper_small":
        types[small] = dict(rows=small_rows, cols=small_cols, pitch_x_um=1.5, pitch_y_um=1.5, r_ohm=r_ohm)
    placements = []
    for interface, prefix in (("source", "SRC"), ("0_1", "UP")):
        for rail, y0 in (("vdd", 55), ("vss", 155)):
            for row in range(4):
                for col in range(large_cols):
                    x = xleft + col*spacing
                    placements.append(dict(
                        id=f"{prefix}_{rail.upper()}_R{row+1}C{col+1}", type=big,
                        interface=interface, rail=rail, x_um=x,
                        y_um=y0 + 200 * row + origin_shift, rotation_deg=0))
    if scenario == "upper_small":
        for rail, y0 in (("vdd", 155), ("vss", 55)):
            for row in range(4):
                for gap in range(large_cols-1):
                    placements.append(dict(
                        id=f"UP_SMALL_{rail.upper()}_R{row+1}"+(f"C{gap+1}" if large_cols>2 else ""), type=small,
                        interface="0_1", rail=rail, x_um=xleft + (gap+.5)*spacing,
                        y_um=y0 + 200 * row + origin_shift, rotation_deg=0))
    layout = dict(schema="mna-tsv-components-1", boundary_policy="strict",
                  types=types, placements=placements)
    assert len(placements) == 16*large_cols+(8*(large_cols-1) if scenario == "upper_small" else 0)
    return config, layout


def write_case(folder, spacing, pitch, scenario, r_ohm=5, small_rows=10, small_cols=3, current_density=J_A_MM2, large_cols=2):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    config, layout = project_values(spacing, pitch, scenario, r_ohm, small_rows, small_cols, current_density,large_cols)
    config.set("components", "layout", "project.layout.json")
    (folder / "project.layout.json").write_text(
        json.dumps(layout, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    ini = folder / "project.ini"
    with ini.open("w", encoding="utf-8") as stream:
        config.write(stream)
    return ini


def calculate(ini, spacing, pitch, scenario, r_ohm=5, small_rows=10, small_cols=3, current_density=J_A_MM2, large_cols=2, parallel_rails=True):
    r_ohm = checked_resistance(r_ohm)
    current_density = checked_current_density(current_density)
    large_cols = checked_large_cols(large_cols)
    small_rows, small_cols = checked_small_shape(small_rows, small_cols)
    from mna_process_metrics import MemorySampler
    sampler = MemorySampler().start()
    start = perf_counter()
    try:
        p = read_stack_config(ini)
        width = (large_cols-1)*spacing+WIDTH_MARGIN_UM
        expected_current = current_density * width * HEIGHT_UM / 1e6
        assert math.isclose(float(-p["load"].sum()),expected_current,rel_tol=1e-12,abs_tol=1e-12)
        assert p["layers"][0]["load_current_A"] == 0
        # Validate every physical branch and ensure source/upper counts did not
        # change while converting the saved layout to the electrical network.
        has_small = scenario == "upper_small"
        extra = 8 * (large_cols-1) * small_rows * small_cols if has_small else 0
        source_count = 3000*large_cols
        expected, upper_count = 12000*large_cols + extra, source_count + extra // 2
        assert len(p["component_data"]["records"]) == expected
        assert not p["component_data"]["warnings"]
        for rail in ("vdd", "vss"):
            assert sum(len(s["nodes"]) for s in p["sources"][rail]) == source_count
            assert len(p["links"][0][rail]) == upper_count
            assert all(s["branch_r"] == r_ohm for s in p["sources"][rail])
            assert all(r["r"] == r_ohm for r in p["links"][0][rail])
        results, timing = solve_stack(p, parallel=parallel_rails, solver="direct")
        compute_s = perf_counter() - start  # no CSV, plots, or final summary output
    finally:
        memory = sampler.stop()  # frozen before peak summaries or output/plots
    total = results[0][0] + results[1][0]
    current = float(-p["load"].sum())
    row = dict(scenario=scenario, spacing_um=spacing, mesh_pitch_um=pitch,
               width_um=width, height_um=HEIGHT_UM,large_cols=large_cols,
               current_density_A_mm2=current_density, top_current_A=current,
               physical_tsv_count=expected, components=16*large_cols+(8*(large_cols-1) if has_small else 0),
               nodes_per_rail=p["node_count"], compute_excluding_output_s=compute_s,
               numeric_wall_s=timing["numeric_wall_s"])
    for layer in p["layers"]:
        offset, nx, ny = layer["offset"], layer["xgrid"], layer["ygrid"]
        field = total[offset:offset + nx * ny]
        idx = int(field.argmax())
        row.update({f"layer{layer['id']}_max_total_IR_mV": float(field[idx] * 1000),
                    f"layer{layer['id']}_peak_x_um": (idx % nx + 1) * pitch,
                    f"layer{layer['id']}_peak_y_um": (idx // nx + 1) * pitch})
    row["max_total_IR_mV"] = float(total.max() * 1000)
    row["pass_strict_11p2mV"] = row["max_total_IR_mV"] < SPEC_MV
    row["min_effective_voltage_V"] = p["powerv"] - float(total.max())
    checks = [r[3] for r in results]
    row["max_relative_residual"] = max(c["relative_residual"] for c in checks)
    row["max_layer_current_balance_error_A"] = max(
        abs(v) for c in checks for v in c["layer_current_balance_error_A"])
    supplied = p["powerv"] * checks[0]["source_current_magnitude_A"]
    actual = float(np.sum(-p["load"] * (p["powerv"] - total)))
    dissipation = sum(c["resistor_dissipation_W"] for c in checks)
    row["power_balance_error_W"] = supplied - actual - dissipation
    row["vertical_ideal_lower_bound_mV"] = current * 2 * (
        r_ohm / source_count + r_ohm / upper_count) * 1000
    row["tsv_resistance_ohm"] = r_ohm
    row["small_rows"], row["small_cols"] = small_rows, small_cols
    row["worker_pid"] = os.getpid()
    row["worker_started_perf_s"] = start
    row["worker_finished_perf_s"] = start + compute_s
    row["peak_compute_rss_bytes"] = memory.get("peak_sampled_rss_bytes",0)
    row["peak_compute_rss_MiB"] = memory.get("peak_sampled_rss_mib",0)
    row["compute_rss_available"] = int(memory.get("available",False))
    assert row["max_total_IR_mV"] + 1e-8 >= row["vertical_ideal_lower_bound_mV"]
    assert row["max_relative_residual"] < 1e-9
    assert row["max_layer_current_balance_error_A"] < 1e-8
    assert abs(row["power_balance_error_W"]) < 1e-8
    return row


def write_csv(path, rows):
    if not rows:
        return
    path = Path(path)
    fields = list(dict.fromkeys(key for row in rows for key in row))
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", newline="", encoding="utf-8-sig",
                prefix=f".{path.name}.",suffix=".tmp",dir=path.parent,delete=False) as f:
            temporary = Path(f.name)
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(sorted(rows, key=lambda r: (r["scenario"], float(r["spacing_um"]))))
        os.replace(temporary,path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def read_csv(path):
    if not path.exists():
        return []
    with path.open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        for key, value in row.items():
            if key == "scenario":
                continue
            optional = ("worker_pid","worker_started_perf_s","worker_finished_perf_s",
                        "peak_compute_rss_bytes","peak_compute_rss_MiB","compute_rss_available")
            row[key] = (value.lower() == "true" if key == "pass_strict_11p2mV" else
                        0 if key in optional and not value else float(value))
        row.setdefault("tsv_resistance_ohm", 5.0)  # Historical R5 CSV format.
        row.setdefault("small_rows", 10)
        row.setdefault("small_cols", 3)
        row.setdefault("current_density_A_mm2", J_A_MM2)
        row.setdefault("large_cols", 2)
        row.setdefault("worker_pid", 0)
        row.setdefault("worker_started_perf_s", 0)
        row.setdefault("worker_finished_perf_s", 0)
        row.setdefault("peak_compute_rss_bytes", 0)
        row.setdefault("peak_compute_rss_MiB", 0)
        row.setdefault("compute_rss_available", 0)
    return rows


def parallel_rows(tasks, workers):
    """Yield completed points, stopping every child promptly on any failure.

    Explicit processes and queues expose worker liveness without private pool
    internals.  A worker exiting unexpectedly cannot leave an orphaned future
    waiting forever.  Only the caller in the parent writes shared outputs.
    """
    from mna_scan_worker import THREAD_ENVIRONMENT, worker_loop
    context = multiprocessing.get_context("spawn")
    incoming, outgoing = context.Queue(), context.Queue()
    processes = [context.Process(target=worker_loop, args=(incoming, outgoing)) for _ in range(workers)]
    saved_environment = {key: os.environ.get(key) for key in THREAD_ENVIRONMENT}
    success = False
    try:
        # A direct study CLI is re-imported as __mp_main__ before worker_loop
        # starts.  Set limits before spawn so even those early imports obey it.
        for key in THREAD_ENVIRONMENT:
            os.environ[key] = "1"
        try:
            for process in processes:
                process.start()
        finally:
            for key, previous in saved_environment.items():
                if previous is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = previous
        iterator = iter(tasks)
        for _ in processes:
            incoming.put(next(iterator))
        completed = 0
        while completed < len(tasks):
            try:
                item = outgoing.get(timeout=.25)
            except Empty:
                dead = [p for p in processes if p.exitcode is not None]
                if dead:
                    raise RuntimeError("Scan worker exited before finishing its point: " +
                                       ", ".join(f"pid={p.pid}, exit={p.exitcode}" for p in dead))
                continue
            if item["error"]:
                raise RuntimeError(f"Scan worker pid={item['worker_pid']} failed at point {item['index']}: "
                                   + item["error"] + "\n" + item.get("traceback", ""))
            completed += 1
            yield item["row"]
            task = next(iterator, None)
            if task is not None:
                incoming.put(task)
        success = True
    finally:
        if success:
            for process in processes:
                incoming.put(None)
        else:
            for process in processes:
                if process.pid is not None and process.is_alive():
                    process.terminate()
        for process in processes:
            if process.pid is None:
                continue
            process.join(timeout=2)
            if process.is_alive():
                process.kill()
                process.join(timeout=1)
        for queue in (incoming, outgoing):
            queue.cancel_join_thread()
            queue.close()


def summarize(rows, pitch):
    columns = {checked_large_cols(r.get("large_cols",2)) for r in rows}
    if len(columns)>1:
        raise ValueError("Cannot combine scans with different large component columns")
    large_cols = next(iter(columns),2)
    densities = {checked_current_density(r.get("current_density_A_mm2",J_A_MM2)) for r in rows}
    if len(densities) > 1:
        raise ValueError("Cannot combine scans with different top current densities")
    current_density = next(iter(densities),J_A_MM2)
    resistances = {r.get("tsv_resistance_ohm", 5.0) for r in rows}
    if len(resistances) > 1:
        raise ValueError("Cannot combine scans with different single-TSV resistances")
    resistance = next(iter(resistances), 5.0)
    shapes = {checked_small_shape(r.get("small_rows", 10), r.get("small_cols", 3)) for r in rows}
    if len(shapes) > 1:
        raise ValueError("Cannot combine scans with different small TSV dimensions")
    small_rows, small_cols = next(iter(shapes), (10, 3))
    summary = dict(mesh_pitch_um=pitch, spec_mV=SPEC_MV,
                   large_cols=large_cols,upper_small_columns=large_cols-1,
                   current_density_A_mm2=current_density,
                   tsv_resistance_ohm=resistance, small_rows=small_rows, small_cols=small_cols, scenarios={})
    for scenario in SCENARIOS:
        part = sorted((r for r in rows if r["scenario"] == scenario), key=lambda r: r["spacing_um"])
        passed = [r for r in part if r["pass_strict_11p2mV"]]
        if not passed:
            continue
        best = max(passed, key=lambda r: r["spacing_um"])
        next_failed = next((r for r in part if r["spacing_um"] > best["spacing_um"]), None)
        assert next_failed is None or not next_failed["pass_strict_11p2mV"]
        summary["scenarios"][scenario] = dict(
            best=best, next_failed=next_failed,
            vertical_ideal_upper_spacing_um=vertical_bound_spacing(scenario, resistance, small_rows, small_cols,current_density,large_cols),
            bottom_clear_tsv_center_span_um=best["spacing_um"] - 36,
            bottom_contiguous_gap_count=large_cols-1,
            bottom_total_clear_tsv_center_span_um=(large_cols-1)*(best["spacing_um"]-36),
            bottom_clear_span_area_proxy_mm2=(large_cols-1)*(best["spacing_um"] - 36) * HEIGHT_UM / 1e6)
    if len(summary["scenarios"]) == 2:
        a, b = (summary["scenarios"][s] for s in SCENARIOS)
        d0, d1 = a["best"]["spacing_um"], b["best"]["spacing_um"]
        summary["benefit"] = dict(
            spacing_gain_um=d1 - d0, spacing_gain_percent=100 * (d1 / d0 - 1),
            outer_large_center_span_gain_um=(large_cols-1)*(d1-d0),
            bottom_clear_width_gain_percent=100 * ((d1 - 36) / (d0 - 36) - 1),
            bottom_area_gain_proxy_mm2=(large_cols-1)*(d1 - d0) * HEIGHT_UM / 1e6,
            bottom_contiguous_gap_count=large_cols-1,
            upper_each_clear_span_um=(d1 - 36 - (small_cols - 1) * 1.5) / 2)
    return summary


def plot_sweep(out, rows, summary):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5), constrained_layout=True)
    columns = summary.get("large_cols",2)
    for scenario, color, label in zip(SCENARIOS, ("#1e5793", "#d47821"),
            (f"{columns} large columns", f"+ {columns-1} upper columns of {summary['small_rows']} x {summary['small_cols']} TSV components")):
        part = sorted((r for r in rows if r["scenario"] == scenario), key=lambda r: r["spacing_um"])
        x = [r["spacing_um"] for r in part]
        y = [r["max_total_IR_mV"] for r in part]
        for ax in axes:
            ax.plot(x, y, color=color, label=label, lw=1.6)
        item = summary["scenarios"].get(scenario)
        if item:
            best = item["best"]
            axes[1].scatter(best["spacing_um"], best["max_total_IR_mV"], color=color, zorder=5)
    for ax in axes:
        ax.axhline(SPEC_MV, color="#b43340", linestyle="--", lw=1.2, label="11.2 mV limit")
        ax.set(xlabel="Adjacent large-column X center spacing D (um)", ylabel="Maximum total IR (mV)")
        ax.grid(alpha=.2)
    centers = [v["best"]["spacing_um"] for v in summary["scenarios"].values()]
    if centers:
        axes[1].set_xlim(min(centers) - 60, max(centers) + 60)
        axes[1].set_ylim(10.0, 12.4)
    axes[0].legend(fontsize=8)
    axes[0].set_title(f"R/TSV = {summary['tsv_resistance_ohm']:g} ohm; J = {summary.get('current_density_A_mm2',J_A_MM2):g} A/mm2; mesh {summary['mesh_pitch_um']:g} um")
    axes[1].set_title("Threshold detail (strict IR < 11.2 mV)")
    fig.savefig(out / "spacing_comparison.png", dpi=180)
    plt.close(fig)


def export_cases(out, summary):
    pitch = summary["mesh_pitch_um"]
    for scenario, item in summary["scenarios"].items():
        for label, row in (("max_pass", item["best"]), ("next_fail", item["next_failed"])):
            if row is None:
                continue
            folder = out / f"{scenario}_{label}"
            ini = write_case(folder, row["spacing_um"], pitch, scenario, summary["tsv_resistance_ohm"], summary["small_rows"], summary["small_cols"],summary.get("current_density_A_mm2",J_A_MM2),summary.get("large_cols",2))
            from tsv_template_io import save_templates
            layout = json.loads(ini.with_suffix(".layout.json").read_text(encoding="utf-8"))
            save_templates(folder/"tsv_templates.json",layout["types"])
            (folder / "study_case.json").write_text(json.dumps(row, indent=2) + "\n", encoding="utf-8")
            if label == "max_pass":
                print(f"Exporting full results: {folder.name}", flush=True)
                result = run(str(ini), str(folder / "results_ir"), solver="direct")
                # run() saves full-resolution node/TSV CSVs and the normal maps.
                # Verify independent fresh solve agrees with the sweep.
                mv = result["global_max_total_loss"]["value"] * 1000
                assert abs(mv - row["max_total_IR_mV"]) < 1e-7
                plt.close("all")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--pitch", type=float, default=10)
    parser.add_argument("--step", type=float, default=10)
    parser.add_argument("--r-ohm", type=float, default=5, help="Single physical TSV resistance, both types/interfaces/rails")
    parser.add_argument("--current-density",type=float,default=J_A_MM2,
                        help="Top uniform current density in A/mm2 (positive consumption; default 2); bottom stays unloaded")
    parser.add_argument("--small-rows", type=int, default=10)
    parser.add_argument("--small-cols", type=int, default=3)
    parser.add_argument("--large-cols",type=int,default=2,help="Large-component columns at both interfaces; one small column in each gap (default 2)")
    parser.add_argument("--workers",type=int,default=1,
                        help="Independent scan point processes (default 1); bounded by CPU count and pending points")
    parser.add_argument("--min", dest="minimum", type=float, default=40)
    parser.add_argument("--max", dest="maximum", type=float)
    parser.add_argument("--spacings", help="Comma separated D values, instead of a full sweep")
    parser.add_argument("--scenarios", nargs="+", choices=SCENARIOS, default=list(SCENARIOS))
    parser.add_argument("--export", action="store_true", help="Save best/failing projects and full best-case IR")
    args = parser.parse_args(argv)
    args.r_ohm = checked_resistance(args.r_ohm)
    args.current_density = checked_current_density(args.current_density)
    args.small_rows, args.small_cols = checked_small_shape(args.small_rows, args.small_cols)
    args.large_cols = checked_large_cols(args.large_cols)
    if args.workers < 1:
        raise ValueError("Workers must be an integer >= 1")
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    maximum = args.maximum or math.ceil(max(vertical_bound_spacing(s, args.r_ohm, args.small_rows, args.small_cols,args.current_density,args.large_cols) for s in SCENARIOS) / args.step) * args.step
    if not args.spacings and maximum < args.minimum:
        raise ValueError("Spacing upper limit is below --min; check the current density and scan range")
    spacings = ([float(v) for v in args.spacings.split(",")] if args.spacings else
                [args.minimum + k * args.step for k in range(round((maximum - args.minimum) / args.step) + 1)])
    rows = read_csv(out / "sweep_results.csv")
    if any(r["mesh_pitch_um"] != args.pitch or r["tsv_resistance_ohm"] != args.r_ohm or r["small_rows"] != args.small_rows or r["small_cols"] != args.small_cols or r["current_density_A_mm2"] != args.current_density or r["large_cols"] != args.large_cols for r in rows):
        raise ValueError("Output directory contains a different mesh pitch, TSV resistance, small TSV dimensions, current density or large component columns; use a new directory")
    existing = {(r["scenario"], r["spacing_um"]) for r in rows}
    pending = []
    seen = set(existing)
    for d in spacings:
        for scenario in args.scenarios:
            if (scenario, d) in seen:
                continue
            seen.add((scenario, d))
            pending.append(dict(index=len(pending), study_file=str(Path(__file__).resolve()),
                base_ini=str(BASE.resolve()), values=dict(spacing=d, pitch=args.pitch,
                scenario=scenario, r_ohm=args.r_ohm, small_rows=args.small_rows,
                small_cols=args.small_cols,current_density=args.current_density,large_cols=args.large_cols)))
    effective_workers = min(args.workers, len(pending), max(1, os.cpu_count() or 1))
    for task in pending:
        task["folder"] = str(out / "scratch" / task["values"]["scenario"] /
                            f"point_{task['index']:06d}_D_{task['values']['spacing']:.12g}")
    inputs = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
              for path in (BASE, BASE.with_suffix(".layout.json"), ROOT / "mna_ir_stack.py",
                           ROOT / "tsv_components.py", Path(__file__))}
    metadata = dict(python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__,
                    source_sha256=inputs, mesh_pitch_um=args.pitch, intended_spacings_um=spacings,
                    requested_scenarios=args.scenarios,
                    workers_requested=args.workers,workers_effective=effective_workers,
                    upper_current_density_A_mm2=args.current_density, height_um=HEIGHT_UM,
                    large_cols=args.large_cols,region_width_rule=f"W_um = {args.large_cols-1}*D_um + 70", spec="max_all_nodes_all_layers(VDD_drop+VSS_rise) < 11.2 mV",
                    tsv_pitch_um=1.5, tsv_resistance_ohm=args.r_ohm,
                    big_array_rows_cols=[30, 25], small_array_rows_cols=[args.small_rows, args.small_cols],
                    source_big_per_rail=4*args.large_cols, upper_big_per_rail=4*args.large_cols, upper_small_per_rail=4*(args.large_cols-1),
                    rh_ohm=0.061, rv_ohm=0.061, mesh_sampling_domain="h/2..W+h/2, h/2..800+h/2",
                    fine_grid_origin_shift_um=(args.pitch - 10) / 2,
                    finite_bound_spacing_um={s: vertical_bound_spacing(s, args.r_ohm, args.small_rows, args.small_cols,args.current_density,args.large_cols) for s in SCENARIOS},
                    note="Only numerical grid sampling; free-space spans exclude TSV diameters and keep-out zones")
    (out / "study_inputs.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    started = perf_counter()
    new_rows = []
    print(f"Scan workers: requested={args.workers}, effective={effective_workers}; "
          f"pending points={len(pending)}", flush=True)
    def serial_rows():
        for task in pending:
            values = task["values"]
            ini = write_case(Path(task["folder"]), **values)
            yield calculate(ini, **values)
    iterator = parallel_rows(pending,effective_workers) if effective_workers > 1 else serial_rows()
    try:
        for row in iterator:
            rows.append(row)
            new_rows.append(row)
            write_csv(out / "sweep_results.csv", rows)
            print(f"[{len(new_rows)}/{len(pending)}] pid={int(row.get('worker_pid',os.getpid()))} "
                  f"{row['scenario']:12} D={row['spacing_um']:7.2f} um  "
                  f"maxIR={row['max_total_IR_mV']:.9f} mV "
                  f"{'PASS' if row['pass_strict_11p2mV'] else 'FAIL'}  "
                  f"compute={row['compute_excluding_output_s']:.3f}s  "
                  f"peakRSS={row.get('peak_compute_rss_MiB',0):.1f} MiB", flush=True)
    finally:
        iterator.close()
    summary = summarize(rows, args.pitch)
    summary["new_sweep_wall_s_excluding_final_exports"] = perf_counter() - started
    summary["workers_requested"], summary["workers_effective"] = args.workers, effective_workers
    summary["new_points_computed"] = len(new_rows)
    summary["new_points_compute_s_sum"] = sum(r["compute_excluding_output_s"] for r in new_rows)
    summary["all_points_compute_s_sum"] = sum(r["compute_excluding_output_s"] for r in rows)
    summary["max_individual_point_compute_rss_MiB"] = max((r.get("peak_compute_rss_MiB",0) for r in new_rows),default=0)
    summary["per_point_memory_metric"] = ("Peak sampled process RSS during config read, assembly and solve; "
        "excludes final summaries/CSV/plots; individual peaks are not added and are not a concurrent-job peak")
    (out / "comparison.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    plot_sweep(out, rows, summary)
    if args.export:
        export_cases(out, summary)
    print(json.dumps(summary.get("benefit", {}), indent=2), flush=True)


if __name__ == "__main__":
    main()
