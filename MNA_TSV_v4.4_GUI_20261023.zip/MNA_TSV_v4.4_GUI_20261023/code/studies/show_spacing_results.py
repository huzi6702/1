#!/usr/bin/env python3
"""Display existing spacing curves; optionally redraw PNGs from saved CSVs.

This viewer never assembles or solves a circuit. It works offline and does not
require numerical packages when the saved PNG files already exist.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import html
import json
import os
from pathlib import Path
import sys
from urllib.parse import quote
import webbrowser

ROOT = Path(__file__).resolve().parents[1]
PAGE_NAME = "查看间距IR结果.html"
LABELS = {"r5_10x3":"5 Ω · 小组件10×3", "r12_10x3":"12 Ω · 小组件10×3",
          "r12_20x4":"12 Ω · 小组件20×4"}


def has_results(folder):
    return any(folder.rglob("spacing_comparison.png")) or any(folder.rglob("sweep_results.csv"))


def latest_results(parent):
    parent = Path(parent)
    candidates = [p for p in parent.iterdir() if p.is_dir() and has_results(p)] if parent.is_dir() else []
    if not candidates:
        raise FileNotFoundError("没有找到已有扫描结果。请在旧包根目录使用本入口，或加 --results 指定当次输出目录。")
    def updated(folder):
        marker = folder/"verification.json"
        return (marker.stat().st_mtime if marker.exists() else folder.stat().st_mtime,folder.name)
    return max(candidates,key=updated)


def read_json(path):
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        return value if isinstance(value,dict) else {}
    except (ValueError,OSError):
        return {}


def regenerate_plot(csv_path):
    # Import numerical/plotting dependencies only when a saved image is missing.
    # This calls read/summarize/plot only, never calculate or solve_stack.
    os.environ["MPLBACKEND"] = "Agg"
    for location in (ROOT,Path(__file__).resolve().parent):
        if str(location) not in sys.path:
            sys.path.insert(0,str(location))
    import two_column_spacing as study
    import matplotlib.pyplot as plt
    plt.switch_backend("Agg")
    rows = study.read_csv(csv_path)
    if not rows:
        return
    summary = study.summarize(rows,rows[0]["mesh_pitch_um"])
    study.plot_sweep(csv_path.parent,rows,summary)
    return summary


def build_report(folder, regenerate_missing=True):
    folder = Path(folder).resolve()
    if not folder.is_dir():
        raise FileNotFoundError(f"结果目录不存在：{folder}")
    regenerated = {}
    if regenerate_missing:
        for csv_path in sorted(folder.rglob("sweep_results.csv")):
            if not (csv_path.parent/"spacing_comparison.png").exists():
                regenerated[csv_path.parent] = regenerate_plot(csv_path) or {}
    figures = sorted(folder.rglob("spacing_comparison.png"))
    if not figures:
        raise FileNotFoundError("此目录没有间距对比图或可重绘的扫描CSV；无需重跑求解，请检查是否选中了当次输出目录。")
    esc = lambda value:html.escape(str(value),quote=True)
    sections = []
    for figure in figures:
        relative = figure.relative_to(folder)
        summary = read_json(figure.parent/"comparison.json") or regenerated.get(figure.parent,{})
        parts = relative.parts
        label = LABELS.get(parts[0],parts[0]) if len(parts)>1 else folder.name
        pitch = summary.get("mesh_pitch_um")
        grid = f"{pitch:g} μm 网格" if isinstance(pitch,(int,float)) else figure.parent.name
        rows = []
        scenarios = summary.get("scenarios",{})
        for scenario,item in (scenarios.items() if isinstance(scenarios,dict) else ()):
            if not isinstance(item,dict):
                continue
            best,fail = item.get("best",{}),item.get("next_failed") or {}
            title = "仅大组件" if scenario == "large_only" else "上层加入小组件"
            def cell(record,key):
                value = record.get(key)
                return f"{value:.6f}".rstrip("0").rstrip(".") if isinstance(value,(int,float)) else "—"
            rows.append("<tr>"+"".join(f"<td>{esc(v)}</td>" for v in (title,cell(best,"spacing_um"),
                cell(best,"max_total_IR_mV"),cell(fail,"spacing_um")))+"</tr>")
        table = ("<table><thead><tr><th>方案</th><th>最大已测通过间距 / μm</th>"
                 "<th>对应总 IR / mV</th><th>下一失败间距 / μm</th></tr></thead><tbody>"
                 +"".join(rows)+"</tbody></table>") if rows else ""
        link = quote(relative.as_posix(),safe="/")
        sections.append(f'<section><h2>{esc(label)} · {esc(grid)}</h2>{table}'
                        f'<a href="{link}" title="打开原图"><img src="{link}" alt="{esc(label)} 间距与IR对比"></a>'
                        f'<p class="path">图片：{esc(relative.as_posix())}</p></section>')
    verification = read_json(folder/"verification.json")
    profile = verification.get("profile","自定义扫描")
    status = verification.get("status","请结合本次扫描日志核对完成状态")
    body = f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>间距与IR对比结果</title><style>
body{{font-family:system-ui,"Microsoft YaHei",sans-serif;background:#f4f6f8;color:#202d39;margin:0}}
main{{max-width:1240px;margin:auto;padding:28px 20px}}h1{{margin:0 0 12px}}h2{{font-size:20px}}
.note{{line-height:1.7;color:#465766}}section{{background:white;padding:20px;margin-top:24px;border:1px solid #dce3e8;border-radius:10px}}
img{{display:block;width:100%;height:auto;margin-top:18px}}table{{border-collapse:collapse;width:100%;font-size:14px}}
th,td{{text-align:left;padding:10px;border-bottom:1px solid #e4e9ed}}th{{background:#f3f6f8}}
.path{{font-size:13px;overflow-wrap:anywhere;color:#667786}}a{{color:#23588d}}
</style></head><body><main><h1>间距与 IR 对比结果</h1>
<p class="note">运行模式：{esc(profile)} · 对照状态：{esc(status)}<br>
本页读取已有扫描图和数据，没有重新计算电路。点击图片可打开原图。</p>
<p class="note">quick 仅核对已记录边界，scan 扫描原 10 μm 网格；细网格为等效电阻面局部参考。
通过判据为最大总 IR &lt; 11.2 mV。表格列出已计算的离散点，不插值成连续精确极值。</p>
{''.join(sections)}
<p class="path">结果目录：{esc(folder)}<br>页面生成时间：{esc(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}</p>
</main></body></html>'''
    page = folder/PAGE_NAME
    page.write_text(body,encoding="utf-8")
    return page


def open_report(page):
    try:
        return bool(webbrowser.open(Path(page).resolve().as_uri()))
    except Exception:
        return False


def main(argv=None):
    for stream in (sys.stdout,sys.stderr):
        configure = getattr(stream,"reconfigure",None)
        if configure:
            configure(encoding="utf-8",errors="backslashreplace")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results",type=Path,help="Existing run/output directory; default latest under reproduced/")
    parser.add_argument("--no-open",action="store_true",help="Build the result page without opening the browser")
    parser.add_argument("--no-regenerate",action="store_true",help="Do not redraw missing PNGs from saved CSV")
    args = parser.parse_args(argv)
    folder = args.results if args.results is not None else latest_results(ROOT/"reproduced")
    page = build_report(folder,regenerate_missing=not args.no_regenerate)
    print(f"结果页面：{page}")
    if not args.no_open and not open_report(page):
        print("浏览器未能自动打开；请双击上述HTML文件查看。")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError,FileNotFoundError,ImportError) as error:
        print(f"查看结果失败：{error}",file=sys.stderr)
        raise SystemExit(1)
