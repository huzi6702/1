# MNA TSV 项目：本地 Codex 接续说明

## 最新增量：v4.4 GUI（2026-10-23）

最新源码配置包为`dist/MNA_TSV_v4.4_GUI_20261023.zip`，根目录只含`MNA_GUI.py`、`启动.bat`、`code/`、`configs/`。下面早期v4.2交接信息作为历史保留；当前入口为`python MNA_GUI.py`，原布局器/求解器CLI仍兼容。

- 适配视图改用F，删除按钮；工作台快捷键只路由到可见布局页，输入框保留输入。
- `mna_workbench_jobs.py`的scan配置新增workers，新预设2、缺失时1。`studies/two_column_spacing.py --workers N`通过`mna_scan_worker.py`的稳定spawn入口并行独立点，每worker数值库限单线程，保留全部TSV支路。父进程唯一写CSV并按方案/间距排序；异常与停止清理所有本任务worker。
- `mna_process_metrics.py`依赖psutil，提供RSS进程树采样和精确进程树停止；停止先冻结协调进程以封住启动竞态。GUI停止线程异步执行，关闭复用同一线程，收尾保存日志/资源后退出。
- GUI进程树RSS含界面/计算/导出；每点RSS采样与compute时间在组装求解完成后停止，排除最终输出/图。摘要墙钟含逐点CSV与调度，不能和各点累计计算时间混为一谈。共享页可能重复计，采样不是OS精确高水位。
- Qt仅分析，见`docs/QT_ANALYSIS_v4_4.md`，未修改GUI框架。

回归入口仍为`python -m unittest discover -s tests -v`。Windows受限临时目录环境可设置TEMP/TMP到工作区`.local_validation/tmp`。基础依赖见requirements-core.txt；PyAMG可选。完整GUI包的`code/tests/`是可独立执行的专项测试，`code/developer_tests/`保留需要原工程fixture的开发测试。

交接日期：2026-10-19。代码版本：v4.2。本文件保存项目上下文，使本地继续工作不依赖云端聊天记录。

## 1. Windows 本地开始

1. 下载并解压完整 ZIP。打开真正包含 `AGENTS.md`、本文件和 Python 脚本的 `MNA_Dual_IR` 文件夹。
2. 用本地 Codex 打开这个文件夹。可使用 VS Code 的官方 Codex 扩展；或者在支持本地文件夹的 ChatGPT 桌面应用中选择 Codex 并打开本文件夹。
3. 安装 Python（包含 Tcl/Tk）。本项目已有 Windows 启动入口 `start_tsv_editor.bat`。
4. 在项目目录终端运行以下命令。Windows 若没有 `py`，可使用已配置好的 `python` 命令。

```powershell
py -m pip install -r requirements.txt
py -m unittest discover -s tests -v
py tsv_layout_editor.py
```

只使用布局器、几何导出与模板文件工具时不需要 NumPy/SciPy 等第三方包；完整 IR 求解和测试需要 requirements.txt。若使用虚拟环境，应在该环境中安装依赖并以该环境的 `python tsv_layout_editor.py` 启动，保证窗口调用求解器时使用同一个 Python。

布局器与求解器的默认项目是 `pginfo_components.ini`；INI 内的布局路径相对 INI 所在目录解析。移动用户项目时同时带上 INI 和对应 .layout.json。模板导出 JSON 可单独使用。

## 2. 给本地 Codex 的第一条消息

```text
请先阅读根目录 AGENTS.md、CODEX_HANDOFF.md 和 README.md，接手这个现有 MNA/TSV 项目。
当前版本是 v4.2，2026-10-19—20 本机 Python 3.12＋PyAMG 下 89 项自动测试全部通过；环境与实窗验证范围见 docs/VALIDATION_v4_2.md。请使用本机 Python 检查依赖并运行回归。
重点验证 Windows Tkinter 的多选、Ctrl+A、Delete、灰色层不可选、跨层原位复制、整体拖动和模板独立导入导出。
请保留现有电阻模型与我的默认配置，基于现有代码继续修改；先汇报当前状态和验证结果。
```

后续可以直接描述新功能或实际错误，并提供本机报错、项目 INI、布局 JSON、模板文件或相关截图。

## 3. 项目目标和电气模型

这是一个多层静态电阻网络的 IR 分析工具，不是网站或云服务。所有 Mesh 层在每条供电轨内联立求解，VDD/VSS 默认并行。

拓扑：理想 VDD/地 → Bump+TSV 阵列 → layer0 Mesh → 层间 TSV 阵列 → layer1 Mesh，可继续扩层。每层独立加载；上层负载会影响底层供电路径。

用户约定：负电流表示耗电。单根 TSV 电阻由模板指定；组件阵列按中心、行列数与 pitch 展开。每根 TSV 在每个端点层寻找最近的 Mesh 节点。多根落同一节点/同端点对时保留全部支路电导。默认边界策略 nearest；strict 可拒绝超出外圈半 pitch 的位置。

新组件坐标与 pitch 用 μm，电阻用 Ω。节点编号从 1 开始，物理位置为 `(x_node*xpitch,y_node*ypitch)`。Mesh 吸附连接不增加横向电阻；Bump 为理想等电位输入端。`R/N` 只表示端点全等电位时的参考值，实际模型保留分布支路。

纯电阻系统等价消元成 SPD 节点方程；小系统稀疏直接求解，大系统 auto 可选 CG+AMG。默认 25 万节点门槛；完整结果与峰值使用全分辨率，云图显示降采样。

## 4. 用户当前默认配置

| 参数 | layer0 | layer1 |
|---|---:|---:|
| xgrid × ygrid | 127 × 80 | 127 × 80 |
| X/Y pitch | 10 / 10 μm | 10 / 10 μm |
| rh / rv | 61 / 61 mΩ | 61 / 61 mΩ |
| 电流模式 | currentmode=1 | currentmode=1 |
| i / mul | -0.14 A / 7 | -0.5 A / 1 |
| 总耗电电流大小 | 0.98 A | 0.50 A |

共同额定电压 powerv=0.8 V，stack.layers=2，mode=2。顶层之前使用 currentmode=3、power_w=.4 W，以 .8 V 折算 .5 A 固定电流；用户要求电流输入，因此当前改成 -0.5 A。currentmode=3 的功能保留兼容，但默认不启用。currentmode=1 时 imap 不参与计算。

包内 TSV 位置、阵列和电阻仍是示例值，不是用户实际版图：34 个组件、1952 根 TSV。当前默认 Mesh+示例布局每轨 20320 个节点，layer0/layer1 最大总供电损失分别约 107.378152 / 97.382590 mV；功率误差约 9.34e-13 W。请不要把演示布局当作实际设计，也不要在后续修改时无意覆盖用户在本机保存的真实布局或模板。

`pginfo2.ini` 与 `pginfo_stack.ini` 为历史回归配置，不是当前默认。

## 5. 文件地图

| 文件 | 职责 |
|---|---|
| mna_ir_dual.py | 求解器 CLI、旧模式兼容、版本；多层/组件模式分派 |
| mna_ir_stack.py | 多层组装、联立求解、守恒校核、图与 CSV |
| tsv_components.py | TSV 模板/布局规范、物理展开、最近节点映射、配置保存及几何 CSV |
| tsv_layout_editor.py | Tkinter 布局器、选择/拖动、灰层叠加、跨层复制、模板 UI |
| tsv_template_io.py | 独立模板库导入导出、单位校验、重名合并策略；标准库依赖 |
| pginfo_components.ini / .layout.json | 当前默认模型与组件布局 |
| tsv_templates.example.json | 可独立导入的示例模板库 |
| tests/ | 数值、几何、事件及模板回归 |
| benchmark_editor_drag.py | 无显示 Python 处理与 Canvas 指令对照，不测实机 FPS |
| benchmark_performance.py / performance/ | 历史数值求解加速测试 |
| docs/VALIDATION_v4_2.md | 最近验证说明 |
| docs/test_results_v4_2.txt | 云端交接时 77 项测试输出（历史） |
| .local_validation/run_regression_py312.py | 本机 Python 3.12 完整回归入口，初始化 Conda DLL 搜索路径 |
| docs/test_results_windows_20261020.txt | 本机最新 82 项全部通过、无跳过的完整输出 |
| docs/windows_environment_20261020.json | 本机完整回归环境与 Conda DLL 路径 |
| docs/editor_drag_windows_20261020.json | Windows 可见窗口的拖动与原生定时预览记录 |
| docs/editor_drag_benchmark.json | v4.1/v4.2 拖动调用统计 |
| results_components_example/ | 新默认配置+示例布局的完整结果 |

## 6. 已实现的布局器交互

- 当前编辑接口 source 或 0_1 的 VDD/VSS 同时显示，其他接口灰色叠加且不可选。
- Ctrl 点击切换多选，Shift 点击追加，空白处拖框，Ctrl+A 全选当前接口，Delete 删除已选；文本框快捷键正常编辑文字。
- 选中组整体拖动、数值平移、复制/删除、撤销/重做；跨接口原位复制保留位置、类型、轨别与旋转，生成新 ID。
- 模板定义行列、X/Y pitch、单根 R。可单独导出当前或全部模板，导入独立 JSON 或从 .layout.json 提取 types。
- 模板导入重名策略：自动改名（默认）、保留已有、覆盖同名。覆盖影响已有组件；相同参数直接跳过。导入可撤销。

## 7. 最近性能修正：请保留

用户报告全选整体拖动卡顿。v4.1 在每个鼠标事件深拷贝布局并删除/重建全部画布对象。

v4.2 的路径：拖动中模型与展开缓存不变；隐藏选中详细对象，创建轻量轮廓预览；以共享 Canvas tag 移动轮廓组；鼠标事件按 16 ms 间隔合并。释放时按最终鼠标位置只提交一次布局、展开一次完整映射，更新撤销并刷新。

本机修复后，Canvas 的 Configure 在拖动或框选期间不再触发整图重画，避免提示文字高度变化引起布局调整时取消刚开始的手势；释放后的原有路径统一刷新。请保留该保护。

静态显示点阵约限 16000 点、连接线 1200 条、节点框 1200 个和数字 300 个。`physical_tsvs(...,stride=1)` 默认保留全量；更大的 stride 仅限显示。

无显示测试：100 选中+100 灰色组件，各 312 根，总 62400 根。20 次移动中，旧版重建 1248000 圆点、清空画布 20 次；新版重建圆点 0、清空全画布 0，创建一次 100 个轮廓后执行 20 次组移动。这不能直接换算 Windows FPS。

## 8. 验证与下一步

云端交接前 77 项自动测试通过。2026-10-19—20 本机接手修复左栏矮窗口不可达、旧 Bump 导入的目标层数校验与复制目标刷新，以及 Configure 事件中断拖动／框选的问题；新增 2 项 Bump 与 3 项 Configure 回归。Windows 11／Python 3.12.11＋PyAMG 5.3.0 下 82 项全部通过、无跳过；系统 Python 3.14.3 下 78 项通过、4 项因缺少 PyAMG 跳过。

Tk 8.6.15 原生窗口已检查中文显示、Ctrl+A 当前接口全选、整体拖动和撤销、模板真实对话框、最小窗口左栏滚动与画布滚轮缩放。200 组件／62400 根 TSV 场景还通过原生定时事件观察到 100 个绿色轮廓预览、背景保留、释放后完整映射与单次撤销。持续 FPS、人工手感及未单独执行的快捷键操作仍需后续验证。具体证据、边界和复现方法见 [v4.2 验证记录](docs/VALIDATION_v4_2.md)。默认 INI、布局及示例模板的 SHA-256 均未改变。后续建议：

1. 开始新改动前按验证记录选择运行环境；本机完整回归入口为 `.venv312\Scripts\python.exe .local_validation\run_regression_py312.py`。
2. 补充人工长时间拖动体验与实际帧率测量；已有原生定时预览结果不作为持续 FPS。
3. 实窗补查 Ctrl／Shift 多选、Delete、跨层原位复制等尚未单独验证的操作；试导入用户文件时使用副本。
4. 有新改动时按影响范围验证；不要为纯文档修改重复数值仿真。

## 9. 官方入口（交接时查证）

- Codex IDE 扩展：https://learn.chatgpt.com/docs/codex/ide
- 桌面应用与本地文件夹：https://learn.chatgpt.com/docs/quickstart
- AGENTS.md 说明：https://learn.chatgpt.com/docs/agent-configuration/agents-md

云端目录路径不需要在本机复现；所有代码均以当前文件夹/配置所在目录工作。把完整源码文件夹交给本地 Codex 即可接续。

## 10. 最新用户项目：上层反相小组件（2026-10-20）

`projects/tsv30x25_small4x4_top4Amm2_Y100_R5_20261020/project.ini` 是最新保存的用户项目。原 R5/Y100 项目及已发送的旧试用包均保留；根目录默认示例未替换。

- 原80个30×25大组件保持原位，单根5 Ω、pitch 1.5 μm。
- 仅0_1上层接口新增32个4×4小组件，单根5 Ω、pitch 1.5 μm；两轨各4行×4列。
- 小组件X中心190/490/790/1090 μm；VDD Y=155/355/555/755，VSS Y=55/255/455/655，与相邻大组件列的电源地顺序相反。source仍40组件，0_1为72组件，共112组件、60512根TSV。
- Mesh与负载未改：每层127×80，pitch 10 μm，rh=rv=.061 Ω；.8 V；上层4 A/mm²合计4.064 A，底层0 A。
- `mna_ir_stack.plot_vertical_layout` 将路径图source和所有层间接口统一为每组件一个目的层中心点，颜色为R/N等电位参考值，组件汇总不改变分布电气模型。详细映射图、逐根支路、电流CSV保留。
- 顶层最大总IR=13.959192210532066 mV，最低有效电压=.7860408077894679 V；底层最大总IR=4.3490400591703935 mV。底层峰值随电流重新分布而增加，逐层电流与功率守恒通过。
- 全部84项回归通过；原R5项目所有节点的VDD/VSS IR重现；几何无警告；Windows可见布局和交互路径图已核对。
- 纯计算5次中位数.549437 s；峰值物理工作集最高233.965 MiB，均在输出/绘图前冻结。完整数值保存在新项目的compute_benchmark/。
- 具体布局、模板、检查结果见同目录project_settings.json、tsv_templates.json、verification.json；`open_layout.bat`下次加载，`run_ir.bat`重新求解。
- 配套新便携包`dist/MNA_TSV_v4.2_Win64_Trial_Small4x4_20261020.zip`，约86.927 MiB，SHA-256为`cfd9ab1970857ab4de9819c4276614d18631a8e406bba9954ba8bb1f5fc1bf62`。新EXE默认加载小组件项目；移除Python/Conda路径后在中文+空格目录独立配置/模板校核、求解和PNG输出通过，与源码IR误差0 V。新EXE编辑器实际启动并切换上层界面核对过；本轮未重复布局器求解按钮测试（分派逻辑沿用上一包）。包内源码84项中80项通过、4项可选PyAMG跳过。ZIP全部2148文件、CRC、清单哈希及侧车SHA校验通过，旧ZIP原哈希未变。新包尚未通过微信发送。

## 11. 交付方式修正（用户2026-10-20确认）

用户明确要求只打包代码与配置，接收者会人工配好环境；后续默认按源码包交付，不主动生成便携EXE或捆绑Python/第三方运行库。既有便携包是历史产物，不是当前交付入口。

当前源码包为`dist/MNA_TSV_v4.2_Source_Config_Small4x4_20261020.zip`。打包脚本`distribution/build_source_package.py`仅使用标准库，按清单包含五个核心模块、当前112组件配置、独立模板、依赖清单、回归测试及必要说明，不附预计算结果和本机环境。包内`OPEN_CURRENT_PROJECT.bat`与`RUN_CURRENT_IR.bat`显式指定最新项目，避免无参数入口打开原示例。接收者应在自己配置好的Python环境中运行。`requirements-core.txt`为基础求解，`requirements-amg.txt`为可选AMG，`requirements-benchmark.txt`增加性能工具依赖；原始`requirements.txt`保留完整依赖。

源码ZIP包含45个文件、127296字节（约124 KiB），SHA-256为`c3a6537611a183552aa48ec2e5cbaac2e42287a639054ae8b2f7676748d6277e`。包内程序源码与当前配置逐字节一致，标准Python3.14下运行84项（80通过、4项可选PyAMG跳过），无失败或错误；中文与空格目录解压后112组件、60512根TSV、相对配置路径及独立模板校验通过，未捆绑EXE/DLL/运行环境。未重复完整用户案例数值求解，本次仅改变交付内容。

## 12. 选中组件套用当前模板（2026-10-20）

用户要求将“更新选中”改成把选中组件变更为当前选择的模板。按钮现为“套用当前模板”，`Editor.update_selected`只修改当前接口可编辑选中项的type，支持单选与混合多选，保留ID/坐标/接口/电源轨/方向。未选中项、灰色其他接口与模板定义本身均不改；使用已应用的模板参数，手工修改参数需先点“应用模板参数”。

操作顺序：先选组件，再选左上模板，最后套用。一次套用完整校核/重建映射，只记录一次撤销；无变化时不产生新历史，保留重做；无效模板或strict边界失败不提交。原表单提交函数移至`update_properties`，界面另有“更新位置/属性”：单选提交属性，多选按主组件坐标平移。

89项完整回归通过（Python3.12＋PyAMG，无跳过）。当前已保存的112组件项目与模板文件不因本功能自动改变。新交付文件为`dist/MNA_TSV_v4.2_Source_Config_TemplateApply_20261020.zip`，继续仅打包源码与配置。

Windows实窗已完成目标模板选择、按钮套用两个不同轨别的大组件、Ctrl+Z/Ctrl+Y与Ctrl+S：测试副本根数60512↔59044，只有指定两项type变化，坐标/ID/接口/轨别/方向与其余组件不变，原项目文件SHA未变。包内源码Python3.14下89项中85通过、4项可选PyAMG跳过；中文空格目录解压后原112组件配置可加载。新ZIP为47文件、135748字节，SHA-256为`91796cebef668afb8ade7a6210215ac5729702fc5d94612c179e00f6cdae1a3f`。详见docs/VALIDATION_v4_2.md的新章节及对应日志/状态记录。

## 13. 两列大组件间距与上层小组件收益（2026-10-20）

用户确认供电区域随间距扩大：上下接口每轨各4行×2列30×25大组件，单根5Ω、pitch1.5μm；X左列40μm、右列40+Dμm；Y排布不变（VDD55+200k、VSS155+200k）。两层区域宽D+70μm、高800μm，顶层均匀2A/mm²，电流0.0016(D+70)A，底层0自有负载。方案二仅0_1接口中心加一列10×3小组件，每轨4个，Y顺序与大组件相反；source不加。原112组件项目、根目录默认示例及求解器均未改。

- 分析脚本 `studies/two_column_spacing.py`，报告生成 `studies/report_two_column_spacing.py`；所有配置与结果在 `projects/two_columns_2Amm2_spacing_20261020/`。
- 判据为全节点全层最大总IR（VDD压降+VSS抬升）严格小于11.2mV，保留每根TSV分布电阻。没有使用历史spec_result启发式指标。
- 原10μm Mesh直接结果为D460μm（10.962796101mV，D470失败）及D510μm（11.164688420mV，D520失败）；间距增益50μm/10.8696%，底层中心跨度净宽424→474μm/11.7925%，面积代理值+0.0400mm²。这是保持原电阻网格参数时的主要结果，配置及完整IR在mesh10/large_only_max_pass和mesh10/upper_small_max_pass。
- 后续细化网格假设rh/rv描述二维等效电阻面，保持方形单元每平方电阻不变，用于离散敏感性分析；它改变节点/吸附映射，不是固定物理10μm连线网格的同一离散电路，需与原模型结果区分。
- 10μm网格穷举D=40..2060、步长10，两方案406次；包含局部5/2.5/1.25/0.625μm复核共502次。电气耗散下界排除2030/2050.792079μm以外的可行点；细网格仅在临界区局部验证，不声称细网格全域穷举或连续精确极值。
- 0.625μm网格：仅大组件D=463.125μm通过（11.187469463mV）、463.75失败（11.210018590mV）；上层加小组件D=506.25通过（11.190267371mV）、506.875失败（11.214588920mV）。通过点间距增加43.125μm/9.3117%。
- 大组件X中心跨度36μm；底层连续净宽代理值427.125→470.25μm，增加10.0966%；按高800μm面积代理值增加0.0345mm²。上层被分成各233.625μm的两块净宽。均未扣孔径/禁布区/布线；新增8个小组件240根TSV，只增加上层接口。
- 建议加载 `recommended_large_D460/project.ini` 或 `recommended_small_D500/project.ini`：沿用原10μm网格，顶层0.848/0.912A，最大总IR10.962796/10.893967mV；1.25μm复核11.063411/10.975518mV。建议配置底层连续净宽424→464μm，增益9.434%，面积代理值+0.032mm²。各有open_layout.bat、run_ir.bat、独立模板和完整结果。细网格边界配置在critical_cases/。
- 原点按(h-10)/2μm平移保持相同采样域边距，正方形网格rh/rv保持.061Ω。所有点电流密度、物理TSV根数、单根R、几何、残差和守恒均校核；最大相对残差5.189e-11，分层电流误差1.017e-11A，功率误差1.037e-11W。502点读配置/展开/组装/求解及求解器内校核累计338.578s，不含后续汇总、文件输出和绘图；不是冷启动性能基准。
- 本次只新增独立分析与保存配置、更新文档，没有修改桌面事件或数值求解核心，未重复Windows实窗或89项回归。建议配置已由桌面项目加载器与数值加载器重新读取、模板往返校验，并导出完整CSV/云图；临界配置只保存设置与扫描结果，重算需较多内存。

## 14. 单根12Ω的两列分析（2026-10-20）

用户将单根TSV改为12Ω；大小组件、上下接口、VDD/VSS全部修改，其余条件沿用第13节。新项目 `projects/two_columns_2Amm2_spacing_R12_20261020/`，R5项目、根目录示例和求解核心均保留。

- 原10μm Mesh穷举D40..820μm、步长10，共158次。仅大组件D360μm通过（11.009124824mV，顶层.688A），D370失败（11.381506227mV）；上层加小组件D380通过（11.086542880mV，顶层.720A），D390失败（11.427979140mV）。间距+20μm/5.5556%，底层连续净宽324→344μm/+6.1728%，面积代理值+.016mm²；上层两块各170.5μm净宽。未扣孔径与工艺禁布距离。
- 沿用原R5的D460/510μm只改12Ω，则IR15.037722441/16.047040872mV，均超标；`reference_previous_spacing/`保存这两份配置和完整输出。新最大通过配置在 `mesh10/large_only_max_pass/` 和 `mesh10/upper_small_max_pass/`，各有open_layout.bat、run_ir.bat、独立模板与完整results_ir。
- 额外细网格仍是假设二维等效电阻面，不替代固定物理10μm网格：.625μm网格仅大组件363.125通过（11.196827728mV）、363.75失败；加小组件381.25通过（11.197700528mV）、381.875失败。此组间距收益4.9914%，底层中心跨度净宽收益5.5407%；通过/失败配置在critical_cases/。
- 含1.25/.625μm局部复核共186个扫描求解，纯计算累计188.199s（不含后续峰值汇总、输出、可视化）；相对残差最大5.627e-11，分层电流误差8.793e-12A，功率误差9.404e-12W。不是独立冷启动性能或内存基准。
- `studies/two_column_spacing.py`增加`--r-ohm`，默认5Ω，参数传入模板、每根支路校核、耗散上界及导出；R12类型名明确带R12。扫描CSV记录单根电阻，旧格式按5Ω读取，阻止不同电阻/网格混用同一输出目录。新增报告脚本`studies/report_resistance_spacing.py --out <新项目目录>`。
- 数值核心/桌面交互未改，未重复全部89项回归或实窗。已进行脚本编译、R5 D460结果重现、R5/R12配置仅电阻与类型名变化对比、混合电阻续算拒绝且不改旧文件；新案例通过桌面/数值加载、每根12Ω、模板往返、轨别与反相Y排布、完整CSV节点/TSV根数/电流与电压一致性校核。

## 15. 小组件改为20行×4列（2026-10-20）

单根仍12Ω，其他条件沿用第14节；仅0_1上层中间8个小组件从10×3改20×4，每个80根、共640根，全部40组件24640根。source仍每轨6000根，0_1每轨6320根。新项目 `projects/two_columns_2Amm2_spacing_R12_small20x4_20261020/`，旧案例均保留。

- 原10μm Mesh全扫D40..830μm、步长10，两方案160点。无小组件仍D360通过11.009124824mV；新20×4方案D400通过11.057554603mV，D410失败11.352647713mV。通过点总电流.752A、节点7520/轨，底层最大总IR4.575198mV。电气必要间距上界827.727273μm，扫描覆盖到上界之外。
- 相对无小组件：间距+40μm/+11.1111%，底层连续净宽324→364μm/+12.3457%，800μm高度下面积代理值+.032mm²。相对旧12Ω的10×3小组件：最大通过间距380→400μm/+5.2632%，连续净宽344→364μm/+5.8140%，面积代理值+.016mm²。小组件中心X跨度4.5μm，上层每块净宽179.75μm；均未扣孔径和禁布边距。
- 同D400、同总电流下：旧10×3 IR11.798194062mV，新20×4 IR11.057554603mV，下降.740639459mV，超标变通过。新报告以旧R12项目为`--reference-out`，`reference_previous_spacing/`保存旧D360/D380在新尺寸下的配置及完整结果；二者均通过。
- 额外等效电阻面细网格（不替代固定物理10μm网格）：.625μm下仅大组件363.125通过11.196827728mV，363.75失败；20×4小组件402.5通过11.196151160mV、403.125失败11.215411351mV。新旧小组件细网格最大通过间距381.25→402.5μm/+5.5738%。细网格只覆盖局部临界区、不作连续精确极值插值。
- 共182点扫描（含1.25/.625μm），计算累计182.697s，不含后续汇总/输出/可视化；最大相对残差5.814e-11，分层电流误差9.225e-12A，功率误差1.023e-11W。不是冷启动或内存基准。
- 分析脚本新增`--small-rows/--small-cols`，默认10/3兼容旧结果；模板名称、展开根数、耗散上界、净空公式、CSV参数、防混校验、导出均按尺寸生成。报告脚本新增`--reference-out`并按实际尺寸/电阻动态生成设置、对比文本和图，避免10×3/R5硬编码。
- 新案例最大通过配置在`mesh10/upper_small_max_pass/project.ini`，附open_layout.bat、run_ir.bat、独立模板及完整results_ir；边界细网格配置在critical_cases/。未改数值/GUI核心，未重复89项全部回归或实窗。已执行默认10×3数值重现、仅小模板变化对比、混用尺寸拒绝且旧文件不变、脚本编译、新配置/模板往返及完整CSV电压/电流/根数核验，并由独立代理只读复核原网格160点与source/0_1所有支路数量及参数。

## 16. 间距扫描源码复现包（2026-10-22）

用户要求重新打包代码并快速复现间距扫描。新包`dist/MNA_TSV_v4.2_Spacing_Reproduction_20261022.zip`仅含源码、配置、独立模板和小型参考，不捆运行环境/EXE/DLL/大节点CSV。构建脚本为`distribution/build_spacing_reproduction_package.py`，支持prepare/finalize分阶段测试、拒绝覆盖、白名单载荷、去本机绝对路径、清单SHA与ZIP CRC校验；旧交付ZIP均保留。

- 新入口`studies/reproduce_spacing.py`：quick默认最新R12/20×4的4个原网格边界；`--case all`快速核对三组12点；scan/all完整原10μm三组724点；full/all额外包含历史局部细网格，总870点。full/latest为182点。细网格逐scenario原点集保留，不作D笛卡尔积扩展。
- 参考参数`studies/spacing_reproduction.json`及`studies/reference_spacing/`：保留三组精简电气CSV与通过/失败配置，参考CSV有独立SHA和覆盖范围核验。比较三项全层/逐层最大IR，默认绝对容差1e-6mV；通过判定仍严格11.2mV，另外校核支路、节点、R、尺寸、密度、I、残差和守恒。对称并列峰值位置与历史耗时不作为逐值对照项。
- 每次新建`reproduced/<时间戳>`，拒绝复用已有目录，不读取旧计算结果当缓存；实际生成TSV、组装联立求解。输出verification.json逐点对照、环境/哈希、中文复现报告、CSV、配置/模板、曲线以及默认原网格通过点完整IR。quick只验证边界，不能单独证明全域最大值；full细网格也仅为原局部点。命令行输出spec为布局达标、match为数值复现一致。
- 新包根目录提供CHECK_ENVIRONMENT、REPRODUCE_QUICK、REPRODUCE_SCAN、REPRODUCE_FULL四个BAT，优先已激活虚拟环境/Conda，再PATH python/py -3。环境人工配置，requirements-core为基础求解，requirements-amg可选。批量复现强制Agg，原求解器CLI的plt.show保留。`--export-ir none --no-plots`可最快做纯数值核对。
- 含中文/空格目录的源码副本已实测：96项回归中92通过、4项可选AMG跳过；真实BAT quick/all12点、scan/all724点、full/latest182点均PASS且最大IR误差0。最终入口另在MPLBACKEND=TkAgg环境复核quick/all12点，强制无GUI且结果一致。full/all870点的计划及全部11份参考CSV覆盖/SHA已核查，本次未重新运行全部870个细网格组合；具体实测范围记录于包内VALIDATION_REPRODUCTION.json。
- 新增7项验证覆盖计划数、IR不一致、容差不放宽严格规格、参考缺点/篡改拒绝、已有输出和参考树保护、已有目录在导入/求解前拒绝；未改数值求解核心与Tk事件，未重复Windows实窗。
- 旧report脚本在精简包里仅供源码追溯，依赖未附的历史大CSV；统一复现与新报告使用新入口。包内同时保留旧BASE项目INI/layout、三组原扫描CSV及原网格边界配置，避免相对输入缺失。

## 17. 已有间距曲线查看（2026-10-22）

用户运行REPRODUCE_SCAN后未见对比图：旧入口强制Agg保存PNG，没有弹窗。新增 `studies/show_spacing_results.py`，从指定目录或 `reproduced/` 最新输出生成离线HTML并调用默认浏览器。已有PNG仅使用标准库；缺图时只调用read_csv/summarize/plot_sweep，不调用calculate/solve_stack/run，扫描CSV、配置及参考均保留。每组原图在 `<案例>/mesh10/spacing_comparison.png`。已有结果使用新增 `SHOW_RESULTS.bat`，可加 `--results "结果目录"`；不需要重跑扫描。

复现Python入口增加 `--show-results/--no-show-results`，默认继续仅保存；新源码包的三个复现BAT默认带 `--show-results`。浏览器打开失败不改变已保存的数值对照结论，可手工打开HTML。新完整包名包含 `Spacing_Reproduction_Viewer_20261022`；另交付只含查看器、BAT与说明的增量补丁，解压到旧包根目录即可使用。旧ZIP不覆盖。本轮只修改结果查看与打包，不修改求解核心、历史数值或Tk事件；具体验证范围见新版包内VALIDATION_VIEWER.json。

## 18. 自定义顶层电流密度（2026-10-22）

`studies/two_column_spacing.py` 新增 `--current-density`，单位A/mm²、正有限数，默认2。沿用区域随D扩大、底层0负载，顶层总电流为J×(D+70)×800/1e6 A。project_values/write_case/calculate/vertical_bound_spacing在尾部增加可选current_density，保持旧位置参数兼容；密度贯穿必要间距上界、INI、CSV、metadata、summary、图标题与通过/失败配置导出。calculate核对INI实际负载与指定J；旧CSV缺密度按2读取，混密度汇总/续算拒绝且旧数据不写入；必要上界低于起点时明确报错。

用户示例改为 `python studies/two_column_spacing.py --small-rows 24 --small-cols 6 --r-ohm 15 --current-density 3 --out scans/R15_small24x6_J3 --export`。参数是密度而非固定总A。历史三个REPRODUCE案例及旧report脚本仍为2A/mm²；自定义结果使用本入口PNG/comparison.json和通用查看器。新增真实数值线性缩放与配置/数据保护验证，求解核心和Tk事件未改。旧已封存ZIP不覆盖，新功能通过增量源码补丁交付。

## 19. 三列大组件与上层两列小组件（2026-10-22）

新case为 `projects/three_columns_2Amm2_spacing_R12_small20x4_20261022/`。所有单根12Ω、pitch1.5μm；大小分别30×25与20×4。source与0_1接口各轨均4行×3列大组件；增强方案仅0_1每个间隙中点各一小列（每轨4行×2列，Y电源地反相）。相邻大列步长D，左右大列中心跨度2D，两层区域宽2D+70μm、高800μm；仍顶层2A/mm²、底层0自有负载。

- 通用脚本追加large_cols=2尾参和 `--large-cols`，默认两列与旧位置参数兼容；宽度、面积负载、必要电气间距上界、逐根支路数量校核、CSV/防混、图例和配置/独立模板导出全部按列数处理。旧CSV缺列数按2。不得将多段净空加总后称作一块连续空间。
- 独立入口 `studies/three_column_spacing.py` 默认三列/R12/20×4/J2，完整IR导出、自动打开汇总页；无--out时使用按实际参数命名的新时间戳目录，可用--no-export/--no-show-results。case内run_scan.bat为固定mesh10目录扫描/续算；SHOW_RESULTS.bat仅查看。scan_case.json为条件说明，实际CLI输入记录于study_inputs.json。
- 原10μm网格D40..650步长10，两方案124点；必要上界分别621.25与643.782188841μm，扫描覆盖到界外。仅三大列最大扫描通过D320μm、IR11.085397593mV，D330为11.500202165mV失败；增强方案D350通过10.927348053mV，D360为11.335070071mV失败。未作细网格或连续极值声明。
- 相邻列间距增益30μm/9.375%；最外两大列跨度640→700μm。底层两段净宽各284→314μm/+10.563%，合计面积代理0.4544→0.5024mm²，+0.048mm²；上层四块净宽各154.75μm。均按TSV中心跨度，未扣孔径/禁布。
- 无小件48组件36000TSV；增强64组件37280TSV，每轨source9000、upper9640。通过点电流1.136/1.232A，每轨11360/12320节点。四个通过/失败配置与独立模板、open_layout/run_ir入口保存；两通过点附完整节点/TSV CSV、峰值、图。
- 121项回归117通过、4项可选PyAMG跳过；新增11项覆盖真实三列求解、几何/反相/根数/总I/上界、默认两列和旧CSV、防混文件保护、导出配置/模板重载。三组历史12边界真实重算IR误差0；独立审核124点和四配置，直接联立复算D350增强点误差0，两个完整节点CSV峰值与扫描一致。计算累计39.055s（读配置/展开/组装/求解及内校核），不含后续输出/汇总/绘图，非冷启动性能基准。未改求解核心或Tk事件，未重复Windows实窗。
- 新补充包 `dist/MNA_TSV_ThreeColumns_R12_small20x4_Case_20261022.zip` 仅源码/配置/独立模板与小型参考，解压到原源码包根目录。41文件181331字节，SHA256为c5821fc46ff8ca37539b9e7b4e8474f2d95ee0db8b851b1ade7183ea31e7cdce。参考CSV/图置于reference_results，默认mesh10扫描CSV未附，避免解压后误用缓存；中文空格目录覆盖旧源码包实测D350重算及SHOW_RESULTS BAT通过，ZIP CRC/清单SHA通过。旧ZIP均保留。

## 20. v4.3 双Tab工作台与清爽完整包（2026-10-23）

用户要求重新生成完整包，统一原布局/IR与扫描为同一GUI两Tab，配置加载后点Run复现，包根只留Python入口、一个BAT、代码和配置文件夹。新入口MNA_GUI.py、窗口mna_workbench.py、配置/任务后端mna_workbench_jobs.py；扫描和单次IR都用独立子进程、Agg绘图、GUI内直接显示PNG/完整摘要/日志，保留原CLI plt.show和每根TSV分布联立求解。每次Run新建results/时间戳目录，无缓存；保存单JSON内嵌两个Tab的完整状态与布局/模板/INI文本。原INI仍可加载。

- Editor新增可选container/manage_window/bind_shortcuts嵌入参数，默认独立行为保留；嵌入不接管宿主标题、窗口关闭与快捷键。宿主按当前Tab路由快捷键，扫描输入不触发布局删除/全选，布局文本输入的Ctrl+Z/Y保留文本行为。拖动预览及释放提交逻辑未改。
- 工作台界面提供预设/加载/保存/Run/停止；扫描大列数、R、小组件尺寸、顶层J、网格、起止步长与指定点列表均可编辑；终点空按必要电气上界。左栏可滚动；结果可载入已有目录。保存严格校核扫描输入，不会把非法值悄悄回退为旧参数；运行布局时允许未使用的扫描输入暂时非法。子进程冻结配置，结束后恢复按钮、保留最终日志；失败摘要与快照可追溯。
- 配置schema mna-workbench-1，layout含ini_text/components，scan含large_cols/r_ohm/small_rows/small_cols/current_density/pitch/minimum/maximum/step/spacings/export_ir，active_tab决定Run行为。规范化与物理范围/网格整除/有限正数/区间校验均在计算前执行；保存原子写入。输出目录禁止已有文件，旧项目/参考不改。
- 构建脚本distribution/build_gui_package.py提供prepare/finalize与拒覆盖，包名MNA_TSV_v4.3_GUI_20261023。根严格MNA_GUI.py、启动.bat、code、configs四项；7核心模块与2study、scan_base、文档、依赖和测试在code；8个工作台JSON在configs/布局和configs/扫描，原INI+layout兼容工程在configs/项目。无解释器/EXE/DLL/历史大CSV，环境人工配置。
- 146项开发回归142通过、4项可选AMG跳过；新增6个Editor嵌入、13个后台配置/任务、6个GUI构造/重载/Tab隔离/任务快照/非法保存/损坏结果回归。中文空格目录准备包内25项自包含测试全部通过。8个JSON均校验加载/点数；7种独立布局全节点双轨求解通过，8个独立INI相对引用完整。
- Windows可见实窗用原生鼠标一键Run完成三列124点扫描、导出完整IR并在GUI显示320/350与原IR一致；切布局Tab后Ctrl+A选24个source组件，实际整体拖动并一次Ctrl+Z恢复；Run布局的IR=10.927348052548639mV，与扫描一致，在同一Tab显示层IR/云图。最终版另实机Run并点击停止，按钮恢复、部分CSV/日志保留。显示/事件验证与无显示回归分别记录；未重新评价持续帧率与手感。原生配置文件对话框正常打开，配置保存/完整重载由真实Tk回归与文件字节验证覆盖。
- 制品及校验范围见包内code/VALIDATION_GUI.json，清单为code/PACKAGE_MANIFEST.json。旧源码ZIP和试用ZIP均保留。
