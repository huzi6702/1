# MNA TSV 工作台 v4.4：布局、IR 与并行间距扫描

最新完整GUI包为 `dist/MNA_TSV_v4.4_GUI_20261023.zip`。解压后根目录仅有 `MNA_GUI.py`、`启动.bat`、`code/` 和 `configs/`；依赖与开发说明在code内，运行环境由使用者人工配置。首次安装基础依赖：`python -m pip install -r code/requirements-core.txt`，双击启动.bat或运行 `python MNA_GUI.py`。

v4.4 删除“适配视图”按钮，布局画布改用 **F**（大小写均可）；输入框与扫描页不触发布局操作。扫描新增“并发扫描点数”，1为串行，多个点使用Windows兼容的独立进程；新预设为2，旧配置缺少workers时仍按1读取。worker内部数值库限单线程，避免点并行与底层线程叠加。停止与关闭会清理本任务计算进程树，并保存取消记录。

运行日志每秒显示GUI及递归子进程RSS合计、采样峰值和进程数，并写入`resource_usage.json`；这一整机程序口径包含绘图/导出，共享页可能重复计。扫描逐点`peak_compute_rss_MiB`只采样读配置、组装、求解期间的worker进程RSS，不含最终结果输出与绘图；并行点的峰值不能相加作为同时内存峰值。新增基础依赖`psutil>=5.9`，采样可能漏过短暂峰值。`new_sweep_wall_s_excluding_final_exports`是扫描墙钟（含启动、调度、逐点CSV），`new_points_compute_s_sum`是各点纯计算累计时间，两者分开记录。

Qt效率分析见`docs/QT_ANALYSIS_v4_4.md`（包内`code/docs/`）：当前仍使用Tkinter，未迁移GUI库。

同一窗口两个Tab：**组件布局与IR**保留原有布局、整体拖动、模板、跨层复制、撤销/重做和完整IR；**间距扫描**可设置大列数、单根电阻、小组件尺寸、电流密度与扫描范围。加载 `configs/扫描/三列_R12_20x4.json` 后点击 **Run** 即可真实重算三列124点并在GUI中直接显示曲线；另外提供三组两列扫描和四种布局预设。

工作台JSON内嵌布局、模板、Mesh、负载与扫描参数，加载不依赖原始INI路径；保存配置后下次可一键Run。原INI＋layout也可加载。每次任务在独立 `results/<时间戳>` 下输出完整配置快照、数值结果、日志与图片，不复用计算缓存。计算在子进程运行，可停止；主窗口保持响应。已有结果可在结果页“加载结果”，无需重算。核心分布电阻求解仍为v4.2；桌面整合版本为v4.4。

完整包构建：`python distribution/build_gui_package.py --prepare-only`，验证准备目录后用 `--finalize-only` 封包；已存在目录或ZIP拒绝覆盖。开发源目录仍保留下述独立CLI与历史工程，旧ZIP均保留。

本地使用 Codex 接续开发：先阅读根目录 `CODEX_HANDOFF.md`。`AGENTS.md` 保存项目开发约定；完整源码、默认配置、测试和接续说明均在本包内。

本版将垂直连接改为可摆放的物理 TSV 阵列组件。第 0 层输入端是 Bump＋TSV；层间组件也采用 TSV 阵列，可混用不同的行列数、pitch、单根电阻与方向。每层独立加载，VDD/VSS 默认并行、所有层联立求解；云图降采样，求解和 CSV 保留全部节点。

## 间距扫描一键复现（2026-10-22）

源码复现包提供 `CHECK_ENVIRONMENT.bat`、`REPRODUCE_QUICK.bat`、`REPRODUCE_SCAN.bat`、`REPRODUCE_FULL.bat`，环境仍由使用者自行配置：`python -m pip install -r requirements-core.txt`。扫描固定使用direct求解，PyAMG可选。默认快速入口重算最新12Ω/20×4案例的4个原网格通过/失败边界，数秒至数十秒可查看结果；`REPRODUCE_QUICK.bat --case all`核对三组12点。完整原网格三组共724点，包含历史局部细网格共870点；full需要更多时间与内存。quick只核对边界，不单独证明最大值；fine仅为等效电阻面局部参考。

源目录也可执行 `python studies/reproduce_spacing.py --profile quick`；原网格三组全扫用`--profile scan --case all`，包含历史全部点用`--profile full --case all`。每次新建`reproduced/<时间戳>`，实际重新生成TSV、组装并求解；自动对照参考IR（默认容差1e-6mV）和严格11.2mV判定，输出`verification.json`、中文结果说明、扫描CSV、配置/模板及原网格通过点的完整IR。`spec`表示布局达标情况，`match`表示复现对照是否一致。`--export-ir none --no-plots`可只做数值核对；`--out`必须是新目录。来源参数与精简参考在`studies/spacing_reproduction.json`和`studies/reference_spacing/`。打包入口为`python distribution/build_spacing_reproduction_package.py`，只含源码、配置和小型对照数据。

旧复现包只保存PNG，不弹出图窗；每组曲线位于 `reproduced/<时间戳>/<案例名>/mesh10/spacing_comparison.png`。带 `Viewer` 的新版源码包在三个复现BAT完成后自动打开离线汇总页；追加 `--no-show-results` 可关闭。源目录命令加 `--show-results` 开启显示；纯数值核对可加 `--export-ir none --no-plots --no-show-results`。

已计算过的结果无需重跑：双击新版包或补丁中的 `SHOW_RESULTS.bat` 查看最新一次输出，历史或自定义目录用 `SHOW_RESULTS.bat --results "结果目录"`。源码命令为 `python studies/show_spacing_results.py --results "结果目录"`。查看器直接展示已有PNG；缺图时只从扫描CSV重绘，不求解电路，也不修改扫描CSV与配置。生成的 `查看间距IR结果.html` 也可直接双击打开。

自定义尺寸、电阻和顶层电流密度，使用独立扫描入口，例如：

```powershell
python studies/two_column_spacing.py --small-rows 24 --small-cols 6 --r-ohm 15 --current-density 3 --out scans/R15_small24x6_J3 --export
```

`--current-density` 单位为 A/mm²，取正数表示耗电，不填仍为2；底层自有负载保持0。区域为 `(D+70)×800 μm²`，每点总电流为 `J×(D+70)×800/1000000 A`，并非固定总安培数。密度同步写入INI、CSV、输入参数、对比图和导出配置，必要扫描上界也随之更新。更换密度须使用新输出目录，防止混用旧数据。此入口在输出目录保存 `spacing_comparison.png`，可用查看器的 `--results` 打开；旧 `report_*` 脚本仅用于原2A/mm²历史项目，通用扫描使用本入口生成的图与comparison.json。固定参考复现入口 `REPRODUCE_*` 保持原三组2A/mm²条件。

三列新case：`projects/three_columns_2Amm2_spacing_R12_small20x4_20261022/`。上下接口各三列30×25大组件，对比仅上层两个间隙各加入一列20×4小组件，全部单根12Ω，顶层2A/mm²、底层0。D为相邻大列中心步长，区域宽度为 `2D+70 μm`；小组件Y轨别顺序反相。双击目录内 `run_scan.bat` 扫描/续算并显示结果，`SHOW_RESULTS.bat` 只查看已有结果。独立入口 `python studies/three_column_spacing.py` 默认使用新的时间戳目录并导出完整IR、自动打开图；加 `--no-show-results` 可后台运行。通用入口也可用：

```powershell
python studies/two_column_spacing.py --large-cols 3 --r-ohm 12 --small-rows 20 --small-cols 4 --current-density 2 --out scans/three_columns_R12_small20x4_J2 --export
```

`--large-cols` 默认仍2。C列时，区域为 `((C-1)D+70)×800 μm²`，上层每个间隙居中加一小列，共C−1列；不同列数不允许混在同一输出目录。底层有C−1段净空，每段按TSV中心跨度为D−36μm；合计面积代理值为 `(C-1)(D-36)×800/1e6 mm²`，并非一整块连续空间，未扣孔径和工艺禁布边距。

三列case已完成原10μm网格124点：仅三大列D320μm通过（11.085398mV），加两小列D350μm通过（10.927348mV），下一330/360μm均失败。间距+9.375%，底层每段净宽284→314μm，两段合计面积代理+0.048mm²。图、完整IR、四套边界配置及独立模板均在case目录；说明见“扫描结果说明.txt”，源码/配置补充包位于 `dist/MNA_TSV_ThreeColumns_R12_small20x4_Case_20261022.zip`。

## Windows 快速使用

1. 安装带 Tcl/Tk 的 Python 3.10 或更新版本，安装时启用 Tcl/Tk 和 PATH。
2. 解压完整包，双击 **start_tsv_editor.bat**；或运行 `python tsv_layout_editor.py`。布局器只依赖 Python 标准库，不需要先安装 SciPy。
3. 左上选择模板，输入 TSV 行数（Y）、列数（X）、X/Y pitch（μm）、**单根**电阻（Ω），点击“应用模板参数”。修改会更新所有同类组件；需要新类型时输入名称，点击“复制为新类型”。
4. 接口 source 代表 Bump＋TSV→layer0；0_1 代表 layer0→layer1。分别选择 vdd/vss，再输入组件中心坐标并“新增”，或选择“点击放置”后点击画布。
5. 当前接口的 VDD、VSS 同时显示并可编辑。Ctrl 点击切换单个组件选中状态，Shift 点击追加；空白处拖框选择，Ctrl+A 全选当前接口。拖动任一已选组件即可整组移动，Delete 删除整组选中项，均可撤销。批量阵列以输入中心为起点，按组件步长生成；组件步长与内部 TSV pitch 不同。
6. “编辑接口”确定当前可操作的层次：source 为下层 Bump+TSV，0_1 为层间 TSV；其他接口默认灰色叠加，不能选中、移动或删除。“放置电源轨”只决定新组件的轨别。切换“查看端点”检查上下层，节点数字按 VDD/VSS 分别统计。
7. “另存为 INI+布局”生成 `.ini` 与 `.layout.json`，一起复制/移动，放在同一目录。“校核 / 映射导出”保存几何映射 CSV。
8. 选中要复用的组件，在画布上方选择目标接口，点“复制到另一接口”。复制保留物理坐标、组件类型、电源轨及旋转方向，生成新 ID；原层选择保持，副本先以灰色显示。切换编辑接口即可编辑副本。复制使用同一模板；需要独立模板时另建类型。
9. 首次求解先执行 `python -m pip install -r requirements.txt`，然后点击“运行 IR 求解”。输出为配置旁的 `<配置名>_results`；日志为 solver_console.log。`plt.show()` 保留，关闭结果图后任务退出。

原“更新选中”按钮现为“套用当前模板”：先单选或多选当前接口组件，再在左上模板下拉框选目标模板，最后点按钮，所选组件统一换成该模板。每个组件原来的ID、中心坐标、接口、电源轨和旋转方向保留，未选中组件及模板定义本身不变。模板参数如有手工修改，应先点“应用模板参数”，再套用到组件；套用使用已应用的模板定义。整批更换可一次撤销/重做，Ctrl+S后随项目保存；已使用目标模板的整组选中不会产生额外修改或撤销记录。

原表单提交功能保留为“更新位置/属性”：单选时提交表单属性；多选时只按主组件X/Y改变量平移整组，保留各组件的模板、轨别与方向。

```bash
python tsv_layout_editor.py
python tsv_layout_editor.py my_tsv_layout.ini

# 仅检查几何与导出映射；不需要第三方库
python tsv_components.py pginfo_components.ini --out component_mapping

# 新组件模型
python mna_ir_dual.py pginfo_components.ini --out results_components

# 原配置仍可运行
python mna_ir_dual.py pginfo2.ini
python mna_ir_dual.py pginfo_stack.ini --out results_stack

python -m unittest discover -s tests -v
```

求解器与布局器现在都默认打开 pginfo_components.ini。原 pginfo2.ini 与 pginfo_stack.ini 保留为历史回归示例，需显式传入文件名。

## 拖动性能与模板文件

旧版每次鼠标移动会深拷贝布局、删除所有画布元素并重画 Mesh、背景层和 TSV 点阵，组件/TSV 多时会明显卡顿。v4.2 改为：

- 拖动中只显示选中组件的轻量轮廓，背景与未选组件保留；同一预览组通过一次 Canvas move 移动。
- 密集鼠标事件合并，预览刷新间隔为 16 ms；这不是帧率保证。
- 松开鼠标后才提交精确物理坐标，更新全部 TSV 映射并记录一次撤销。鼠标最终位置优先于尚未刷新的预览。
- 点阵全图约限制 16000 个显示点，连接线约 1200 条、节点标记约 1200 个、数字约 300 个；实际 TSV、电阻、求解和 CSV 均为完整数据。缩略数字仍是该节点真实绑定数量。
- 框选时只更新选择矩形，不反复重画全图。

松开后大布局仍需一次完整节点映射及显示刷新；拖动过程中不会求解 IR。已完成 Windows 本机窗口与整体拖动验证，尚未测量持续实机 FPS；验证范围见 [v4.2 验证记录](docs/VALIDATION_v4_2.md)。

模板区增加“导入模板”和“导出模板”菜单：

1. 修改参数后先点击“应用模板参数”。
2. “导出当前模板”只导出下拉框当前类型；“导出全部模板”导出当前项目全部类型。
3. 独立 JSON 只包含名称、TSV 行列数、X/Y pitch（μm）、单根电阻（Ω），不含摆放坐标、Mesh 或负载，可用于其他项目。
4. 导入也可选择旧版 .layout.json，工具只提取其中的 types，不导入摆放位置。
5. 同名默认“自动改名”：参数相同的跳过，不同的生成 _imported 名称。也可选“保留已有同名”或“覆盖同名（影响已有）”；覆盖会更新所有使用该名称的已放置组件。
6. 导入支持撤销，并随项目保存；导出不修改当前项目。随包 tsv_templates.example.json 是可直接导入的示例。

命令行也可从布局文件提取模板：

```bash
python tsv_template_io.py --from-layout pginfo_components.layout.json --out my_templates.json
# 可重复 --name 以只导出指定名称
python tsv_template_io.py --from-layout pginfo_components.layout.json --out one_template.json --name BUMP_8x10
```

## 物理坐标与连接规则

新组件位置和 pitch 都是 μm 物理坐标，不是 Mesh 节点编号。沿用原脚本：节点 (i,j) 位于 (i*xpitch,j*ypitch)，首个节点在 (xpitch,ypitch)。

组件中心为 (xc,yc)，零起始行列为 r,c，旋转前：

```text
x = xc + (c - (cols-1)/2) * pitch_x_um
y = yc + (r - (rows-1)/2) * pitch_y_um
```

偶数阵列中心可位于四根 TSV 之间。rotation_deg 为绕组件中心逆时针旋转，支持 0/90/180/270°。TSV 中心跨度为 (cols-1)*pitch_x 与 (rows-1)*pitch_y，不包含孔直径。

每根 TSV 在每个端点层独立寻找最近节点。X/Y 分别取最近整数，恰在中点时取更大的节点编号。边缘 TSV 同样连接最近的边界节点，并在超出最外圈半 pitch 时给出提示，记录实际吸附距离。布局 JSON 的 boundary_policy 默认 nearest；设为 strict 时，超出 X=[0.5*xpitch,(xgrid+0.5)*xpitch]、Y 同理的范围会报错。该范围是网格采样覆盖域，不自动代表 DIE 物理边界。

| 接口 | 物理 TSV 支路 |
|---|---|
| source | 理想 Bump 等电位端→TSV→layer0 最近节点 |
| 0_1 | layer0 最近节点→同一根 TSV→layer1 最近节点 |
| 1_2 | layer1 最近节点→同一根 TSV→layer2 最近节点 |

**多根 TSV 可以接入同一节点，每根电阻全部保留，不去重。** 同端点对 k 根、单根 R，合计电导 k/R。不同端点则保留分布支路，由网络求电流，不将整个组件强制压成 R/N 接到一个节点。

R_if_all_endpoints_equipotential_ohm=R/N 仅为所有端点等电位的参考值；实际网络始终使用单根电阻。Bump 为理想等电位输入端，没有另加公共 Bump 串联电阻。吸附连接视为理想连接，不附加 TSV 中心到节点的横向电阻。

例如示例的 BUMP_8x10 有 80 根、pitch=2 μm、单根 5 Ω，放在 (60,220) μm，接到 10 μm Mesh 的 **9 个 layer0 节点**。移动组件后节点数可能改变。层间 TSV 在两层分别映射，允许两端节点编号不同。

## 导入原 Bump 位置

先选定并设好模板，点击“导入 Bump 位置”，选择带 [bumploc] 的原配置。工具将 bumplocvdd/bumplocvss 的节点坐标按原配置 Mesh pitch 转成物理中心，替换当前 source 组件；保留层间组件与当前 Mesh/负载。

只迁移中心。旧 rz 是等效路径电阻，**不会当作单根 TSV 电阻导入**；新单根值由你填写。旧 xpn/ypn footprint 不决定新组件覆盖范围。

## 新配置

```ini
[stack]
layers=2
[bump]
powerv=0.8
[components]
layout=pginfo_components.layout.json
```

[mesh]、[mesh.1]、[current]、[current.1] 延用 v3。“网格 / 负载”可编辑 INI。负电流表示耗电；currentmode=3 的 power_w 按额定 powerv 折算固定电流。详细负载模式见 docs/README_v3.md。

存在 [components] 时，JSON 定义全部垂直路径，旧 [bumploc]、bump.rz/xpn/ypn、[tsv.*] 不参与计算。编辑器保存时移除这些失效字段。不含 [components] 的旧文件保持原逻辑。

JSON 片段（完整可运行项目见示例）：

```json
{
  "schema": "mna-tsv-components-1",
  "types": {
    "BUMP_A": {"rows":8,"cols":10,"pitch_x_um":2,"pitch_y_um":2,"r_ohm":5},
    "UPPER_A": {"rows":6,"cols":8,"pitch_x_um":1.5,"pitch_y_um":1.5,"r_ohm":4.9},
    "UPPER_B": {"rows":4,"cols":6,"pitch_x_um":3,"pitch_y_um":3,"r_ohm":5.5}
  },
  "placements": [
    {"id":"B1","type":"BUMP_A","interface":"source","rail":"vdd","x_um":60,"y_um":220,"rotation_deg":0},
    {"id":"U1","type":"UPPER_A","interface":"0_1","rail":"vdd","x_um":80,"y_um":60,"rotation_deg":0},
    {"id":"U2","type":"UPPER_B","interface":"0_1","rail":"vdd","x_um":220,"y_um":60,"rotation_deg":90}
  ]
}
```

r_ohm 始终是一根 TSV 的电阻。不同层、类型、VDD/VSS 均可使用不同模板；单个组件要不同电阻可复制专用模板。ID 全局唯一。真正物理位置重叠或 VDD/VSS 孔坐标重合会提示；多个不同 TSV 映射同一节点完全允许。

## 输出

| 文件 | 内容 |
|---|---|
| component_geometry.csv | 组件行列、pitch、根数、两层端点数、layer0 接入节点数、最大吸附距离 |
| tsv_node_mapping.csv | 每根物理 TSV 的坐标、行列、两端节点；source 下层 -1 表示理想源 |
| physical_tsv_current.csv | source 与层间所有 TSV 的单根电流及组件 ID |
| component_current.csv | 每组件总电流、最大单根电流与节点数 |
| bump_current.csv | 下层 Bump 总电流；R_ohm 为 R/N 参考值，单根值为 R_single_tsv_ohm |
| tsv_current.csv | 层间各 TSV 两端节点、电压差和电流 |
| node_results.csv | 所有层全部节点的 IR、电压、负载 |
| component_mapping.png | 物理 TSV 与上下层吸附节点分布 |
| stack_tsv_layout.png | 所有接口统一每组件一个中心点；颜色为等电位条件下 R/N 参考值 |
| stack_ir_overview.png、stack_ir_surface.png | 各层云图、曲面 |
| summary.json、run_summary.txt | 峰值、守恒、组件统计、耗时 |

source 电流方向为理想源→layer0；层间为 lower→upper。正常 VDD 正、VSS 负。11.2 spec 保留为 layer0 历史指标。

组件模式的路径图在 source 和所有层间接口都按组件汇总显示，并注明组件数与实际 TSV 根数，统一使用 R/N 参考色标。这个汇总仅用于显示；数值求解与 CSV 仍保留每根 TSV 的电阻及独立端点。没有组件布局的历史配置仍按原电阻路径显示。

2026-10-20 此前五列用户布局保存在 `projects/tsv30x25_small4x4_top4Amm2_Y100_R5_20261020/`：上层五列大组件之间新增四列 4×4 小组件，两轨顺序相反，共112组件、60512根TSV。该目录的 `open_layout.bat` 加载项目，`run_ir.bat` 重新求解；大小模板、结果及纯计算性能统计随项目保存。

5Ω两列间距分析保存在 `projects/two_columns_2Amm2_spacing_20261020/`，详见该目录“分析说明.txt”和对比图。大组件30×25、单根5Ω、pitch1.5μm，顶层2A/mm²，底层无自有负载；区域宽度随中心距D按D+70μm扩大，高度800μm。上层中间可加一列10×3小组件（4个VDD、4个VSS，Y顺序反相）。原10μm Mesh的最大扫描通过点为460μm / 510μm，IR为10.962796 / 11.164688mV，下一失败点为470μm / 520μm；间距增益10.87%，底层按TSV中心跨度算的连续净宽增益11.79%。原模型配置和完整结果在mesh10/large_only_max_pass及mesh10/upper_small_max_pass。

额外将Mesh视为二维等效电阻面作细化敏感性分析（方形单元rh/rv保持0.061Ω），0.625μm网格的局部通过点为463.125μm / 506.25μm，相邻失败点463.75μm / 506.875μm；此组间距增益9.31%、连续净宽增益10.10%。固定物理10μm连线网格的结果仍用原模型一组。共502次扫描，净宽均未扣孔径/禁布距离。另保存留有一定余量的 `recommended_large_D460/project.ini` 和 `recommended_small_D500/project.ini`，各有独立布局、模板、启动入口和完整IR结果；`critical_cases/`保留细网格边界配置。求解器与此前项目未修改。

用户最新将大小组件所有单根TSV改为12Ω，其他条件不变。新分析在 `projects/two_columns_2Amm2_spacing_R12_20261020/`：原10μm Mesh最大扫描通过间距为360μm / 380μm，最大总IR为11.009125 / 11.086543mV；下一失败点370μm / 390μm。加小组件的间距收益5.56%，底层连续净宽324→344μm（+6.17%）。0.625μm等效电阻面细化参考通过点363.125μm / 381.25μm。`mesh10/`保存最大通过及下一失败配置，`reference_previous_spacing/`保留原460/510μm只改12Ω的超标案例，均有独立模板和完整IR输出。复现扫描使用 `studies/two_column_spacing.py --r-ohm 12`（须同时指定新输出目录）；默认仍为5Ω，禁止将不同电阻扫描混在同一目录。R5项目保留。

随后小组件改为20行×4列、单根仍12Ω，新案例在 `projects/two_columns_2Amm2_spacing_R12_small20x4_20261020/`。原10μm网格最大通过间距为400μm，IR11.057555mV，410μm失败；无小组件仍360μm。比10×3案例380μm增加20μm/5.26%，底层连续净宽344→364μm/+5.81%；比无小组件间距+11.11%、连续净宽+12.35%。最细等效电阻面参考通过点402.5μm，403.125μm失败。共8个20×4小组件640根，全部40组件24640根；仅上层新增，Y仍反相。`mesh10/upper_small_max_pass/open_layout.bat`加载新配置，完整IR与模板同目录保存。扫描新增`--small-rows 20 --small-cols 4`，默认仍10×3且拒绝混用不同尺寸续算；报告支持`--reference-out`指定旧R12案例对比。旧案例均保留。

此前交付的源码与配置包为 `dist/MNA_TSV_v4.2_Source_Config_TemplateApply_20261020.zip`，环境由使用者自行配置。包内 `OPEN_CURRENT_PROJECT.bat` 打开五列112组件项目，`RUN_CURRENT_IR.bat`重新计算该项目；后续两列间距分析使用各自项目目录的启动入口，旧ZIP未随分析更新。依赖与运行步骤见包内“使用前请读.txt”。源码打包入口为 `python distribution/build_source_package.py`。

默认 pginfo_components.ini 使用用户本次参数：两层均为 127×80、X/Y pitch=10 μm、rh=rv=61 mΩ、powerv=0.8 V。底层为 i=-0.14、mul=7，即 0.98 A。顶层采用下列电流输入，保持旧示例 0.4 W/0.8 V 对应的 0.5 A 大小：

```ini
[current.1]
currentmode=1
i=-0.5
mul=1
```

currentmode=1 表示均匀电流输入，总电流为 i*mul，负号表示耗电。currentmode=3 表示均匀名义功耗输入，power_w=0.4 是本层总功耗 0.4 W，按 powerv 折算固定电流（0.4/0.8=0.5 A），不迭代维持本地恒功率。mode=1 下 power_w 不参与计算；默认文件已移除该项。原 imap 按用户内容保留，currentmode=1 时不参与计算。

TSV 组件布局保持包内示例：16 个 source 组件，每个 80 根；18 个层间组件混用两类型；合计 34 个组件、1952 根 TSV。此布局、电阻和阵列仍是演示参数，可用编辑器重新排布。按新 Mesh 和当前示例布局重新生成了 results_components_example/，每轨 20320 个节点，底层/顶层最大总损失分别为 107.378152 / 97.382590 mV；这些数值只用于验证包内配置可运行。

## 验证与运行条件

云端 v4.2 交接时 77 项自动测试通过；2026-10-19—20 本机接手新增 2 项旧 Bump 导入与 3 项窗口尺寸事件回归，Python 3.12.11＋PyAMG 环境下 82 项全部通过、无跳过。系统 Python 3.14.3 下 78 项通过、4 项因缺少 PyAMG 跳过。完整环境、复现入口及历史数值验证见 [v4.2 验证记录](docs/VALIDATION_v4_2.md)。

上层小组件与统一路径图更新后，新增组件汇总显示和历史路径兼容两项回归，Python 3.12＋PyAMG 下84项全部通过。已在Windows可见窗口核对小组件参数、交错摆放和每组件一个点的交互路径图；详见同一验证记录中的最新章节。

“套用当前模板”更新后，新增单选/混合多选、其他层保护、无效输入、重复操作与严格边界回滚等5项回归，Python3.12＋PyAMG下89项全部通过。

Windows 11／Tk 8.6.15 实窗已检查中文显示、当前接口全选、整体拖动与撤销、模板文件对话框、左栏滚动及画布滚轮缩放；修复了提示文字改变窗口布局时意外中断拖动／框选的问题。62400 根 TSV 场景通过原生定时事件连续观察到绿色轮廓预览、背景保留，以及释放后完整映射和单次撤销。无显示测试、Windows 输入与原生定时事件分别记录；持续拖动帧率和人工手感尚未评价。布局器本地运行，无需网络。

窗口默认 1420×900，最小 1140×760；左栏可用滚动条或在标签、按钮区域滚轮向下访问批量控件，Tab 聚焦也会自动露出控件。Entry／Combobox 保留原有滚轮行为。Ctrl+S 保存，Ctrl+Z/Ctrl+Y 撤销/重做布局；画布滚轮缩放，右键/中键平移。网格/负载文本修改独立于布局撤销栈。最多展开 200 万根 TSV；大图显示可减密度，完整映射与求解不受影响。

