"""One desktop window for TSV layout editing, IR and spacing scans."""
from __future__ import annotations

import argparse
import copy
from datetime import datetime
import io
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
from time import monotonic
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import mna_workbench_jobs as jobs
import mna_process_metrics as metrics
from tsv_layout_editor import Editor, read_project

COLORS = dict(background="#eef3f7",ink="#17324d",muted="#617588",accent="#17766e",border="#c6d3de",paper="#ffffff")
DEFAULT_SCAN = dict(large_cols=3,r_ohm=12,small_rows=20,small_cols=4,current_density=2,
                    pitch=10,minimum=40,maximum=None,step=10,spacings=None,export_ir=True,workers=2)


class ResultPane(ttk.Frame):
    def __init__(self,parent):
        super().__init__(parent,padding=8)
        self.output = None
        self.images = []
        self.image_ref = None
        self.status = tk.StringVar(self,value="运行后在这里查看结果。")
        ttk.Label(self,textvariable=self.status,wraplength=950,foreground=COLORS["ink"]).pack(fill="x",pady=(0,8))
        self.table = ttk.Treeview(self,columns=("name","spacing","ir","next"),show="headings",height=3)
        for key,title,width in (("name","方案 / 层",190),("spacing","通过间距 D / μm",140),
                                ("ir","最大总 IR / mV",150),("next","下一失败 D / μm",140)):
            self.table.heading(key,text=title)
            self.table.column(key,width=width,anchor="w",stretch=True)
        self.table.pack(fill="x",pady=(0,7))
        tools = ttk.Frame(self)
        tools.pack(fill="x",pady=(0,5))
        ttk.Label(tools,text="结果图片").pack(side="left")
        self.image_choice = ttk.Combobox(tools,state="readonly",width=48)
        self.image_choice.pack(side="left",fill="x",expand=True,padx=7)
        self.image_choice.bind("<<ComboboxSelected>>",lambda event:self.show_image())
        ttk.Button(tools,text="打开原图",command=self.open_image).pack(side="left",padx=2)
        ttk.Button(tools,text="加载结果",command=self.load_saved).pack(side="left",padx=2)
        ttk.Button(tools,text="结果目录",command=self.open_folder).pack(side="left",padx=2)
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both",expand=True)
        picture = ttk.Frame(self.notebook)
        self.notebook.add(picture,text="结果图")
        self.canvas = tk.Canvas(picture,background="white",highlightthickness=1,highlightbackground=COLORS["border"])
        self.canvas.pack(fill="both",expand=True)
        self.canvas.bind("<Configure>",self.resized)
        self.resize_after = None
        logs = ttk.Frame(self.notebook)
        self.notebook.add(logs,text="运行日志")
        self.log = tk.Text(logs,wrap="word",font=("Consolas",10),state="disabled",background="#f8fafc",relief="flat")
        self.log.pack(side="left",fill="both",expand=True)
        bar = ttk.Scrollbar(logs,command=self.log.yview)
        bar.pack(side="right",fill="y")
        self.log.configure(yscrollcommand=bar.set)

    def set_log(self,text):
        self.log.configure(state="normal")
        self.log.delete("1.0","end")
        self.log.insert("1.0",text[-100000:])
        self.log.see("end")
        self.log.configure(state="disabled")

    def append_log(self,text):
        if not text:
            return
        at_bottom=self.log.yview()[1]>.98
        self.log.configure(state="normal")
        self.log.insert("end",text)
        if int(self.log.index("end-1c").split(".")[0])>2500:
            self.log.delete("1.0","500.0")
        if at_bottom:
            self.log.see("end")
        self.log.configure(state="disabled")

    def resized(self,event=None):
        if self.resize_after:
            self.after_cancel(self.resize_after)
        self.resize_after = self.after(100,self.show_image)

    def show_image(self):
        self.resize_after = None
        if not self.images:
            return
        index = max(0,self.image_choice.current())
        path = self.images[index]
        width,height = max(200,self.canvas.winfo_width()-14),max(150,self.canvas.winfo_height()-14)
        try:
            try:
                from PIL import Image, ImageTk
                with Image.open(path) as original:
                    picture = original.copy()
                picture.thumbnail((width,height),Image.Resampling.LANCZOS)
                self.image_ref = ImageTk.PhotoImage(picture,master=self.canvas)
            except ImportError:
                picture = tk.PhotoImage(file=str(path),master=self.canvas)
                factor = max(1,math.ceil(max(picture.width()/width,picture.height()/height)))
                self.image_ref = picture.subsample(factor,factor)
            self.canvas.delete("all")
            self.canvas.create_image(self.canvas.winfo_width()/2,self.canvas.winfo_height()/2,image=self.image_ref,anchor="center")
        except (OSError,tk.TclError,ValueError) as error:
            self.canvas.delete("all")
            self.canvas.create_text(15,15,anchor="nw",text=f"图片暂时无法显示：{error}",width=width)

    def open_image(self):
        if self.images:
            open_local(self.images[max(0,self.image_choice.current())])

    def open_folder(self):
        if self.output:
            open_local(self.output)

    def load_saved(self):
        folder=filedialog.askdirectory(parent=self.winfo_toplevel(),title="选择已有结果目录")
        if not folder:
            return
        folder=Path(folder)
        try:
            if (folder/"job_summary.json").is_file():
                result=json.loads((folder/"job_summary.json").read_text(encoding="utf-8"))
                if result.get("status")!="PASS":
                    raise ValueError("该目录的任务未完成，请查看console.log。")
                self.show_result(folder,result["mode"],result["summary"])
            elif (folder/"comparison.json").is_file():
                self.show_result(folder,"scan",json.loads((folder/"comparison.json").read_text(encoding="utf-8")))
            elif (folder/"summary.json").is_file():
                self.show_result(folder,"layout",json.loads((folder/"summary.json").read_text(encoding="utf-8")))
            else:
                raise ValueError("未找到结果摘要；请选择包含job_summary.json、comparison.json或summary.json的目录。")
            logfile=next((folder/name for name in ("console.log","solver_console.log") if (folder/name).is_file()),None)
            if logfile:
                self.set_log(logfile.read_text(encoding="utf-8",errors="replace"))
        except (OSError,ValueError,KeyError,TypeError,AttributeError) as error:
            messagebox.showerror("无法加载结果",str(error),parent=self.winfo_toplevel())

    def show_result(self,output,mode,summary):
        if not isinstance(summary,dict):
            raise ValueError("结果摘要格式不正确。")
        if mode=="scan":
            scenarios=summary.get("scenarios")
            if not isinstance(scenarios,dict):
                raise ValueError("扫描摘要缺少方案数据。")
            for item in scenarios.values():
                if not isinstance(item,dict) or not isinstance(item.get("best"),dict):
                    raise ValueError("扫描摘要中的通过点不完整。")
                for record in (item["best"],item.get("next_failed")):
                    if record is not None:
                        if not isinstance(record,dict):
                            raise ValueError("扫描边界记录格式不正确。")
                        for key in ("spacing_um","max_total_IR_mV"):
                            value=record.get(key)
                            if not isinstance(value,(int,float)) or not math.isfinite(value):
                                raise ValueError("扫描边界缺少有效的间距或IR数值。")
        elif mode=="layout":
            full=Path(output)/"ir/summary.json"
            if full.is_file():
                summary=json.loads(full.read_text(encoding="utf-8"))
            if not isinstance(summary,dict) or not isinstance(summary.get("layers"),list):
                raise ValueError("IR摘要缺少层结果。")
        else:
            raise ValueError("无法识别结果类型。")
        self.output = Path(output)
        self.table.delete(*self.table.get_children())
        if mode == "scan":
            self.table.heading("spacing",text="通过间距 D / μm")
            self.table.heading("next",text="下一失败 D / μm")
            for key,item in summary.get("scenarios",{}).items():
                best,failed = item["best"],item.get("next_failed")
                self.table.insert("","end",values=("仅大组件" if key=="large_only" else "上层加入小组件",
                    f"{best['spacing_um']:g}",f"{best['max_total_IR_mV']:.6f}",f"{failed['spacing_um']:g}" if failed else "未覆盖"))
            gain = summary.get("benefit",{})
            if gain:
                text = (f"相邻大列间距增加 {gain['spacing_gain_um']:g} μm（{gain['spacing_gain_percent']:.3f}%）；"
                        f"每段下层净宽增加 {gain['bottom_clear_width_gain_percent']:.3f}%，合计面积代理增加 {gain['bottom_area_gain_proxy_mm2']:.6f} mm²。")
            else:
                text = "扫描完成。表格仅显示已有通过点；本次范围可能未覆盖通过或失败边界。"
            self.status.set(text+" 按已测离散点判断，未扣孔径与禁布边距。")
        else:
            self.table.heading("spacing",text="本层负载 / A")
            self.table.heading("next",text="最低有效电压 / V")
            for layer in summary.get("layers",[]):
                self.table.insert("","end",values=(f"Layer {layer['id']}",f"{layer['load_current_A']:.6f}",
                    f"{layer['max_total_loss']['value']*1000:.6f}",f"{layer['min_effective_voltage']['value']:.9f}"))
            loss = summary.get("global_max_total_loss",{}).get("value")
            self.status.set(f"单次 IR 完成；全层最大总 IR = {loss*1000:.6f} mV。" if loss is not None else "单次 IR 完成。")
        priority={"spacing_comparison.png":0,"stack_ir_overview.png":1,"stack_ir_surface.png":2,"stack_tsv_layout.png":3}
        self.images = sorted(self.output.rglob("*.png"),key=lambda p:(priority.get(p.name,4),p.as_posix()))
        self.image_choice.configure(values=[p.relative_to(self.output).as_posix() for p in self.images])
        if self.images:
            self.image_choice.current(0)
            self.show_image()
        self.notebook.select(0)


def open_local(path):
    try:
        if os.name == "nt":
            os.startfile(str(Path(path).resolve()))
        else:
            import webbrowser
            webbrowser.open(Path(path).resolve().as_uri())
    except OSError as error:
        messagebox.showerror("无法打开",str(error))


class EmbeddedEditor(Editor):
    def __init__(self,app,path,container):
        self.app = app
        super().__init__(app.root,path,container=container,manage_window=False,bind_shortcuts=False)

    def run(self):
        return self.app.run_job("layout")

    def open(self):
        return self.app.load_dialog()

    def save(self):
        return self.app.save_dialog()


class Workbench:
    def __init__(self,root,app_root,config_path=None):
        self.root,self.home = root,Path(app_root).resolve()
        self.state_dir = self.home/"code/.state"
        self.state_dir.mkdir(parents=True,exist_ok=True)
        self.current_path = None
        self.dirty,self.loading = False,True
        self.process,self.log_handle,self.output = None,None,None
        self.cancelled = False
        self.last_log = ""
        self.config_data = None
        self.need_fit = True
        self.configure_style()
        root.title("MNA TSV 工作台 v4.4")
        root.geometry(f"{min(1500,root.winfo_screenwidth()-70)}x{min(990,root.winfo_screenheight()-80)}")
        root.minsize(1140,700)
        self.build_header()
        self.tabs = ttk.Notebook(root)
        self.tabs.pack(fill="both",expand=True,padx=10,pady=(0,7))
        self.layout_tab = ttk.Frame(self.tabs)
        self.scan_tab = ttk.Frame(self.tabs)
        self.tabs.add(self.layout_tab,text="  组件布局与 IR  ")
        self.tabs.add(self.scan_tab,text="  间距扫描  ")
        self.layout_tabs = ttk.Notebook(self.layout_tab)
        self.layout_tabs.pack(fill="both",expand=True)
        self.editor_host = ttk.Frame(self.layout_tabs)
        self.layout_results = ResultPane(self.layout_tabs)
        self.layout_tabs.add(self.editor_host,text="布局 / 模板")
        self.layout_tabs.add(self.layout_results,text="IR 结果")
        self.build_scan()
        self.scan_results = ResultPane(self.scan_right)
        self.scan_results.pack(fill="both",expand=True)
        self.status = tk.StringVar(root,value="加载配置后，点击 Run 运行当前 Tab。")
        footer = ttk.Frame(root,padding=(14,5))
        footer.pack(fill="x")
        ttk.Label(footer,textvariable=self.status,width=55,foreground=COLORS["muted"]).pack(side="left",fill="x",expand=True)
        self.progress = ttk.Progressbar(footer,mode="indeterminate",length=190)
        self.progress.pack(side="right")
        self.memory_status=tk.StringVar(root,value="内存：未运行")
        ttk.Label(footer,textvariable=self.memory_status,foreground=COLORS["muted"],font=("Consolas",9)).pack(side="right",padx=8)
        self.presets = self.discover_presets()
        self.preset_combo.configure(values=list(self.presets))
        initial = Path(config_path) if config_path else self.default_preset()
        data = jobs.load_config(initial) if initial else self.fallback_config()
        path = jobs.write_layout(self.state_dir/"editor"/datetime.now().strftime("%Y%m%d_%H%M%S_%f"),data["layout"])
        self.editor = EmbeddedEditor(self,path,self.editor_host)
        self.apply_config(data,initial,discard=False)
        self.tabs.bind("<<NotebookTabChanged>>",self.tab_changed)
        for key in ("<Control-s>","<Control-S>"):
            root.bind(key,lambda event:self.save_dialog())
        root.bind("<Control-z>",lambda event:self.editor_shortcut("undo",event))
        root.bind("<Control-y>",lambda event:self.editor_shortcut("redo",event))
        root.bind("<Control-a>",lambda event:self.editor_shortcut("select_all_key",event))
        root.bind("<Control-A>",lambda event:self.editor_shortcut("select_all_key",event))
        root.bind("<Delete>",lambda event:self.editor_shortcut("delete_key",event))
        root.bind("<KeyPress-f>",lambda event:self.editor_shortcut("fit_key",event))
        root.bind("<KeyPress-F>",lambda event:self.editor_shortcut("fit_key",event))
        root.protocol("WM_DELETE_WINDOW",self.close)
        self.loading=False
        self.update_plan()

    def configure_style(self):
        style = ttk.Style(self.root)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure(".",font=("Microsoft YaHei UI",10))
        style.configure("TFrame",background=COLORS["background"])
        style.configure("TLabel",background=COLORS["background"],foreground=COLORS["ink"])
        style.configure("Title.TLabel",font=("Segoe UI Semibold",18),foreground=COLORS["ink"])
        style.configure("TButton",padding=(8,5))
        style.configure("Run.TButton",background=COLORS["accent"],foreground="white",font=("Segoe UI Semibold",11),padding=(22,7))
        style.map("Run.TButton",background=[("disabled","#aabdc5"),("active","#12645d")])
        style.configure("TNotebook.Tab",padding=(16,8))
        style.configure("TLabelframe",background=COLORS["background"])
        style.configure("TLabelframe.Label",background=COLORS["background"],foreground=COLORS["ink"])
        self.root.configure(background=COLORS["background"])

    def build_header(self):
        header = ttk.Frame(self.root,padding=(14,10,14,5))
        header.pack(fill="x")
        ttk.Label(header,text="MNA / TSV",style="Title.TLabel").pack(side="left")
        ttk.Label(header,text="布局 · 供电 · 间距",foreground=COLORS["muted"]).pack(side="left",padx=14)
        ttk.Button(header,text="使用说明",command=self.help).pack(side="right")
        self.stop_button = ttk.Button(header,text="停止",command=self.stop,state="disabled")
        self.stop_button.pack(side="right",padx=6)
        self.run_button = ttk.Button(header,text="Run",style="Run.TButton",command=lambda:self.run_job())
        self.run_button.pack(side="right",padx=(14,4))
        files = ttk.Frame(self.root,padding=(14,4,14,9))
        files.pack(fill="x")
        self.load_button = ttk.Button(files,text="加载配置",command=self.load_dialog)
        self.load_button.pack(side="left")
        ttk.Button(files,text="保存配置",command=self.save_dialog).pack(side="left",padx=5)
        ttk.Label(files,text="预设").pack(side="left",padx=(12,5))
        self.preset_combo = ttk.Combobox(files,state="readonly",width=35)
        self.preset_combo.pack(side="left")
        self.preset_combo.bind("<<ComboboxSelected>>",self.load_preset)
        self.config_label = tk.StringVar(self.root,value="")
        ttk.Label(files,textvariable=self.config_label,foreground=COLORS["muted"],anchor="e").pack(side="right",fill="x",expand=True,padx=8)

    def build_scan(self):
        body = ttk.Panedwindow(self.scan_tab,orient="horizontal")
        body.pack(fill="both",expand=True,padx=6,pady=6)
        sidebar = ttk.Frame(body)
        scroll = tk.Canvas(sidebar,width=365,highlightthickness=0,background=COLORS["background"])
        scroll.pack(side="left",fill="both",expand=True)
        scrollbar = ttk.Scrollbar(sidebar,orient="vertical",command=scroll.yview)
        scrollbar.pack(side="right",fill="y")
        scroll.configure(yscrollcommand=scrollbar.set,yscrollincrement=25)
        left = ttk.Frame(scroll,padding=(8,8,15,8))
        window = scroll.create_window((0,0),window=left,anchor="nw")
        left.bind("<Configure>",lambda event:scroll.configure(scrollregion=scroll.bbox("all")))
        scroll.bind("<Configure>",lambda event:scroll.itemconfigure(window,width=event.width))
        self.scan_right = ttk.Frame(body)
        body.add(sidebar,weight=0)
        body.add(self.scan_right,weight=1)
        ttk.Label(left,text="供电与组件",font=("Microsoft YaHei UI",13,"bold")).pack(anchor="w",pady=(0,8))
        self.scan_vars = {}
        fields = (("large_cols","大组件列数","3"),("r_ohm","单根 TSV 电阻 / Ω","12"),
                  ("small_rows","小组件 TSV 行数（Y）","20"),("small_cols","小组件 TSV 列数（X）","4"),
                  ("current_density","顶层电流密度 / A/mm²","2"),("pitch","Mesh pitch / μm","10"),
                  ("workers","并发扫描点数（1 = 串行）","2"))
        box = ttk.LabelFrame(left,text="对比方案",padding=9)
        box.pack(fill="x")
        for row,(key,label,value) in enumerate(fields):
            self.scan_field(box,row,key,label,value)
        ttk.Label(box,text="大组件固定 30×25，TSV pitch 1.5 μm。\n每个大列间隙的上层加一列小组件，轨别沿 Y 反相。\n底层负载为 0；两层供电区域随间距同步扩大。\n并发点数越多，合计内存通常越高。",wraplength=325,foreground=COLORS["muted"]).grid(row=len(fields),column=0,columnspan=2,sticky="w",pady=(8,0))
        box = ttk.LabelFrame(left,text="间距范围",padding=9)
        box.pack(fill="x",pady=10)
        for row,(key,label,value) in enumerate((("minimum","起点 D / μm","40"),("maximum","终点 D / μm（空 = 自动）",""),
                                                ("step","扫描步长 / μm","10"),("spacings","指定 D 列表（可选）",""))):
            self.scan_field(box,row,key,label,value)
        ttk.Label(box,text="D 为相邻大列中心步长。指定列表用逗号分隔，\n填写后覆盖起点、终点与步长。",foreground=COLORS["muted"]).grid(row=4,column=0,columnspan=2,sticky="w",pady=(7,0))
        self.export_ir = tk.BooleanVar(self.root,value=True)
        ttk.Checkbutton(left,text="同时导出通过点完整 IR 与配置",variable=self.export_ir,command=self.changed).pack(anchor="w")
        self.plan_label = tk.StringVar(self.root,value="")
        ttk.Label(left,textvariable=self.plan_label,wraplength=325,foreground=COLORS["accent"]).pack(fill="x",pady=12)
        self.diagram = tk.Canvas(left,width=350,height=115,background="white",highlightthickness=1,highlightbackground=COLORS["border"])
        self.diagram.pack(fill="x")
        def wheel(event):
            scroll.yview_scroll(-1 if getattr(event,"num",None)==4 or getattr(event,"delta",0)>0 else 1,"units")
            return "break"
        def bind_scroll(widget):
            if widget.winfo_class() not in ("Entry","TEntry","TCombobox","Text"):
                for event in ("<MouseWheel>","<Button-4>","<Button-5>"):
                    widget.bind(event,wheel,add="+")
            for child in widget.winfo_children():
                bind_scroll(child)
        bind_scroll(sidebar)
        for variable in self.scan_vars.values():
            variable.trace_add("write",lambda *args:self.changed())

    def scan_field(self,box,row,key,label,value):
        ttk.Label(box,text=label).grid(row=row,column=0,sticky="w",pady=4,padx=(0,8))
        variable = tk.StringVar(self.root,value=value)
        self.scan_vars[key] = variable
        ttk.Entry(box,textvariable=variable,width=12).grid(row=row,column=1,sticky="ew",pady=4)
        box.columnconfigure(1,weight=1)

    def discover_presets(self):
        result = {}
        base = self.home/"configs"
        for path in sorted(base.rglob("*.json")):
            try:
                data = json.loads(path.read_text(encoding="utf-8-sig"))
                if data.get("schema")=="mna-workbench-1":
                    result[str(path.relative_to(base).with_suffix(""))] = path
            except (ValueError,OSError,AttributeError):
                continue
        return result

    def default_preset(self):
        return next((path for path in self.presets.values() if path.name=="三列_R12_20x4.json"),next(iter(self.presets.values()),None))

    def fallback_config(self):
        source = Path(__file__).parent
        path = source/"data/scan_base/project.ini"
        if not path.is_file():
            path = source/"pginfo_components.ini"
        config,components,_ = read_project(path)
        text = io.StringIO()
        config.write(text)
        return dict(schema="mna-workbench-1",name="默认项目",active_tab="layout",scan=copy.deepcopy(DEFAULT_SCAN),
                    layout=dict(ini_text=text.getvalue(),components=components))

    def current_mode(self):
        return "scan" if self.tabs.select()==str(self.scan_tab) else "layout"

    def scan_values(self):
        values = {key:variable.get().strip() for key,variable in self.scan_vars.items()}
        values["maximum"] = values["maximum"] or None
        values["spacings"] = values["spacings"] or None
        values["export_ir"] = bool(self.export_ir.get())
        return jobs.validate_scan(values)

    def snapshot(self,mode=None,allow_scan_fallback=False):
        active = mode or self.current_mode()
        try:
            scan = self.scan_values()
        except (ValueError,TypeError):
            if active=="scan" or not allow_scan_fallback:
                raise
            scan = copy.deepcopy(self.config_data.get("scan",DEFAULT_SCAN))
        text = io.StringIO()
        self.editor.config.write(text)
        return dict(schema="mna-workbench-1",name=self.config_data.get("name","我的配置"),active_tab=active,
                    layout=dict(ini_text=text.getvalue(),components=copy.deepcopy(self.editor.layout)),scan=scan)

    def changed(self):
        if not self.loading:
            self.dirty = True
            if hasattr(self,"plan_after") and self.plan_after:
                self.root.after_cancel(self.plan_after)
            self.plan_after = self.root.after(180,self.update_plan)

    def update_plan(self):
        self.plan_after = None
        try:
            plan = jobs.plan_scan(self.scan_values())
            count = int(plan["large_cols"])
            self.plan_label.set(f"{count} 大列 vs {count} 大列 + {count-1} 上层小列\n"
                                f"预计 {plan['point_count']} 个求解点，设置 {self.scan_values()['workers']} 点并发；\n"
                                f"区域 W=({count}-1)D+70 μm，高 800 μm。")
            self.draw_diagram(count)
        except (ValueError,TypeError,OverflowError) as error:
            self.plan_label.set(f"请检查参数：{error}")

    def draw_diagram(self,count):
        c = self.diagram
        c.delete("all")
        n = min(count,8)
        step = 295/max(1,n-1)
        for y,label in ((28,"仅大列"),(80,"+ 小列")):
            for index in range(n):
                x = 30+index*step
                c.create_rectangle(x-8,y-13,x+8,y+13,fill="#2867b2",outline="")
                if y==80 and index<n-1:
                    c.create_rectangle(x+step/2-4,y-7,x+step/2+4,y+7,fill="#c33b42",outline="")
            c.create_text(5,y+23,text=label,anchor="w",fill=COLORS["muted"],font=("Microsoft YaHei UI",8))

    def has_changes(self):
        return self.dirty or self.editor.dirty

    def discard_allowed(self):
        return not self.has_changes() or messagebox.askyesno("尚未保存","放弃当前未保存的修改并继续？",parent=self.root)

    def apply_config(self,data,path=None,discard=True):
        if discard and not self.discard_allowed():
            return False
        self.loading=True
        try:
            ini = jobs.write_layout(self.state_dir/"editor"/datetime.now().strftime("%Y%m%d_%H%M%S_%f"),data["layout"])
            config,layout,layers = read_project(ini)
            self.editor.cancel_drag()
            self.editor.config,self.editor.layout,self.editor.layers,self.editor.path = config,layout,layers,ini
            self.editor.selected,self.editor.primary,self.editor.dirty = set(),None,False
            self.editor.undo_stack.clear()
            self.editor.redo_stack.clear()
            self.editor.refresh_types()
            self.editor.refresh_interfaces()
            self.editor.rebuild()
            self.config_data=copy.deepcopy(data)
            scan=jobs.validate_scan(data["scan"])
            for key,variable in self.scan_vars.items():
                value=scan.get(key)
                if isinstance(value,list):
                    value=",".join(f"{x:g}" for x in value)
                variable.set("" if value is None else str(value))
            self.export_ir.set(scan["export_ir"])
            self.current_path=Path(path).resolve() if path else None
            self.config_label.set(f"{data.get('name','未命名')}  ·  {self.current_path.name if self.current_path else '尚未保存'}")
            preset=next((label for label,source in self.presets.items() if source==self.current_path),None)
            self.preset_combo.set(preset or "自定义配置")
            self.tabs.select(self.scan_tab if data["active_tab"]=="scan" else self.layout_tab)
            self.layout_tabs.select(self.editor_host)
            self.need_fit=True
            self.dirty=False
        finally:
            self.loading=False
        self.update_plan()
        self.root.after(100,self.fit_visible)
        return True

    def load_path(self,path):
        path=Path(path)
        if path.suffix.lower()==".ini":
            config,layout,_=read_project(path)
            stream=io.StringIO()
            config.write(stream)
            try:
                scan=self.scan_values()
            except (ValueError,TypeError):
                scan=copy.deepcopy(self.config_data["scan"])
            data=dict(schema="mna-workbench-1",name=path.stem,active_tab="layout",scan=scan,
                      layout=dict(ini_text=stream.getvalue(),components=layout))
        else:
            data=jobs.load_config(path)
        return self.apply_config(data,path)

    def load_dialog(self):
        if self.process:
            return
        path=filedialog.askopenfilename(parent=self.root,title="加载工作台配置 / 原项目INI",initialdir=self.home/"configs",
                                       filetypes=[("工作台配置 / MNA项目","*.json *.ini"),("所有文件","*.*")])
        if path:
            self.guard(lambda:self.load_path(path))

    def load_preset(self,event=None):
        if not self.process:
            self.guard(lambda:self.load_path(self.presets[self.preset_combo.get()]))

    def save_dialog(self):
        try:
            snapshot=self.snapshot()
        except (ValueError,TypeError) as error:
            self.error(error)
            return False
        initial=self.current_path if self.current_path and self.current_path.suffix.lower()==".json" else self.home/"configs/我的配置.json"
        path=filedialog.asksaveasfilename(parent=self.root,title="保存完整工作台配置",defaultextension=".json",
            initialdir=initial.parent,initialfile=initial.name,filetypes=[("完整工作台配置","*.json")])
        if not path:
            return False
        try:
            snapshot["name"]=Path(path).stem
            jobs.save_config(path,snapshot)
            self.config_data=copy.deepcopy(snapshot)
            self.current_path=Path(path).resolve()
            self.dirty,self.editor.dirty=False,False
            self.config_label.set(f"{snapshot['name']}  ·  {self.current_path.name}")
            self.status.set("配置已保存；下次加载此JSON即可运行。")
            return True
        except (OSError,ValueError) as error:
            self.error(error)
            return False

    def editor_shortcut(self,name,event):
        widget=getattr(event,"widget",None)
        if name in ("undo","redo") and widget is not None and widget.winfo_class() in ("Entry","TEntry","Text","TCombobox","Spinbox","TSpinbox"):
            return None
        if self.current_mode()=="layout" and self.layout_tabs.select()==str(self.editor_host):
            return getattr(self.editor,name)(event) if name.endswith("_key") else self.editor.guarded(getattr(self.editor,name))

    def tab_changed(self,event=None):
        self.root.after(80,self.fit_visible)

    def fit_visible(self):
        if self.need_fit and self.current_mode()=="layout":
            self.editor.fit()
            self.need_fit=False

    def run_job(self,mode=None):
        if self.process:
            self.error("当前任务仍在运行，请等待完成或点击停止。")
            return
        try:
            if not metrics.process_tree_memory(os.getpid())["available"]:
                raise RuntimeError("内存监测与安全停止需要psutil。请执行：python -m pip install -r code/requirements-core.txt")
            snapshot=self.snapshot(mode,allow_scan_fallback=True)
            output=jobs.new_output(self.home,snapshot["active_tab"],snapshot["name"])
            identity=output.name
            job_file=self.state_dir/"jobs"/f"{identity}.json"
            jobs.save_config(job_file,snapshot)
            logs=self.state_dir/"job_logs"
            logs.mkdir(parents=True,exist_ok=True)
            log_path=logs/f"{identity}.log"
            handle=log_path.open("w",encoding="utf-8")
            environment=os.environ.copy()
            environment.update(PYTHONUTF8="1",PYTHONUNBUFFERED="1",MPLBACKEND="Agg",PYTHONDONTWRITEBYTECODE="1")
            process=subprocess.Popen([sys.executable,"-B",str(Path(jobs.__file__).resolve()),"--job-file",str(job_file),"--out",str(output)],
                cwd=str(self.home),env=environment,stdout=handle,stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        except (ValueError,OSError,TypeError,RuntimeError) as error:
            if "handle" in locals():
                handle.close()
            self.error(error)
            return
        self.process,self.log_handle,self.log_path,self.output=process,handle,log_path,output
        self.stop_controller=metrics.ProcessTreeStopController(process.pid)
        self.job_mode,self.cancelled=snapshot["active_tab"],False
        self.job_file=job_file
        self.memory_samples=[]
        self.memory_peak=0
        self.memory_peak_count=0
        self.last_memory_time=0
        self.merged_log=""
        self.termination_result=None
        self.stop_thread=None
        self.cancel_failure_reported=False
        self.last_log=""
        self.current_pane=self.scan_results if self.job_mode=="scan" else self.layout_results
        self.current_pane.set_log("")
        self.memory_status.set("内存：采样中")
        self.current_pane.status.set("正在计算，可切换 Tab 查看其他内容。")
        self.current_pane.notebook.select(1)
        if self.job_mode=="layout":
            self.layout_tabs.select(self.layout_results)
        self.set_busy(True)
        self.status.set(f"正在运行 {'间距扫描' if self.job_mode=='scan' else '布局 IR'}；输出：{output.name}")
        self.root.after(250,self.poll_job)

    def ingest_log(self):
        try:
            raw=self.log_path.read_text(encoding="utf-8",errors="replace")
        except OSError:
            return
        addition=raw[len(self.last_log):] if raw.startswith(self.last_log) else "\n"+raw
        self.last_log=raw
        self.add_log(addition)

    def add_log(self,text):
        self.merged_log+=text
        self.current_pane.append_log(text)

    def sample_memory(self,force=False):
        now=monotonic()
        if not force and now-self.last_memory_time<1:
            return
        self.last_memory_time=now
        sample=metrics.process_tree_memory(os.getpid())
        if not sample["available"]:
            self.memory_status.set("内存：暂不可用")
            return
        self.memory_peak=max(self.memory_peak,sample["rss_bytes"])
        self.memory_peak_count=max(self.memory_peak_count,sample["process_count"])
        timestamp=datetime.now().isoformat(timespec="seconds")
        self.memory_samples.append(dict(time=timestamp,rss_bytes=sample["rss_bytes"],process_count=sample["process_count"],
            partial=sample["partial"],errors=sample.get("errors",[])))
        self.memory_status.set(f"RSS {sample['rss_bytes']/1024**2:.1f} MiB / 峰值 {self.memory_peak/1024**2:.1f} MiB")
        self.add_log(f"\n[内存 {timestamp[11:]}] 程序进程树 RSS={sample['rss_bytes']/1024**2:.1f} MiB；采样峰值={self.memory_peak/1024**2:.1f} MiB；进程数={sample['process_count']}（含GUI、计算、绘图/导出，共享页可能重复计）\n")
        if sample["partial"]:
            self.add_log("[内存采样不完整] 部分进程读取失败，当前RSS可能低估："+str(sample.get("errors",[]))+"\n")

    def save_resource_usage(self):
        usage=dict(metric="sum of RSS",unit="bytes",root="GUI and recursive descendants",sample_interval_s=1,
            peak_sampled_rss_bytes=self.memory_peak,peak_sampled_process_count=self.memory_peak_count,
            includes_export_and_visualization=True,shared_pages_may_be_counted_multiple_times=True,samples=self.memory_samples)
        jobs._atomic_json(self.output/"resource_usage.json",usage)
        marker=self.output/"job_summary.json"
        if marker.is_file():
            result=json.loads(marker.read_text(encoding="utf-8"))
            result["resource_usage"]=usage
            jobs._atomic_json(marker,result)
        elif self.cancelled:
            jobs.save_config(self.output/"workbench_config.json",jobs.load_config(self.job_file))
            failed=self.termination_result and (self.termination_result.get("alive_pids") or self.termination_result.get("errors"))
            jobs._atomic_json(marker,dict(status="CANCEL_FAILED" if failed else "CANCELLED",mode=self.job_mode,resource_usage=usage,
                config_snapshot="workbench_config.json",termination=self.termination_result))

    def set_busy(self,busy):
        self.run_button.configure(state="disabled" if busy else "normal")
        self.editor.run_button.configure(state="disabled" if busy else "normal")
        self.stop_button.configure(state="normal" if busy else "disabled")
        self.load_button.configure(state="disabled" if busy else "normal")
        self.preset_combo.configure(state="disabled" if busy else "readonly")
        self.progress.start(15) if busy else self.progress.stop()

    def poll_job(self):
        if self.process is None:
            return
        self.ingest_log()
        self.sample_memory()
        code=self.process.poll()
        if self.cancelled and self.stop_thread is not None and not self.stop_thread.is_alive() and self.termination_result:
            failed=self.termination_result.get("alive_pids") or self.termination_result.get("errors")
            if failed:
                if not self.cancel_failure_reported:
                    self.add_log("\n[停止未完成] "+str(self.termination_result)+"\n")
                    self.status.set("未能停止全部计算进程，可点击停止重试；具体原因见日志。")
                    self.stop_button.configure(state="normal")
                    self.cancel_failure_reported=True
                # Keep the controller and Run lock even after the coordinator
                # exits: its previously captured workers may still need retry.
                self.root.after(350,self.poll_job)
                return
        if code is None:
            self.root.after(350,self.poll_job)
            return
        if self.cancelled and self.stop_thread is not None and self.stop_thread.is_alive():
            self.root.after(150,self.poll_job)
            return
        self.log_handle.close()
        self.log_handle=None
        self.process=None
        self.set_busy(False)
        try:
            self.ingest_log()
            self.sample_memory(force=True)
            self.add_log(f"\n[任务内存汇总] 程序进程树采样峰值 {self.memory_peak/1024**2:.1f} MiB，包含GUI、绘图和导出。每点peakRSS仅统计读配置/组装/求解阶段，不含最终输出。\n")
            (self.output/"console.log").write_text(self.merged_log,encoding="utf-8")
            self.save_resource_usage()
        except (OSError,ValueError,TypeError) as error:
            self.status.set(f"任务已退出；日志保存在 {self.log_path}：{error}")
        if self.cancelled:
            failed=self.termination_result and (self.termination_result.get("alive_pids") or self.termination_result.get("errors"))
            if failed:
                self.current_pane.status.set("协调进程已退出，但部分子进程的停止未确认。请查看日志。")
                self.status.set(f"停止未完成：{self.output}")
                self.error(str(self.termination_result))
            else:
                self.current_pane.status.set("任务已停止，已生成的文件保留在结果目录。")
                self.status.set(f"已停止：{self.output}")
            return
        try:
            marker=self.output/"job_summary.json"
            if code or not marker.is_file():
                raise RuntimeError(self.merged_log[-2600:] or f"计算进程返回 {code}；没有生成结果摘要。")
            result=json.loads(marker.read_text(encoding="utf-8"))
            if result.get("status")!="PASS":
                raise RuntimeError(result.get("error","计算未完成"))
            self.current_pane.show_result(self.output,self.job_mode,result["summary"])
            self.status.set(f"已完成：{self.output}")
        except (OSError,ValueError,KeyError,TypeError,AttributeError,RuntimeError) as error:
            self.current_pane.status.set("运行未完成，请在运行日志中查看原因。")
            self.status.set(f"运行失败：{self.output}")
            self.error(error)

    def stop(self):
        if self.process:
            if self.stop_thread is not None and self.stop_thread.is_alive():
                return
            self.cancelled=True
            self.cancel_failure_reported=False
            self.termination_result=None
            def terminate():
                self.termination_result=self.stop_controller.stop(timeout=1)
            self.stop_thread=threading.Thread(target=terminate,name="MNA stop job tree",daemon=True)
            self.stop_thread.start()
            self.stop_button.configure(state="disabled")
            self.status.set("正在停止任务…")

    def error(self,error):
        text=str(error)
        if "No module named" in text:
            text+="\n\n请先人工配置环境：python -m pip install -r code/requirements-core.txt"
        messagebox.showerror("操作未完成",text[-3500:],parent=self.root)

    def guard(self,action):
        try:
            return action()
        except (ValueError,OSError,KeyError,TypeError) as error:
            self.error(error)

    def help(self):
        dialog=tk.Toplevel(self.root)
        dialog.title("MNA 工作台 · 使用说明")
        dialog.geometry("740x600")
        text=tk.Text(dialog,wrap="word",font=("Microsoft YaHei UI",11),padx=18,pady=18)
        text.pack(fill="both",expand=True)
        text.insert("1.0","加载配置 → 选择 Tab → Run\n\n"
            "组件布局与 IR：保留组件编辑、整体拖动、模板导入导出、跨层复制、撤销和重做。F键适配视图（输入框内保留输入）。点击 Run 对当前布局求解，结果显示在同一 Tab 的 IR 结果页。\n\n"
            "间距扫描：比较仅大组件与上层各间隙加入小组件。大列数、单根电阻、小组件尺寸、电流密度、网格和扫描范围都可修改。终点留空时按必要电气上界扫描。\n\n"
            "保存配置会把当前布局、模板、Mesh、负载、扫描参数一起写入一个 JSON。下次加载后，点击 Run 即可复现；也支持加载原 INI＋布局文件。\n\n"
            "扫描的并发点数设为1是串行，大于1时多进程同时计算独立点；并发会增加内存。每次 Run 创建独立 results 目录，不使用旧计算缓存。停止会终止该任务的整个计算进程树。\n\n"
            "日志每秒记录程序进程树当前RSS与采样峰值（包含GUI、计算、绘图和导出，共享页可能重复计）。每个扫描点另记录纯计算区间的peakRSS。resource_usage.json保存采样记录；采样可能漏过很短的峰值。\n\n"
            "IR 采用全层全节点最大(VDD压降＋VSS抬升)，扫描规格严格小于11.2mV。显示可以缩放，数值与CSV保留完整节点和每根TSV。底层多段净空分别计算，面积合计不是单块连续空间。\n\n"
            "首次使用请自行配置带Tcl/Tk的Python环境，并执行：\npython -m pip install -r code/requirements-core.txt\n\n"
            "包内只有启动入口、BAT、code和configs；运行后结果在results。代码、依赖清单和开发说明都放在code内。")
        text.configure(state="disabled")
        ttk.Button(dialog,text="关闭",command=dialog.destroy).pack(pady=8)

    def close(self):
        if getattr(self,"closing",False):
            return
        if self.process and not messagebox.askyesno("任务正在运行","停止当前任务并退出？",parent=self.root):
            return
        if not self.discard_allowed():
            return
        if self.process:
            self.closing=True
            if self.stop_thread is None:
                self.stop()
            self.root.after(100,self.close_after_stop)
            return
        self.destroy_window()

    def close_after_stop(self):
        if self.stop_thread is not None and self.stop_thread.is_alive():
            self.root.after(100,self.close_after_stop)
            return
        result=self.termination_result or {}
        if result.get("alive_pids") or result.get("errors"):
            self.closing=False
            self.error("未能确认全部计算进程退出："+str(result))
            return
        if self.process is not None:
            if self.process.poll() is None:
                self.closing=False
                self.error("计算进程仍未退出，请在运行日志中检查停止状态。")
                return
            # Use the normal completion path to save the merged log, resource
            # samples and cancellation marker before the GUI is destroyed.
            self.poll_job()
        self.destroy_window()

    def destroy_window(self):
        if self.log_handle:
            self.log_handle.close()
        for pending in self.root.tk.call("after","info"):
            self.root.tk.call("after","cancel",pending)
        self.root.destroy()


def main(argv=None,app_root=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config",type=Path)
    args=parser.parse_args(argv)
    root=tk.Tk()
    try:
        Workbench(root,app_root or Path(__file__).parent,args.config)
    except Exception:
        root.destroy()
        raise
    root.mainloop()
    return 0
