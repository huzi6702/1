"""Stable Windows-spawn entry point for independent TSV scan points.

Do not import the dynamically named study module at module import time: spawn
must be able to import this small, normally named module in an installed app.
"""
from __future__ import annotations

import importlib.util
import os
from pathlib import Path
import sys
import traceback


THREAD_ENVIRONMENT = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                      "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS")
_studies = {}


def execute_point(task):
    for key in THREAD_ENVIRONMENT:
        os.environ[key] = "1"
    os.environ["MPLBACKEND"] = "Agg"
    path = str(Path(task["study_file"]).resolve())
    if path not in _studies:
        root = str(Path(path).parent.parent)
        if root not in sys.path:
            sys.path.insert(0, root)
        spec = importlib.util.spec_from_file_location("mna_scan_worker_study", path)
        study = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(study)
        _studies[path] = study
    study = _studies[path]
    study.BASE = Path(task["base_ini"])
    from threadpoolctl import threadpool_limits
    values = task["values"]
    # Every process assembles its own full distributed-TSV circuit.  Serial
    # VDD/VSS and one BLAS thread prevent nested concurrency within a worker.
    with threadpool_limits(limits=1):
        ini = study.write_case(Path(task["folder"]), **values)
        return study.calculate(ini, **values, parallel_rails=False)


def worker_loop(tasks, results):
    """One result per assigned point; exceptions are reported to the parent."""
    while True:
        task = tasks.get()
        if task is None:
            return
        try:
            row = execute_point(task)
            results.put(dict(index=task["index"], row=row, error=None))
        except BaseException as error:
            results.put(dict(index=task["index"], row=None,
                             error=f"{type(error).__name__}: {error}",
                             traceback=traceback.format_exc(), worker_pid=os.getpid()))
            return
