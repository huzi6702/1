#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Dual VDD/VSS DC IR analysis; negative configured current means load.

The original electrical model and historical Bump footprint are retained:
ypn extends the footprint in X, and xpn extends it in Y. Coordinates are
one-based. Run: python mna_ir_dual.py [pginfo2.ini] [--out results]
"""

import argparse
import ast
import importlib.util
import json
from concurrent.futures import ThreadPoolExecutor
from configparser import ConfigParser
from pathlib import Path
from time import perf_counter

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix, diags
from scipy.sparse.linalg import cg, splu
from threadpoolctl import threadpool_limits

VERSION = "4.2"


def gfunc(m, n, gh, gv):
    """Stamp the X/Y resistor mesh using float64 sparse matrices."""
    nodes = np.arange(m * n).reshape(n, m)
    a = np.concatenate((nodes[:, :-1].ravel(), nodes[:-1, :].ravel()))
    b = np.concatenate((nodes[:, 1:].ravel(), nodes[1:, :].ravel()))
    g = np.concatenate((np.full(n * (m - 1), gh), np.full((n - 1) * m, gv)))
    G = coo_matrix(
        (np.concatenate((g, g, -g, -g)),
         (np.concatenate((a, b, a, b)), np.concatenate((a, b, b, a)))),
        shape=(m * n, m * n), dtype=np.float64,
    ).tocsc()
    return G, G.diagonal().reshape(n, m)


def integer_coord(value, label):
    numeric = float(value)
    if not np.isfinite(numeric) or not numeric.is_integer():
        raise ValueError(f"{label} must be an integer, got {value!r}")
    return int(numeric)


def gen_imap(imap, m, n, Z, flat):
    """Each rectangle's total current covers BOTH endpoints; overlaps add.

    Format: [total_A, x1, y1, x2, y2], coordinates 1..m and 1..n.
    As in the original regional mode, current.mul does not scale imap.
    Validate the entire map before modifying Z, so errors cannot half-apply it.
    """
    regions = []
    for index, region in enumerate(imap, start=1):
        if len(region) != 5:
            raise ValueError(f"imap region {index} requires [I, x1, y1, x2, y2]")
        current = float(region[0])
        if not np.isfinite(current):
            raise ValueError(f"imap region {index} current must be finite")
        x1, y1, x2, y2 = [integer_coord(v, f"imap region {index} coordinate")
                          for v in region[1:]]
        xlo, xhi = sorted((x1, x2))
        ylo, yhi = sorted((y1, y2))
        if not (1 <= xlo <= xhi <= m and 1 <= ylo <= yhi <= n):
            raise ValueError(f"imap region {index} ({x1},{y1})..({x2},{y2}) "
                             f"is outside mesh X=1..{m}, Y=1..{n}")
        regions.append((current, xlo, xhi, ylo, yhi))
    current_grid = np.zeros((n, m), dtype=np.float64)
    for current, xlo, xhi, ylo, yhi in regions:
        count = (xhi - xlo + 1) * (yhi - ylo + 1)
        current_grid[ylo - 1:yhi, xlo - 1:xhi] += flat * current / count
    Z[:m * n] += current_grid.ravel().reshape(Z[:m * n].shape)


def build_vloc(bumps, m, n, xpn, ypn):
    """Keep the original X/Y footprint convention, with explicit index checks."""
    effective_bumps = np.array(bumps, dtype=int, copy=True)
    locations = []
    for x, y in effective_bumps:
        if not (1 <= x <= m and 1 <= y <= n):
            raise ValueError(f"Bump ({x},{y}) is outside the mesh")
        footprint = [(x + p - 1, yy - 1)
                     for p in range(-ypn, ypn + 1)
                     for yy in range(y - xpn, y + xpn + 1)]
        if any(not (0 <= px < m and 0 <= py < n) for px, py in footprint):
            raise ValueError(f"Bump ({x},{y}) footprint is outside the mesh; "
                             "historical convention: X radius=ypn, Y radius=xpn")
        locations.extend(footprint)
    return np.asarray(locations, dtype=int)


def printcurrent(ir, voltage, vloc, rz, con_n, bump, bumpcurrent):
    branch_current = ir[vloc[:, 1], vloc[:, 0]] / rz
    current = branch_current.reshape(len(bump), con_n).sum(axis=1)
    rows = pd.DataFrame({
        "voltage:": voltage, "x:": bump[:, 0], "y:": bump[:, 1],
        "I(mA):": current * 1000.0,
    })
    return pd.concat((bumpcurrent, rows), ignore_index=True)


def get_ploc_ir(ploc, ir):
    values = ir[ploc[:, 0], ploc[:, 1]] * 1000.0
    hi, lo = int(np.argmax(values)), int(np.argmin(values))
    return dict(zip(map(str, ploc), values)), {
        "maxir": float(values[hi]), "maxploc": str(ploc[hi]),
        "minir": float(values[lo]), "minploc": str(ploc[lo]),
    }


def read_config(path):
    config = ConfigParser()
    if not config.read(path, encoding="utf-8-sig"):
        raise FileNotFoundError(path)
    if config.getint("mode", "mode", fallback=2) != 2:
        raise ValueError("This script supports mode=2 (dual VDD/VSS) only")
    p = {key: config.getint("mesh", key) for key in ("xgrid", "ygrid")}
    p.update({key: config.getfloat("mesh", key)
              for key in ("rh", "rv", "xpitch", "ypitch")})
    p.update({key: config.getint("bump", key) for key in ("xpn", "ypn")})
    p.update({key: config.getfloat("bump", key) for key in ("rz", "powerv")})
    p["currentmode"] = config.getint("current", "currentmode")
    if p["currentmode"] not in (1, 2):
        raise ValueError("currentmode must be 1 (uniform) or 2 (regional)")
    p["i"] = config.getfloat("current", "i")
    p["mul"] = config.getfloat("current", "mul")
    p["imap"] = (ast.literal_eval(config.get("current", "imap"))
                 if p["currentmode"] == 2 else [])
    for rail in ("vdd", "vss"):
        raw = ast.literal_eval(config.get("bumploc", "bumploc" + rail))
        points = np.asarray(raw, dtype=float)
        if points.ndim != 2 or points.shape[1] != 2 or len(points) == 0:
            raise ValueError(f"bumploc{rail} must be a nonempty list of [x,y]")
        if not np.all(np.isfinite(points)) or not np.all(points == np.floor(points)):
            raise ValueError(f"bumploc{rail} coordinates must be integers")
        p["bump" + rail] = points.astype(int)
    if p["xgrid"] < 1 or p["ygrid"] < 1:
        raise ValueError("mesh dimensions must be positive")
    if p["xpn"] < 0 or p["ypn"] < 0:
        raise ValueError("Bump footprint radii must be nonnegative")
    for key in ("rh", "rv", "rz", "xpitch", "ypitch", "powerv"):
        if not np.isfinite(p[key]) or p[key] <= 0:
            raise ValueError(f"{key} must be finite and positive")
    if not np.isfinite(p["i"]) or not np.isfinite(p["mul"]):
        raise ValueError("i and mul must be finite")
    return p


def select_solver(requested, nodes, amg_threshold):
    if requested not in ("auto", "direct", "amg"):
        raise ValueError("solver must be auto, direct or amg")
    has_amg = importlib.util.find_spec("pyamg") is not None
    if requested == "amg" and not has_amg:
        raise ImportError("CG+AMG requires pyamg; install requirements.txt or use --solver direct")
    if requested == "auto":
        return "amg" if nodes >= amg_threshold and has_amg else "direct"
    return requested


def reduced_system(p, G, bump):
    """Eliminate the prescribed source voltage and its current exactly.

    (Gmesh + diag(gsource)) * delta = -current, with delta=Vsource-Vnode.
    Positive resistor values and at least one Bump anchor make this SPD.
    Overlapping Bump footprints contribute parallel source conductances.
    """
    m, n = p["xgrid"], p["ygrid"]
    con_n = (2 * p["xpn"] + 1) * (2 * p["ypn"] + 1)
    branch_r = p["rz"] * con_n
    vloc = build_vloc(bump, m, n, p["xpn"], p["ypn"])
    nodes = vloc[:, 0] + vloc[:, 1] * m
    gsource = np.bincount(nodes, minlength=m * n).astype(np.float64) / branch_r
    A = (G + diags(gsource, format="csc")).tocsc()
    return A, vloc, branch_r, con_n


def solve_rail(p, G, bump, voltage, current, solver="direct", rtol=1e-10, maxiter=1000):
    start = perf_counter()
    m, n = p["xgrid"], p["ygrid"]
    A, vloc, branch_r, con_n = reduced_system(p, G, bump)
    rhs = -np.asarray(current, dtype=np.float64).reshape(m * n)
    assembly_s = perf_counter() - start
    iterations = 0
    start = perf_counter()
    if solver == "direct":
        factor = splu(A, permc_spec="MMD_AT_PLUS_A", diag_pivot_thresh=0.0,
                      options={"SymmetricMode": True})
        setup_s = perf_counter() - start
        start = perf_counter()
        delta = factor.solve(rhs)
    elif solver == "amg":
        import pyamg
        A = A.tocsr()
        hierarchy = pyamg.smoothed_aggregation_solver(
            A, symmetry="symmetric", max_coarse=50,
            presmoother=("gauss_seidel", {"sweep": "symmetric"}),
            postsmoother=("gauss_seidel", {"sweep": "symmetric"}))
        preconditioner = hierarchy.aspreconditioner(cycle="V")
        setup_s = perf_counter() - start
        def count_iteration(_):
            nonlocal iterations
            iterations += 1
        start = perf_counter()
        delta, info = cg(A, rhs, M=preconditioner, rtol=rtol, atol=0.0,
                         maxiter=maxiter, callback=count_iteration)
        if info != 0:
            raise RuntimeError(f"CG+AMG did not converge (info={info}); "
                               "increase --maxiter or use --solver direct")
    else:
        raise ValueError("solve_rail requires solver=direct or amg")
    solve_s = perf_counter() - start
    residual = A @ delta - rhs
    relative_residual = float(np.linalg.norm(residual) /
                              max(np.linalg.norm(rhs), np.finfo(float).tiny))
    if not np.all(np.isfinite(delta)) or relative_residual > max(50 * rtol, 1e-7):
        raise RuntimeError(f"Solver residual check failed: {relative_residual:.3e}")
    branch_ir = delta.reshape(n, m)
    node_voltage = voltage - branch_ir
    bumpcurrent = printcurrent(branch_ir, voltage, vloc, branch_r,
                               con_n, bump, pd.DataFrame())
    balance = float(bumpcurrent["I(mA):"].sum() / 1000.0 + np.sum(current))
    if abs(balance) > max(1e-9, 50 * rtol * float(np.sum(np.abs(current)))):
        raise RuntimeError(f"Bump/node current balance failed: {balance:.3e} A")
    diagnostics = {
        "formulation": "exactly reduced SPD nodal system",
        "solver": solver, "matrix_size": m * n, "matrix_nnz": int(A.nnz),
        "max_nodal_residual_A": float(np.max(np.abs(residual))),
        "relative_residual": relative_residual,
        "iterations": iterations, "rtol": rtol,
        "assembly_s": assembly_s, "setup_s": setup_s, "solve_s": solve_s,
        "bump_current_sum_A": float(bumpcurrent["I(mA):"].sum() / 1000.0),
        "node_injection_sum_A": float(np.sum(current)),
        "current_balance_error_A": balance,
        "source_voltage_V": float(voltage),
        "source_current_A": -float(bumpcurrent["I(mA):"].sum() / 1000.0),
    }
    return node_voltage, bumpcurrent, diagnostics


def solve_network(p, load, parallel=True, solver="auto", rtol=1e-10,
                  maxiter=1000, amg_threshold=250000):
    """Share the immutable mesh; solve independent rails in two CPU threads."""
    if not 0 < rtol < 1 or maxiter < 1 or amg_threshold < 1:
        raise ValueError("Require 0<rtol<1, maxiter>=1 and amg_threshold>=1")
    selected = select_solver(solver, p["xgrid"] * p["ygrid"], amg_threshold)
    # Import before timing and starting worker threads, including first-use setup.
    if selected == "amg":
        import pyamg
    start = perf_counter()
    G, _ = gfunc(p["xgrid"], p["ygrid"], 1 / p["rh"], 1 / p["rv"])
    mesh_s = perf_counter() - start
    work = ((p, G, p["bumpvdd"], p["powerv"], load, selected, rtol, maxiter),
            (p, G, p["bumpvss"], 0.0, -load, selected, rtol, maxiter))
    # The limit wraps the whole pool because BLAS limits are process-wide.
    # Two rail workers x one BLAS thread avoids nested thread oversubscription.
    with threadpool_limits(limits=1, user_api="blas"):
        if parallel:
            with ThreadPoolExecutor(max_workers=2, thread_name_prefix="IR_rail") as pool:
                futures = [pool.submit(solve_rail, *args) for args in work]
                result = tuple(future.result() for future in futures)
        else:
            result = tuple(solve_rail(*args) for args in work)
    timing = {"solver_requested": solver, "solver_used": selected,
              "parallel_rails": bool(parallel), "rail_workers": 2 if parallel else 1,
              "blas_threads_per_worker": 1, "mesh_assembly_s": mesh_s,
              "numeric_wall_s": perf_counter() - start, "amg_threshold": amg_threshold}
    return result[0], result[1], timing


def extreme(field, dx, dy, find_max=True):
    flat = np.argmax(field) if find_max else np.argmin(field)
    y, x = np.unravel_index(flat, field.shape)
    return {"value": float(field[y, x]), "x_node": int(x + 1), "y_node": int(y + 1),
            "x_um": float((x + 1) * dx), "y_um": float((y + 1) * dy)}


def display_grid(field, dx, dy, max_axis=240, x_offset=0, y_offset=0):
    """Block-max display only; each plotted pixel retains its block's peak.

    Field and full-resolution results are never modified. Coordinates returned
    here are cell EDGES, so even a 1x1 block preserves the original extent.
    """
    if max_axis < 2:
        raise ValueError("plot maximum axis size must be >=2")
    rows, cols = field.shape
    sy, sx = max(1, (rows + max_axis - 1) // max_axis), max(1, (cols + max_axis - 1) // max_axis)
    ys, xs = np.arange(0, rows, sy), np.arange(0, cols, sx)
    sampled = np.maximum.reduceat(np.maximum.reduceat(field, ys, axis=0), xs, axis=1)
    xedges = (np.r_[xs, cols] + x_offset + 0.5) * dx
    yedges = (np.r_[ys, rows] + y_offset + 0.5) * dy
    return xedges, yedges, sampled


def plot_results(p, vdd_ir, vss, total, bumpcurrent, summary, out,
                 plot_max_axis=240, surface_max_axis=50):
    m, n = p["xgrid"], p["ygrid"]
    dx, dy = p["xpitch"], p["ypitch"]
    fig = plt.figure(figsize=(17, 10), dpi=140, constrained_layout=True)
    grid = fig.add_gridspec(2, 3)
    for index, (field, title) in enumerate(((vss, "VSS ground rise"),
                                           (vdd_ir, "VDD drop"),
                                           (total, "Total VDD + VSS loss"))):
        ax = fig.add_subplot(grid[0, index])
        xedge, yedge, displayed = display_grid(field, dx, dy, plot_max_axis)
        cp = ax.pcolormesh(xedge, yedge, displayed * 1000.0, shading="flat", cmap="turbo",
                           vmin=field.min() * 1000, vmax=field.max() * 1000)
        e = extreme(field, dx, dy)
        ax.scatter(e["x_um"], e["y_um"], marker="x", s=60, c="black")
        ax.set_title(f"{title}\nmax {field.max() * 1000:.4f} mV "
                     f"({field.max() / p['powerv'] * 100:.3f}%)")
        ax.set(xlabel="X (um)", ylabel="Y (um)")
        ax.set_aspect("equal")
        fig.colorbar(cp, ax=ax, label="mV", shrink=0.82)
    # Retain the original central crop when the mesh is large enough.
    ys, ye = round(n / 4), round(3 * n / 4) - 1
    xs, xe = round(m / 4), round(3 * m / 4) - 1
    if ye <= ys or xe <= xs:
        ys, ye, xs, xe = 0, n, 0, m
    core = total[ys:ye, xs:xe]
    xedge, yedge, displayed = display_grid(core, dx, dy, plot_max_axis, xs, ys)
    ax = fig.add_subplot(grid[1, 0])
    cp = ax.pcolormesh(xedge, yedge, displayed * 1000, shading="flat", cmap="turbo",
                       vmin=core.min() * 1000, vmax=core.max() * 1000)
    ax.set_title(f"Central region: total loss\nmax {core.max() * 1000:.4f} mV")
    ax.set(xlabel="X (um)", ylabel="Y (um)", aspect="equal")
    fig.colorbar(cp, ax=ax, label="mV", shrink=0.82)
    ax = fig.add_subplot(grid[1, 1], projection="3d")
    sxedge, syedge, surface = display_grid(core, dx, dy, surface_max_axis, xs, ys)
    XX, YY = np.meshgrid((sxedge[:-1] + sxedge[1:]) / 2,
                         (syedge[:-1] + syedge[1:]) / 2)
    if min(surface.shape) >= 2:
        ax.plot_surface(XX, YY, surface * 1000, cmap="viridis", linewidth=0,
                        rcount=surface.shape[0], ccount=surface.shape[1])
    else:
        ax.scatter(XX.ravel(), YY.ravel(), (surface * 1000).ravel(), c=surface.ravel())
    ax.set(xlabel="X (um)", ylabel="Y (um)", zlabel="Loss (mV)",
           title="Central region: total loss (3D)")
    ax.view_init(elev=26, azim=-55)
    ax = fig.add_subplot(grid[1, 2])
    ax.scatter(p["bumpvdd"][:, 0] * dx, p["bumpvdd"][:, 1] * dy,
               c="#cf3131", s=21, label=f"VDD: {len(p['bumpvdd'])} Bumps")
    ax.scatter(p["bumpvss"][:, 0] * dx, p["bumpvss"][:, 1] * dy,
               c="#226dcc", s=21, label=f"VSS: {len(p['bumpvss'])} Bumps")
    ax.set(xlabel="X (um)", ylabel="Y (um)", title="Bump positions",
           xlim=(0, (m + 1) * dx), ylim=(0, (n + 1) * dy), aspect="equal")
    ax.legend(loc="upper center", fontsize=9)
    ax.grid(alpha=0.2)
    _, _, full_display = display_grid(total, dx, dy, plot_max_axis)
    fig.suptitle(f"DC IR | {m} x {n} solved nodes | load {summary['load_current_A']:.3f} A | "
                 f"VDD {p['powerv']:.3f} V\n"
                 f"Display: block maxima, {full_display.shape[1]} x {full_display.shape[0]} cells; "
                 "peak values use all solved nodes", fontsize=15)
    fig.savefig(out / "ir_overview.png", dpi=180)
    fig2, axes = plt.subplots(1, 2, figsize=(13, 5), constrained_layout=True)
    for ax, rail in zip(axes, ("VDD", "VSS")):
        data = bumpcurrent[bumpcurrent["rail"] == rail]
        cp = ax.scatter(data["x:"] * dx, data["y:"] * dy,
                        c=np.abs(data["I(mA):"]), s=55, cmap="viridis")
        ax.set(xlabel="X (um)", ylabel="Y (um)", aspect="equal",
               xlim=(0, (m + 1) * dx), ylim=(0, (n + 1) * dy),
               title=f"{rail} Bump current magnitude\nmax {abs(data['I(mA):']).max():.4f} mA")
        fig2.colorbar(cp, ax=ax, label="|I| (mA)")
    fig2.savefig(out / "bump_current.png", dpi=180)


def run(config_path, out, parallel=True, solver="auto", rtol=1e-10,
        maxiter=1000, amg_threshold=250000, plot_max_axis=240, surface_max_axis=50):
    config_kind = ConfigParser()
    config_kind.read(config_path, encoding="utf-8-sig")
    if config_kind.has_section("stack") or config_kind.has_section("components"):
        from mna_ir_stack import run as run_stack
        return run_stack(config_path, out, parallel, solver, rtol, maxiter,
                         amg_threshold, plot_max_axis, surface_max_axis)
    if plot_max_axis < 2 or surface_max_axis < 2:
        raise ValueError("Plot and surface maximum axis sizes must be >=2")
    run_started = perf_counter()
    p = read_config(config_path)
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    m, n = p["xgrid"], p["ygrid"]
    load = np.zeros(m * n, dtype=np.float64)
    if p["currentmode"] == 2:
        gen_imap(p["imap"], m, n, load, 1)
    else:
        load[:] = p["i"] * p["mul"] / (m * n)
    if load.sum() >= 0:
        raise ValueError("The total VDD load must be negative (current consumption)")
    (vdd, pcurrent, pcheck), (vss, gcurrent, gcheck), timing = solve_network(
        p, load, parallel, solver, rtol, maxiter, amg_threshold)
    pcurrent.insert(0, "rail", "VDD")
    gcurrent.insert(0, "rail", "VSS")
    bumpcurrent = pd.concat((pcurrent, gcurrent), ignore_index=True)
    vdd_ir = p["powerv"] - vdd
    total = vdd_ir + vss
    effective = vdd - vss
    _, ploc = get_ploc_ir(np.vstack((p["bumpvdd"], p["bumpvss"]))[:, [1, 0]] - 1,
                          total)
    irv = ploc["maxir"]
    irh = float(total.max() * 1000 - irv)
    irvh = irv + 0.5 * irh
    max_bump = {}
    for rail, table in (("VDD", pcurrent), ("VSS", gcurrent)):
        row = table.loc[table["I(mA):"].abs().idxmax()]
        max_bump[rail] = {"current_mA": float(row["I(mA):"]),
                          "x_node": int(row["x:"]), "y_node": int(row["y:"])}
    summary = {
        "version": VERSION, "performance": timing,
        "plotting": {"max_2d_axis": plot_max_axis, "max_surface_axis": surface_max_axis,
                     "method": "block maximum for display only",
                     "full_resolution_csv": True, "full_resolution_extrema": True},
        "mode": 2, "currentmode": p["currentmode"], "mesh_nodes": [m, n],
        "node_count": m * n, "load_current_A": float(-load.sum()),
        "node_current_A": float(load[0]) if p["currentmode"] == 1 else None,
        "bump_count": {"VDD": len(p["bumpvdd"]), "VSS": len(p["bumpvss"])},
        "bump_equivalent_r_ohm": p["rz"],
        "branch_r_ohm": p["rz"] * (2 * p["xpn"] + 1) * (2 * p["ypn"] + 1),
        "footprint_convention": "Original mapping retained: X radius=ypn; Y radius=xpn",
        "max_vdd_drop": extreme(vdd_ir, p["xpitch"], p["ypitch"]),
        "max_vss_rise": extreme(vss, p["xpitch"], p["ypitch"]),
        "max_total_loss": extreme(total, p["xpitch"], p["ypitch"]),
        "min_effective_voltage": extreme(effective, p["xpitch"], p["ypitch"], False),
        "max_bump_current": max_bump,
        "original_spec_metrics": {"IRv_mV": irv, "IRh_mV": irh,
                                  "IRv_plus_0p5_IRh_mV": irvh,
                                  "spec": 11.2, "spec_result_A_per_mm2": 11.2 / irvh},
        "checks": {"VDD": pcheck, "VSS": gcheck},
    }
    export_started = perf_counter()
    X, Y = np.meshgrid(np.arange(1, m + 1), np.arange(1, n + 1))
    pd.DataFrame({
        "x_node": X.ravel(), "y_node": Y.ravel(),
        "x_um": X.ravel() * p["xpitch"], "y_um": Y.ravel() * p["ypitch"],
        "vdd_node_injection_A": load, "vss_node_injection_A": -load,
        "VDD_V": vdd.ravel(), "VSS_V": vss.ravel(),
        "VDD_drop_mV": vdd_ir.ravel() * 1000, "VSS_rise_mV": vss.ravel() * 1000,
        "total_loss_mV": total.ravel() * 1000,
        "effective_voltage_V": effective.ravel(),
    }).to_csv(out / "node_results.csv", index=False, encoding="utf-8-sig")
    bumpcurrent.to_csv(out / "bump_current.csv", index=False, encoding="utf-8-sig")
    timing["csv_export_s"] = perf_counter() - export_started
    lines = [f"Current mode: {p['currentmode']}; total load: {-load.sum():.9f} A",
             f"VDD max drop: {vdd_ir.max() * 1000:.6f} mV",
             f"VSS max rise: {vss.max() * 1000:.6f} mV",
             f"Total max loss: {total.max() * 1000:.6f} mV "
             f"({total.max() / p['powerv'] * 100:.6f}%)",
             f"Minimum effective voltage: {effective.min():.9f} V"]
    for rail in ("VDD", "VSS"):
        b = max_bump[rail]
        lines.append(f"{rail} max |Bump current|: {abs(b['current_mA']):.6f} mA "
                     f"at ({b['x_node']},{b['y_node']})")
    lines.extend((f"IRv={irv:.9f} mV", f"IRh={irh:.9f} mV",
                  f"IRv+0.5*IRh={irvh:.9f} mV", f"11.2/(IRv+0.5*IRh)={11.2 / irvh:.9f} A/mm2",
                  f"VDD current balance error: {pcheck['current_balance_error_A']:.3e} A",
                  f"VSS current balance error: {gcheck['current_balance_error_A']:.3e} A"))
    plot_started = perf_counter()
    plot_results(p, vdd_ir, vss, total, bumpcurrent, summary, out,
                  plot_max_axis, surface_max_axis)
    timing["plot_and_save_s"] = perf_counter() - plot_started
    timing["total_run_s_before_show"] = perf_counter() - run_started
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2),
                                      encoding="utf-8")
    lines.extend((f"Solver: {timing['solver_used']}; parallel VDD/VSS: {parallel}",
                  f"Numeric wall time: {timing['numeric_wall_s']:.6f} s",
                  f"CSV export time: {timing['csv_export_s']:.6f} s",
                  f"Plot/save time: {timing['plot_and_save_s']:.6f} s"))
    text = "\n".join(lines) + "\n"
    print(text, end="")
    (out / "run_summary.txt").write_text(text, encoding="utf-8")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", nargs="?", default=str(Path(__file__).resolve().parent / "pginfo_components.ini"))
    parser.add_argument("--out", default="results", help="Output directory")
    parser.add_argument("--serial", action="store_true", help="Use serial rail solving (default: parallel)")
    parser.add_argument("--solver", choices=("auto", "direct", "amg"), default="auto")
    parser.add_argument("--rtol", type=float, default=1e-10, help="Relative CG residual tolerance")
    parser.add_argument("--maxiter", type=int, default=1000)
    parser.add_argument("--amg-threshold", type=int, default=250000,
                        help="Auto uses CG+AMG at/above this node count if PyAMG is installed")
    parser.add_argument("--plot-max-axis", type=int, default=240)
    parser.add_argument("--surface-max-axis", type=int, default=50)
    args = parser.parse_args()
    run(args.config, args.out, not args.serial, args.solver, args.rtol, args.maxiter,
        args.amg_threshold, args.plot_max_axis, args.surface_max_axis)
    plt.show()


if __name__ == "__main__":
    main()
