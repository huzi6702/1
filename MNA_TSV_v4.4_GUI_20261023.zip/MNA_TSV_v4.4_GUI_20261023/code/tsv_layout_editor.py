#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline desktop TSV component editor. Run with Python (Tkinter required)."""
import argparse
import copy
import io
import json
import math
import os
import subprocess
import sys
import tkinter as tk
from collections import Counter
from configparser import ConfigParser
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from tsv_components import (SCHEMA, compile_components, expand_components,
                            finite, import_bump_positions, integer, load_layout,
                            normalize_layout, physical_tsvs, read_meshes,
                            save_project, write_mapping)
from tsv_template_io import load_templates, merge_templates, save_templates

HERE = Path(__file__).resolve().parent
RED, BLUE, GREEN = '#c33b42', '#2867b2', '#15846d'
MAX_RENDER_POINTS = 16000
MAX_LINK_LINES = 1200
MAX_NODE_MARKERS = 1200
MAX_NODE_LABELS = 300
DRAG_FRAME_MS = 16


def read_project(path):
    path = Path(path).resolve()
    config = ConfigParser()
    if not config.read(path, encoding='utf-8-sig'):
        raise FileNotFoundError(path)
    if not config.has_section('components'):
        raise ValueError('请打开组件模式的 INI。旧配置的 Bump 中心可用“导入 Bump 位置”导入。')
    layers = read_meshes(config)
    layout = normalize_layout(load_layout(path.parent / config.get('components', 'layout')), len(layers))
    return config, layout, layers


def next_id(layout, prefix='C'):
    names = {p['id'] for p in layout['placements']}
    index = 1
    while f'{prefix}{index:04d}' in names:
        index += 1
    return f'{prefix}{index:04d}'


def make_array(layout, prototype, nx, ny, dx, dy):
    nx, ny = integer(nx, 'X个数'), integer(ny, 'Y个数')
    dx, dy = finite(dx, 'X步长'), finite(dy, 'Y步长')
    if nx * ny > 10000:
        raise ValueError('一次最多放置 10000 个组件')
    if (nx > 1 and dx == 0) or (ny > 1 and dy == 0):
        raise ValueError('多个组件的阵列步长不能为零')
    result = copy.deepcopy(layout)
    for iy in range(ny):
        for ix in range(nx):
            p = dict(prototype, id=next_id(result), x_um=prototype['x_um'] + ix * dx,
                     y_um=prototype['y_um'] + iy * dy)
            result['placements'].append(p)
    return result


def component_bounds(placement, component_type):
    w = (component_type['cols'] - 1) * component_type['pitch_x_um'] / 2
    h = (component_type['rows'] - 1) * component_type['pitch_y_um'] / 2
    if placement.get('rotation_deg', 0) in (90, 270):
        w, h = h, w
    return (placement['x_um'] - w, placement['y_um'] - h,
            placement['x_um'] + w, placement['y_um'] + h)


def editable_ids(layout, interface):
    return {p['id'] for p in layout['placements'] if p['interface'] == interface}


def move_components(layout, identities, dx, dy):
    result = copy.deepcopy(layout)
    dx, dy = finite(dx, 'X 位移'), finite(dy, 'Y 位移')
    for p in result['placements']:
        if p['id'] in identities:
            p['x_um'] = round(p['x_um'] + dx, 9)
            p['y_um'] = round(p['y_um'] + dy, 9)
    return result


def copy_components(layout, identities, target_interface, dx=0, dy=0):
    result = copy.deepcopy(layout)
    created = []
    for old in layout['placements']:
        if old['id'] not in identities:
            continue
        p = dict(old, id=next_id(result), interface=target_interface,
                 x_um=old['x_um'] + dx, y_um=old['y_um'] + dy)
        result['placements'].append(p)
        created.append(p['id'])
    return result, created


def components_in_box(layout, interface, bounds):
    x1, y1, x2, y2 = bounds
    left, right = sorted((x1, x2))
    bottom, top = sorted((y1, y2))
    result = set()
    for p in layout['placements']:
        if p['interface'] != interface:
            continue
        a, b, c, d = component_bounds(p, layout['types'][p['type']])
        if c >= left and a <= right and d >= bottom and b <= top:
            result.add(p['id'])
    return result


class Editor:
    def __init__(self, root, path, container=None, manage_window=True, bind_shortcuts=True):
        self.root = root
        self.container = root if container is None else container
        self.manage_window = manage_window
        self.path = Path(path).resolve()
        self.config, self.layout, self.layers = read_project(self.path)
        self.selected, self.primary = set(), None
        self.selection_box = None
        self._syncing_table = False
        self.undo_stack, self.redo_stack = [], []
        self.dirty = False
        self.scale, self.ox, self.oy = 1., 30., 30.
        self.drag = None
        self.pan = None
        self.expanded = None
        self.geometry_error = None
        self.process, self.logfile = None, None
        if manage_window:
            root.title('MNA TSV 组件布局器 v4.2')
            root.geometry('1420x900')
            root.minsize(1140, 760)
        style = ttk.Style(root)
        if 'clam' in style.theme_names():
            style.theme_use('clam')
        style.configure('TButton', padding=(6, 4))
        style.configure('TLabelframe.Label', foreground='#263e56')
        self.vars = {key: tk.StringVar(master=root) for key in (
            'type', 'new_type', 'rows', 'cols', 'pitch_x_um', 'pitch_y_um', 'r_ohm',
            'interface', 'rail', 'rotation_deg', 'x_um', 'y_um', 'id',
            'nx', 'ny', 'step_x', 'step_y', 'mode', 'endpoint', 'status', 'copy_target',
            'template_policy')}
        for key, value in {'interface':'source', 'rail':'vdd', 'rotation_deg':'0',
                           'x_um':'100', 'y_um':'100', 'nx':'3', 'ny':'2',
                           'step_x':'100', 'step_y':'80', 'mode':'select',
                           'endpoint':'upper', 'template_policy':'同名自动改名'}.items():
            self.vars[key].set(value)
        self.show_tsv = tk.BooleanVar(master=root, value=True)
        self.show_links = tk.BooleanVar(master=root, value=True)
        self.show_grid = tk.BooleanVar(master=root, value=True)
        self.show_other_layers = tk.BooleanVar(master=root, value=True)
        self.build_ui()
        self.refresh_types()
        self.refresh_interfaces()
        self.rebuild()
        self.root.after(120, self.fit)
        if bind_shortcuts:
            root.bind('<Control-z>', lambda e: self.undo())
            root.bind('<Control-y>', lambda e: self.redo())
            root.bind('<Control-s>', lambda e: self.save())
            root.bind('<Control-a>', self.select_all_key)
            root.bind('<Control-A>', self.select_all_key)
            root.bind('<Delete>', self.delete_key)
            root.bind('<KeyPress-f>', self.fit_key)
            root.bind('<KeyPress-F>', self.fit_key)
        if manage_window:
            root.protocol('WM_DELETE_WINDOW', self.close)

    def guarded(self, function):
        try:
            return function()
        except (ValueError, KeyError, OSError, RuntimeError, TypeError) as exc:
            messagebox.showerror('未完成操作', str(exc), parent=self.root)
            return None

    def build_ui(self):
        toolbar = self.toolbar = ttk.Frame(self.container, padding=7)
        toolbar.pack(fill='x')
        for text, command in [('打开 INI', self.open), ('保存', self.save),
            ('另存为 INI+布局', self.save_as), ('网格 / 负载', self.edit_config),
            ('导入 Bump 位置', self.import_bumps), ('校核 / 映射导出', self.validate),
            ('运行 IR 求解', self.run), ('撤销', self.undo), ('重做', self.redo)]:
            button = ttk.Button(toolbar, text=text, command=lambda f=command:self.guarded(f))
            button.pack(side='left', padx=2)
            if text == '运行 IR 求解':
                self.run_button = button
        body = ttk.Panedwindow(self.container, orient='horizontal')
        body.pack(fill='both', expand=True, padx=7)
        sidebar = ttk.Frame(body)
        sidebar.rowconfigure(0, weight=1)
        sidebar.columnconfigure(0, weight=1)
        self.sidebar_canvas = tk.Canvas(sidebar, width=310, highlightthickness=0,
            background=ttk.Style(self.root).lookup('TFrame', 'background'))
        self.sidebar_canvas.grid(row=0, column=0, sticky='nsew')
        scrollbar = ttk.Scrollbar(sidebar, orient='vertical', command=self.sidebar_canvas.yview)
        scrollbar.grid(row=0, column=1, sticky='ns')
        self.sidebar_canvas.configure(yscrollcommand=scrollbar.set, yscrollincrement=24)
        left = ttk.Frame(self.sidebar_canvas, padding=(0, 0, 8, 0))
        self.sidebar_frame = left
        sidebar_window = self.sidebar_canvas.create_window((0, 0), window=left, anchor='nw')
        left.bind('<Configure>', lambda e:self.sidebar_canvas.configure(
            scrollregion=self.sidebar_canvas.bbox('all'), width=left.winfo_reqwidth()))
        self.sidebar_canvas.bind('<Configure>', lambda e:self.sidebar_canvas.itemconfigure(
            sidebar_window, width=e.width))
        self._sidebar_wheel_delta = 0
        middle = ttk.Frame(body)
        body.add(sidebar, weight=0)
        body.add(middle, weight=1)
        box = ttk.LabelFrame(left, text='1  组件模板（修改会更新全部同类组件）', padding=8)
        box.pack(fill='x')
        self.type_combo = ttk.Combobox(box, textvariable=self.vars['type'], state='readonly', width=27)
        self.type_combo.grid(row=0, column=0, columnspan=2, sticky='ew', pady=3)
        self.type_combo.bind('<<ComboboxSelected>>', lambda e:self.load_type())
        for row, (key, label) in enumerate((('rows','TSV 行数（Y）'), ('cols','TSV 列数（X）'),
                    ('pitch_x_um','X pitch / μm'), ('pitch_y_um','Y pitch / μm'),
                    ('r_ohm','单根 TSV 电阻 / Ω')), 1):
            ttk.Label(box, text=label).grid(row=row, column=0, sticky='w', pady=2)
            ttk.Entry(box, textvariable=self.vars[key], width=13).grid(row=row, column=1, sticky='ew')
        ttk.Button(box, text='应用模板参数', command=lambda:self.guarded(self.apply_type)).grid(row=6,column=0,columnspan=2,sticky='ew',pady=4)
        ttk.Entry(box, textvariable=self.vars['new_type'], width=16).grid(row=7,column=0,sticky='ew')
        ttk.Button(box, text='复制为新类型', command=lambda:self.guarded(self.new_type)).grid(row=7,column=1,sticky='ew')
        self.type_info = ttk.Label(box, text='', wraplength=280, foreground=GREEN)
        self.type_info.grid(row=8,column=0,columnspan=2,sticky='w',pady=4)
        template_tools = ttk.Frame(box)
        template_tools.grid(row=9,column=0,columnspan=2,sticky='ew',pady=2)
        ttk.Button(template_tools,text='导入模板',command=lambda:self.guarded(self.import_templates)).pack(side='left')
        export = ttk.Menubutton(template_tools,text='导出模板')
        export.pack(side='left',padx=3)
        menu = tk.Menu(export,tearoff=False)
        menu.add_command(label='导出当前模板',command=lambda:self.guarded(lambda:self.export_templates(True)))
        menu.add_command(label='导出全部模板',command=lambda:self.guarded(lambda:self.export_templates(False)))
        export['menu'] = menu
        ttk.Combobox(template_tools,textvariable=self.vars['template_policy'],state='readonly',width=15,
            values=('同名自动改名','保留已有同名','覆盖同名（影响已有）')).pack(side='left')
        box = ttk.LabelFrame(left, text='2  放置 / 编辑组件（中心物理坐标）', padding=8)
        box.pack(fill='x', pady=7)
        for row, (key, label, values) in enumerate((
                ('interface','编辑接口',[]), ('rail','放置电源轨',['vdd','vss']),
                ('rotation_deg','逆时针旋转',['0','90','180','270']))):
            ttk.Label(box, text=label).grid(row=row,column=0,sticky='w')
            cb = ttk.Combobox(box,textvariable=self.vars[key],values=values,state='readonly',width=18)
            cb.grid(row=row,column=1,sticky='ew',pady=2)
            if key == 'interface':
                self.interface_combo = cb
            if key == 'interface':
                cb.bind('<<ComboboxSelected>>',lambda e:self.filter_changed())
        for row, (key,label) in enumerate((('id','组件 ID'),('x_um','中心 X / μm'),('y_um','中心 Y / μm')),3):
            ttk.Label(box,text=label).grid(row=row,column=0,sticky='w')
            ttk.Entry(box,textvariable=self.vars[key],width=19).grid(row=row,column=1,sticky='ew',pady=2)
        row = ttk.Frame(box)
        row.grid(row=6,column=0,columnspan=2,sticky='ew',pady=4)
        for text,mode in [('选择 / 拖动','select'),('点击放置','place')]:
            ttk.Radiobutton(row,text=text,variable=self.vars['mode'],value=mode).pack(side='left')
        row = ttk.Frame(box)
        row.grid(row=7,column=0,columnspan=2,sticky='ew')
        for text,command in [('新增',self.add),('套用当前模板',self.update_selected),('复制',self.duplicate),('删除',self.delete)]:
            ttk.Button(row,text=text,command=lambda f=command:self.guarded(f)).pack(side='left',padx=1)
        ttk.Button(box,text='更新位置/属性',command=lambda:self.guarded(self.update_properties)).grid(
            row=8,column=0,columnspan=2,sticky='ew',pady=(4,0))
        ttk.Label(box,text='仅更换模板；位置、轨别和方向保持。',
                  wraplength=300,foreground='#556677').grid(row=9,column=0,columnspan=2,sticky='w',pady=(4,0))
        box = ttk.LabelFrame(left,text='3  批量阵列（使用上方起点与类型）',padding=8)
        box.pack(fill='x')
        for row,(key,label) in enumerate((('nx','X 方向组件数'),('ny','Y 方向组件数'),
                                         ('step_x','组件 X 步长 / μm'),('step_y','组件 Y 步长 / μm'))):
            ttk.Label(box,text=label).grid(row=row,column=0,sticky='w')
            ttk.Entry(box,textvariable=self.vars[key],width=12).grid(row=row,column=1,sticky='ew',pady=2)
        ttk.Button(box,text='生成组件阵列（新增）',command=lambda:self.guarded(self.batch)).grid(row=4,column=0,columnspan=2,sticky='ew',pady=4)
        ttk.Label(left,text='红：VDD  蓝：VSS  绿：已选  灰：其他层\nCtrl 点击多选；空白处拖框选择。\nCtrl+A 全选当前接口；Delete 删除。\n拖动任一已选组件，可整体移动。\n滚轮缩放；右键 / 中键平移。',wraplength=300,foreground='#556677').pack(fill='x',pady=8)
        self.bind_sidebar_scrolling(self.sidebar_canvas)
        tools = ttk.Frame(middle)
        tools.pack(fill='x',pady=(0,5))
        ttk.Label(tools,text='F：适配视图',foreground='#556677').pack(side='left',padx=(0,7))
        for label,var in [('Mesh',self.show_grid),('TSV',self.show_tsv),('连接线',self.show_links),
                          ('灰色叠加其他层',self.show_other_layers)]:
            ttk.Checkbutton(tools,text=label,variable=var,command=self.draw).pack(side='left',padx=5)
        ttk.Label(tools,text='查看端点：').pack(side='left')
        for text,value in [('上端 / layer0','upper'),('下端','lower')]:
            ttk.Radiobutton(tools,text=text,variable=self.vars['endpoint'],value=value,command=self.draw).pack(side='left')
        copies = ttk.Frame(middle)
        copies.pack(fill='x', pady=(0, 5))
        ttk.Label(copies, text='选中组件原位复制到：').pack(side='left')
        self.copy_target_combo = ttk.Combobox(copies, textvariable=self.vars['copy_target'],
                                              state='readonly', width=12)
        self.copy_target_combo.pack(side='left', padx=5)
        self.copy_button = ttk.Button(copies, text='复制到另一接口',
                                      command=lambda:self.guarded(self.copy_to_interface))
        self.copy_button.pack(side='left')
        ttk.Label(copies, text='  坐标 / 模板 / 电源轨 / 方向保持一致；生成新 ID。',
                  foreground='#556677').pack(side='left')
        self.canvas = tk.Canvas(middle,background='#f5f8fb',highlightthickness=1,highlightbackground='#cbd5df')
        self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<Configure>',self.canvas_configured)
        self.canvas.bind('<Button-1>',self.press)
        self.canvas.bind('<B1-Motion>',self.motion)
        self.canvas.bind('<ButtonRelease-1>',self.release)
        self.canvas.bind('<MouseWheel>',self.zoom)
        self.canvas.bind('<Button-4>',lambda e:self.zoom(e,1))
        self.canvas.bind('<Button-5>',lambda e:self.zoom(e,-1))
        for button in (2,3):
            self.canvas.bind(f'<Button-{button}>',self.pan_start)
            self.canvas.bind(f'<B{button}-Motion>',self.pan_motion)
        self.canvas.bind('<Motion>',self.hover)
        self.info = ttk.Label(middle,text='',wraplength=1000,justify='left',padding=6)
        self.info.pack(fill='x')
        self.table = ttk.Treeview(middle,columns=('type','xy','tsv','nodes'),show='tree headings',height=6,selectmode='extended')
        for key,label,width in (('#0','组件 ID',155),('type','类型',140),('xy','中心 X,Y / μm',155),
                                ('tsv','TSV 数',80),('nodes','下 / 上节点数',130)):
            self.table.heading(key,text=label)
            self.table.column(key,width=width,stretch=True)
        self.table.pack(fill='x')
        self.table.bind('<<TreeviewSelect>>',self.table_select)
        ttk.Label(self.container,textvariable=self.vars['status'],anchor='w',padding=7).pack(fill='x')

    def bind_sidebar_scrolling(self, widget):
        # Keep wheel handling local; entries and comboboxes retain their Tk bindings.
        if widget.winfo_class() not in ('Entry', 'TEntry', 'Text', 'TCombobox', 'Spinbox', 'TSpinbox'):
            widget.bind('<MouseWheel>', self.scroll_sidebar)
            widget.bind('<Button-4>', self.scroll_sidebar)
            widget.bind('<Button-5>', self.scroll_sidebar)
        widget.bind('<FocusIn>', self.reveal_sidebar_focus, add='+')
        for child in widget.winfo_children():
            self.bind_sidebar_scrolling(child)

    def scroll_sidebar(self, event):
        if getattr(event, 'num', None) in (4, 5):
            steps = -1 if event.num == 4 else 1
        else:
            self._sidebar_wheel_delta -= event.delta
            steps = int(self._sidebar_wheel_delta / 120)
            self._sidebar_wheel_delta -= steps * 120
        if steps:
            self.sidebar_canvas.yview_scroll(steps, 'units')
        return 'break'

    def reveal_sidebar_focus(self, event):
        # Tab navigation must also expose controls below the viewport.
        top = event.widget.winfo_rooty() - self.sidebar_frame.winfo_rooty()
        bottom = top + event.widget.winfo_height()
        visible_top = self.sidebar_canvas.canvasy(0)
        height = self.sidebar_canvas.winfo_height()
        if top < visible_top:
            target = max(0, top - 6)
        elif bottom > visible_top + height:
            target = max(0, bottom - height + 6)
        else:
            return
        self.sidebar_canvas.yview_moveto(target / max(1, self.sidebar_frame.winfo_height()))

    def checkpoint(self):
        self.undo_stack.append(copy.deepcopy(self.layout))
        self.undo_stack = self.undo_stack[-60:]
        self.redo_stack.clear()
        self.dirty = True

    def apply_layout(self, candidate):
        self.cancel_drag()
        candidate = normalize_layout(candidate, len(self.layers))
        expanded = expand_components(candidate, self.layers)
        self.checkpoint()
        self.layout = candidate
        self.rebuild(expanded=expanded)

    def refresh_types(self):
        values = list(self.layout['types'])
        self.type_combo['values'] = values
        if self.vars['type'].get() not in values:
            self.vars['type'].set(values[0])
        self.load_type()

    def load_type(self):
        name = self.vars['type'].get()
        t = self.layout['types'][name]
        for key in ('rows','cols','pitch_x_um','pitch_y_um','r_ohm'):
            self.vars[key].set(str(t[key]))
        self.type_info.config(text=f"{t['rows']*t['cols']} 根 / 组件；TSV 中心跨度 "
            f"{(t['cols']-1)*t['pitch_x_um']:g} × {(t['rows']-1)*t['pitch_y_um']:g} μm\n"
            f"同端点等电位时 R/N = {t['r_ohm']/(t['rows']*t['cols']):.6g} Ω")

    def edited_type(self):
        return {key:self.vars[key].get() for key in ('rows','cols','pitch_x_um','pitch_y_um','r_ohm')}

    def apply_type(self):
        layout = copy.deepcopy(self.layout)
        layout['types'][self.vars['type'].get()] = self.edited_type()
        self.apply_layout(layout)
        self.load_type()

    def new_type(self):
        name = self.vars['new_type'].get().strip()
        if not name or name in self.layout['types']:
            raise ValueError('新类型名必须非空且不与已有名称重复')
        layout = copy.deepcopy(self.layout)
        layout['types'][name] = self.edited_type()
        self.apply_layout(layout)
        self.vars['type'].set(name)
        self.refresh_types()

    def import_templates(self):
        path = filedialog.askopenfilename(parent=self.root,initialdir=self.path.parent,
            title='导入独立模板，或提取布局文件中的模板',filetypes=[('TSV 模板 / 布局 JSON','*.json')])
        if not path:
            return
        policies = {'同名自动改名':'rename','保留已有同名':'keep','覆盖同名（影响已有）':'replace'}
        candidate, report = merge_templates(self.layout,load_templates(path),
                                            policies[self.vars['template_policy'].get()])
        if report['added'] or report['replaced']:
            self.apply_layout(candidate)
            self.vars['type'].set((report['added'] + report['replaced'])[0])
            self.refresh_types()
        self.vars['status'].set(f"模板导入：新增 {len(report['added'])}，覆盖 {len(report['replaced'])}，"
            f"跳过 {len(report['skipped'])}。摆放坐标不变；保存项目后保留导入的模板。")

    def export_templates(self, current_only=False):
        names = [self.vars['type'].get()] if current_only else None
        path = filedialog.asksaveasfilename(parent=self.root,initialdir=self.path.parent,
            title='导出已应用的模板参数',initialfile='tsv_templates.json',defaultextension='.json',
            filetypes=[('独立 TSV 模板库','*.json')])
        if path:
            result = save_templates(path,self.layout['types'],names)
            self.vars['status'].set(f"已导出 {len(result['types'])} 个模板到 {path}；仅包含模板参数，不含摆放位置。")

    def refresh_interfaces(self):
        values = ['source'] + [f'{i}_{i+1}' for i in range(len(self.layers)-1)]
        values += [p['interface'] for p in self.layout['placements'] if p['interface'] not in values]
        self.interface_combo['values'] = list(dict.fromkeys(values))
        if self.vars['interface'].get() not in values:
            self.vars['interface'].set('source')
        self.refresh_copy_targets()

    def refresh_copy_targets(self):
        values = [v for v in self.interface_combo['values'] if v != self.vars['interface'].get()]
        self.copy_target_combo['values'] = values
        if self.vars['copy_target'].get() not in values:
            self.vars['copy_target'].set(values[0] if values else '')
        self.copy_button.configure(state='normal' if values else 'disabled')

    def visible(self):
        return [p for p in self.layout['placements'] if p['interface']==self.vars['interface'].get()]

    def background_components(self):
        if not self.show_other_layers.get():
            return []
        return [p for p in self.layout['placements'] if p['interface'] != self.vars['interface'].get()]

    def filter_changed(self):
        self.cancel_drag()
        self.selected, self.primary = set(), None
        self.drag = self.selection_box = None
        self.refresh_copy_targets()
        self.rebuild()

    def active_selection(self):
        return self.selected & editable_ids(self.layout, self.vars['interface'].get())

    def editing_text(self, event):
        return event.widget.winfo_class() in ('Entry', 'TEntry', 'Text', 'TCombobox', 'Spinbox', 'TSpinbox')

    def select_all_key(self, event):
        if self.editing_text(event):
            return None
        self.set_selection(editable_ids(self.layout, self.vars['interface'].get()))
        return 'break'

    def delete_key(self, event):
        if self.editing_text(event):
            return None
        if self.active_selection():
            self.guarded(self.delete)
        return 'break'

    def prototype(self):
        return {'id':self.vars['id'].get().strip() or next_id(self.layout),
                'type':self.vars['type'].get(), 'interface':self.vars['interface'].get(),
                'rail':self.vars['rail'].get(), 'rotation_deg':int(self.vars['rotation_deg'].get()),
                'x_um':finite(self.vars['x_um'].get(),'中心 X'),
                'y_um':finite(self.vars['y_um'].get(),'中心 Y')}

    def add(self):
        p = self.prototype()
        # New placement always gets a fresh ID when the form shows a selected ID.
        if p['id'] in self.selected:
            p['id'] = next_id(self.layout)
        layout = copy.deepcopy(self.layout)
        layout['placements'].append(p)
        self.apply_layout(layout)
        self.select(p['id'])

    def update_selected(self):
        """Assign the selected stored template without changing placement fields."""
        identities = self.active_selection()
        if not identities:
            raise ValueError('请先选择要套用模板的组件')
        name = self.vars['type'].get()
        if name not in self.layout['types']:
            raise ValueError('请先选择一个有效的组件模板')
        if all(p['type'] == name for p in self.layout['placements'] if p['id'] in identities):
            self.vars['status'].set(f'所选组件已使用模板 {name}，无需更改。')
            return
        layout = copy.deepcopy(self.layout)
        for p in layout['placements']:
            if p['id'] in identities:
                p['type'] = name
        self.apply_layout(layout)
        self.set_selection(identities, self.primary)
        self.vars['status'].set(f'已将 {len(identities)} 个组件套用模板 {name}；'
                                '位置、接口、轨别、方向和 ID 保留；Ctrl+S 保存。')

    def update_properties(self):
        """Commit the placement form; multiple selections translate as a group."""
        identities = self.active_selection()
        if not identities:
            raise ValueError('请先选择一个组件')
        if len(identities) > 1:
            anchor = next(p for p in self.layout['placements'] if p['id'] == self.primary)
            self.apply_layout(move_components(self.layout, identities,
                finite(self.vars['x_um'].get(), '中心 X') - anchor['x_um'],
                finite(self.vars['y_um'].get(), '中心 Y') - anchor['y_um']))
            self.set_selection(identities, self.primary)
            return
        p = self.prototype()
        layout = copy.deepcopy(self.layout)
        layout['placements'] = [p if old['id'] in identities else old for old in layout['placements']]
        self.apply_layout(layout)
        self.select(p['id'])

    def duplicate(self):
        identities = self.active_selection()
        if not identities:
            raise ValueError('请先选择一个组件')
        layout, created = copy_components(self.layout, identities, self.vars['interface'].get(), dx=10)
        self.apply_layout(layout)
        self.set_selection(created)

    def copy_to_interface(self):
        identities = self.active_selection()
        if not identities:
            raise ValueError('请先选择要复制的组件')
        target = self.vars['copy_target'].get()
        if target == self.vars['interface'].get() or target not in self.copy_target_combo['values']:
            raise ValueError('请选择另一个有效的目标接口')
        layout, created = copy_components(self.layout, identities, target)
        self.apply_layout(layout)
        self.set_selection(identities, self.primary)
        self.vars['status'].set(f'已原位复制 {len(created)} 个组件到 {target}；当前接口与选择保持不变，目标层以灰色显示。')

    def delete(self):
        identities = self.active_selection()
        if not identities:
            raise ValueError('请先选择一个组件')
        layout = copy.deepcopy(self.layout)
        layout['placements'] = [p for p in layout['placements'] if p['id'] not in identities]
        self.apply_layout(layout)
        self.set_selection(set())

    def batch(self):
        self.apply_layout(make_array(self.layout,self.prototype(),self.vars['nx'].get(),
                                    self.vars['ny'].get(),self.vars['step_x'].get(),self.vars['step_y'].get()))

    def select(self, identity):
        self.set_selection({identity}, identity)

    def set_selection(self, identities, primary=None, redraw=True):
        self.selected = set(identities) & editable_ids(self.layout, self.vars['interface'].get())
        if primary not in self.selected:
            primary = self.primary if self.primary in self.selected else next(
                (p['id'] for p in self.layout['placements'] if p['id'] in self.selected), None)
        self.primary = primary
        self._syncing_table = True
        try:
            self.table.selection_set(tuple(p['id'] for p in self.layout['placements']
                                           if p['id'] in self.selected and self.table.exists(p['id'])))
            if primary is not None:
                self.table.focus(primary)
                self.table.see(primary)
                p = next(p for p in self.layout['placements'] if p['id'] == primary)
                for key in ('id','type','rail','rotation_deg','x_um','y_um'):
                    self.vars[key].set(str(p[key]))
                self.load_type()
            else:
                self.vars['id'].set('')
        finally:
            self._syncing_table = False
        if redraw:
            self.draw()

    def table_select(self,event=None):
        if self._syncing_table:
            return
        identities = set(self.table.selection())
        if identities != self.selected:
            self.set_selection(identities, self.table.focus())

    def rebuild(self, expanded=None):
        self.geometry_error = None
        try:
            self.expanded = expanded if expanded is not None else expand_components(self.layout,self.layers)
        except (ValueError,KeyError,TypeError) as exc:
            self.expanded = None
            self.geometry_error = str(exc)
        self.selected &= editable_ids(self.layout, self.vars['interface'].get())
        if self.primary not in self.selected:
            self.primary = next(iter(sorted(self.selected)), None)
        self._syncing_table = True
        self.table.delete(*self.table.get_children())
        summaries = {s['component_id']:s for s in self.expanded['summaries']} if self.expanded else {}
        for p in self.visible():
            t = self.layout['types'][p['type']]
            s = summaries.get(p['id'])
            self.table.insert('', 'end',iid=p['id'],text=p['id'],values=(p['type'],
                f"{p['x_um']:g}, {p['y_um']:g}",t['rows']*t['cols'],
                (f"源 / {s['unique_upper_nodes']}" if p['interface']=='source' else
                 f"{s['unique_lower_nodes']} / {s['unique_upper_nodes']}") if s else '越界 / 无效'))
        self.table.selection_set(tuple(p['id'] for p in self.visible() if p['id'] in self.selected))
        self._syncing_table = False
        count = sum(self.layout['types'][p['type']]['rows']*self.layout['types'][p['type']]['cols'] for p in self.layout['placements'])
        self.vars['status'].set(f"{'* 未保存 | ' if self.dirty else ''}{self.path.name} | "
            f"{len(self.layout['placements'])} 个组件 / {count:,} 根 TSV | "
            + (self.geometry_error or '全部 TSV 映射有效；Ctrl+S 保存，Ctrl+Z / Ctrl+Y 撤销 / 重做'))
        self.draw()

    def viewed_layer(self):
        interface = self.vars['interface'].get()
        if interface == 'source':
            return self.layers[0]
        lower,upper = map(int,interface.split('_'))
        return self.layers[lower if self.vars['endpoint'].get()=='lower' else upper]

    def world(self,x,y):
        return (x-self.ox)/self.scale, (self.oy-y)/self.scale

    def screen(self,x,y):
        return self.ox+x*self.scale, self.oy-y*self.scale

    def fit(self):
        xmax = max((l['xgrid']+.5)*l['xpitch'] for l in self.layers)
        ymax = max((l['ygrid']+.5)*l['ypitch'] for l in self.layers)
        w,h = max(200,self.canvas.winfo_width()), max(200,self.canvas.winfo_height())
        self.scale = min((w-85)/xmax,(h-65)/ymax)
        self.ox,self.oy = 45,h-30
        self.draw()

    def fit_key(self,event=None):
        widget=getattr(event,'widget',None)
        if widget is not None and widget.winfo_class() in ('Entry','TEntry','Text','TCombobox','Spinbox','TSpinbox'):
            return None
        # On Tk/Windows Mod1 (0x8) is NumLock; Alt has its own mask.
        # Treating Mod1 as Alt would disable F on most numeric keyboards.
        alt_mask = 0x20000 if sys.platform == 'win32' else 0x0008
        if getattr(event,'state',0) & (0x0004 | alt_mask):
            return None
        self.fit()
        return 'break'

    def draw_component(self, p, background=False):
        c = self.canvas
        t = self.layout['types'][p['type']]
        left, bottom, right, top = component_bounds(p, t)
        x0, y0 = self.screen(left, bottom)
        x1, y1 = self.screen(right, top)
        selected = not background and p['id'] in self.selected
        color = '#b5bdc7' if background else RED if p['rail']=='vdd' else BLUE
        tags = ('component', 'background_component' if background else
                'selected_component' if selected else 'unselected_component')
        options = {'outline': GREEN if selected else color, 'width': 2 if selected else 1, 'tags': tags}
        if background:
            options['dash'] = (3, 2)
        c.create_rectangle(x0-4, y0+4, x1+4, y1-4, **options)
        cx, cy = self.screen(p['x_um'], p['y_um'])
        c.create_line(cx-4,cy,cx+4,cy,fill=color,width=1 if background else 2,tags=tags)
        c.create_line(cx,cy-4,cx,cy+4,fill=color,width=1 if background else 2,tags=tags)
        stride = max(1, math.ceil(t['rows']*t['cols']/getattr(self,'_render_points_per_component',5000)))
        self._display_sampled = getattr(self,'_display_sampled',False) or stride > 1
        if self.show_tsv.get():
            for _,_,x,y in physical_tsvs(p,t,stride):
                xx, yy = self.screen(x,y)
                radius = 1.3 if background else 1.7
                c.create_oval(xx-radius, yy-radius, xx+radius, yy+radius, fill=color, outline='',tags=tags)
        if selected:
            c.create_text(cx,y1-13,text=p['id'],fill=GREEN,font=('TkDefaultFont',10,'bold'),tags=tags)

    def canvas_configured(self, event=None):
        # Label wrapping can resize the canvas after a press. Keep the gesture's
        # retained items until release; world/screen coordinates do not use its size.
        if self.drag or self.selection_box:
            return
        self.draw()

    def draw(self):
        if not hasattr(self,'canvas'):
            return
        self.cancel_drag()
        c = self.canvas
        c.delete('all')
        l = self.viewed_layer()
        px,py,m,n = l['xpitch'],l['ypitch'],l['xgrid'],l['ygrid']
        x0,y0 = self.screen(.5*px,.5*py)
        x1,y1 = self.screen((m+.5)*px,(n+.5)*py)
        c.create_rectangle(x0,y0,x1,y1,fill='#ffffff',outline='#aebfce')
        if self.show_grid.get():
            sx = max(1,math.ceil(7/(px*self.scale)),math.ceil(m/220))
            sy = max(1,math.ceil(7/(py*self.scale)),math.ceil(n/220))
            for ix in range(1,m+1,sx):
                x,_ = self.screen(ix*px,0)
                c.create_line(x,y0,x,y1,fill='#e0e8ef')
            for iy in range(1,n+1,sy):
                _,y = self.screen(0,iy*py)
                c.create_line(x0,y,x1,y,fill='#e0e8ef')
        backgrounds, foregrounds = self.background_components(), self.visible()
        self._render_points_per_component = max(1,MAX_RENDER_POINTS//max(1,len(backgrounds)+len(foregrounds)))
        self._display_sampled = False
        for p in backgrounds:
            self.draw_component(p, background=True)
        for p in foregrounds:
            self.draw_component(p)
        if self.expanded:
            nodes = Counter()
            total_selected = sum(self.layout['types'][p['type']]['rows']*self.layout['types'][p['type']]['cols']
                                 for p in foregrounds if p['id'] in self.selected)
            line_stride = max(1,math.ceil(total_selected/MAX_LINK_LINES))
            line_index = 0
            for r in self.expanded['records']:
                if r['component_id'] not in self.selected:
                    continue
                x,y = (r['xl'],r['yl']) if l['id']==r['lower'] else (r['xu'],r['yu'])
                nodes[r['rail'],x,y] += 1
                if self.show_links.get() and line_index % line_stride == 0:
                    xx,yy = self.screen(r['x_um'],r['y_um'])
                    a,b = self.screen(x*px,y*py)
                    c.create_line(xx,yy,a,b,fill='#d6a052',width=1,tags=('node_detail',))
                line_index += 1
            node_stride = max(1,math.ceil(len(nodes)/MAX_NODE_MARKERS))
            label_stride = max(1,math.ceil(len(nodes)/MAX_NODE_LABELS))
            for index,((rail,x,y),count) in enumerate(nodes.items()):
                if index % node_stride:
                    continue
                a,b = self.screen(x*px,y*py)
                color = RED if rail == 'vdd' else BLUE
                c.create_rectangle(a-4,b-4,a+4,b+4,outline=color,width=2,tags=('node_detail',))
                if index % label_stride == 0:
                    c.create_text(a+6,b+(-7 if rail=='vdd' else 7),text=str(count),anchor='w',
                                  fill=color,font=('TkDefaultFont',9,'bold'),tags=('node_detail',))
        if self.selection_box:
            box = self.selection_box
            a,b = self.screen(*box['start'])
            d,e = self.screen(*box['end'])
            c.create_rectangle(a,b,d,e,outline=GREEN,width=2,dash=(4,3),tags=('selection_box',))
        c.create_text(12,12,anchor='nw',fill='#304e68',text=f"编辑接口 {self.vars['interface'].get()} | "
            f"VDD + VSS | 查看 Layer {l['id']} | Mesh {m}×{n}, pitch {px:g}×{py:g} μm | "
            f"已选 {len(self.selected)}；灰色组件不可选"+
            (' | 点阵显示降采样' if self._display_sampled else ''))
        warnings = ('\n'+'\n'.join(self.expanded['warnings'])) if self.expanded and self.expanded['warnings'] else ''
        if len(self.selected) == 1 and self.expanded:
            summary = next((s for s in self.expanded['summaries'] if s['component_id']==self.primary),None)
            if summary:
                endpoint = (f"理想 Bump → layer0 的 {summary['unique_upper_nodes']} 个节点；"
                            if summary['interface']=='source' else
                            f"下端 {summary['unique_lower_nodes']} 个节点 / 上端 {summary['unique_upper_nodes']} 个节点；")
                self.info.config(text=f"{self.primary}：{summary['tsv_count']} 根 TSV；"+endpoint+
                    f"{summary['unique_node_pairs']} 对不同端点；同端点对最多 {summary['max_tsvs_same_node_pair']} 根；"
                    f"最大吸附距离 {summary['max_snap_distance_um']:.4g} μm。"+warnings)
        elif self.selected:
            count = sum(self.layout['types'][p['type']]['rows']*self.layout['types'][p['type']]['cols']
                        for p in self.visible() if p['id'] in self.selected)
            self.info.config(text=f"已选 {len(self.selected)} 个组件 / {count} 根 TSV。拖动任一已选组件可整体移动；"
                "“套用当前模板”批量换模板；“更新位置/属性”按主组件 X/Y 平移；Delete 删除。"+warnings)
        else:
            self.info.config(text=self.geometry_error or
                '当前接口的 VDD / VSS 均可选；Ctrl 点击多选、空白处拖框、Ctrl+A 全选。灰色层仅用于对齐，不可选择。')
    def press(self,event):
        self.cancel_drag()
        self.canvas.focus_set()
        x,y = self.world(event.x,event.y)
        if self.vars['mode'].get()=='place':
            self.vars['x_um'].set(f'{x:.6f}')
            self.vars['y_um'].set(f'{y:.6f}')
            self.vars['id'].set(next_id(self.layout))
            self.guarded(self.add)
            return
        hits = []
        for p in self.visible():
            a,b,d,e = component_bounds(p,self.layout['types'][p['type']])
            margin = 7/self.scale
            if a-margin<=x<=d+margin and b-margin<=y<=e+margin:
                hits.append(p)
        control, shift = bool(event.state & 0x0004), bool(event.state & 0x0001)
        if hits:
            p = min(hits,key=lambda p:(p['x_um']-x)**2+(p['y_um']-y)**2)
            if control:
                chosen = self.selected ^ {p['id']}
                self.set_selection(chosen, p['id'] if p['id'] in chosen else None)
                return
            if shift:
                self.set_selection(self.selected | {p['id']},p['id'])
                return
            identities = self.selected if p['id'] in self.selected else {p['id']}
            self.set_selection(identities,p['id'],redraw=identities != self.selected)
            self.drag = {'ids':self.active_selection(),'start':(x,y),
                         'original':self.layout,'after':None,'preview':False,
                         'shown':(0.,0.),'pending':(x,y),
                         'status_before':self.vars['status'].get()}
        else:
            keep = set(self.selected) if control or shift else set()
            self.set_selection(keep)
            self.selection_box = {'start':(x,y),'end':(x,y),'keep':keep}

    def motion(self,event):
        x,y = self.world(event.x,event.y)
        if self.drag:
            self.drag['pending'] = (x,y)
            if not self.drag['preview']:
                self.prepare_drag_preview()
            if self.drag['after'] is None:
                self.drag['after'] = self.root.after(DRAG_FRAME_MS,self.flush_drag_preview)
        elif self.selection_box:
            self.selection_box['end'] = (x,y)
            a,b = self.screen(*self.selection_box['start'])
            d,e = self.screen(x,y)
            if not self.selection_box.get('drawn'):
                self.canvas.create_rectangle(a,b,d,e,outline=GREEN,width=2,dash=(4,3),tags=('selection_box',))
                self.selection_box['drawn'] = True
            else:
                self.canvas.coords('selection_box',a,b,d,e)

    def prepare_drag_preview(self):
        drag = self.drag
        self.canvas.itemconfigure('selected_component',state='hidden')
        self.canvas.itemconfigure('node_detail',state='hidden')
        for p in drag['original']['placements']:
            if p['id'] not in drag['ids']:
                continue
            a,b,d,e = component_bounds(p,self.layout['types'][p['type']])
            x0,y0 = self.screen(a,b)
            x1,y1 = self.screen(d,e)
            self.canvas.create_rectangle(x0-4,y0+4,x1+4,y1-4,outline=GREEN,width=2,tags=('drag_preview',))
            if len(drag['ids']) <= 80:
                cx,cy = self.screen(p['x_um'],p['y_um'])
                self.canvas.create_text(cx,y1-12,text=p['id'],fill=GREEN,tags=('drag_preview',))
        drag['preview'] = True

    def flush_drag_preview(self):
        if not self.drag:
            return
        drag = self.drag
        drag['after'] = None
        x,y = drag['pending']
        sx,sy = drag['start']
        dx,dy = x-sx,y-sy
        previous_x,previous_y = drag['shown']
        self.canvas.move('drag_preview',(dx-previous_x)*self.scale,-(dy-previous_y)*self.scale)
        drag['shown'] = (dx,dy)
        self.vars['status'].set(f"正在整体移动 {len(drag['ids'])} 个组件：ΔX={dx:.4g} μm，ΔY={dy:.4g} μm；松开后更新节点连接。")

    def cancel_drag(self):
        drag = self.drag
        if not drag:
            return
        self.drag = None
        if drag.get('after') is not None:
            try:
                self.root.after_cancel(drag['after'])
            except tk.TclError:
                pass
        if drag.get('preview'):
            self.canvas.delete('drag_preview')
            self.canvas.itemconfigure('selected_component',state='normal')
            self.canvas.itemconfigure('node_detail',state='normal')
            self.vars['status'].set(drag.get('status_before',''))

    def release(self,event):
        if self.selection_box:
            box = self.selection_box
            self.selection_box = None
            box['end'] = self.world(event.x,event.y)
            self.set_selection(box['keep'] | components_in_box(self.layout,self.vars['interface'].get(),
                               (*box['start'],*box['end'])))
            return
        if not self.drag:
            return
        drag = self.drag
        original = drag['original']
        x,y = self.world(event.x,event.y)
        sx,sy = drag['start']
        dx,dy = x-sx,y-sy
        self.cancel_drag()
        if dx == 0 and dy == 0:
            return
        error = None
        expanded = self.expanded
        try:
            candidate = move_components(original,drag['ids'],dx,dy)
            expanded = expand_components(candidate,self.layers)
            if candidate != original:
                self.layout = candidate
                self.undo_stack.append(original)
                self.undo_stack = self.undo_stack[-60:]
                self.redo_stack.clear()
                self.dirty = True
        except (ValueError,KeyError,TypeError) as exc:
            self.layout = original
            error = str(exc)
        self.rebuild(expanded=expanded)
        self.set_selection(self.selected,self.primary,redraw=False)
        if error:
            self.vars['status'].set('整组移动已撤销：'+error)

    def zoom(self,event,direction=None):
        factor = 1.15 if (direction if direction is not None else event.delta)>0 else 1/1.15
        x,y = self.world(event.x,event.y)
        self.scale = min(100,max(.02,self.scale*factor))
        self.ox,self.oy = event.x-x*self.scale,event.y+y*self.scale
        self.draw()

    def pan_start(self,event):
        self.pan = (event.x,event.y,self.ox,self.oy)

    def pan_motion(self,event):
        if self.pan:
            x,y,ox,oy = self.pan
            self.ox,self.oy = ox+event.x-x,oy+event.y-y
            self.draw()

    def hover(self,event):
        if self.drag:
            return
        x,y = self.world(event.x,event.y)
        self.canvas.config(cursor='crosshair' if self.vars['mode'].get()=='place' else 'arrow')
        if getattr(self, 'manage_window', True):
            self.root.title(f'MNA TSV 组件布局器 v4.2 | X={x:.2f}, Y={y:.2f} μm')

    def undo(self):
        self.cancel_drag()
        if self.undo_stack:
            self.redo_stack.append(copy.deepcopy(self.layout))
            self.layout = self.undo_stack.pop()
            self.selected,self.primary,self.dirty = set(),None,True
            self.refresh_types()
            self.rebuild()

    def redo(self):
        self.cancel_drag()
        if self.redo_stack:
            self.undo_stack.append(copy.deepcopy(self.layout))
            self.layout = self.redo_stack.pop()
            self.selected,self.primary,self.dirty = set(),None,True
            self.refresh_types()
            self.rebuild()

    def save(self):
        self.config,_ = save_project(self.config,self.layout,self.path)
        self.dirty = False
        self.rebuild()
        return True

    def save_as(self):
        path = filedialog.asksaveasfilename(parent=self.root,defaultextension='.ini',
            initialdir=self.path.parent,initialfile='my_tsv_layout.ini',filetypes=[('MNA INI','*.ini')])
        if path:
            config,_ = save_project(self.config,self.layout,path)
            self.config,self.path,self.dirty = config,Path(path).resolve(),False
            self.rebuild()

    def discard_allowed(self):
        return not self.dirty or messagebox.askyesno('尚未保存','放弃未保存的修改？',parent=self.root)

    def open(self):
        if not self.discard_allowed():
            return
        path = filedialog.askopenfilename(parent=self.root,initialdir=self.path.parent,filetypes=[('MNA INI','*.ini')])
        if path:
            config,layout,layers = read_project(path)
            self.config,self.layout,self.layers,self.path = config,layout,layers,Path(path).resolve()
            self.selected,self.primary,self.dirty = set(),None,False
            self.undo_stack.clear()
            self.redo_stack.clear()
            self.refresh_types()
            self.refresh_interfaces()
            self.rebuild()
            self.fit()

    def import_bumps(self):
        path = filedialog.askopenfilename(parent=self.root,initialdir=self.path.parent,filetypes=[('旧版 MNA INI','*.ini')])
        if not path:
            return
        config = ConfigParser()
        if not config.read(path,encoding='utf-8-sig'):
            raise FileNotFoundError(path)
        self.apply_layout(import_bump_positions(config,self.layout,self.vars['type'].get(),
                                               layer_count=len(self.layers)))
        self.vars['interface'].set('source')
        self.refresh_copy_targets()
        self.rebuild()
        self.vars['status'].set('已替换 source 组件中心；全部使用当前所选模板的行列数、pitch 与单根电阻。原旧版 rz / footprint 不导入。')

    def edit_config(self):
        dialog = tk.Toplevel(self.root)
        dialog.title('修改 Mesh / 负载参数（保持组件路径不变）')
        dialog.geometry('720x720')
        text = tk.Text(dialog,wrap='none',font=('TkFixedFont',10),undo=True)
        text.pack(fill='both',expand=True,padx=8,pady=8)
        output = io.StringIO()
        self.config.write(output)
        text.insert('1.0',output.getvalue())
        def apply():
            config = ConfigParser()
            config.read_string(text.get('1.0','end'))
            layers = read_meshes(config)
            expand_components(self.layout,layers)
            if not config.has_section('components') or config.getfloat('bump','powerv')<=0:
                raise ValueError('请保留 [components] 与正的 bump.powerv')
            self.config,self.layers,self.dirty = config,layers,True
            self.refresh_interfaces()
            self.rebuild()
            self.fit()
            dialog.destroy()
        ttk.Label(dialog,text='负载用负电流；currentmode=3 可输入 power_w。组件布局文件由保存操作同步。').pack(pady=4)
        ttk.Button(dialog,text='应用配置',command=lambda:self.guarded(apply)).pack(pady=6)

    def validate(self):
        sources,links,expanded = compile_components(self.layout,self.layers)
        # Small graph check catches an entirely unpowered layer before export.
        for rail in ('vdd','vss'):
            reached = {0}
            for _ in self.layers:
                for link in links:
                    if link[rail] and ({link['lower'],link['upper']} & reached):
                        reached.update((link['lower'],link['upper']))
            if len(reached)!=len(self.layers):
                raise ValueError(f'{rail.upper()} 层 {set(range(len(self.layers)))-reached} 未连到电源')
        out = filedialog.askdirectory(parent=self.root,title='选择映射 CSV 的保存目录',initialdir=self.path.parent)
        if out:
            write_mapping(expanded,out)
            messagebox.showinfo('校核通过',f"{len(expanded['summaries'])} 个组件，{len(expanded['records'])} 根 TSV。\n映射与节点数已导出到：{out}"
                + ('\n'+'\n'.join(expanded['warnings']) if expanded['warnings'] else ''),parent=self.root)

    def run(self):
        if self.process and self.process.poll() is None:
            raise ValueError('已有求解任务在运行，或结果图窗口尚未关闭')
        self.save()
        script = HERE / 'mna_ir_dual.py'
        out = self.path.parent / (self.path.stem+'_results')
        out.mkdir(parents=True,exist_ok=True)
        self.logfile = (out/'solver_console.log').open('w',encoding='utf-8')
        try:
            self.process = subprocess.Popen([sys.executable,str(script),str(self.path),'--out',str(out)],
                cwd=str(HERE),stdout=self.logfile,stderr=subprocess.STDOUT)
        except Exception:
            self.logfile.close()
            raise
        self.vars['status'].set('正在求解；完成后弹出结果图。日志：'+str(out/'solver_console.log'))
        self.root.after(500,lambda:self.poll(out))

    def poll(self,out):
        code = self.process.poll()
        if code is None:
            self.root.after(500,lambda:self.poll(out))
            return
        self.logfile.close()
        if code:
            log = (out/'solver_console.log').read_text(encoding='utf-8',errors='replace')
            messagebox.showerror('求解失败',log[-3500:],parent=self.root)
        self.vars['status'].set(f"{'求解完成' if code==0 else '求解失败'}：{out}")

    def close(self):
        if self.discard_allowed():
            self.root.destroy()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('config',nargs='?',default=str(HERE/'pginfo_components.ini'))
    args = parser.parse_args()
    try:
        root = tk.Tk()
    except tk.TclError as exc:
        print(f'需要桌面显示及 Tkinter。Windows 官方 Python 安装时启用 Tcl/Tk。详情：{exc}',file=sys.stderr)
        return 1
    try:
        Editor(root,args.config)
    except Exception as exc:
        messagebox.showerror('无法打开项目',str(exc),parent=root)
        root.destroy()
        return 1
    root.mainloop()
    return 0


if __name__=='__main__':
    raise SystemExit(main())
