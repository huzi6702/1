#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Physical TSV component geometry shared by the editor and DC solver.

No third-party dependencies. Coordinates and pitches are in micrometres;
resistance is for ONE TSV, including any desired series metal/via resistance.
Mesh node (1,1) is at (xpitch,ypitch), matching the existing solver.
"""
import argparse
import ast
import copy
import csv
import json
import math
from collections import Counter
from configparser import ConfigParser
from pathlib import Path

SCHEMA = 'mna-tsv-components-1'
MAX_TSVS = 2000000


def finite(value, label, positive=False):
    if isinstance(value, bool):
        raise ValueError(f'{label}: expected a number')
    number = float(value)
    if not math.isfinite(number) or (positive and number <= 0):
        raise ValueError(f'{label}: expected a finite {"positive " if positive else ""}number')
    return number


def integer(value, label, minimum=1):
    number = finite(value, label)
    if not number.is_integer() or number < minimum:
        raise ValueError(f'{label}: expected an integer >= {minimum}')
    return int(number)


def read_meshes(config):
    count = config.getint('stack', 'layers', fallback=1)
    if count < 1:
        raise ValueError('stack.layers must be >=1')
    layers, offset = [], 0
    for index in range(count):
        section = 'mesh' if index == 0 else f'mesh.{index}'
        layer = {'id': index, 'offset': offset}
        for key in ('xgrid', 'ygrid', 'xpitch', 'ypitch'):
            value = config.get(section, key, fallback=config.get('mesh', key))
            layer[key] = (integer(value, f'{section}.{key}') if key.endswith('grid')
                          else finite(value, f'{section}.{key}', True))
        offset += layer['xgrid'] * layer['ygrid']
        layers.append(layer)
    return layers


def normalize_layout(layout, layer_count):
    if not isinstance(layout, dict) or layout.get('schema') != SCHEMA:
        raise ValueError(f'layout.schema must be {SCHEMA!r}')
    types, placements = layout.get('types'), layout.get('placements')
    if not isinstance(types, dict) or not types or not isinstance(placements, list):
        raise ValueError('layout needs nonempty types and a placements list')
    policy = layout.get('boundary_policy', 'nearest')
    if policy not in ('nearest', 'strict'):
        raise ValueError('boundary_policy must be nearest or strict')
    clean = {'schema': SCHEMA, 'boundary_policy': policy, 'types': {}, 'placements': []}
    for name, raw in types.items():
        if not isinstance(name, str) or not name.strip() or not isinstance(raw, dict):
            raise ValueError('Each component type needs a nonempty name and object')
        item = {key: integer(raw[key], f'{name}.{key}') for key in ('rows', 'cols')}
        for key in ('pitch_x_um', 'pitch_y_um', 'r_ohm'):
            item[key] = finite(raw[key], f'{name}.{key}', True)
        clean['types'][name] = item
    seen, total = set(), 0
    for raw in placements:
        if not isinstance(raw, dict):
            raise ValueError('Each placement must be an object')
        identity, name = raw.get('id'), raw.get('type')
        if not isinstance(identity, str) or not identity.strip() or identity in seen:
            raise ValueError(f'Duplicate or empty component id: {identity!r}')
        seen.add(identity)
        if name not in clean['types']:
            raise ValueError(f'{identity}: unknown type {name!r}')
        rail = raw.get('rail', '').lower()
        if rail not in ('vdd', 'vss'):
            raise ValueError(f'{identity}: rail must be vdd or vss')
        interface = raw.get('interface')
        if interface != 'source':
            try:
                lower, upper = map(int, interface.split('_'))
            except (AttributeError, ValueError):
                raise ValueError(f'{identity}: interface must be source or lower_upper') from None
            if not 0 <= lower < upper < layer_count or interface != f'{lower}_{upper}':
                raise ValueError(f'{identity}: invalid interface {interface!r}')
        rotation = integer(raw.get('rotation_deg', 0), f'{identity}.rotation_deg', 0)
        if rotation not in (0, 90, 180, 270):
            raise ValueError(f'{identity}: rotation must be 0,90,180,270 degrees')
        p = {'id': identity, 'type': name, 'rail': rail, 'interface': interface,
             'x_um': finite(raw['x_um'], f'{identity}.x_um'),
             'y_um': finite(raw['y_um'], f'{identity}.y_um'), 'rotation_deg': rotation}
        clean['placements'].append(p)
        t = clean['types'][name]
        total += t['rows'] * t['cols']
        if total > MAX_TSVS:
            raise ValueError(f'This layout exceeds the {MAX_TSVS:,} physical TSV limit')
    return clean


def nearest_node(x_um, y_um, layer, label='TSV', policy='strict'):
    """Nearest in each axis; exact half pitch ties choose the larger index.

    Permit only the mesh's half-pitch boundary cells. A point farther outside
    is rejected, rather than arbitrarily folded onto an edge node.
    """
    indices = []
    for value, axis in ((x_um, 'x'), (y_um, 'y')):
        q = finite(value, label) / layer[f'{axis}pitch']
        count = layer[f'{axis}grid']
        tolerance = 1e-10
        if policy == 'strict' and (q < .5 - tolerance or q > count + .5 + tolerance):
            raise ValueError(f'{label} ({x_um:g},{y_um:g}) um is outside layer '
                             f'{layer["id"]} nearest-node domain on {axis.upper()}')
        # Small numerical tolerance makes decimal pitch midpoint ties stable.
        indices.append(min(count, max(1, math.floor(q + .5 + tolerance))))
    x, y = indices
    return layer['offset'] + (y - 1) * layer['xgrid'] + x - 1, x, y


def physical_tsvs(placement, component_type, stride=1):
    """Default stride=1 always yields every TSV; larger strides are display only."""
    rows, cols = component_type['rows'], component_type['cols']
    rotation = placement.get('rotation_deg', 0)
    for index in range(0, rows * cols, stride):
        row, col = divmod(index, cols)
        dx = (col - (cols - 1) / 2) * component_type['pitch_x_um']
        dy = (row - (rows - 1) / 2) * component_type['pitch_y_um']
        if rotation == 90:
            dx, dy = -dy, dx
        elif rotation == 180:
            dx, dy = -dx, -dy
        elif rotation == 270:
            dx, dy = dy, -dx
        yield row + 1, col + 1, placement['x_um'] + dx, placement['y_um'] + dy


def expand_components(layout, layers):
    """Return every physical TSV, including coincident electrical endpoints."""
    layout = normalize_layout(layout, len(layers))
    records, summaries = [], []
    occupied = Counter()
    for p in layout['placements']:
        t = layout['types'][p['type']]
        lower, upper = ((-1, 0) if p['interface'] == 'source' else
                        tuple(map(int, p['interface'].split('_'))))
        start = len(records)
        # The source component center must also lie in layer 0's mesh domain.
        center = nearest_node(p['x_um'], p['y_um'], layers[upper], p['id'], layout['boundary_policy'])
        for row, col, x_um, y_um in physical_tsvs(p, t):
            label = f'{p["id"]} TSV({row},{col})'
            b, xu, yu = nearest_node(x_um, y_um, layers[upper], label, layout['boundary_policy'])
            a, xl, yl = (-1, 0, 0) if lower == -1 else nearest_node(x_um, y_um, layers[lower], label, layout['boundary_policy'])
            records.append({'component_id': p['id'], 'component_type': p['type'],
                            'interface': p['interface'], 'rail': p['rail'],
                            'tsv_id': f'{p["id"]}:{row}:{col}', 'row': row, 'col': col,
                            'x_um': x_um, 'y_um': y_um, 'r': t['r_ohm'],
                            'lower': lower, 'upper': upper,
                            'a': a, 'b': b, 'xl': xl, 'yl': yl, 'xu': xu, 'yu': yu,
                            'lower_snap_um': (0. if lower == -1 else math.hypot(
                                xl * layers[lower]['xpitch'] - x_um,
                                yl * layers[lower]['ypitch'] - y_um)),
                            'upper_snap_um': math.hypot(xu * layers[upper]['xpitch'] - x_um,
                                                       yu * layers[upper]['ypitch'] - y_um)})
            occupied[(p['interface'], p['rail'], round(x_um, 9), round(y_um, 9))] += 1
        items = records[start:]
        pair_counts = Counter((r['a'], r['b']) for r in items)
        summaries.append({'component_id': p['id'], 'component_type': p['type'],
                          'interface': p['interface'], 'rail': p['rail'].upper(),
                          'rows': t['rows'], 'cols': t['cols'],
                          'pitch_x_um': t['pitch_x_um'], 'pitch_y_um': t['pitch_y_um'],
                          'rotation_deg': p['rotation_deg'],
                          'center_x_um': p['x_um'], 'center_y_um': p['y_um'],
                          'center_x_node': center[1], 'center_y_node': center[2],
                          'tsv_count': len(items), 'R_single_ohm': t['r_ohm'],
                          'R_if_all_endpoints_equipotential_ohm': t['r_ohm'] / len(items),
                          'unique_lower_nodes': len({r['a'] for r in items}) if lower >= 0 else 0,
                          'unique_upper_nodes': len({r['b'] for r in items}),
                          'connected_layer0_nodes': (len({r['b'] for r in items}) if lower == -1 else
                                                     len({r['a'] for r in items}) if lower == 0 else 0),
                          'unique_node_pairs': len(pair_counts),
                          'max_tsvs_same_node_pair': max(pair_counts.values()),
                          'max_snap_distance_um': max(max(r['lower_snap_um'], r['upper_snap_um']) for r in items)})
    warnings = []
    edge_count = 0
    for row in records:
        for layer_id in ([row['upper']] if row['lower'] == -1 else [row['lower'], row['upper']]):
            layer = layers[layer_id]
            if any(not .5 - 1e-10 <= row[f'{axis}_um'] / layer[f'{axis}pitch'] <= layer[f'{axis}grid'] + .5 + 1e-10
                   for axis in ('x', 'y')):
                edge_count += 1
    if edge_count:
        warnings.append(f'{edge_count} TSV endpoints lie beyond the outer half-pitch cells and '
                        'were connected to the nearest boundary node. Review snap distances; '
                        'boundary_policy=strict can reject these placements.')
    overlap = sum(n - 1 for n in occupied.values() if n > 1)
    if overlap:
        warnings.append(f'{overlap} TSV positions overlap another component on the same rail/interface. '
                        'They are modeled as separate physical resistors; review the placement.')
    # A coincident VDD/VSS via cannot physically occupy the same location either.
    vdd = {k[:1] + k[2:] for k in occupied if k[1] == 'vdd'}
    vss = {k[:1] + k[2:] for k in occupied if k[1] == 'vss'}
    if vdd & vss:
        warnings.append(f'{len(vdd & vss)} TSV positions coincide between VDD and VSS; review geometry.')
    return {'layout': layout, 'records': records, 'summaries': summaries, 'warnings': warnings}


def compile_components(layout, layers):
    expanded = expand_components(layout, layers)
    sources, links = {'vdd': [], 'vss': []}, {}
    by_component = {}
    for row in expanded['records']:
        by_component.setdefault(row['component_id'], []).append(row)
    for p in expanded['layout']['placements']:
        rows = by_component[p['id']]
        t = expanded['layout']['types'][p['type']]
        if p['interface'] == 'source':
            _, x, y = nearest_node(p['x_um'], p['y_um'], layers[0], p['id'], expanded['layout']['boundary_policy'])
            sources[p['rail']].append({'id': len(sources[p['rail']]) + 1,
                'component_id': p['id'], 'component_type': p['type'],
                'x': x, 'y': y, 'x_um': p['x_um'], 'y_um': p['y_um'],
                'r': t['r_ohm'] / len(rows), 'branch_r': t['r_ohm'],
                'nodes': [r['b'] for r in rows], 'tsv_records': rows})
        else:
            link = links.setdefault(p['interface'], {'name': p['interface'],
                'lower': rows[0]['lower'], 'upper': rows[0]['upper'], 'vdd': [], 'vss': []})
            for raw in rows:
                row = dict(raw)
                row['id'] = len(link[p['rail']]) + 1
                link[p['rail']].append(row)
    for rail in ('vdd', 'vss'):
        if not sources[rail]:
            raise ValueError(f'Component layout needs at least one source {rail.upper()} component')
    return sources, list(links.values()), expanded


def load_layout(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write_mapping(expanded, out):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    names = ['component_id', 'component_type', 'interface', 'rail', 'tsv_id',
             'row', 'col', 'x_um', 'y_um', 'r', 'lower', 'upper',
             'a', 'b', 'xl', 'yl', 'xu', 'yu', 'lower_snap_um', 'upper_snap_um']
    with (out / 'tsv_node_mapping.csv').open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, names)
        writer.writeheader()
        writer.writerows(expanded['records'])
    with (out / 'component_geometry.csv').open('w', newline='', encoding='utf-8-sig') as f:
        names = list(expanded['summaries'][0]) if expanded['summaries'] else ['component_id']
        writer = csv.DictWriter(f, names)
        writer.writeheader()
        writer.writerows(expanded['summaries'])


def import_bump_positions(config, layout, type_name, layer_count=None):
    """Migrate centers using old pitch, never old footprint/R; validate target layers."""
    meshes = read_meshes(config)
    if type_name not in layout['types']:
        raise ValueError('Select an existing component type before importing Bump centers')
    result = copy.deepcopy(layout)
    result['placements'] = [p for p in result['placements'] if p['interface'] != 'source']
    for rail in ('vdd', 'vss'):
        points = ast.literal_eval(config.get('bumploc', f'bumploc{rail}'))
        for index, row in enumerate(points, 1):
            result['placements'].append({'id': f'BUMP_{rail}_{index}', 'type': type_name,
                'interface': 'source', 'rail': rail, 'x_um': float(row[0]) * meshes[0]['xpitch'],
                'y_um': float(row[1]) * meshes[0]['ypitch'], 'rotation_deg': 0})
    return normalize_layout(result, len(meshes) if layer_count is None else layer_count)


def save_project(config, layout, ini_path):
    """Export an independent INI+JSON pair, preserving all Mesh/load sections."""
    ini_path = Path(ini_path).resolve()
    meshes = read_meshes(config)
    expanded = expand_components(layout, meshes)
    compile_components(expanded['layout'], meshes)
    out_config = copy.deepcopy(config)
    if not out_config.has_section('stack'):
        out_config.add_section('stack')
        out_config.set('stack', 'layers', '1')
    # Component mode owns ALL vertical paths, so remove inactive legacy entries.
    for section in list(out_config.sections()):
        if section == 'bumploc' or section.startswith('tsv.') or section in ('superconnect', 'cutmode'):
            out_config.remove_section(section)
    for key in list(out_config['bump']):
        if key != 'powerv':
            out_config.remove_option('bump', key)
    if not out_config.has_section('components'):
        out_config.add_section('components')
    json_path = ini_path.with_suffix('.layout.json')
    out_config.set('components', 'layout', json_path.name)
    ini_path.parent.mkdir(parents=True, exist_ok=True)
    # JSON goes first; the saved INI never points at an unwritten layout.
    json_path.write_text(json.dumps(expanded['layout'], ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    with ini_path.open('w', encoding='utf-8') as f:
        out_config.write(f)
    return out_config, json_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('config', nargs='?', default='pginfo_components.ini')
    parser.add_argument('--out', default='component_mapping')
    args = parser.parse_args()
    config = ConfigParser()
    if not config.read(args.config, encoding='utf-8-sig'):
        raise FileNotFoundError(args.config)
    layout_path = Path(args.config).resolve().parent / config.get('components', 'layout')
    _, _, expanded = compile_components(load_layout(layout_path), read_meshes(config))
    write_mapping(expanded, args.out)
    print(f'{len(expanded["summaries"])} components, {len(expanded["records"])} TSVs. Mapping: {args.out}')
    for warning in expanded['warnings']:
        print('WARNING:', warning)


if __name__ == '__main__':
    main()
