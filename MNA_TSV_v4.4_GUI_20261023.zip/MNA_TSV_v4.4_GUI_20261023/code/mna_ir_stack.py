#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Coupled multilayer resistive DC IR model; VDD/VSS solve in parallel.

Run: python mna_ir_dual.py pginfo_stack.ini --out results_stack
Current inputs are negative for consumption. Power inputs are converted to
fixed current using the nominal source voltage, not a constant-power solve.
"""

import ast
import json
from concurrent.futures import ThreadPoolExecutor
from configparser import ConfigParser
from pathlib import Path
from time import perf_counter

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.sparse import block_diag, coo_matrix, diags
from scipy.sparse.linalg import cg, splu
from threadpoolctl import threadpool_limits

from mna_ir_dual import (VERSION, build_vloc, display_grid, extreme, gen_imap,
                         gfunc, integer_coord, select_solver)


def positive(value, label):
    value = float(value)
    if not np.isfinite(value) or value <= 0:
        raise ValueError(f"{label} must be finite and positive")
    return value


def point_node(x, y, layer, label):
    x, y = integer_coord(x, label), integer_coord(y, label)
    if not (1 <= x <= layer['xgrid'] and 1 <= y <= layer['ygrid']):
        raise ValueError(f"{label} ({x},{y}) is outside layer {layer['id']}")
    return layer['offset'] + (y - 1) * layer['xgrid'] + x - 1, x, y


def parse_load(config, section, layer, voltage):
    if not config.has_section(section):
        raise ValueError(f"Missing [{section}]; specify each layer's load explicitly")
    mode = config.getint(section, 'currentmode', fallback=1)
    m, n = layer['xgrid'], layer['ygrid']
    load = np.zeros(m * n, dtype=float)
    if mode == 1:
        current = config.getfloat(section, 'i')
        multiplier = config.getfloat(section, 'mul', fallback=1)
        if not np.isfinite(current) or current > 0 or not np.isfinite(multiplier) or multiplier < 0:
            raise ValueError(f"[{section}] needs i<=0 and mul>=0, both finite")
        load[:] = current * multiplier / load.size
    elif mode in (2, 4):
        key = 'imap' if mode == 2 else 'pmap'
        regions = ast.literal_eval(config.get(section, key))
        for region in regions:
            if len(region) != 5:
                raise ValueError(f"[{section}] {key} needs [total, x1,y1,x2,y2]")
            value = float(region[0])
            if not np.isfinite(value) or (value > 0 if mode == 2 else value < 0):
                raise ValueError(f"[{section}] use negative current or positive power")
        if mode == 4:
            regions = [[-float(r[0]) / voltage, *r[1:]] for r in regions]
        gen_imap(regions, m, n, load, 1)
    elif mode == 3:
        power = config.getfloat(section, 'power_w')
        if not np.isfinite(power) or power < 0:
            raise ValueError(f"[{section}] power_w must be finite and nonnegative")
        load[:] = -power / voltage / load.size
    else:
        raise ValueError(f"[{section}] currentmode must be 1,2,3,4")
    layer['currentmode'] = mode
    layer['load'] = load
    layer['load_current_A'] = float(-load.sum())
    layer['nominal_load_power_W'] = float(-load.sum() * voltage)


def read_stack_config(path):
    config = ConfigParser()
    if not config.read(path, encoding='utf-8-sig'):
        raise FileNotFoundError(path)
    if config.getint('mode', 'mode', fallback=2) != 2:
        raise ValueError('Only dual VDD/VSS mode=2 is supported')
    count = config.getint('stack', 'layers', fallback=1)
    if count < 1:
        raise ValueError('stack.layers must be >=1')
    voltage = positive(config.getfloat('bump', 'powerv'), 'powerv')
    layers, offset = [], 0
    mesh_keys = ('xgrid', 'ygrid', 'rh', 'rv', 'xpitch', 'ypitch')
    for index in range(count):
        section = 'mesh' if index == 0 else f'mesh.{index}'
        layer = {'id': index, 'name': config.get(section, 'name', fallback=f'Layer {index}'),
                 'offset': offset}
        for key in mesh_keys:
            raw = config.get(section, key, fallback=config.get('mesh', key))
            layer[key] = (integer_coord(raw, f'{section}.{key}') if key in ('xgrid', 'ygrid')
                          else positive(raw, f'{section}.{key}'))
            if layer[key] <= 0:
                raise ValueError(f'{section}.{key} must be positive')
        parse_load(config, 'current' if index == 0 else f'current.{index}', layer, voltage)
        offset += layer['xgrid'] * layer['ygrid']
        layers.append(layer)
    component_data = None
    if config.has_section('components'):
        from tsv_components import compile_components, load_layout
        layout_path = Path(path).resolve().parent / config.get('components', 'layout')
        sources, links, component_data = compile_components(load_layout(layout_path), layers)
        con_n = None
    else:
        xpn, ypn = (config.getint('bump', key, fallback=0) for key in ('xpn', 'ypn'))
        if min(xpn, ypn) < 0:
            raise ValueError('Bump footprint radii must be nonnegative')
        con_n = (2 * xpn + 1) * (2 * ypn + 1)
        default_r = positive(config.getfloat('bump', 'rz'), 'bump.rz')
        sources = {}
        for rail in ('vdd', 'vss'):
            resistance = positive(config.getfloat('bump', f'rz_{rail}', fallback=default_r),
                                  f'bump.rz_{rail}')
            raw = ast.literal_eval(config.get('bumploc', f'bumploc{rail}'))
            if not isinstance(raw, list) or not raw:
                raise ValueError(f'bumploc{rail} must contain at least one source path')
            sources[rail] = []
            for index, row in enumerate(raw):
                if len(row) not in (2, 3):
                    raise ValueError(f'bumploc{rail}: use [x,y] or [x,y,R_ohm]')
                _, x, y = point_node(*row[:2], layers[0], f'bumploc{rail}')
                r = positive(row[2], 'source path R') if len(row) == 3 else resistance
                loc = build_vloc(np.array([[x, y]]), layers[0]['xgrid'], layers[0]['ygrid'], xpn, ypn)
                nodes = loc[:, 0] + loc[:, 1] * layers[0]['xgrid']
                sources[rail].append({'id': index + 1, 'x': x, 'y': y, 'r': r,
                                      'nodes': nodes, 'branch_r': r * con_n})
        links = []
        for section in config.sections():
            if not section.startswith('tsv.'):
                continue
            lower = config.getint(section, 'lower')
            upper = config.getint(section, 'upper')
            if not 0 <= lower < upper < count:
                raise ValueError(f'[{section}] needs 0<=lower<upper<stack.layers')
            resistance = positive(config.getfloat(section, 'rz'), f'{section}.rz')
            link = {'name': section[4:], 'lower': lower, 'upper': upper}
            for rail in ('vdd', 'vss'):
                r_default = positive(config.getfloat(section, f'rz_{rail}', fallback=resistance),
                                     f'{section}.rz_{rail}')
                rows = ast.literal_eval(config.get(section, f'loc{rail}', fallback='[]'))
                link[rail] = []
                for index, row in enumerate(rows):
                    if len(row) not in (2, 4, 5):
                        raise ValueError(f'[{section}] loc{rail}: use [x,y], [xl,yl,xu,yu], '
                                         'or [xl,yl,xu,yu,R_ohm]')
                    if len(row) == 2:
                        if any(layers[lower][k] != layers[upper][k] for k in ('xpitch', 'ypitch')):
                            raise ValueError('Different pitches require explicit lower/upper TSV endpoints')
                        coords = [*row, *row]
                    else:
                        coords = row[:4]
                    a, xl, yl = point_node(*coords[:2], layers[lower], section)
                    b, xu, yu = point_node(*coords[2:], layers[upper], section)
                    r = positive(row[4], f'{section} path R') if len(row) == 5 else r_default
                    link[rail].append({'id': index + 1, 'a': a, 'b': b, 'r': r,
                                       'xl': xl, 'yl': yl, 'xu': xu, 'yu': yu})
            links.append(link)
    # Each individual mesh is connected. Check the much smaller layer graph
    # before factorization so floating layers never produce a singular solve.
    for rail in ('vdd', 'vss'):
        reached = {0}
        while True:
            previous = set(reached)
            for link in links:
                if link[rail] and (link['lower'] in reached or link['upper'] in reached):
                    reached.update((link['lower'], link['upper']))
            if previous == reached:
                break
        missing = sorted(set(range(count)) - reached)
        if missing:
            raise ValueError(f'{rail.upper()} layers {missing} have no TSV path to the source')
    load = np.concatenate([layer['load'] for layer in layers])
    if load.sum() >= 0:
        raise ValueError('At least one layer must have a consuming load')
    return {'layers': layers, 'sources': sources, 'links': links, 'load': load,
            'powerv': voltage, 'node_count': offset, 'con_n': con_n,
            'component_data': component_data}


def assemble_rail(p, mesh, rail):
    size = p['node_count']
    source_g = np.zeros(size)
    for source in p['sources'][rail]:
        np.add.at(source_g, source['nodes'], 1 / source['branch_r'])
    rows = [row for link in p['links'] for row in link[rail]]
    if rows:
        a = np.array([r['a'] for r in rows])
        b = np.array([r['b'] for r in rows])
        g = 1 / np.array([r['r'] for r in rows])
        vertical = coo_matrix((np.r_[g, g, -g, -g],
                               (np.r_[a, b, a, b], np.r_[a, b, b, a])),
                              shape=(size, size)).tocsc()
        matrix = mesh + vertical + diags(source_g, format='csc')
    else:
        matrix = mesh + diags(source_g, format='csc')
    return matrix.tocsc()


def solve_spd(matrix, rhs, solver, rtol, maxiter):
    start = perf_counter()
    iterations = 0
    if solver == 'direct':
        factor = splu(matrix, permc_spec='MMD_AT_PLUS_A', diag_pivot_thresh=0.,
                      options={'SymmetricMode': True})
        setup_s = perf_counter() - start
        start = perf_counter()
        delta = factor.solve(rhs)
    else:
        import pyamg
        matrix = matrix.tocsr()
        hierarchy = pyamg.smoothed_aggregation_solver(
            matrix, symmetry='symmetric', max_coarse=50,
            presmoother=('gauss_seidel', {'sweep': 'symmetric'}),
            postsmoother=('gauss_seidel', {'sweep': 'symmetric'}))
        setup_s = perf_counter() - start
        start = perf_counter()
        def iteration(_):
            nonlocal iterations
            iterations += 1
        delta, info = cg(matrix, rhs, M=hierarchy.aspreconditioner(cycle='V'),
                         rtol=rtol, atol=0., maxiter=maxiter, callback=iteration)
        if info:
            raise RuntimeError(f'CG+AMG did not converge (info={info})')
    solve_s = perf_counter() - start
    residual = matrix @ delta - rhs
    relative = float(np.linalg.norm(residual) / max(np.linalg.norm(rhs), np.finfo(float).tiny))
    if not np.all(np.isfinite(delta)) or relative > max(50 * rtol, 1e-7):
        raise RuntimeError(f'{solver} residual check failed: {relative:.3e}')
    return delta, {'solver': solver, 'matrix_size': len(rhs), 'matrix_nnz': int(matrix.nnz),
                   'iterations': iterations, 'rtol': rtol, 'relative_residual': relative,
                   'max_nodal_residual_A': float(np.max(abs(residual))),
                   'setup_s': setup_s, 'solve_s': solve_s}



def physical_current_row(row, current):
    return {'rail': row['rail'].upper(), 'interface': row['interface'],
            'component_id': row['component_id'], 'component_type': row['component_type'],
            'tsv_id': row['tsv_id'], 'row': row['row'], 'col': row['col'],
            'x_um': row['x_um'], 'y_um': row['y_um'],
            'lower_layer': row['lower'], 'upper_layer': row['upper'],
            'lower_x_node': row['xl'], 'lower_y_node': row['yl'],
            'upper_x_node': row['xu'], 'upper_y_node': row['yu'],
            'R_ohm': row['r'], 'current_A': current, 'current_mA': current * 1000}


def plot_component_mapping(p, out):
    from matplotlib.collections import LineCollection
    data = p['component_data']
    interfaces = list(dict.fromkeys(r['interface'] for r in data['records']))
    fig, axes = plt.subplots(len(interfaces), 2, figsize=(12, 4.5 * len(interfaces)),
                             squeeze=False, constrained_layout=True)
    for interface, axs in zip(interfaces, axes):
        rows = [r for r in data['records'] if r['interface'] == interface]
        for rail, ax in zip(('vdd', 'vss'), axs):
            selected = [r for r in rows if r['rail'] == rail]
            if selected:
                upper = p['layers'][selected[0]['upper']]
                segments = [[(r['x_um'], r['y_um']),
                             (r['xu'] * upper['xpitch'], r['yu'] * upper['ypitch'])] for r in selected]
                ax.add_collection(LineCollection(segments, colors='#d38a33', linewidths=.4, alpha=.4))
                ax.scatter([r['x_um'] for r in selected], [r['y_um'] for r in selected],
                           s=3, c='#c83d3d' if rail == 'vdd' else '#285eaa', label='Physical TSV')
                endpoints = sorted({(r['xu'], r['yu']) for r in selected})
                ax.scatter([x * upper['xpitch'] for x, y in endpoints],
                           [y * upper['ypitch'] for x, y in endpoints],
                           marker='s', facecolors='none', edgecolors='#26a184', s=22, label='Snapped upper node')
                if selected[0]['lower'] >= 0:
                    lower = p['layers'][selected[0]['lower']]
                    endpoints = sorted({(r['xl'], r['yl']) for r in selected})
                    ax.scatter([x * lower['xpitch'] for x, y in endpoints],
                               [y * lower['ypitch'] for x, y in endpoints],
                               marker='+', c='#6935ad', s=22, label='Snapped lower node')
                ax.legend(fontsize=8)
            ax.set(title=f'{interface}: {rail.upper()} | {len(selected)} physical TSVs',
                   xlabel='X (um)', ylabel='Y (um)', aspect='equal')
            if selected:
                ax.set_xlim(.5 * upper['xpitch'], (upper['xgrid'] + .5) * upper['xpitch'])
                ax.set_ylim(.5 * upper['ypitch'], (upper['ygrid'] + .5) * upper['ypitch'])
            ax.grid(alpha=.15)
    fig.savefig(out / 'component_mapping.png', dpi=170)


def solve_stack_rail(p, mesh, rail, solver, rtol, maxiter):
    start = perf_counter()
    matrix = assemble_rail(p, mesh, rail)
    assembly_s = perf_counter() - start
    rhs = -p['load']
    delta, check = solve_spd(matrix, rhs, solver, rtol, maxiter)
    sign = 1 if rail == 'vdd' else -1
    balances = -np.array([l['load_current_A'] for l in p['layers']])
    source_rows, tsv_rows, physical_rows = [], [], []
    resistor_power = float(delta @ (mesh @ delta))
    for source in p['sources'][rail]:
        currents = delta[source['nodes']] / source['branch_r']
        current = float(currents.sum())
        balances[0] += current
        resistor_power += float(np.sum(delta[source['nodes']] ** 2 / source['branch_r']))
        source_rows.append({'component_id': source.get('component_id', ''),
                            'component_type': source.get('component_type', ''),
                            'tsv_count': len(source['nodes']) if 'component_id' in source else None,
                            'branch_count': len(source['nodes']),
                            'R_single_tsv_ohm': source['branch_r'] if 'component_id' in source else None, 'rail': rail.upper(), 'id': source['id'], 'layer': 0,
                            'x_node': source['x'], 'y_node': source['y'],
                            'R_ohm': source['r'], 'current_A': sign * current,
                            'current_mA': sign * current * 1000})
        if 'tsv_records' in source:
            for row, value in zip(source['tsv_records'], currents):
                physical_rows.append(physical_current_row(row, sign * float(value)))
    for link in p['links']:
        for row in link[rail]:
            forward = float((delta[row['b']] - delta[row['a']]) / row['r'])
            balances[link['lower']] -= forward
            balances[link['upper']] += forward
            resistor_power += (delta[row['b']] - delta[row['a']]) ** 2 / row['r']
            physical_current = sign * forward
            if 'tsv_id' in row:
                physical_rows.append(physical_current_row(row, physical_current))
            tsv_rows.append({'component_id': row.get('component_id', ''),
                             'component_type': row.get('component_type', ''),
                             'tsv_id': row.get('tsv_id', ''), 'rail': rail.upper(), 'interface': link['name'], 'id': row['id'],
                             'lower_layer': link['lower'], 'upper_layer': link['upper'],
                             'lower_x_node': row['xl'], 'lower_y_node': row['yl'],
                             'upper_x_node': row['xu'], 'upper_y_node': row['yu'],
                             'R_ohm': row['r'], 'current_A': physical_current,
                             'current_mA': physical_current * 1000,
                             'delta_V_upper_minus_lower': float(sign * (delta[row['a']] - delta[row['b']]))})
    tolerance = max(1e-9, 50 * rtol * float(np.sum(abs(p['load']))))
    if np.max(abs(balances)) > tolerance:
        raise RuntimeError(f'{rail}: layer current conservation failed: {balances} A')
    source_sum = float(sum(abs(r['current_A']) for r in source_rows))
    check.update({'assembly_s': assembly_s, 'formulation': 'coupled reduced SPD nodal system',
                  'source_current_magnitude_A': source_sum,
                  'current_balance_error_A': float(balances.sum()),
                  'layer_current_balance_error_A': balances.tolist(),
                  'resistor_dissipation_W': float(resistor_power)})
    if p.get('component_data') is not None:
        check['physical_tsv_currents'] = physical_rows
    return delta, source_rows, tsv_rows, check


def solve_stack(p, parallel=True, solver='auto', rtol=1e-10, maxiter=1000,
                amg_threshold=250000):
    if not 0 < rtol < 1 or maxiter < 1 or amg_threshold < 1:
        raise ValueError('Require 0<rtol<1, maxiter>=1 and amg_threshold>=1')
    selected = select_solver(solver, p['node_count'], amg_threshold)
    if selected == 'amg':
        import pyamg
    start = perf_counter()
    blocks = [gfunc(l['xgrid'], l['ygrid'], 1 / l['rh'], 1 / l['rv'])[0]
              for l in p['layers']]
    mesh = block_diag(blocks, format='csc')
    mesh_s = perf_counter() - start
    args = [(p, mesh, rail, selected, rtol, maxiter) for rail in ('vdd', 'vss')]
    with threadpool_limits(limits=1, user_api='blas'):
        if parallel:
            with ThreadPoolExecutor(max_workers=2, thread_name_prefix='IR_stack') as pool:
                futures = [pool.submit(solve_stack_rail, *a) for a in args]
                results = tuple(f.result() for f in futures)
        else:
            results = tuple(solve_stack_rail(*a) for a in args)
    return results, {'parallel_rails': bool(parallel), 'solver_requested': solver,
                     'solver_used': selected, 'rail_workers': 2 if parallel else 1,
                     'amg_threshold': amg_threshold, 'mesh_assembly_s': mesh_s,
                     'numeric_wall_s': perf_counter() - start,
                     'unknown_nodes_per_rail': p['node_count']}


def plot_vertical_layout(p, out):
    """Show one destination-center point per component on every interface.

    R/N is an equipotential reference for the color scale only. The solver's
    distributed TSV branches and the full physical exports are untouched.
    Legacy configurations continue to show their individual resistor paths.
    """
    component_mode = p.get('component_data') is not None
    if component_mode:
        grouped = {}
        for component in p['component_data']['summaries']:
            rails = grouped.setdefault(component['interface'], {'vdd': [], 'vss': []})
            rails[component['rail'].lower()].append({
                'x': component['center_x_node'], 'y': component['center_y_node'],
                'r': component['R_if_all_endpoints_equipotential_ohm'],
                'tsv_count': component['tsv_count']})
        interfaces = [('Source -> layer 0', 0, grouped['source'])]
        interfaces.extend((f"TSV {link['name']}: {link['lower']} -> {link['upper']}",
                           link['upper'], grouped[link['name']]) for link in p['links'])
    else:
        interfaces = [('Source -> layer 0', 0, p['sources'])]
        for link in p['links']:
            interfaces.append((f"TSV {link['name']}: {link['lower']} -> {link['upper']}",
                               link['upper'], {r: [{'x': t['xu'], 'y': t['yu'], 'r': t['r']}
                                                 for t in link[r]] for r in ('vdd', 'vss')}))
    fig, axes = plt.subplots(len(interfaces), 2, figsize=(11, 4 * len(interfaces)),
                             squeeze=False, constrained_layout=True)
    if component_mode:
        references = [row['r'] for _, _, rails in interfaces
                      for rows in rails.values() for row in rows]
        normalization = plt.Normalize(min(references), max(references))
        fig.suptitle('One point per component on every interface\n'
                     'R/N reference assumes equipotential endpoints; solver retains every TSV',
                     fontsize=11)
    for (name, layer_id, rails), axs in zip(interfaces, axes):
        layer = p['layers'][layer_id]
        for ax, rail in zip(axs, ('vdd', 'vss')):
            rows = rails[rail]
            if rows:
                cp = ax.scatter([r['x'] * layer['xpitch'] for r in rows],
                                 [r['y'] * layer['ypitch'] for r in rows],
                                 c=[r['r'] for r in rows], s=30, cmap='viridis',
                                 **({'norm': normalization} if component_mode else {}))
                fig.colorbar(cp, ax=ax, label='R/N reference (ohm)' if component_mode
                             else 'Path R (ohm)', shrink=.8)
            count = (f"{len(rows)} components | {sum(r['tsv_count'] for r in rows):,} TSVs"
                     if component_mode else f'{len(rows)} paths')
            location = ('Component center on destination mesh' if component_mode
                        else 'Endpoint on destination mesh')
            title = (f'{name}, {rail.upper()}\n{count}\n{location}' if component_mode
                     else f'{name}, {rail.upper()} ({count})\n{location}')
            ax.set(title=title,
                   xlabel='X (um)', ylabel='Y (um)', aspect='equal',
                   xlim=(0, (layer['xgrid'] + 1) * layer['xpitch']),
                   ylim=(0, (layer['ygrid'] + 1) * layer['ypitch']))
            ax.grid(alpha=.2)
            if component_mode:
                ax.title.set_fontsize(10)
    fig.savefig(out / 'stack_tsv_layout.png', dpi=160)
    return fig


def plot_stack(p, fields, out, plot_max_axis, surface_max_axis):
    fig, axes = plt.subplots(len(p['layers']), 3, figsize=(16, 4.2 * len(p['layers'])),
                             squeeze=False, constrained_layout=True)
    for layer, data, axs in zip(p['layers'], fields, axes):
        for ax, field, title in zip(axs, data[:3], ('VDD drop', 'VSS rise', 'Total supply loss')):
            x, y, shown = display_grid(field, layer['xpitch'], layer['ypitch'], plot_max_axis)
            cp = ax.pcolormesh(x, y, shown * 1000, cmap='turbo', shading='flat',
                               vmin=float(field.min() * 1000), vmax=float(field.max() * 1000))
            peak = extreme(field, layer['xpitch'], layer['ypitch'])
            ax.scatter(peak['x_um'], peak['y_um'], marker='x', c='black', s=40)
            ax.set(title=f"Layer {layer['id']}: {title}\nmax {field.max() * 1000:.4f} mV",
                   xlabel='X (um)', ylabel='Y (um)', aspect='equal')
            fig.colorbar(cp, ax=ax, label='mV', shrink=.8)
    fig.suptitle('Coupled multilayer DC IR | all nodes solved; block maxima for display only')
    fig.savefig(out / 'stack_ir_overview.png', dpi=160)
    # Layer total-loss surfaces retain the separately configured display limit.
    fig3 = plt.figure(figsize=(7 * len(fields), 5), constrained_layout=True)
    for index, (layer, data) in enumerate(zip(p['layers'], fields)):
        ax = fig3.add_subplot(1, len(fields), index + 1, projection='3d')
        xe, ye, shown = display_grid(data[2], layer['xpitch'], layer['ypitch'], surface_max_axis)
        xx, yy = np.meshgrid((xe[:-1] + xe[1:]) / 2, (ye[:-1] + ye[1:]) / 2)
        if min(shown.shape) >= 2:
            ax.plot_surface(xx, yy, shown * 1000, cmap='viridis', linewidth=0,
                            rcount=shown.shape[0], ccount=shown.shape[1])
        else:
            ax.scatter(xx.ravel(), yy.ravel(), shown.ravel() * 1000)
        ax.set(title=f"Layer {layer['id']}: total loss", xlabel='X (um)',
               ylabel='Y (um)', zlabel='Loss (mV)')
    fig3.savefig(out / 'stack_ir_surface.png', dpi=150)
    plot_vertical_layout(p, out)
    if p.get('component_data') is not None:
        plot_component_mapping(p, out)


def run(config_path, out, parallel=True, solver='auto', rtol=1e-10, maxiter=1000,
        amg_threshold=250000, plot_max_axis=240, surface_max_axis=50):
    if min(plot_max_axis, surface_max_axis) < 2:
        raise ValueError('Display limits must be >=2')
    start = perf_counter()
    p = read_stack_config(config_path)
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    results, timing = solve_stack(p, parallel, solver, rtol, maxiter, amg_threshold)
    vd, vs = results[0][0], results[1][0]
    sources = pd.DataFrame(results[0][1] + results[1][1])
    tsv_columns = ['component_id', 'component_type', 'tsv_id', 'rail', 'interface', 'id', 'lower_layer', 'upper_layer',
                   'lower_x_node', 'lower_y_node', 'upper_x_node', 'upper_y_node',
                   'R_ohm', 'current_A', 'current_mA', 'delta_V_upper_minus_lower']
    tsvs = pd.DataFrame(results[0][2] + results[1][2], columns=tsv_columns)
    checks = {rail: dict(result[3]) for rail, result in zip(('VDD', 'VSS'), results)}
    physical_rows = [row for check in checks.values()
                     for row in check.pop('physical_tsv_currents', [])]
    summary = {'version': VERSION, 'mode': 2, 'layer_count': len(p['layers']),
               'node_count_per_rail': p['node_count'], 'powerv_V': p['powerv'],
               'load_current_A': float(-p['load'].sum()), 'layers': [],
               'load_model': 'fixed current; power inputs converted at nominal powerv',
               'performance': timing, 'checks': checks,
               'plotting': {'method': 'block maximum for display only',
                            'max_2d_axis': plot_max_axis, 'max_surface_axis': surface_max_axis,
                            'full_resolution_csv': True, 'full_resolution_extrema': True,
                            'vertical_layout_points': ('one per component at destination center'
                                if p.get('component_data') is not None else 'one per legacy path'),
                            'vertical_layout_resistance': ('R/N equipotential reference only'
                                if p.get('component_data') is not None else 'path resistance')}}
    fields, frames = [], []
    actual_power = 0.
    for layer in p['layers']:
        m, n, first = layer['xgrid'], layer['ygrid'], layer['offset']
        sl = slice(first, first + m * n)
        u, w = vd[sl].reshape(n, m), vs[sl].reshape(n, m)
        total = u + w
        effective = p['powerv'] - total
        fields.append((u, w, total, effective))
        layer_power = float(np.sum(-layer['load'] * effective.ravel()))
        actual_power += layer_power
        info = {k: layer[k] for k in ('id', 'name', 'xgrid', 'ygrid', 'rh', 'rv',
                                      'xpitch', 'ypitch', 'currentmode', 'load_current_A',
                                      'nominal_load_power_W')}
        for key, field, maximize in (('max_vdd_drop', u, True), ('max_vss_rise', w, True),
                                     ('max_total_loss', total, True),
                                     ('min_effective_voltage', effective, False)):
            info[key] = extreme(field, layer['xpitch'], layer['ypitch'], maximize)
        info['actual_load_power_W'] = layer_power
        summary['layers'].append(info)
        x, y = np.meshgrid(np.arange(1, m + 1), np.arange(1, n + 1))
        frames.append(pd.DataFrame({'layer': layer['id'], 'x_node': x.ravel(), 'y_node': y.ravel(),
                                    'x_um': x.ravel() * layer['xpitch'],
                                    'y_um': y.ravel() * layer['ypitch'],
                                    'load_current_A': -layer['load'],
                                    'VDD_V': p['powerv'] - u.ravel(), 'VSS_V': w.ravel(),
                                    'VDD_drop_mV': u.ravel() * 1000,
                                    'VSS_rise_mV': w.ravel() * 1000,
                                    'total_loss_mV': total.ravel() * 1000,
                                    'effective_voltage_V': effective.ravel()}))
    loss = sum(check['resistor_dissipation_W'] for check in checks.values())
    supplied = p['powerv'] * checks['VDD']['source_current_magnitude_A']
    summary['power_balance'] = {'source_power_W': supplied, 'actual_load_power_W': actual_power,
                                'resistor_dissipation_W': loss,
                                'balance_error_W': supplied - actual_power - loss}
    if abs(supplied - actual_power - loss) > max(1e-8, abs(supplied) * 100 * rtol):
        raise RuntimeError('Power conservation check failed')
    summary['global_max_total_loss'] = max(
        ({'layer': l['id'], **l['max_total_loss']} for l in summary['layers']),
        key=lambda e: e['value'])
    summary['global_min_effective_voltage'] = min(
        ({'layer': l['id'], **l['min_effective_voltage']} for l in summary['layers']),
        key=lambda e: e['value'])
    summary['max_source_current_mA'] = {r: float(sources.loc[sources.rail == r, 'current_mA'].abs().max())
                                         for r in ('VDD', 'VSS')}
    summary['tsv_interfaces'] = []
    for link in p['links']:
        item = {'name': link['name'], 'lower': link['lower'], 'upper': link['upper']}
        for rail in ('vdd', 'vss'):
            values = tsvs[(tsvs['interface'] == link['name']) & (tsvs['rail'] == rail.upper())]
            item[rail.upper()] = {'count': len(values),
                                  'current_lower_to_upper_A': float(values.current_A.sum()),
                                  'max_abs_current_mA': float(values.current_mA.abs().max()) if len(values) else 0.}
        summary['tsv_interfaces'].append(item)
    # Preserve the user's 11.2 spec as a bottom-layer historical metric only.
    bottom_total = fields[0][2]
    anchors = p['sources']['vdd'] + p['sources']['vss']
    irv = max(bottom_total[s['y'] - 1, s['x'] - 1] for s in anchors) * 1000
    irh = float(bottom_total.max() * 1000 - irv)
    denominator = float(irv + .5 * irh)
    summary['original_spec_metrics'] = {'scope': 'layer 0 only, historical heuristic', 'spec': 11.2,
                                        'IRv_mV': float(irv), 'IRh_mV': irh,
                                        'IRv_plus_0p5_IRh_mV': denominator,
                                        'spec_result_A_per_mm2': 11.2 / denominator if denominator > 0 else None}
    export = perf_counter()
    pd.concat(frames, ignore_index=True).to_csv(out / 'node_results.csv', index=False, encoding='utf-8-sig')
    sources.to_csv(out / 'bump_current.csv', index=False, encoding='utf-8-sig')
    tsvs.to_csv(out / 'tsv_current.csv', index=False, encoding='utf-8-sig')
    if p.get('component_data') is not None:
        from tsv_components import write_mapping
        write_mapping(p['component_data'], out)
        physical = pd.DataFrame(physical_rows)
        physical.to_csv(out / 'physical_tsv_current.csv', index=False, encoding='utf-8-sig')
        components = []
        for geometry in p['component_data']['summaries']:
            values = physical[physical.component_id == geometry['component_id']]
            components.append({**geometry, 'current_A': float(values.current_A.sum()),
                               'max_abs_tsv_current_mA': float(values.current_mA.abs().max())})
        pd.DataFrame(components).to_csv(out / 'component_current.csv', index=False, encoding='utf-8-sig')
        summary['components'] = components
        summary['component_warnings'] = p['component_data']['warnings']
        summary['vertical_model'] = 'one resistor per physical TSV; nearest mesh node per endpoint'
    timing['csv_export_s'] = perf_counter() - export
    plot = perf_counter()
    plot_stack(p, fields, out, plot_max_axis, surface_max_axis)
    timing['plot_and_save_s'] = perf_counter() - plot
    timing['total_run_s_before_show'] = perf_counter() - start
    lines = [f"Coupled layers: {len(p['layers'])}; nodes per rail: {p['node_count']}",
             f"Total load: {summary['load_current_A']:.9f} A; source: {p['powerv']} V"]
    for layer in summary['layers']:
        lines.append(f"Layer {layer['id']}: load {layer['load_current_A']:.6f} A; "
                     f"max loss {layer['max_total_loss']['value'] * 1000:.6f} mV; "
                     f"min effective V {layer['min_effective_voltage']['value']:.9f} V")
    for rail in ('VDD', 'VSS'):
        lines.append(f"{rail} layer current balance errors (A): "
                     f"{checks[rail]['layer_current_balance_error_A']}")
    lines.extend((f"Power balance error: {summary['power_balance']['balance_error_W']:.3e} W",
                  f"Solver: {timing['solver_used']}; parallel VDD/VSS: {parallel}",
                  f"Numeric wall time: {timing['numeric_wall_s']:.6f} s"))
    if p.get('component_data') is not None:
        lines.append(f"Components: {len(summary['components'])}; physical TSVs: {len(physical_rows)}")
        lines.extend('WARNING: ' + w for w in summary['component_warnings'])
    text = '\n'.join(lines) + '\n'
    print(text, end='')
    (out / 'run_summary.txt').write_text(text, encoding='utf-8')
    (out / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    return summary


if __name__ == '__main__':
    from mna_ir_dual import main
    main()
